﻿using System.Collections;
using System.Data;
using Dapper;
using Microsoft.Data.SqlClient;


namespace Utilities.DatabaseUtility
{
    public class DbSql
    {
        private readonly string        _connectionString;
        public           int           Timeout   = 60;

        public DbSql(string sqlConnection)
        {
            _connectionString = sqlConnection;
        }

        public DbSql(string serverName, string database)
        {
            var builder = new SqlConnectionStringBuilder
            {
                DataSource             = serverName,
                InitialCatalog         = database,
                CommandTimeout         = Timeout,
                IntegratedSecurity     = true,
                TrustServerCertificate = true
            };

            _connectionString = builder.ConnectionString;
        }

        public DbSql(string serverName, string database, string userName, string password)
        {
            
            var builder = new SqlConnectionStringBuilder()
            {
                DataSource             = serverName,
                InitialCatalog         = database,
                CommandTimeout         = Timeout,
                UserID                 = userName,
                Password               = password,
                Encrypt = false
            };
            _connectionString = builder.ConnectionString;
        }
        
        private DataSet GetRecords(string query)
        {
            using var connection = new SqlConnection(_connectionString);
            connection.Open();
            SqlDataAdapter adapter = new SqlDataAdapter(query, connection);

            DataSet results = new DataSet();
            adapter.Fill(results);

            return results;
        }


        public DataTable GetRecordsIntoDataTable(string query)
        {
            DataTable dbResults;

            try
            {
                dbResults = GetRecords(query).Tables[0];
            }
            catch (SqlException e)
            {
                Console.WriteLine($"Unable to get records from database!\r\n{e.ToString()}");
                throw;
            }
            return dbResults;
        }

        
        public IEnumerable<T> GetRecordsIntoObject<T>(string query)
        {
            using IDbConnection connection = new SqlConnection(_connectionString);
            return connection.Query<T>(query, commandTimeout: Timeout);
        }

        public T GetRecordIntoObject<T>(string query)
        {
            using IDbConnection connection = new SqlConnection(_connectionString);
            return connection.QuerySingleOrDefault<T>(query);
        }
    }
}
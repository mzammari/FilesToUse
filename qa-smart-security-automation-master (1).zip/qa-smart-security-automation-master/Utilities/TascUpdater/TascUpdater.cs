﻿using Newtonsoft.Json;
using System.Text;
using System;
using System.ComponentModel.Design;
using System.Resources;

namespace Utilities.TascUpdater;

public class TascUpdater
{
    private readonly string _baseUrl;
    private const    string PostMetricResource = "/api/Metrics/PostAutomationLog";

    public TascUpdater(string baseUrl)
    {
        _baseUrl = baseUrl;
    }

    public string SendTestMetricsResult(int applicationId, string testName, string executedBy, int timeSaved)
    {
        //Create Object to Send
        var metric = new TascMetric(applicationId: applicationId, automationName: testName, executedBy: executedBy,
            savingsSeconds: timeSaved);

        JsonSerializerSettings jsonNullSetting = new()
            { NullValueHandling = NullValueHandling.Ignore };

        using var client  = new HttpClient();
        var       payload = JsonConvert.SerializeObject(metric, jsonNullSetting);
        string    result;

        try
        {
            var response = client.PostAsync($"{_baseUrl}{PostMetricResource}",
                new StringContent(payload, Encoding.UTF8, "application/json")).Result;

            result = !response.StatusCode.ToString().Equals("OK")
                ? $"Unable to upload TASC metrics!\r\nResponse: {(int)response.StatusCode} - {response.StatusCode}\r\nBody: {response.Content.ReadAsStringAsync().Result}"
                : "Uploaded TASC Metrics.";
        }
        catch (Exception e)
        {
            result = $"Unable to upload TASC metrics!\r\nError: {e}";
        }

        return result;
    }
}

public class TascMetric
{
    public TascMetric()
    {
    }

    public TascMetric(int applicationId, string automationName, string executedBy, int savingsSeconds)
    {
        ApplicationId  = applicationId;
        AutomationName = automationName;
        ExecutedBy     = executedBy;
        SavingsSeconds = savingsSeconds;
    }

    public int    ApplicationId  { get; set; }
    public string AutomationName { get; set; }
    public int    SavingsSeconds { get; set; }
    public string ExecutedBy     { get; set; }
}
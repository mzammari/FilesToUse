﻿using Utilities.ObjectExtensions;

namespace Utilities.Generators;

public static class StringGenerator
{
    private static readonly Random Random = new();

    /// <summary>
    /// Generates a random alpha characters string based on length.
    /// </summary>
    /// <param name="length">Length of string to return</param>
    /// <returns></returns>
    public static string RandomAlphaString(int length) => RandomString(length, "ABCDEFGHIJKLMNOPQRSTUVWXYZ");

    /// <summary>
    /// Generates a random number characters string based on length.
    /// </summary>
    /// <param name="length">Length of string to return</param>
    /// <returns></returns>
    public static string RandomNumberString(int length) => RandomString(length, "0123456789");

    /// <summary>
    /// Generates a random characters based user defined string and length.
    /// </summary>
    /// <param name="length"></param>
    /// <param name="baseCharacters"></param>
    /// <returns></returns>
    public static string RandomUserDefinedString(int length, string baseCharacters) =>
        RandomString(length, baseCharacters);

    /// <summary>
    /// Generates random characters strings based on length and characters provided
    /// </summary>
    /// <param name="length">Length of string to return</param>
    /// <param name="chars">Base characters for use in random generation</param>
    /// <returns></returns>
    private static string RandomString(int length, string chars)
    {
        return new string(Enumerable.Repeat(chars, length)
            .Select(s => s[Random.Next(s.Length)]).ToArray());
    }

    /// <summary>
    /// Returns a random trooper type.
    /// </summary>
    /// <returns></returns>
    public static string RandomStormTrooper()
    {
        var troopers = new List<string>(){ "Stormtrooper", "ShockTrooper", "ShadowTroopers", "DeathTroopers", "Snowtroopers", "DarkTroopers", "PurgeTroopers", "RangeTroopers", "Jumptroopers", "Flametroopers", "HeavyTroopers", "SithTroopers" };

        return troopers.PickRandom();
    }
}
﻿namespace Utilities.ObjectExtensions;

public static class LongExtensions
{
    /// <summary>
    /// 
    /// </summary>
    /// <param name="value"></param>
    /// <param name="toLocal">Boolean value to determine to return date time as local time or UTC time. Default is True(local time)</param>
    /// <returns></returns>
    public static DateTime ConvertToDateTime(this long value,bool toLocal = true)
    {
        var start = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
        return toLocal ? start.AddMilliseconds(value).ToLocalTime() : start.AddMilliseconds(value);
    }
}
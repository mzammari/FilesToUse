﻿using System.Text.RegularExpressions;

namespace Utilities.ObjectExtensions
{
    public static class StringExtensions
    {

        public static TOutput Or<TInput, TOutput>(this TInput obj, Func<TInput, TOutput> transformation, TOutput orElse)
        {
            return obj == null ? orElse : transformation(obj);
        }

        public static TOutput OrDefault<TInput, TOutput>(this TInput obj, Func<TInput, TOutput> transformation)
        {
            return obj.Or(transformation, default);
        }

        /// <summary>
        /// Returns the value of orElse if the implicit parameter is null. If the implicit parameter is not null, then this will return the object's ToString() value.
        /// </summary>
        /// <param name="me">The implicit object to inspect</param>
        /// <param name="orElse">The thing to return if me is null</param>
        /// <returns>The thing</returns>
        public static string? ToStringOr(this object? me, string? orElse)
        {
            return me.Or(x => x.ToString().Trim(), orElse);
        }

        /// <summary>
        /// Returns the value of orNull if the implicit parameter is null. If the implicit parameter is not null, then this will return the object's ToString() value.
        /// </summary>
        /// <param name="me"></param>
        /// <returns></returns>
        public static string? ToStringOrNull(this object me)
        {
            return me.ToStringOr(null);
        }

        /// <summary>
        /// Returns the value of String or String.Empty if the implicit parameter is null. If the implicit parameter is not null, then this will return the object's ToString() value.
        /// </summary>
        /// <param name="me"></param>
        /// <returns></returns>
        public static string ToStringOrEmpty(this object? me)
        {
            return me.ToStringOr(string.Empty);
        }

        /// <summary>
        /// Checks to see if the object is null.
        /// </summary>
        /// <param name="me"></param>
        /// <returns></returns>
        public static bool IsNull(this object me)
        {
            return me == null;
        }

        /// <summary>
        /// Returns the value of String or String.Empty if the implicit parameter is null. If the implicit parameter is not null, then this will return the object's ToString() and remove all blank spaces, new line characters, dashes, underscore, and single quotes value.
        /// </summary>
        /// <param name="me"></param>
        /// <returns></returns>
        public static string? ToStringCleanOrEmpty(this object me)
        {
            return me.IsNull() ? string.Empty : me.ToString().Replace("\u200B", "")
                .Replace("  ", " ")
                .Replace(Environment.NewLine, " ")
                .Replace("–", "")
                .Replace("-", "")
                .Replace("’", "")
                .Replace("'", "")
                .Replace("&","")
                .Replace("/","")
                .ToStringOr(string.Empty);
        }

        /// <summary>
        /// Returns the sub-string value of the object between 2 characters provide by the ending character and starting character (Optional. Default beginning character).
        /// </summary>
        /// <param name="me"></param>
        /// <param name="endingChar"></param>
        /// <param name="startingChar"></param>
        /// <returns></returns>
        public static string SubStringChar(this object me, string endingChar, string? startingChar = null)
        {
            int startingIndex = startingChar.ToStringOrEmpty() != string.Empty
                ? me.ToString().IndexOf(startingChar) + startingChar.Length
                : 0;
            int length = me.ToString().LastIndexOf(endingChar) - startingIndex;
            return me.ToString().Substring(startingIndex, length);
        }

        /// <summary>
        /// This will pull the value that matches 
        /// </summary>
        /// <param name="me"></param>
        /// <param name="pattern"></param>
        /// <returns></returns>
        public static string? SubStringRegEx(this object me, string pattern)
        {
            MatchCollection coll = Regex.Matches(me.ToString(), pattern);
            string result = null;
            try
            {
                result = coll[0].Groups[0].Value;
            }
            catch (Exception)
            {
                Console.WriteLine($"Unable to find match for Input: '{me}' with Pattern: '{pattern}'!");
            }

            return result.ToStringOrEmpty();
        }

        /// <summary>
        /// Removes new line characters and replaces it with a space
        /// </summary>
        /// <param name="me"></param>
        /// <returns></returns>
        public static string RemoveNewLine(this object me)
        {
            return me.ToString().Replace(Environment.NewLine, " ");
        }

        /// <summary>
        /// Returns the string value of the object from the first character to n length.
        /// </summary>
        /// <param name="me"></param>
        /// <param name="length"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentOutOfRangeException"></exception>
        public static string Truncate(this object me, int length)
        {
            if (length < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(length), "Length must be >= 0");
            }

            if (me == null)
            {
                return null;
            }

            int maxLength = Math.Min(me.ToString().Length, length);
            return me.ToString().Substring(0, maxLength);
        }

        /// <summary>
        /// Returns the string value for the user defined date format. if the value is null then it will return a string.empty.
        /// </summary>
        /// <param name="me"></param>
        /// <param name="format"></param>
        /// <returns></returns>
        public static string ToDateStringOrEmpty(this object me, string format)
        {
            return me.ToStringOrEmpty() == string.Empty
              ? string.Empty
              : Convert.ToDateTime(me.ToString()).ToString(format);
        }

        /// <summary>
        /// Returns the string value for the user defined decimal format. if the value is null then it will return a string.empty.
        /// </summary>
        /// <param name="me"></param>
        /// <param name="format"></param>
        /// <returns></returns>
        public static string ToDecimalStringOrEmpty(this object me, string format)
        {
            return me.ToStringOrEmpty() == string.Empty
              ? string.Empty
              : Convert.ToDecimal(me.ToString()).ToString(format);
        }

        /// <summary>
        /// converts a object from string to an int if possible
        /// </summary>
        /// <param name="me"></param>
        /// <returns></returns>
        public static int ToInt(this object? me)
        {
            if (me.ToStringOrEmpty() == string.Empty)
                throw new ArgumentException("Parameter cannot be null!");
            try
            {
                return Convert.ToInt32(me.ToString());
            }
            catch (Exception)
            {
                throw new ArgumentException("Parameter is not an interger!", $"Parameter Value: {me}");
            }
        }

        /// <summary>
        /// Converts a object from a string to a double
        /// </summary>
        /// <param name="me"></param>
        /// <returns></returns>
        public static double ToDouble(this object me)
        {
            if (me.ToStringOrEmpty() == string.Empty)
                throw new ArgumentException("Parameter cannot be null!");
            try
            {
                return Convert.ToDouble(me.ToString());
            }
            catch (Exception)
            {
                throw new ArgumentException("Parameter is not an double!", $"Parameter Value: {me}");
            }
        }

        /// <summary>
        /// Converts a string to a datetime
        /// </summary>
        /// <param name="me"></param>
        /// <returns></returns>
        public static DateTime ToDateTime(this object me)
        {
            if (me.ToStringOrEmpty() == string.Empty)
            {
                var exp = new Exception();
                throw new ArgumentException("Parameter cannot be null!", exp);
            }

            try
            {
                return Convert.ToDateTime(me.ToString());
            }
            catch (Exception)
            {
                throw new ArgumentException("Parameter is not an Date Time!", $"Parameter Value: {me}");
            }
        }

        /// <summary>
        /// Converts a string value to a boolean.
        /// </summary>
        /// <param name="me"></param>
        /// <returns></returns>
        public static bool ToBool(this object me)
        {
            if (me.ToStringOrEmpty() == string.Empty)
                throw new ArgumentException("Parameter cannot be null!");

            try
            {
                return Convert.ToBoolean(me.ToStringOrEmpty());
            }
            catch (Exception)
            {
                throw new ArgumentException("Parameter is not an Boolean Type!", $"Parameter Value: {me}");
            }
        }
    }
}
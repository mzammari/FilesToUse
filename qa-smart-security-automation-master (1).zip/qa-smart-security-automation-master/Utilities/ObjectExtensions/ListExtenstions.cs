﻿using System.Collections.Concurrent;

namespace Utilities.ObjectExtensions;

public static class ListExtenstions
{

    /// <summary>
    /// Determines whether the collection is null or contains no elements.
    /// </summary>
    /// <typeparam name="T">The IEnumerable type.</typeparam>
    /// <param name="enumerable">The enumerable, which may be null or empty.</param>
    /// <returns>
    ///     <c>true</c> if the IEnumerable is null or empty; otherwise, <c>false</c>.
    /// </returns>
    public static bool IsNullOrEmpty<T>(this IEnumerable<T> enumerable)
    {
        if (enumerable == null)
        {
            return true;
        }

        /* If this is a list, use the Count property for efficiency.
         * The Count property is O(1) while IEnumerable.Count() is O(N). */
        var collection = enumerable as ICollection<T>;
        if (collection != null)
        {
            return collection.Count < 1;
        }

        return !enumerable.Any();
    }

    /// <summary>
    /// Returns a random row from a list of objects.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="me"></param>
    /// <returns></returns>
    public static T PickRandom<T>(this IEnumerable<T> me)
    {
        if (me == null)
            throw new ArgumentException("Parameter cannot be null", nameof(T));

        Random rnd  = new Random((int)DateTime.Now.Millisecond);
        var    temp = me.ToList();
        if (temp.IsNullOrEmpty())
            throw new SystemException($"Unable to Pick random object from list! Name of object: '{nameof(T)}' as it is empty!");
        return temp[rnd.Next(temp.Count)];
    }

    /// <summary>
    /// Returns a set number of random objects from a list of objects.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="me"></param>
    /// <param name="amount"></param>
    /// <returns></returns>
    public static List<T> PickRandomList<T>(this IEnumerable<T> me, int amount)
    {
        Random rnd    = new Random((int)DateTime.Now.Ticks);
        var    temp   = me.ToList();
        var    result = new List<T>();

        var minAmount = amount >= me.Count() ? me.Count() : amount;

        if (temp.IsNullOrEmpty())
            throw new SystemException("Unable to Pick random object from list!");

        for (int i = 0; i < minAmount; i++)
        {
            result.Add(temp[rnd.Next(temp.Count)]);
        }

        return result;
    }

    /// <summary>
    /// Adds multiple elements to a ConcurrentBag collection.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="this"></param>
    /// <param name="toAdd"></param>
    public static void AddRange<T>(this ConcurrentBag<T> @this, IEnumerable<T> toAdd)
    {
        foreach (var element in toAdd)
        {
            @this.Add(element);
        }
    }
}
﻿using OpenQA.Selenium;

namespace Utilities.ObjectExtensions
{
    public static class BrowserExtenstion
    {
        public static INetwork GetNetworkInterceptor(this IWebDriver driver, string userName, string password, string domain)
        {
            NetworkAuthenticationHandler handler = new NetworkAuthenticationHandler
            {
                UriMatcher = (Uri d) => d.AbsoluteUri.Contains(domain),
                Credentials = new PasswordCredentials(userName, password)
            };
            INetwork network = driver.Manage().Network;
            network.AddAuthenticationHandler(handler);

            return network;
        }
    }
}

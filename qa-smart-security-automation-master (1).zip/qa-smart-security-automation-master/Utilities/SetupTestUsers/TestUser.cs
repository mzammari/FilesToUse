﻿using System.Text.Json.Serialization;

namespace Utilities.SetupTestUsers;

public class SpanOfControl
{
    public string HierarchyType { get; set; }
    public string ObjectId      { get; set; }
    public string OrgName       { get; set; }
    public bool? IsDeleted { get; set; }
}

public abstract class VendorModel
{
    public int    Id   { get; set; }
    public string Name { get; set; }
}

public class TestUser
{
    public string              UserName        { get; set; }
    public string              Domain          { get; set; }
    public string              Email           { get; set; }
    public string              FirstName       { get; set; }
    public string              LastName        { get; set; }
    public string              Type            { get; set; }
    public string              ApplicationName { get; set; }
    public List<string>        RoleName        { get; set; }
    public List<SpanOfControl> SpanOfControls  { get; set; }
    public List<VendorModel>   Vendor          { get; set; }
    public string              Creds           { get; set; }
    public string              VproStatus      { get; set; }
    public DateTimeOffset      ByPassVPROEndDate { get; set; }
    public bool                IsDeactivated   { get; set; }
}

public class User
{
    [JsonPropertyName("id")]
    public string Id { get; set; }

    [JsonPropertyName("username")]
    public string Username { get; set; }

    [JsonPropertyName("firstName")]
    public string FirstName { get; set; }

    [JsonPropertyName("lastName")]
    public string LastName { get; set; }

    [JsonPropertyName("email")]
    public string Email { get; set; }

    [JsonPropertyName("type")]
    public string Type { get; set; }

    [JsonPropertyName("isDeactivated")]
    public bool IsDeactivated { get; set; }

    [JsonPropertyName("domain")]
    public string Domain { get; set; }

    [JsonPropertyName("vproStatus")]
    public string? VproStatus { get; set; }

    [JsonPropertyName("bypassVPROEndDate")]
    public DateTime? ByPassVPROEndDate { get; set; }

}
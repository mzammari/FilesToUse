﻿using Newtonsoft.Json.Linq;
using System.Net;
using System.Text;
using Newtonsoft.Json;
using Utilities.ObjectExtensions;
using mailinator_csharp_client.Models.Stats.Entities;



namespace Utilities.SetupTestUsers;

public class SmartSecurity
{
    private const string ApplicationResource = "/applications";
    private const string RolesResource       = "/roles";
    private const string ClaimResource       = "/claims";
    private const string UserResource        = "/Users";
    private const string AuthTokenResource   = "/token";

    private          string                        _authToken;
    private readonly string                        _baseUrl;
    private readonly NetworkCredential             _securityUser;
    private readonly IEnumerable<ApplicationRoles> _applicationList;
    
    public SmartSecurity(string baseUrl, string token)
    {
        _baseUrl      = baseUrl;
        _authToken = token;
        _applicationList = GetApplicationList();
        
    }

    /// <summary>
    /// Gets the authorization token for the security user.
    /// </summary>
    private void GetAuthToken(string securityUser, string credentials)
    {
        var httpClientHandler = new HttpClientHandler
        {
            Credentials = _securityUser
        };
        var uri = $"{_baseUrl}{AuthTokenResource}";

        using HttpClient client = new(httpClientHandler);

        try
        {
            var response = client.GetAsync(uri).Result;
            if (!response.StatusCode.Equals(HttpStatusCode.OK))
                throw new Exception(
                    $"Unable to get security auth token! Server responded with '{response.StatusCode}'");
            
            var body = response.Content.ReadAsStringAsync().Result;
            _authToken = JObject.Parse(body).GetValue("access_token").ToString();
        }
        catch (Exception e)
        {
            Console.WriteLine($"Unable to get security auth token!\r\nError: {e}");
            throw;
        }
    }

    /// <summary>
    /// Sends an API request to SMART - Security to retrieve user information.
    /// </summary>
    /// <param name="email"></param>
    /// <returns></returns>
    private User? GetUserInfo(string email)
    {
        var uri = $"{_baseUrl}{UserResource}?email={email}";

        var httpClientHandler = new HttpClientHandler();
        // Return `true` to allow certificates that are untrusted/invalid
        httpClientHandler.ServerCertificateCustomValidationCallback =
            HttpClientHandler.DangerousAcceptAnyServerCertificateValidator;

        using HttpClient client = new(httpClientHandler);
        client.DefaultRequestHeaders.Add("Authorization", $"Bearer {_authToken}");

        try
        {
            var response = client.GetAsync(uri).Result;
            if (!response.StatusCode.Equals(HttpStatusCode.OK))
                throw new Exception(
                    $"Unable to retrieve User Info for email: '{email}'! Server responded with '{response.StatusCode}'");
            var body = response.Content.ReadAsStringAsync().Result;
            var userList =
                JsonConvert.DeserializeObject<List<User>>(JObject.Parse(body).GetValue("userSearchResult").ToString());

            //check if any results returned. If not then return null.
            if (userList.IsNull() || !userList.Any()) return null;

            //check if more than one results returned. if so then throw exception.
            if (userList.Count > 1)
                throw new(
                    $"More than one User info returned for Email: '{email}'! Please Contact someone from SMART - Security!");

            return userList[0];
        }
        catch (Exception e)
        {
            Console.WriteLine($"Unable to retrieve User Info for email: '{email}'!\r\nError: {e}");
            throw;
        }
    }
    
    /// <summary>
    /// Will check a user if the user exists in SMART - Security.
    /// </summary>
    /// <param name="user"></param>
    public void CheckAndProvisionUser(TestUser user)
    {
        //check to see if user exists. if not then create it
        var testUser = GetUserInfo(user.Email);
        if (testUser.IsNull())
            testUser = CreateUser(user);
		
        ProvisionUser(user, testUser);
    }

    /// <summary>
    /// Will check multiple user if the user exists in SMART - Security.
    /// </summary>
    /// <param name="users"></param>
    public void CheckAndProvisionUsers(IEnumerable<TestUser> users)
    {
        foreach (var user in users)
        {
            Console.WriteLine($"Provisioning User: '{user.UserName}'");
            CheckAndProvisionUser(user);
        }
    }

    /// <summary>
    /// Create a user in SMART - Security via a POST Request.
    /// </summary>
    /// <param name="user"></param>
    /// <returns></returns>
    private User CreateUser(TestUser user)
    {
        var addRequest = new AddUserRequest()
        {
            UserName      = user.UserName,
            Domain        = user.Domain,
            Email         = user.Email,
            FirstName     = user.FirstName,
            LastName      = user.LastName,
            IsDeactivated = false,
            Type          = user.Type
        };

        var payload = JsonConvert.SerializeObject(addRequest);
        var uri     = $"{_baseUrl}{UserResource}";

        using HttpClient client = new();
        client.DefaultRequestHeaders.Add("Authorization", $"Bearer {_authToken}");

        try
        {
            var response = client.PostAsync(uri, new StringContent(payload, Encoding.UTF8, "application/json")).Result;
            if (!response.StatusCode.Equals(HttpStatusCode.OK))
                throw new Exception(
                    $"Unable to create User: '{user.Email}'! Server responded with '{response.StatusCode}'");

            return GetUserInfo(user.Email);
        }
        catch (Exception e)
        {
            Console.WriteLine($"Unable to create User: '{user.Email}'!\r\nError: {e}");
            throw;
        }
    }

    /// <summary>
    /// Provision a user with the roles, Span of Control, and/or Vendor Affiliation.
    /// </summary>
    /// <param name="user"></param>
    /// <param name="testUser"></param>
    private void ProvisionUser(TestUser user, User testUser)
    {
        //get application id and role ids
        var applicationId =
            _applicationList.FirstOrDefault(
                i => i.Name.Equals(user.ApplicationName, StringComparison.OrdinalIgnoreCase));

        if (applicationId.IsNull()) throw new($"Unable to find Application ID for '{user.ApplicationName}'! Please check with SMART - Security and or the Name is correct.");

        //get application roles
        var roleDictionary = GetRoleList(applicationId.Id).ToDictionary(i => i.Name, j => j);
        
        //translate the role name to the official role Id
        var assignedRoles = new List<string>();
        List<RoleDetails> rolesList= new List<RoleDetails>();
        var roleDetails = new RoleDetails();
        foreach (var role in user.RoleName)
        {
            if (!roleDictionary.TryGetValue(role, out var roleId))
                throw new Exception($"Unable to find Role '{role}' in SMART - Security! Please Check.");
            
            assignedRoles.Add(roleId.Id);
            roleDetails.Id = roleId.Id;
			roleDetails.Name = roleId.Name;
			roleDetails.IsDeleted = false;
        }
        rolesList.Add(roleDetails);
        
        //create request
        var request = new ProvisionUser()
        {
	        UserId = testUser.Id,
            ApplicationId = applicationId.Id,
            RoleIds = assignedRoles,
            Roles = rolesList,
			SpanOfControl = user.SpanOfControls,
	        IsDeactivated = false
        };

        if (!user.Vendor.IsNull()) request.VendorAffiliation = user.Vendor;

        //POST request to SMART - Security.
        PostUserProvision(request, user);
    }

    /// <summary>
    /// Retrieves applications list from SMART - Security
    /// </summary>
    /// <param name="Application"></param>
    /// <returns></returns>
    private IEnumerable<ApplicationRoles> GetApplicationList()
    {
        var              uri    = $"{_baseUrl}{ApplicationResource}";
		using HttpClient client = new();
        client.DefaultRequestHeaders.Add("Authorization", $"Bearer {_authToken}");

        try
        {
            HttpResponseMessage response;
            var                counter    = 0;
            var                maxCounter = 5;
            
            do
            {
                response = client.GetAsync(uri).Result;
                if (response.StatusCode.Equals(HttpStatusCode.OK))
                    break;

                client.DefaultRequestHeaders.Remove("Authorization");
                //GetAuthToken();
                client.DefaultRequestHeaders.Add("Authorization", $"Bearer {_authToken}");

                counter++;
            } while (counter < maxCounter);
           
            if (!response.StatusCode.Equals(HttpStatusCode.OK))
                throw new Exception(
                    $"Unable to retrieve Application list from SMART - Security! Server responded with '{response.StatusCode}' - Uri: {uri}");

            var body            = response.Content.ReadAsStringAsync().Result;
            var applicationList = JsonConvert.DeserializeObject<List<ApplicationRoles>>(body);

            if (applicationList.IsNull())
                throw new Exception(
                    $"Unable to get applications list in SMART - Security! - Uri: {uri}");
            return applicationList;
        }
        catch (Exception e)
        {
            Console.WriteLine(
                $"Unable to get applications list in SMART - Security!\r\nError: {e}");
            throw;
        }
    }

    /// <summary>
    /// Get Roles from SMART - Security for a specified application ID
    /// </summary>
    /// <param name="applicationId"></param>
    /// <returns></returns>
    private IEnumerable<ApplicationRoles> GetRoleList(string applicationId)
    {
        var              uri    = $"{_baseUrl}{ApplicationResource}/{applicationId}{RolesResource}";
        using HttpClient client = new();
        client.DefaultRequestHeaders.Add("Authorization", $"Bearer {_authToken}");

        try
        {
            var response = client.GetAsync(uri).Result;
            if (!response.StatusCode.Equals(HttpStatusCode.OK))
                throw new Exception(
                    $"Unable to retrieve Application role list from SMART - Security for Application ID: {applicationId}! Server responded with '{response.StatusCode}'");

            var body            = response.Content.ReadAsStringAsync().Result;
            var applicationList = JsonConvert.DeserializeObject<List<ApplicationRoles>>(body);

            if (applicationList.IsNull())
                throw new Exception(
                    $"Unable to retrieve Application role list from SMART - Security for Application ID: {applicationId}!");
            return applicationList;
        }
        catch (Exception e)
        {
            Console.WriteLine(
                $"Unable to retrieve Application role list from SMART - Security for Application ID: {applicationId}!\r\nError: {e}");
            throw;
        }
    }

    /// <summary>
    /// POST the user request to SMART - Security
    /// </summary>
    /// <param name="userRequest"></param>
    /// <param name="user"></param>
    private void PostUserProvision(ProvisionUser userRequest, TestUser user)
    {
        var payload = JsonConvert.SerializeObject(userRequest);
        var uri     = $"{_baseUrl}{UserResource}{ClaimResource}";

        using HttpClient client = new();
        client.DefaultRequestHeaders.Add("Authorization", $"Bearer {_authToken}");

        try
        {
            var response = client.PostAsync(uri, new StringContent(payload, Encoding.UTF8, "application/json")).Result;
            if (!response.StatusCode.Equals(HttpStatusCode.OK))
                throw new Exception(
                    $"Unable to Provision User: '{user.Email}'! Server responded with '{response.StatusCode}'");

        }
        catch (Exception e)
        {
            Console.WriteLine($"Unable to create User: '{user.Email}'!\r\nError: {e}");
            throw;
        }
    }
}
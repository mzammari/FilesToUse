﻿using System.Text.Json.Serialization;

namespace Utilities.SetupTestUsers;

public class ProvisionUser
{
    [JsonPropertyName("userId")]
    public string? UserId { get; set; }

    [JsonPropertyName("applicationId")]
    public string? ApplicationId { get; set; }

    [JsonPropertyName("isDeactivated")]
    public bool? IsDeactivated { get; set; }

    [JsonPropertyName("roleIds")]
    public List<string?> RoleIds { get; set; } 

    [JsonPropertyName("spanOfControl")]
    public List<SpanOfControl> SpanOfControl { get; set; }

    [JsonPropertyName("vendorAffiliation")]
    public List<VendorModel> VendorAffiliation { get; set; }

    [JsonPropertyName("vproStatus")]
    public string? VproStatus { get; set; }

    [JsonPropertyName("bypassVPROEndDate")]
    public DateTimeOffset? ByPassVPROEndDate { get; set; }

    [JsonPropertyName("roles")]
    public List<RoleDetails>? Roles { get; set; }

    
    
}
public class RoleDetails
{
	public RoleDetails()
	{
	}

	[JsonPropertyName("id")]
	public string? Id { get; set; }

	[JsonPropertyName("name")]
	public string? Name { get; set; }

	[JsonPropertyName("userType")]
	public string? UserType { get; set; }

	[JsonPropertyName("isDeleted")]
	public bool? IsDeleted { get; set; }

}
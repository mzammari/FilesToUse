﻿using System.Text.Json.Serialization;

namespace Utilities.SetupTestUsers;

public class ApplicationRoles
{
    [JsonPropertyName("id")]
    public string Id { get; set; }

    [JsonPropertyName("name")]
    public string Name { get; set; }

    [JsonPropertyName("userType")]
    public object UserType { get; set; }
}
﻿namespace Utilities.Validation;

public class ValidationHelpers
{
  /// <summary>
  /// 
  /// </summary>
  /// <param name="exp"></param>
  /// <param name="act"></param>
  /// <param name="field"></param>
  /// <param name="overRideMessage"></param>
  /// <returns></returns>
  public static string AreEqual(string? exp, string? act, string field, string? overRideMessage = null)
  {
    var message = overRideMessage == null 
      ? "Expected: '{0}' Act: '{1}' for Field: '{2}' NOT equal!" 
      : "Expected: '{0}' Act: '{1}' for Field: '{2}' NOT equal " + overRideMessage;

    if(exp.Equals(act))
      Console.WriteLine($"\tExpected: '{exp}' Actual: '{act}' for Field: '{field}' are equal.");

    return !exp.Equals(act)
      ? string.Format(message,exp,act,field)
      : string.Empty;
  }
}
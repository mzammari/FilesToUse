﻿namespace Utilities.HttpUtility;

public enum RestMethod
{
  Get,
  Post,
  Patch,
  Put,
  Delete
}
﻿using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Timers;
using System.Web;
using Microsoft.IdentityModel.Tokens;
using Utilities.ObjectExtensions;

namespace Utilities.HttpUtility;

public class WebRequestCall
{
    #region Variables

    private string              _status;
    private string              _body;
    private TimeSpan            _timeTaken;
    public  WebProxy            Proxy = null;
    private HttpResponseMessage _response;
    private WebException        _ex;
    private string              _token  = string.Empty;
    public  int                 TimeOut = 30;

    #endregion Variables

    /// <summary>
    /// Sends a basic HTTP request based on the enum method passed in.
    /// </summary>
    /// <param name="restMethod">Takes an ENUM of RestMethod</param>
    /// <param name="headers">A dictionary of Header to be added to the request</param>
    /// <param name="uri"></param>
    /// <param name="payload"></param>
    /// <param name="contentType"></param>
    private void SendRequest(string uri, RestMethod restMethod, Dictionary<string, string>? headers,
        string? payload, string contentType)
    {
        using var client = new HttpClient();

        //default timeout of 30 seconds.
        client.Timeout = TimeSpan.FromMilliseconds(1000 * TimeOut);

        //Adds custom headers if needed.
        if (!headers.IsNull())
        {
            foreach (var header in headers)
            {
                client.DefaultRequestHeaders.Add(header.Key, header.Value);
            }
        }

        var timer = new Stopwatch();
        try
        {
            switch (restMethod)
            {
                case RestMethod.Post:
                    timer.Start();
                    _response = client.PostAsync(uri, new StringContent(payload, Encoding.UTF8, contentType)).Result;
                    timer.Stop();
                    break;
                case RestMethod.Put:
                    timer.Start();
                    _response = client.PutAsync(uri, new StringContent(payload, Encoding.UTF8, contentType)).Result;
                    timer.Stop();
                    break;
                case RestMethod.Patch:
                    timer.Start();
                    _response = client.PatchAsync(uri, new StringContent(payload, Encoding.UTF8, contentType)).Result;
                    timer.Stop();
                    break;
                case RestMethod.Delete:
                    timer.Start();
                    _response = client.DeleteAsync(uri).Result;
                    timer.Stop();
                    break;
                case RestMethod.Get:
                    timer.Start();
                    _response = client.GetAsync(uri).Result;
                    timer.Stop();
                    break;
                default:
                    throw new ArgumentException(
                        $"Incorrect 'RestMethod' of '{restMethod}' was passed to SendApiRequest!");
            }

            _timeTaken = timer.Elapsed;
            _body = _response.Content.ReadAsStringAsync().Result;
            _status = $"({(int)_response.StatusCode}) {_response.StatusCode}";
        }
        catch (WebException e)
        {
            _ex = e;
        }
    }

    /// <summary>
    /// Sends an HTTP request using the HttpClient Library.
    /// </summary>
    /// <param name="uri"></param>
    /// <param name="restMethod">An ENUM of RestMethod.</param>
    /// <param name="headers"></param>
    /// <param name="payload"></param>
    /// <param name="contentType"></param>
    /// <returns>Returns an object of HttpResponse</returns>
    public HttpResponse SendApiRequest(string uri, RestMethod restMethod, Dictionary<string, string>? headers = null,
        string? payload = null, string contentType = "application/json")
    {
        SendRequest(uri, restMethod, headers, payload, contentType);
        return new HttpResponse(_status, _body, _timeTaken, DateTime.Now);
    }

    /// <summary>
    /// Sends a request to get the security token.
    /// </summary>
    /// <param name="uri"></param>
    /// <param name="creds"></param>
    /// <returns></returns>
    public HttpResponse GetApiToken(string uri, NetworkCredential? creds = null)
    {
        var httpClientHandler = new HttpClientHandler
        {
            Credentials = creds ?? CredentialCache.DefaultNetworkCredentials
        };
        var timer = new Stopwatch();
        using var client = new HttpClient(httpClientHandler);
        try
        {
            timer.Start();
            _response = client.GetAsync(uri).Result;
            timer.Stop();
            _timeTaken = timer.Elapsed;
            _body      = _response.Content.ReadAsStringAsync().Result;
            _status    = $"({(int)_response.StatusCode}) {_response.StatusCode}";

            return new HttpResponse(_status, _body, _timeTaken, DateTime.Now);
        }
        catch (HttpRequestException he)
        {
            Console.WriteLine(he);
            throw;
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    public HttpResponse GetApiToken(string uri, string clientId, string? clientSecret, string? scope = null, NetworkCredential? creds = null)
    {

        var httpClientHandler = new HttpClientHandler
        {
            Credentials = creds ?? CredentialCache.DefaultNetworkCredentials
        };

        var form = new Dictionary<string, string?>()
        {
            {"grant_type","client_credentials"},
            {"client_id",clientId},
            {"client_secret",clientSecret}
        };

        if(!scope.IsNull()) form.Add("scope",scope);

        var timer = new Stopwatch();
        using var client = new HttpClient(httpClientHandler);
        try
        {
            timer.Start();
            _response = client.PostAsync(uri, new FormUrlEncodedContent(form)).Result;
            timer.Stop();
            _timeTaken = timer.Elapsed;
            _body = _response.Content.ReadAsStringAsync().Result;
            _status = $"({(int)_response.StatusCode}) {_response.StatusCode}";

            return new HttpResponse(_status, _body, _timeTaken, DateTime.Now);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }
}
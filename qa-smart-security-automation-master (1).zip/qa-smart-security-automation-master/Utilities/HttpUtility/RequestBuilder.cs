﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilities.ObjectExtensions;
using Microsoft.AspNetCore.WebUtilities;

namespace Utilities.HttpUtility
{
  public static class RequestBuilder
  {
    public static string BuildRequestWithParameters(string baseUrl, Dictionary<string, string?> parameters = null!)
    {
      return parameters.IsNull() ? baseUrl : QueryHelpers.AddQueryString(baseUrl, parameters);
    }
  }
}

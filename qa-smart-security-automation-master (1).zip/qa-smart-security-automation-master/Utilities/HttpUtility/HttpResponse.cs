﻿namespace Utilities.HttpUtility;

public class HttpResponse
{
  public HttpResponse(string status, string response, TimeSpan timeTaken, DateTime sentTime)
  {
    Status       = status;
    Response     = response;
    ResponseTime = timeTaken;
    SentDateTime = sentTime;
  }

  public HttpResponse(string status, string response, TimeSpan timeTaken)
  {
    Status       = status;
    Response     = response;
    ResponseTime = timeTaken;
  }

  public HttpResponse(string status,string response)
  {
    Status   = status;
    Response = response;
  }

  public string   Status       { get; set; }
  public string   Response     { get; set; }
  public TimeSpan ResponseTime { get; set; }
  public DateTime SentDateTime { get; set; }
}
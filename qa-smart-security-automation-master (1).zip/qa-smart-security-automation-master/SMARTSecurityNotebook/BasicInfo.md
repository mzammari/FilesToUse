# SMART Security
## Purpose of SMART Security
The purpose for SMART Security was to decouple SMART Mod apps from PASS as this was a major pain point for supply chain users to give access to external users to their applications. SMART Security would allow LACs user to grant access to internal and external users by allowing them to assign roles for certain applications and Span of control.

SMART Security is broken up into two parts SMART Authorization and SMART Client Authorization. SMART Authorization primary function is to allow LACs to assign/unassign roles, span of control, and vendor affiliation. SMART Client Authorization primary function is to allow other SMART mod apps to request what a user is authorized for, span of control, and if the user is a vendor, their vendor affiliation.

## Environment Information
### SMART Authorization
| Environment | URL | Base API URL | Swagger Page |
|:---|:---|:---|:---|
| SBX | https://sbx-smart.healthtrustpg.com/Admin/SecurityManagement |  https://sbx-api-smartauthorization.healthtrustpg.com | https://sbx-api-smartauthorization.healthtrustpg.com/index.html |
| QASBX | https://qasbx-smart.healthtrustpg.com/Admin/SecurityManagement | https://qasbx-api-smartauthorization.healthtrustpg.com | https://qasbx-api-smartauthorization.healthtrustpg.com/index.html|
| QA | https://qa-smart.healthtrustpg.com/Admin/SecurityManagement | https://qa-api-smartauthorization.healthtrustpg.com | https://qa-api-smartauthorization.healthtrustpg.com/index.html |
| PROD | https://smart.healthtrustpg.com/Admin/SecurityManagement | https://api-smartauthorization.healthtrustpg.com | https://api-smartauthorization.healthtrustpg.com/index.html |

### SMART Client Authorization
| Environment | Base API URL | Swagger Page |
|:---|:---|:---|
| SBX | https://sbx-api-smartclientauthorization.healthtrustpg.com | https://sbx-api-smartclientauthorization.healthtrustpg.com/index.html |
| QASBX | https://qasbx-api-smartclientauthorization.healthtrustpg.com | https://qasbx-api-smartclientauthorization.healthtrustpg.com/index.html |
| QA | https://qa-api-smartclientauthorization.healthtrustpg.com | https://qa-api-smartclientauthorization.healthtrustpg.com/index.html |
| PROD | https://api-smartclientauthorization.healthtrustpg.com | https://api-smartclientauthorization.healthtrustpg.com/index.html |

## SMART Security Logic
* User Search: 
    * If the user(s) exist in SMART Security then return the user(s).
    * If the user(s) ***does not exist*** in SMART Security then search HCA Active Directory and return user(s).
    * If the user(s) ***does not exist*** in SMART Security and HCA Active Directory then search Lifepoint Active Directory and return user(s).
    * If the user(s) ***does not exist*** in SMART Security, HCA Active Directory, and Lifepoint Active Directory then return no results and show error message.
* External User Creation
    * Email is the unique idetifier for a user. When creating a user, if the email matches an existing user in SMART Security then show error message else create the user info.
* Assign Roles, Span of Control, and Vendor:
    * Internal User: A user must have no roles and no span of control to save or must have at minimum one role and one span of control to save.
    * External User: A user must have no roles, no span of control, and no vendor affiliation to save or must have at minimum one role, one span of control, and one vendor affilaition to save. 

## Source Reference Data
* Vendor information is currenly being sourced from Vendor Master and is being retrived via a REST API call.
* Span of Control data is currently being sourced from HOME and is being retrieved via a REST API call first from Redis Cache and then HOME API.

## Integration
SMART Authorization does integrate with a few applications. As mentioned above, vendor and facility information are sourced from Vendor Master and HOME. SMART Authorization also integrates with Supplier Portal. SMART Authorization will send a vendor users role, span of control, and vendor affilition.
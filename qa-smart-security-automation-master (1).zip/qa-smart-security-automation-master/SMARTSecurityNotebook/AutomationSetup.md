# Automation Setup
SMART Security automation is currently using Automation Core lite module. The gitHub repo is located here: https://github.com/Healthtrust/htti-labs-AutomationCoreModule-Automations

The repo location for SMART Security Automation is here: https://github.com/Healthtrust/qa-smart-security-automation

Nuget Package Sources need:
* HCA Nexus: https://repos.medcity.net/repository/httiqanexus/index.json
* Public Nuget: https://api.nuget.org/v3/index.json
from locust import FastHttpUser, task, events
import random

class ClientAuthUserRequests(FastHttpUser):
    #class variable
    host = "https://qa-api-smartclientauthorization.healthtrustpg.com"

    #Bearer Token for authorization >> current token is from Qa
    bearer_token = "eyJhbGciOiJSUzI1NiIsImtpZCI6InFhLXNpZ25pbmciLCJwaS5hdG0iOiJ4ZG5qIn0.eyJzY29wZSI6InNtYXJ0X3NlY3VyaXR5IiwiY2xpZW50X2lkIjoicWEtc21hcnQtc2VjIiwiaXNzIjoiaHR0cHM6Ly9xYS1zc28uaGVhbHRodHJ1c3RwZy5jb20iLCJleHAiOjE2ODczNjE5MDJ9.XRXdgDwxeh6_-ho3oOkzUw4XPisOcNO_R6p7v0X4PHCorH-IpYxRCvqz-PqrG300Demnd_mCtnY1qiyuUnOsoz1pCwgOAZsjw3sSDD5QdLCWJGPK13ggdbAKDmCIB1ixqJbOB_bh3uQnUe6yuvMVJf4XZip2xon_MAsBe236Rs7JFXQJnQC--LG0By19OAXgRE97JZ-B49hPwyzQuM-f-7uQx1MWHS9wwn3KS-6cHXOnu2ykYqcTBMfS7ne0zi_zmbOPBPL3U5R0rJLV0zuuTVEKRUSJXRPBI6WweGHVWQerZxmNahxduzyZsoWgVQoBCxDwqcxMSLvZrbwWX9o1VGhQqV4-ChOtAHaqgvWHVnwNODXmoxvkOFH5y1qMW0tf4d8SuvFXC16b-4UXbMR5pIYwXuHXqF2d9TSyOTtHgOGbM6HNeZLhativk3PPlAI4XDjSFN07eX4v4LjNArvEsKshy-NkIWmXz9rcwLdxceqtRFmXrps2w5FYmVP7oi4LFdi9n-WoIQaCpIccW6lyKYsrXUKU54BS9dhA6GiJkWv2Fmnql1AE15Aj3B2pPo-nMKYU2aeCpuzJLZFJ2G59120_0k3Gm8FmAPizh7Aa5Klp-RF0EgnKK4dwu-EG9cUKpo7w8EfnqfN0cpAQmfUgf7cTaV77TxWs4tTBIyL57hA"
    
    #class variables
    header_info = "Bearer " + bearer_token
    application_id = "9068249a-1cc4-4d8d-bb30-4a0fc9fc98cd"    
    users = ["CHA7515","CPU4459","DDI4483","CHA5016","MFI4255","EOJ7493","DPY0917"]
    
    #Initialize Random Generator
    random.seed(5)

    @task(1)
    def client_auth_roles_details(self):
                
        user_id = random.choice(self.users)      
        
        request = "/users/" + user_id +"/applications/" + self.application_id + "/soc"
        print("Request: '"+ request +"'")

        with self.client.get(request, headers = {"Authorization":self.header_info}, catch_response = True, name="/users/<userId>/applications/<ApplicationId>/soc") as response:
            print("Response(Application SOC): '" + str(response.status_code) + "'")
   
    def on_start(self):
        """ on_start is called when a Locust start before any task is scheduled """
        self.client.verify = False


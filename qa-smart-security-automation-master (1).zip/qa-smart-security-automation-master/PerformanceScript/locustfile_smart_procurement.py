from locust import FastHttpUser, task, events
import random

@events.test_start.add_listener
def on_test_start(environment, **kwargs):
    print("Getting Token")

class ClientAuthUserRequests(FastHttpUser):
    #class variable
    #https://qa-api-eprocurement.healthtrustpg.com
    #Bearer Token for authorization: Get token by logging into procurement and getting it from the session storage.
    bearer_token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1ZG9tYWluIjoiaGNhcWEiLCJ1bmFtZSI6IkhOSTc5NjQiLCJleHBpcnkiOiJcL0RhdGUoMTY4NjYwNDY3Mzg4MylcLyJ9.QIE2JiQQCO4O1DYhQaDiYW893d_Mjtz7MVu3WNQC2Gk"

    header_info = "Bearer " + bearer_token
    
    coids = ["34222","09391","34242","25745"]
    users = ["CHA7515","GHE7984","NFW2658","MFI8418","FZA9645"]
    
    #Initialize Random Generator
    random.seed(5)

    @task
    def get_user_edit_info(self):
              
        coid = random.choice(self.coids)        
        
        request = "/Configuration/GetUserEditInfo/?COID=" + coid
        print("Request: '"+ request +"'")

        with self.client.get(request, headers = {"Authorization":self.header_info}, catch_response = True, name="/Configuration/GetUserEditInfo/?COID") as response:
            print("Response(Get User Edit Info): '" + str(response.status_code) + "'")

    @task
    def get_user_access_report(self):
        coid = random.choice(self.coids)        
        
        request = "/Report/GetUserAccessReport/?coid=" + coid
        print("Request: '"+ request +"'")

        with self.client.get(request, headers = {"Authorization":self.header_info}, catch_response = True, name="/Report/GetUserAccessReport/?coid") as response:
            print("Response(Get User Access Report): '" + str(response.status_code) + "'")

    @task(5)
    def get_user_parts(self):
        userId = random.choice(self.users)
        request = "/Security/GetUserParts?domain=hcaqa&userName=" + userId
        print("Request: '"+ request +"'")

        with self.client.get(request, headers = {"Authorization":self.header_info}, catch_response = True, name="/Security/GetUserParts") as response:
            print("Response(Get User Parts): '" + str(response.status_code) + "'")  
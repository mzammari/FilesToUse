from locust import FastHttpUser, task, events
import random
import requests
from requests_ntlm import HttpNtlmAuth

class ClientAuthUserRequests(FastHttpUser):
    #class variable
    #Bearer Token for authorization >> current token is from Qa
    bearer_token = "eyJhbGciOiJSUzI1NiIsImtpZCI6InFhLXNpZ25pbmciLCJwaS5hdG0iOiJ4ZG5qIn0.eyJzY29wZSI6InNtYXJ0X3NlY3VyaXR5IiwiY2xpZW50X2lkIjoicWEtc21hcnQtc2VjIiwiaXNzIjoiaHR0cHM6Ly9xYS1zc28uaGVhbHRodHJ1c3RwZy5jb20iLCJleHAiOjE2ODcyMTUwMzh9.ELKCmSipG6OhSwjkHTtDmWrL_3v97HEqAmN_9h9ZG0yli_NgtMBz7FU6PlnhB12KexZob1DrsquPXb0oBBXR2kh1zb4_WJ5TPbuua5_eDljl5NaeM_0dZMo6QQX3UGmYoeGp13o1JmDV0HeESr2biFDiBo99O4hKI5dFnYp-9iThgiDWi0kWoyB_nKEQlAHDlxaQL6w5Foq6QPom3KOfSxMs5Vrf8X7papcg1H2t0_dPOBLIm6DCFi6Lb7bswxhaB4l5lRwlRgc_pJabLgQeg6ufoLs20zlAt-19w0pRKNX0F8S7H3j6ad_gRyT6co3Ua5BRzCX_IroygdWatyPKmU_v5J3A3W6ooZQpVc_3N-s5OepYRKMW6uImUzYtd6d8_s33AZX6rshUkixoUQpNlbyaFbYm2vGk5QqepwVlRaqmvcdNVzMGCiXJJWdFTk3TGnvdpdAPnXkngqmL6UQ6tNuMchGKHU5akmoZY8zhifmLdIEt-TZu3QtfMxOpq7rRHtMLiH0J9vCVWM0dd2KRTy_T5enaiNZvyoVTwtepz1bFZ_2mwPakRhuLHuYJBKPmJTRfXQIuzL0DGT9XIFxxlJBaS1ZU1UXFM5aB2Zh7GOqFDN8bVtSSwfjAJ7Ry_V6W-2pXWInZuPAqHKQhYsJFo07pD5Gobqpf53MMRygULWs"
    

    
    
    #class variables
    header_info = "Bearer " + bearer_token
    application_id = "9068249a-1cc4-4d8d-bb30-4a0fc9fc98cd"
    coids = ["34222","09391","34242","25745"]
    users = ["CHA7515","GHE7984","NFW2658","MFI8418","FZA9645"]
    roles_ids = ["593a0f8c-abc6-4a41-9ba6-ca330ccbc397","7666cba0-b84e-4e9b-9401-15b5a9c44942","ee8b2fb1-d7ed-4fa4-9f62-3f8f5154658e","90114ba0-aca8-43cc-b22a-2b7ffca8bbe9","accd2c46-1db8-452f-8bc8-dd55b11e626c","0b6edd25-4c04-4d31-b28c-20d3b141dac5"]

    #Initialize Random Generator
    random.seed(5)


    @task(1)
    def client_auth_roles_details(self):
                
        role_id = random.choice(self.roles_ids)      
        hierarchy_type = "5"        
        object_id = random.choice(self.coids)        
        
        request = "/roles/" + role_id +"/objectId/" + object_id + "/hierarchyType/" + hierarchy_type + "/applicationId/" + self.application_id + "/withDetails"
        print("Request: '"+ request +"'")

        with self.client.get(request, headers = {"Authorization":self.header_info}, catch_response = True, name="/roles/<roleID>/objectId/<objectID>/hierarchyType/<hierarchyType>/applicationId/<applicationId>/withDetails") as response:
            print("Response(Roles Details): '" + str(response.status_code) + "'")
    
    
    @task(7)
    def client_auth_users_roles(self):
        userId = random.choice(self.users)
        request = "/users/" + userId + "/applications/" + self.application_id + "/roles"
        print("Request: '"+ request +"'")
        
        with self.client.get(request, headers= {"Authorization":self.header_info}, catch_response = True, name = "/users/<userId>/applications/<application_id>/roles") as response:
            print("Response(User Application Roles): '" + str(response.status_code) + "'")

    @task(2)
    def client_auth_users_application(self):
        userId = random.choice(self.users)
        request = "/users/" + userId + "/applications/" + self.application_id
        print("Request: '"+ request +"'")
        
        with self.client.get(request, headers= {"Authorization":self.header_info}, catch_response = True, name = "/users/<userId>/applications/<application_id>") as response:
            print("Response(User Application): '" + str(response.status_code) + "'")

    def on_start(self):
        """ on_start is called when a Locust start before any task is scheduled """
        self.client.verify = False


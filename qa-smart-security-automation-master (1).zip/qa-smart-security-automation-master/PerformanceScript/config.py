import random

# Bearer Token for authorization
bearer_token = "eyJhbGciOiJSUzI1NiIsImtpZCI6InFhLXNpZ25pbmciLCJwaS5hdG0iOiJ4ZG5qIn0.eyJzY29wZSI6InNtYXJ0X3NlY3VyaXR5IiwiYXV0aG9yaXphdGlvbl9kZXRhaWxzIjpbXSwiY2xpZW50X2lkIjoicWEtc21hcnQtc2VjIiwiaXNzIjoiaHR0cHM6Ly9xYS1zc28uaGVhbHRodHJ1c3RwZy5jb20iLCJleHAiOjE3NDI1OTg4MjR9.Qxnn0JV8XfgmDsTSrbyGwc7qeRcwpOrIi7nnfp3AOv6bimscIt3OdbZMjlAeMmesWBaUrMjQaMTth0vnPhgg85s6lQwArdytFYZDWWVDdTGfckH9fwMlo98FoZk6qglnB-seywCh0s5ARuj51FnLazkzUfwnND68RuxUux2RCM00i1VBgzZd_0mVL8eptL2BUVhlEE2lRdMzE9u02TeiK9ZiKjLeZ7Reze_MCQkeyQvu3QCGpqVqR_ihkPQGxyPiSoxDKbLbutniC7AubNMwQds1rG52uuVDnFiWlveLFivGHUm7Gf-M0lCdsmVbKFL1s2gJimC2FtaMbIVduakH1MuOMWvDU4sV_5TOaR_v24x7w1oeYhR1ElKSPPAkW03BkUB6eP7fyxFnoMrWgbnYRzlTzzsbwXjCvvkF00FIj3D_Nyd8wBXH0V0dt_gPcmBwkJFAuOrro0MHrbQixaspZuaPKzJCF7UeYYBaK9V9V1UW2fnSYmTACBTnqhKdrtQcX1VATs0pZ4vp13BeMv4-iPj7o5no0N3sadqXvpbDXPUqyjfbiUupEBly1hJKrFLbF-5JubTjoyTVH4lk5O7pfZKiy8AfSLTFD80hY1sizf5kf4axrN5cemCq9TkCZOAE7dE7bSwxSadg7tODo8Lyx66OW2LZsZSGCXq-IaYYa7A"

# Class variables
header_info = "Bearer " + bearer_token
vpro_UserId = [
    '1450d1c8-e525-4c84-a5d3-37044882a65d', 'df90a7dd-49d3-42f7-a154-a9e8f359689e', 'e9a1b926-5e74-43df-8ff4-b1fe35a0cdae',
    '4afb6e29-b902-478c-a4b2-fa17709dba5f', 'ce6c2b45-dee6-45df-bbc0-5930b18723e6', 'fc779aec-6a97-4e58-aaa8-68bf9654d9c8',
    'c955cc1d-ec25-448d-ba82-3e20ca5901d6', '20bdabb5-bb7e-42f1-a14b-451389518b41', '28e1372d-248e-40df-acf8-12141d829e69',
    '4aa2c9d8-8f0e-460b-bbd4-90d5246fb8c6', '70c46f9f-3e39-4f64-9c7e-161ef750de64', '5b829d94-681d-4cfe-8c75-9b151e148889',
    'b84989b9-4ede-4dfd-a062-420b60b740c8', 'a190a22c-821e-4f25-aea9-2ad909c2808e', '9344c887-1564-484b-bb91-76cd33cf8a91',
    'c64dd06c-ffdb-4de9-83ca-608251cfd231', '7bfc3bd9-250a-4707-86c4-97cf4ad1254d'
]  # VPRO Users

vpro_emails = [
    'VproActive49.TestUser@mailinator.com', 'VproSuspended51.TestUser@mailinator.com', 'VproTermed44.TestUser@mailinator.com',
    'Abigail.james@stryker.zzz', 'Chuck.Norris@gmail.zzz', 'malikaht@gmail.zzz',
    'amrobb0103@gmail.zzz', 'adeahl@globusmedical.zzz', 'allen.wernon@smith-nephew.zzz',
    'april.caldwell@davita.ZZZ', 'craigkarpe+34@gmail.zzz', 'fperezct@gmail.zzz',
    '10jleone@innovative-health.zzz', 'Rebecca.McDaniel@centaurihs.zzz'
]  # VPRO Emails

procurementUsers = ['PEY5375', 'cdi8941', 'VNL8527', 'KAT5623', 'VKF2184', 'FMZ5569', 'cqa5278', 'cmu7228', 'JAJ2390']  # Procurement Users

roleId = [
    '593a0f8c-abc6-4a41-9ba6-ca330ccbc397', '7666cba0-b84e-4e9b-9401-15b5a9c44942', 'ee8b2fb1-d7ed-4fa4-9f62-3f8f5154658e',
    '90114ba0-aca8-43cc-b22a-2b7ffca8bbe9', 'accd2c46-1db8-452f-8bc8-dd55b11e626c', '0b6edd25-4c04-4d31-b28c-20d3b141dac5'
]  # Procurement Roles

objectId = '00001'
hierarchy = ['0', '1', '5']

applicationId = '9068249A-1CC4-4D8D-BB30-4A0FC9FC98CD'  # Procurement AppKey
procurementAppId = '9068249A-1CC4-4D8D-BB30-4A0FC9FC98CD'  # Procurement AppKey
procurementRoles = [
    '0B6EDD25-4C04-4D31-B28C-20D3B141DAC5', '593A0F8C-ABC6-4A41-9BA6-CA330CCBC397', '6F71CB67-27F8-4A89-8FCA-0D4882BE5EFC',
    '7666CBA0-B84E-4E9B-9401-15B5A9C44942', '90114BA0-ACA8-43CC-B22A-2B7FFCA8BBE9', 'ACCD2C46-1DB8-452F-8BC8-DD55B11E626C',
    'EE8B2FB1-D7ED-4FA4-9F62-3F8F5154658E'
]  # All procurement roles

procurementUsers = [
    'hej7854', 'MFI4255', 'czu6731', 'CQA8649', 'gpousered77200455de4', 'UserName-0bc01605-0390-4352-93bf-19dd1491660e', 'OZE4339',
    'UserName-8488f95c-b565-4265-ac7e-0150a8057637', 'NZU4004', 'MZU9549', 'HPO3306'
]  # Employee Users W/ procurement roles

vendors = [
    'gpouser22cfb8e1e37a4', '9a9d71e4-0a1d-49cb-9418-c61ff28a2ee2', 'VproSuspended51.TestUser@mailinator.com',
    '9390014c-02c1-4faf-92d5-ab66190e9fc1', '7154b479-ca80-419c-a7df-d7ad3983d681', '601884b9-2dca-42f5-8566-1bcd690b87bc',
    'a1f3ea06-f1f5-4353-9491-90b87d655977', '39572517-4363-4871-850d-88f9cc9e7db4', 'C946D355-7AF8-4732-9FC9-0879063911AA',
    '1f08460f-bad1-4c5d-b79b-fed1f7d0b5aa', '7d19172c-aaf0-4494-9bc1-9f37d65761ae', '158a004e-9c71-4395-a9e6-ec58aae93c58',
    '51838848-bc91-4dd0-a784-a0a5b3711382', '875567df-3b69-45ee-98c7-cc97f91a6d5b', '9341757c-fae9-4035-820b-bb723cce46a4',
    '5554ed06-0aee-4116-88f4-c90814cdadb2', '625d3d10-45c5-4caa-bbd8-9eb46dbab9f3', '0425c5fb-3d61-45fd-9f54-f0298e9a6cd6',
    'gpouserdf2c58b9d5394', 'add6045c-1e6e-47c7-9a92-aedd0e715eae', '6f046d3f-0a19-40f3-ba59-fd940e912aa1',
    '367b6387-0b6a-42cf-b9f0-e7b549b98a00', '29c8bd60-eb0a-44c8-8f47-6fe048db5112', 'e709e28a-9049-4d62-afe2-6874648498d6',
    '9ed948ba-d964-44e7-aac3-6ce940cf4d7f', 'a2b30cfb-e0c5-40a7-9e78-a1954a15053b', '939577b1-34e0-4132-adb2-61677c67bc60',
    'f3bb0910-06c9-4dbe-ae46-9d25feeb647f'
]  # Vendors

emails = [
    'Lester.Teston@HealthTrustPG.com', 'Wendell.Dartest@HealthTrustPG.com', 'Victoria.Testerman@hcahealthcare.com',
    'Jeana.Testerman@LPNT.net', 'SC0007.ClientAdmin@team509319.testinator.com', 'MarlonVenQaTest2@mailinator.com',
    'testuser5@mailinator.com', 'SC0005.ClientAdmin@team509319.testinator.com', 'qa0002@team509319.testinator.com',
    'redtesttrooper@mailinator.comm', 'qa0001@team509319.testinator.com', 'SC0004.VendorAdmin@team509319.testinator.com',
    'testuser3@mailinator.com', 'testuser-mobile@mailinator.com', 'QATest-User00001.Testing@mailinator.com',
    'QaTransferOrder.ApproverTestUser@mailinator.com', 'VproActive49.TestUser@mailinator.com', 'VproSuspended51.TestUser@mailinator.com'
]  # Emails Mix Emp & Ven types

# Initialize Random Generator
random.seed(2)
from locust import FastHttpUser, task, events
import random
import logging

class SmartAuthRequests(FastHttpUser):
    #class variable
    # UP:   docker-compose -f locust-compose-smart-auth-v1.yml up -d --scale worker=6
    # DOWN: docker-compose -f locust-compose-smart-auth-v1.yml down
    # Link to give it: https://qa-api-smartauthorization.healthtrustpg.com
    #Bearer Token for authorization >> current token is from Qa: {{sm-security}}/token 
    bearer_token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6IkhDQVFBXFxjbXU3MjI4IiwibmJmIjoxNzMzODU5NjU4LCJleHAiOjE3MzM4NjAyNTgsImlhdCI6MTczMzg1OTY1OH0.S_AcUEtbfTdTwiQGbHk50cB09KML2S6y8W5QsuXzUf4"
    
    #class variables
    header_info = "Bearer " + bearer_token
    # application_id = "9068249A-1CC4-4D8D-BB30-4A0FC9FC98CD" #Procurement AppKey in QA
    # userId = [ ' A0649650-4C9B-4929-AA47-D8003FDA6FBA ', ' 6CC33975-E546-4BBB-8C60-05BD01CC1828 ', ' 176D9D99-9E10-40C4-8703-FAAF1AFA2831 ', 
    #             ' 1C10D1E7-0825-47C7-8B47-D772CD7E4BC7 ', ' AA53357C-A1E2-4685-A132-92B76DE45423 ', ' 6DDB2BF5-4EA9-4693-B42B-075059460E76 ', 
    #             ' 3E81D19C-A4CB-4B66-8225-74A8034935F4 ', ' A1A9C320-DF1E-4E60-B1F7-BC37930D9400 ', ' 280F7FD6-12ED-4649-929C-BD2AA89F72E8 ']
    # hierarchyType = "3"
    # orgObjectID = "00003"
    # parentId = "1"
    # orgId = "1"
    #VproVariables
    vpro_EmailId = ['fperezct@gmail.zzz', 'VproActive49.TestUser@mailinator.com', 'adeahl@globusmedical.zzz', 'allen.wernon@smith-nephew.zzz', 
                    'april.caldwell@davita.ZZZ',  'VproSuspended51.TestUser@mailinator.com',  'VproTermed44.TestUser@mailinator.com', 'malikaht@gmail.zzz', 
                    'amrobb0103@gmail.zzz', '10jleone@innovative-health.zzz', 'Rebecca.McDaniel@centaurihs.zzz',  'webmaster@iminshell.com', 
                    'coryburdickmedical@gmail.com', 'smart-vendor1@demo-supplier.com',  'admin990@iminshell.com', 'abby.leatherman@abbott.com', 
                    'test.vendor1@demo-supplier.com', 'sometestvendor@mailinator.com',  'vboUser@mailinator.com', 'immortan.joe@iminshell.com', 
                    'demo.demetri@iminshell.com', 'mad.max@iminshell.com', 'jon.rosemary@iminshell.com', 'greg.duffey@iminshell.com', 
                    'froyo.baggins@iminshell.com',  'newtest677@iminshell.com', 'test.jobs@iminshell.com',  'SMART.vendor1@demo-supplier.com', 
                    'Chuck.Norris@gmail.zzz', 'craigkarpe+34@gmail.zzz']
    
    #Initialize Random Generator
    random.seed(2)    
    
    #roles_ids = ["593a0f8c-abc6-4a41-9ba6-ca330ccbc397","7666cba0-b84e-4e9b-9401-15b5a9c44942","ee8b2fb1-d7ed-4fa4-9f62-3f8f5154658e","90114ba0-aca8-43cc-b22a-2b7ffca8bbe9","accd2c46-1db8-452f-8bc8-dd55b11e626c","0b6edd25-4c04-4d31-b28c-20d3b141dac5"]

    # @task(1)
    # def smart_auth_User_Application_Soc_details(self):
    #     userId = random.choice(self.userId)                
        
    #     request = "/users/" + userId + "/applications/" + self.application_id + "/soc"
    #     print("Request: '"+ request +"'")

    #     with self.client.get(request, headers = {"Authorization":self.header_info}, catch_response = True, name="/users/<userId>/applications/<appId>/soc") as response:
    #         print("Response(User SoC): '" + str(response.status_code) + "'")

    # @task(2)
    # def smart_auth_applications_details(self):
    #     request = "/applications"
    #     print("Request: '"+ request +"'")

    #     with self.client.get(request, headers = {"Authorization":self.header_info}, catch_response = True, name="/applications") as response:
    #         print("Response(Apps): '" + str(response.status_code) + "'")

    # @task(3)
    # def smart_auth_applications_roles_details(self):

    #     request = "/applications/" + self.application_id + "/roles"
    #     print("Request: '"+ request +"'")

    #     with self.client.get(request, headers = {"Authorization":self.header_info}, catch_response = True, name="/applications/<appId>/roles") as response:
    #         print("Response(App Roles): '" + str(response.status_code) + "'")

    # @task(4)
    # def smart_auth_audit_history_details(self):
    #     userId = random.choice(self.userId)                
        
    #     request = "/audit-history?userId="+ userId
    #     print("Request: '"+ request +"'")

    #     with self.client.get(request, headers = {"Authorization":self.header_info}, catch_response = True, name="/audit-history?userId<userId>") as response:
    #         print("Response(Audit Histor): '" + str(response.status_code) + "'")

    # @task(5)
    # def smart_auth_orgs_details(self):
    #     request = "/orgs"
    #     print("Request: '"+ request +"'")

    #     with self.client.get(request, headers = {"Authorization":self.header_info}, catch_response = True, name="/orgs") as response:
    #         print("Response(Orgs): '" + str(response.status_code) + "'")

    # @task(6)
    # def smart_auth_orgs_hierarchy_details(self):
    #     request = "/orgs/" + self.hierarchyType + "/" + self.orgObjectID
    #     print("Request: '"+ request +"'")

    #     with self.client.get(request, headers = {"Authorization":self.header_info}, catch_response = True, name="/orgs/<hierarchyType>/<orgObjectId>") as response:
    #         print("Response(Orgs): '" + str(response.status_code) + "'")

    # @task(7) 
    # def smart_auth_org_child_node_details(self):
    #     request = "/orgs/" + self.hierarchyType + "/" + self.orgObjectID
    #     print("Request: '"+ request +"'")

    #     with self.client.get(request, headers = {"Authorization":self.header_info}, catch_response = True, name="/orgs/<hierarchyType>/<orgObjectId>") as response:
    #         print("Response(Orgs): '" + str(response.status_code) + "'")
 
    #   Load test for Smart Security Auth API: /VPRO/VerifyVPROStatus : Link to host it: https://qa-api-smartauthorization.healthtrustpg.com
    @task(8)
    def smart_verify_vpro_status(self): 
        vproEmail = random.choice(self.vpro_EmailId)
        request = f"/VPRO/VerifyVPROStatus"
        payloadBody = { "email": ""+ vproEmail +""}
        # print("Request: '"+ request+"'")
        with self.client.post(request, headers = {"Authorization":self.header_info}, json = payloadBody ,catch_response = True,) as payloadResponse:
            print("API Response Status: " + str(payloadResponse.status_code))
            print("VproEmailId: " + vproEmail)
            print("Payload Resonse: " + payloadResponse.text)
            logging.info("VproEmailId: " + vproEmail)
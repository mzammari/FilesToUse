﻿using System.ComponentModel;

namespace SmartSecurityTestAutomation.Enums;

public enum UserType
{
    Employee = 1,
    External = 2,
    Vendor   = 3
}

public enum HomeHierarchyType
{
    Organization = 0,
    Company      = 1,
    Group        = 2,
    Division     = 3,
    Market       = 4,
    Facility     = 5
}

public enum SecurityUserType
{
    [Description("Security - Administrator")]
    SecurityAdmin = 0,
    [Description("Security - Client Administrator")]
    ClientAdmin = 1,
    [Description("Security - Vendor Administrator")]
    VendorAdmin = 2,
}

public enum AccessType
{
    [Description("Full")]
    Full = 0,
    [Description("Limited")]
    Limited
}
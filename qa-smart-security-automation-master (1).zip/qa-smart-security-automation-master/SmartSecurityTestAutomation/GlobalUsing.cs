﻿global using AutomationCoreLite.Reporting;
global using Xunit;

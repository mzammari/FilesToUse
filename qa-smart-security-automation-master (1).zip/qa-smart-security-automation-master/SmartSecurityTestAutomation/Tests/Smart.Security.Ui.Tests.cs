﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using SmartSecurityTestAutomation.Enums;
using SmartSecurityTestAutomation.Models;
using SmartSecurityTestAutomation.Page.Objects.Ping;
using SmartSecurityTestAutomation.Page.Objects.SearchPage;
using SmartSecurityTestAutomation.Page.Objects.SupplierPortal;
using SmartSecurityTestAutomation.Page.Objects.UserDetailPage;
using SmartSecurityTestAutomation.Services.SupplierPortal;
using SmartSecurityTestAutomation.Services.Users;
using SmartSecurityTestAutomation.Services.VPRO;
using Utilities.ObjectExtensions;
using WebUiAutomation;
using Xunit.Abstractions;
using AddUserRequest = SmartSecurityTestAutomation.Services.Users.AddUserRequest;


namespace SmartSecurityTestAutomation.Tests;

public class SmartSecurityUiTests : TestMaster
{
    public SmartSecurityUiTests(ITestOutputHelper output) : base(output)
    {
    }

    #region Notes
    /*
        - Need to add scenario for non-HCA user for security admin check.

    */
    #endregion Notes

    #region Tests

    /// <summary>
    /// A standard Smoke Test that will validate that the application is reachable, able to search for users, and validate user information.
    /// Manual Estimated Execution Time: 0:5:00
    /// </summary>
    [Fact(DisplayName = "SecuritySmokeTest")]
    [Trait("Category", "UI")]
    public void SmokeTest()
    {
		AdoTestCaseName = "SecuritySmokeTest";
        TimeSaved       = 180;
        var userDb = new UserRepository(GlobalTestVariables.Configuration!["SmartSecurity:DatabaseServer"]!,
            GlobalTestVariables.Configuration["SmartSecurity:DatabaseName"]!);
        var users = userDb.GetAllUsers().ToList();

        Steps.AddTestStep($"Navigate to the following URL: {Url}.",
            "User should be able to see SMART Security Landing Search Page.");

        NavigateToUrl(Url);

        var searchPage = new SearchPage(Browser);
        searchPage.CheckRedirectAndExpand();

        var sampleSearchUser = users.Where(i => i.Type.Equals("Employee", StringComparison.CurrentCultureIgnoreCase))
            .PickRandom();
		var searchParam = new UserSearch()
        {
            FirstName = sampleSearchUser!.FirstName.ToStringOrEmpty(),
            LastName  = sampleSearchUser.LastName.ToStringOrEmpty(),
        };

        searchPage.SearchUser(searchParam);

        var expectedUsers = searchParam.FirstName.ToStringOrEmpty() == string.Empty
            ? users.Where(i =>
                i.LastName.ToStringOrEmpty()
                    .Equals(sampleSearchUser.LastName, StringComparison.OrdinalIgnoreCase))
            : users.Where(i =>
                i.FirstName.ToStringOrEmpty()
                    .Equals(sampleSearchUser.FirstName, StringComparison.OrdinalIgnoreCase)
                && i.LastName.ToStringOrEmpty()
                    .Equals(sampleSearchUser.LastName, StringComparison.OrdinalIgnoreCase));

        searchPage.ValidateUserSearchResults(expectedUsers);

        var userId   = searchPage.ClickEditUser();
        var userInfo = users.FirstOrDefault(i => i.Username!.Equals(userId, StringComparison.OrdinalIgnoreCase));

        var userDetailPage = new UserDetailPage(Browser);
        userDetailPage.ValidateUserDetailInformation(userInfo!);
        userDetailPage.ValidateRoleApplicationDropDown();
        userDetailPage.AppSelection("SMART - Procurement"); //this feature only available in qasbx at the moment: 24 Sept
		userDetailPage.ValidateAndToggleGcnGroups();


    }

    [Fact(DisplayName = "SmokeTestVproFeatures")]
    public void SmokeTestVproFeatures()
    {
	    //RallyTestCaseId = "TC50289";
		AdoTestCaseName = "SmokeTestVproFeatures";
		TimeSaved = 400;
		//SmokeTestUserDetailVproOptions();
		SmokeTestAddVendorBladeNewVpro();
    }

    private void SmokeTestAddVendorBladeNewVpro()
    {
		/* Emails below do NOT exists in Security Db (qasbx && qa) as of 16 Aug DO NOT Add*/ 
		Dictionary<string, string> vproTestScenarios = new Dictionary<string, string>();
		vproTestScenarios.Add("Active", "Collin.mitchell@CROSSLINK1.zzz");      //49 active: VPRO Active
		vproTestScenarios.Add("InActive", "ERIC.CHU@STRYKER.ZZZ");  // 44 termed: VPRO Inactive
		vproTestScenarios.Add("Not Found", "Fred.FlinstoneAutomationTest@hbb.com"); // NotFound : VPRO Not Found

		//var (sampleSearchUser, testUser) = TestSetupForUser(UserType.Vendor, false);
		var securityUser = GetSecurityUser(SecurityUserType.SecurityAdmin).SecurityUser;

		Steps.AddTestStep($"Navigate to the following URL: {Url}.",
			"User should be able to see SMART Security Landing Search Page.");
		NavigateToUrl(Url, securityUser);
		var searchPage = new SearchPage(Browser);
		searchPage.CheckRedirectAndExpand();
		foreach (var vproUserRequest in vproTestScenarios)
		{
			string email = vproUserRequest.Value;
			string firstName = string.Empty;
			string lastName = string.Empty;

			var atIndex = email.IndexOf('@');
			if (atIndex > 0)
			{
				var localPart = email.Substring(0, atIndex);
				var dotIndex = localPart.IndexOf('.');
				if (dotIndex > 0)
				{
					firstName = localPart.Substring(0, dotIndex);
					lastName = localPart.Substring(dotIndex + 1);
				}
				else
				{
					// If no dot, treat the whole local part as first name, last name empty
					firstName = localPart;
					lastName = string.Empty;
				}
			}

			AddUserRequest newUser = new AddUserRequest()
			{
				FirstName = firstName,
				LastName = lastName,
				Email = email
			};

			Steps.AddTestStep($"Adding New Vendor VPRO User", $"Unique email validation on Check VPRO: {vproUserRequest.Value}");
			//Check VPRO Email Address on the Add Vendor User Page
			searchPage.CreateVendorUserButton.Click();
			searchPage.CreateFirstName.Type(newUser.FirstName);
			searchPage.CreateLastName.Type(newUser.LastName);
			searchPage.CreateEmail.Type(newUser.Email);
			searchPage.CheckVproStatus.Exists();
			Thread.Sleep(1000);
			
			Steps.AddTestStep($"Unique VPRO Email ID Check", "Unique email validation on Check VPRO: Sabastian.Fritzgerald@SomeCompany.com");
			//Provide duplicate value for VproEmailUserId field
			searchPage.VproUserEmailId.Element.Clear();
			searchPage.VproUserEmailId.Type("Sabastian.Fritzgerald@SomeCompany.com");  //Unique entry not in Db...do not add
			searchPage.CheckVproStatus.Click();
			Thread.Sleep(3000);
            searchPage.ModalContButton.Click();
			
            Steps.AddTestStep($"Unique VPRO Email ID Check", "Duplicate email validation ON Save: Rebecca.McDaniel@centaurihs.zzz");
			searchPage.VproUserEmailId.Element.Clear();
			searchPage.VproUserEmailId.Type("Rebecca.McDaniel@centaurihs.zzz");        //Duplicate user exists in Db...do not alter
			searchPage.SaveVendorButton.Click();
			Thread.Sleep(1000);
			
			searchPage.VproUserEmailId.Element.Clear();
			searchPage.VproUserEmailId.Type(newUser.Email);
			searchPage.CheckVproStatus.Click();
			Thread.Sleep(2000);

			searchPage.ValidateModalPupUp(vproUserRequest.Key);

			if (vproUserRequest.Key.Equals("Active"))
            { 
                searchPage.ModalSetNoExpirationButton.Click();
            }
            else
            {
                searchPage.ModalCancelButton.Click();
            }

	        searchPage.ValidateCreateVendorBlade();
            searchPage.CancelButton.ScrollIntoView();
			searchPage.CancelButton.Click();
            searchPage.ConfirmationYesButton.Click();
		}
    } 
     
	public void SmokeTestUserDetailVproOptions()
    {
	    List<string> testCases = new List<string>(){ "VPRO Active", "VPRO Inactive", "VPRO Not Found" };
        var securityUser = GetSecurityUser(SecurityUserType.SecurityAdmin).SecurityUser;
        var vproRepo = new VproRepository(GlobalTestVariables.Configuration["SmartSecurity:DatabaseServer"]!,
	        GlobalTestVariables.Configuration["SmartSecurity:DatabaseName"]!);
        
        var (sampleSearchUser, testUser) = vproRepo.GetAllVproUsers();

		Steps.AddTestStep($"Navigate to the following URL: {Url}.", "User should be able to see SMART Security Landing Search Page.");
		NavigateToUrl(Url, securityUser);
		var searchPage = new SearchPage(Browser);
		searchPage.CheckRedirectAndExpand();

		foreach (var testCase in testCases)
		{
			UserResponse vproSearchUser = new UserResponse();
			var vproUser = testUser.Where(i => i.VproStatus.Contains(testCase)).PickRandom(); 
            vproSearchUser.FirstName = vproUser.FirstName;
            vproSearchUser.LastName = vproUser.LastName;
            vproSearchUser.Username = vproUser.Username;

            UserResponse vproUsers2 = new UserResponse(); 


			searchPage.SearchSpecificUser(vproUser,sampleSearchUser);
			searchPage.ClickEditUser();
			var userDetailPage = new UserDetailPage(Browser);

			Steps.AddTestStep($"Validating User Details - VPRO Elements are present", "VPRO Not Found Check");
			userDetailPage.VproUserEmailId.Element.Clear();
			userDetailPage.VproUserEmailId.Type("Sabastian.Fritzgerald@SomeCompany.com");
			userDetailPage.CheckVproStatus.Click();
            userDetailPage.ConfirmationYesButton.Click();
			Thread.Sleep(2000);

			Steps.AddTestStep($"Validating User Details - Duplicate Check", "Duplicate Check");
			userDetailPage.VproUserEmailId.Element.Clear();
			userDetailPage.VproUserEmailId.Type("Rebecca.McDaniel@centaurihs.zzz");
			userDetailPage.CheckVproStatus.Click();
			Thread.Sleep(2000);
			//userDetailPage.ConfirmationYesButton.Click();

			userDetailPage.VproUserEmailId.Element.Clear();
			userDetailPage.VproUserEmailId.Type(vproUser.VPROUserEmailId);
			userDetailPage.CheckVproStatus.Click();
			Thread.Sleep(2000);

			userDetailPage.ConfirmationYesButton.Click();
			userDetailPage.ValidateUserDetailVpro();
            userDetailPage.ApplicationSelectDropDown.ScrollIntoView();
            userDetailPage.AppSelection("SMART - Procurement");
			Thread.Sleep(1000);

			//Facility Tab Access will be determined on VPRO status: Visible for Active & Inactive ONLY
			if (testCase == "Not Found")
			{
				//Check and see if Radio button set to True for Not Found and return the value displayed; failed otherwise
				var vproStat = userDetailPage.VproNotFoundRbStatus.Element.Displayed.ToBool() ? userDetailPage.VproNotFoundRbStatus.Element.Text.ToString() : "failed";
				HPGWarn.AreEqual("VPRO Not Found", vproStat, field: userDetailPage.VproNotFoundRbStatus.Identifier);
			}
            else //Users are Vpro Active or Vpro InActive
            {
	            if (!userDetailPage.VproFacilitiesTab.Exists())
				{
					HPGWarn.True(userDetailPage.VproFacilitiesTab.Exists(), false, "Vpro Facility Tab should be visible");
				}
				else
				{ 
					Steps.AddTestStep($"Facility tab is visible for User: " + vproSearchUser.Username.ToString(), "Facility tab is visible for User: " + vproSearchUser.Username.ToString());
                    userDetailPage.VproFacilitiesTab.Click();
					Thread.Sleep(2000); //put this timer in here because it happens so fast it fails to see the button when its present
					HPGWarn.True(userDetailPage.VproFacilitiesPanel.Exists(), field: "VPRO Facilities Panel");
					HPGWarn.True(userDetailPage.ReCheckFacilityAccessButton.Exists(), field: "Re-Check Facility Access"); 
					HPGWarn.True(userDetailPage.lblSocDate.Exists(), field: "Soc Since");
					HPGWarn.True(userDetailPage.lblVproSince.Exists(), field: "VPRO Since");
                    HPGWarn.True(userDetailPage.lblVproFacilitiesOutsideSoc.Exists(), field: "VPRO Facilities Outside of SoC");
					if (testCase == "Active")
						HPGWarn.True(userDetailPage.FacilityItem.Exists(), field: "Selected VPRO Facilities");
				} 
			} 
            userDetailPage.CancelButton.Click();
            Thread.Sleep(2000);
			searchPage.RefreshScreen();
			searchPage.CheckRedirectAndExpand(); 
		}// endFor
 }

	/// <summary>
	/// A test that will add User Role(s) and Span of Control for a User Employee Type.
	/// </summary>
	[Fact(DisplayName = "TestAddUserRoleSocToEmployeeType")]
    [Trait("Category", "UI")]
    public void TestAddUserRoleSocToEmployeeType()
    {
        AdoTestCaseName = "AddUserRoleSocToEmployeeType";
        TimeSaved       = 300;
        AddUserRoleSocVendorAffiliation(UserType.Employee, SecurityUserType.SecurityAdmin);
    }

    [Fact(DisplayName = "TestAddUserRoleSocVendorAffiliationToVendorType")]
    [Trait("Category", "UI")]
    public void TestAddUserRoleSocVendorAffiliationToVendorType()
    {
		//todo: Todo: need to drill down on the data. Hits another Db outside security
		RallyTestCaseId = "TC41885";
        AdoTestCaseName = "AddUserRoleSocVendorAffiliationToVendorType";
        TimeSaved       = 300;
        AddUserRoleSocVendorAffiliation(UserType.Vendor, SecurityUserType.SecurityAdmin);
    }
    
    private void AddUserRoleSocVendorAffiliation(Enum userType, Enum securityType)
    {
        var (sampleSearchUser, testUser) = TestSetupForUser(userType, false);
        var securityUser = GetSecurityUser(securityType).SecurityUser;

        Steps.AddTestStep($"Navigate to the following URL: {Url}.",
            "User should be able to see SMART Security Landing Search Page.");

        NavigateToUrl(Url, securityUser);

        var searchPage = new SearchPage(Browser);
        searchPage.CheckRedirectAndExpand();
        searchPage.SearchSpecificUser(sampleSearchUser, testUser);
        searchPage.ClickEditUser();
        var userDetailPage = new UserDetailPage(Browser);
        userDetailPage.ValidateUserDetailInformation(sampleSearchUser);
        userDetailPage.ValidateRoleApplicationDropDown(userType.Equals(UserType.Employee));
        userDetailPage.AddRolesSocVendorAffiliation();

        if (userType.Equals(UserType.Vendor))
            ValidateSupplierPortalIntegration(sampleSearchUser.Email);
    }

    [Fact(DisplayName = "TestCreateNewVendorAddUserRoleSocVendorAffiliation")]
    [Trait("Category", "UI")]
    public void TestCreateNewVendorAddUserRoleSocVendorAffiliation()
    {
        RallyTestCaseId = "TC42770";
        AdoTestCaseName = "CreateNewVendorAddUserRoleSocVendorAffiliation";
        TimeSaved       = 480;
        CreateNewUserAddUserRoleSocVendorAffiliation(UserType.Vendor, SecurityUserType.SecurityAdmin, AccessType.Limited);
    }

    [Fact(DisplayName = "TestCreateNewInternalAddUserRoleSoc")]
    [Trait("Category", "UI")]
    public void TestCreateNewInternalAddUserRoleSoc()
    {
        //RallyTestCaseId = "TC43443";
        TimeSaved       = 480;
        CreateNewUserAddUserRoleSocVendorAffiliation(UserType.Employee, SecurityUserType.SecurityAdmin, AccessType.Limited);
    }

    [Fact(DisplayName = "TestCreateNewLifepointAddUserRoleSoc", Skip = "Can not get Lifepoint users due to AD restrictions until user search is refactored.")]    
    public void TestCreateNewLifepointAddUserRoleSoc()
    {
        RallyTestCaseId = "TC43685";
        AdoTestCaseName = "CreateNewLifepointAddUserRoleSoc";
        TimeSaved       = 480;
        CreateNewUserAddUserRoleSocVendorAffiliation(UserType.Employee, SecurityUserType.SecurityAdmin, AccessType.Limited, false);
    }

	/// <summary>
	/// Creates a new user and assigns roles, span of control, and vendor affiliation based on the user type.
	/// </summary>
	private void CreateNewUserAddUserRoleSocVendorAffiliation(Enum userType, Enum securityUserType, Enum accessType, bool hcaUser = true)
	{
		//check security test user exist in Security app if not set it up with multiple SPOC to validate multiple level of span of control
		var userApi = new UserApi(false);
		var securityUser = GetSecurityUser(securityUserType, accessType.GetEnumDescription()).SecurityUser;
		var securityTestUser = userApi.SetupSecurityUser(securityUser);

		//setup new user based on type.
		UserResponse user = null!;
		if (userType.Equals(UserType.Employee))
			user = GetInternalUser(hcaUser);
		//navigate to app
		Steps.AddTestStep($"Navigate to the following URL: {Url}.",
			"User should be able to see SMART Security Landing Search Page.");

		NavigateToUrl(Url, securityUser);

		var searchPage = new SearchPage(Browser);
		searchPage.CheckRedirectAndExpand();

		//start creation
		if (userType.Equals(UserType.Vendor))
		{
            user = searchPage.CreateVendorUser(new Services.Users.AddUserRequest(true));
		}
		else
		{
			searchPage.SearchSpecificUserAndClickEdit(user);
		}

		//validate user detail page
		var userDetailPage = new UserDetailPage(Browser);
		userDetailPage.ValidateUserDetailInformation(user);
		userDetailPage.ValidateRoleApplicationDropDown(userType.Equals(UserType.Employee));

		//add and assign role(s), SPOC, and vendor affiliation
		userDetailPage.AddRolesSocVendorAffiliation(securityTestUser, true, user);
	}

    [Fact(DisplayName = "TestRemoveUserRoleSocToEmployeeType")]
    [Trait("Category", "UI")]
    public void TestRemoveUserRoleSocToEmployeeType()
    { 
        AdoTestCaseName = "RemoveUserRoleSocToEmployeeType";
        TimeSaved       = 300;
        ModifyRoleSocVendorAffiliation(UserType.Employee);
    }

    [Fact(DisplayName = "TestRemoveUserRoleSocVendorAffiliationToVendorType")]
    [Trait("Category", "UI")]
    public void TestRemoveUserRoleSocVendorAffiliationToVendorType()
    {
        RallyTestCaseId = "TC42793";
        AdoTestCaseName = "RemoveUserRoleSocVendorAffiliationToVendorType";
        TimeSaved       = 300;
        ModifyRoleSocVendorAffiliation(UserType.Vendor);
    }

    private void ModifyRoleSocVendorAffiliation(Enum userType)
    {
        var users = TestSetupForUser(userType, true);
        

        Steps.AddTestStep($"Navigate to the following URL: {Url}.",
            $"User should be able to see SMART Security Landing Search Page: Testing: {userType}.");

        NavigateToUrl(Url);

        var searchPage = new SearchPage(Browser);
        searchPage.CheckRedirectAndExpand();
        searchPage.SearchSpecificUser(users.sampleSearchUser, users.testUser);
        searchPage.ClickEditUser();
        var userDetailPage = new UserDetailPage(Browser);
        userDetailPage.ValidateUserDetailInformation(users.sampleSearchUser);
        userDetailPage.RemoveRolesSocVendorAffiliation();

        //Validate integration with Supplier portal 
        if (userType.Equals(UserType.Vendor))
            ValidateSupplierPortalIntegration(users.sampleSearchUser.Email);
    }

    //todo: Keep an eye on this one. when it fails its warning failures only. It passes others. Think its a data thing
    [Fact(DisplayName = "TestDeactivateReactivateEmployeeType")]
    [Trait("Category", "UI")]
    public void TestDeactivateReactivateEmployeeType()
    { 
        AdoTestCaseName = "DeactivateReactivateEmployeeType";
        TimeSaved       = 300;
        DeactivateReactivateUser(UserType.Employee);
    }

    [Fact(DisplayName = "TestDeactivateReactivateVendorType")]
    [Trait("Category", "UI")]
    public void TestDeactivateReactivateVendorType()
    {
        RallyTestCaseId = "TC42887";
        AdoTestCaseName = "DeactivateReactivateVendorType";
        TimeSaved       = 300;
        DeactivateReactivateUser(UserType.Vendor);
    }

    private void DeactivateReactivateUser(UserType userType)
    {
        var users = TestSetupForUser(userType, true);

        Steps.AddTestStep($"Navigate to the following URL: {Url}.",
            "User should be able to see SMART Security Landing Search Page.");

        NavigateToUrl(Url);

        var searchPage = new SearchPage(Browser);
        searchPage.CheckRedirectAndExpand(); 
		searchPage.SearchSpecificUser(users.sampleSearchUser, users.testUser); 
		searchPage.ClickEditUser();
		var userDetailPage = new UserDetailPage(Browser); 
        userDetailPage.ValidateUserDetailInformation(users.sampleSearchUser);
        var updateUser = userDetailPage.DeactivateReactivateUser(users.sampleSearchUser); 
        userDetailPage.DeactivateReactivateUser(updateUser); 
        //Validate integration with Supplier portal 
        if (userType.Equals(UserType.Vendor))
            ValidateSupplierPortalIntegration(users.sampleSearchUser.Email);
    }


	#endregion Tests

	#region Helpers

	private void NavigateToUrl(string url)
    {
        NavigateToUrl(url, GlobalTestVariables.DefaultUser);
    }

    private void NavigateToUrl(string url, string userName, string password)
    {
        //Setting Proxy to ZAP Server
        if (GlobalTestVariables.SecurityTestToggle.Equals("ON"))
        {
            var proxyServer = GlobalTestVariables.ZapHost;
            var proxySettings = new Dictionary<string, object>
            {
            {"httpProxy", proxyServer},
            {"sslProxy", proxyServer}
            };
            Proxy proxy = new Proxy(proxySettings);
            ChromeOptions options = new ChromeOptions();
            options.AcceptInsecureCertificates = true;
            options.Proxy = proxy;
            Browser.OpenNewBrowser("chrome", GlobalTestVariables.SeleniumGridToggle.Equals("ON"), options);
        }
        else
        {
            Browser.OpenNewBrowser("chrome", GlobalTestVariables.SeleniumGridToggle.Equals("ON"));
        }
        
        _ = Browser.EnterCreds(userName, password, GlobalTestVariables.Configuration["WebDomain"]);
        Thread.Sleep(1000);
        Console.WriteLine($"Testing with: '{userName}'.");

        Browser.Navigate(url);
    }

    private void NavigateToUrl(string url, SecurityUser user)
    {
        
        Browser.OpenNewBrowser("chrome", GlobalTestVariables.SeleniumGridToggle.Equals("ON"));
        Browser.Navigate(url);
        Thread.Sleep(1000);      

        var pingAuth = new AuthorizationPage(Browser);
        pingAuth.SignInThruPing(user.UserName, user.Creds);

    }



    private static (UserResponse sampleSearchUser, List<UserResponse> testUser) TestSetupForUser(Enum userType, bool isSetup)
    {
        var userDb = new UserRepository(GlobalTestVariables.Configuration["SmartSecurity:DatabaseServer"]!,
            GlobalTestVariables.Configuration["SmartSecurity:DatabaseName"]!);
        var scUsers  = GlobalTestVariables.Users.Select(i => i.UserName).ToList();
        var testUser = userDb.GetAllUsers().Where(i => !scUsers.Contains(i.Username, StringComparer.OrdinalIgnoreCase)).ToList();

        var something = testUser.Where(i => !i.IsDeactivated
                                   && i.Type.Equals("Vendor")
                                   && !i.FirstName.IsNull()
                                   && !i.VPROUserEmailId.IsNull()
                                   && !GlobalTestVariables.Configuration.GetSection("BlackListAccts").Get<string[]>().Contains(i.Username))
                                  .ToList();


		var sampleSearchUser = userType.Equals(UserType.Employee)
            ? testUser.Where(i => !i.IsDeactivated
                                  && i.Type.Equals("Employee")
                                  && !GlobalTestVariables.Users.Select(e => e.UserName).Contains(i.Username)
                                  && i.LastName.ToStringOrEmpty()
                                      .Contains("trooper", StringComparison.CurrentCultureIgnoreCase))
		                           .PickRandom()
		     : testUser.Where(i => !i.IsDeactivated
		                           && i.Type.Equals("Vendor")
		                           && !i.FirstName.IsNull()
		                           && !i.VPROUserEmailId.IsNull()
		                           && !GlobalTestVariables.Configuration.GetSection("BlackListAccts").Get<string[]>().Contains(i.Username)) 
								  .ToList()
								  .PickRandom();

        var userApi = new UserApi();
        if (isSetup)
            userApi.SetupUserForRemovalTest(sampleSearchUser);
        else
        {
            userApi.ResetUser(sampleSearchUser.Id.ToString());
        }

        return (sampleSearchUser, testUser.ToList());
    }

    private void GetSupplierPortalToken()
    {
        var browser = new Browser(GlobalTestVariables.SeleniumHub);

        var username = $"{GlobalTestVariables.Configuration["SupplierPortal:UserName"]}";
        browser.OpenNewBrowser("chrome", GlobalTestVariables.SeleniumGridToggle.Equals("ON"));
        _ = browser.EnterCreds(username,
            GlobalTestVariables.Configuration["SupplierPortal:Creds"],
            GlobalTestVariables.Configuration["WebDomain"]);
        browser.Navigate(GlobalTestVariables.Configuration["SupplierPortal:PingToken"]);
        var supplierPortalLogin = new SupplierPortalLoginPage(browser);
        supplierPortalLogin.EnterInCreds(username);
        var supplierPortalToken = new Supplierportaltokenpage(browser);
        GlobalTestVariables.SupplierPortalToken = supplierPortalToken.GetAccessToken();

        browser.Close();
    }

    private void ValidateSupplierPortalIntegration(string? email)
    {
        GetSupplierPortalToken();
        var supplierPortalApi = new SupplierPortalApi(GlobalTestVariables.SupplierPortalToken);
        supplierPortalApi.ValidateUserRole(email);
        supplierPortalApi.ValidateUserSpocAndVendorAffiliation(email);
    }

	/// <summary>
	/// Retrieves an internal user (of type "Employee") from the database who is not already present in the SMART Security application,
	/// using either the HCA or Lifepoint Active Directory server based on the <paramref name="hcaUser"/> flag.
	/// This is typically used to select a candidate for user creation or onboarding scenarios in UI tests.
	/// </summary>
	/// <param name="hcaUser">
	/// If true, uses the HCA Active Directory server; if false, uses the Lifepoint Active Directory server.
	/// </param>
	/// <returns>
	/// A <see cref="UserResponse"/> representing an internal user not yet in SMART Security.
	/// </returns>
	private static UserResponse GetInternalUser(bool hcaUser = true)
    {
        var userRepo = new UserRepository(GlobalTestVariables.Configuration["SmartSecurity:DatabaseServer"]!,
            GlobalTestVariables.Configuration["SmartSecurity:DatabaseName"]!);
        var users = userRepo.GetAllUsers()
            .Where(i => i.Type.Equals("Employee") && !i.LastName.ToStringOrEmpty()
                .Contains("trooper", StringComparison.CurrentCultureIgnoreCase))
            .ToList();

        var adServer = hcaUser
            ? GlobalTestVariables.Configuration["HcaLdapUri"]!
            : GlobalTestVariables.Configuration["LifepointLdapUri"]!;

        var activeDirectUserRepository = new ActiveDirectoryUserRepository(adServer);

        return activeDirectUserRepository.GetUserNotInSmartSecurity(users);
    }

    private static (SecurityUser? SecurityUser, AddUserRoleSoc SecurityRequest) GetSecurityUser(Enum securityType,
        string access = "Full")
    {
        var specifiedSecurityUser = GlobalTestVariables.Users!.FirstOrDefault(i =>
                i.RoleName.Contains(securityType.GetEnumDescription()) && i.Access.Equals(access));

        var userApi         = new UserApi(false);
        var securityRequest = userApi.SetupSecurityUser(specifiedSecurityUser);

        return (specifiedSecurityUser, securityRequest);
    }

    #endregion Helpers
}
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using AdoTestCasePlugin;
using System.Xml.Linq;
using Microsoft.Extensions.Configuration;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using qazapsecurity;
using SmartSecurityTestAutomation.Models;
using SmartSecurityTestAutomation.Page.Objects.Ping;
using SmartSecurityTestAutomation.Services.Users;
using Utilities.ObjectExtensions;
using Utilities.SetupTestUsers;
using Utilities.TascUpdater;
using WebUiAutomation;
using Xunit.Abstractions;
using ZapSecurityReportGenerator;


namespace SmartSecurityTestAutomation.Tests
{
    /// <summary>
    /// need this class to setup the listener for xunit test failure.
    /// </summary>
    public static class GlobalSetup
    {
        [ModuleInitializer]
        public static void Setup() =>
            XunitContext.EnableExceptionCapture();
    }

    public class TestMaster : IDisposable
    {
        protected readonly Browser Browser;
        protected          string  RallyTestCaseId = string.Empty;
        protected          string  AdoTestCaseName = string.Empty;
        private            string  _vmName         = string.Empty;
        public readonly string PingAuthUri;
		protected readonly string  Url;

        //ADO Update Variables
        private const      string  AdoBaseUrl = "https://dev.azure.com/HCAHealthTrust/"; //https://dev.azure.com/HCAHealthTrust/  //"https://dev.azure.com/HCABAQS/"
		private const      string  AdoProject = "Healthtrust ITG";
        private const string AdoTestPlan = "SMART-Security - Regression"; //"Regression";

        //TASC update variables
        private static int    _applicationId;
        private static string _tascBaseUrl = null!;
        protected      int?   TimeSaved    = null;
        private static string _tascSecurityUrl = null!;
       
        private readonly ITestOutputHelper _output;

        //Setup
        protected TestMaster(ITestOutputHelper output)
        {
            //xUnit register logging
            _output = output;
            XunitContext.Register(output);
            GlobalTestVariables.TestName = XunitContext.Context.Test.DisplayName;
            Steps.BeginTestSteps(GlobalTestVariables.TestName);

            //Loads Runtime values and environment.
            LoadRuntimeParameters();

            //Loads main configuration
            var testSettings = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
            GlobalTestVariables.ScreenShotFileLocation = testSettings["ScreenShotFileLocation"] + "\\SMART_Security";
            GlobalTestVariables.ZapReportLocation       = $"{testSettings["ScreenShotFileLocation"]}\\ZAP";
            GlobalTestVariables.SeleniumGridToggle     = testSettings["SeleniumGridToggle"];
            GlobalTestVariables.SeleniumHub            = testSettings["SeleniumHub"];
            GlobalTestVariables.AppName                = testSettings["AppName"];
            GlobalTestVariables.ZapHost                = testSettings["ZapHost"];
            GlobalTestVariables.SecurityTestToggle     = testSettings["SecurityTestToggle"];
            _applicationId                             = testSettings["TascApplicationId"].ToInt();
            _tascBaseUrl                               = testSettings["TascUrl"];
            _tascSecurityUrl                           = testSettings["TascSecurityUrl"];

            //Loads settings for the specific environment
            ConfigurationManager? configuration = new();
            configuration.SetBasePath(Path.Combine(Directory.GetCurrentDirectory(), "AppSettings"))
                .AddJsonFile($"appsettings.{GlobalTestVariables.TestEnvironment}.json");

            GlobalTestVariables.Configuration = configuration;

            //setup Full security test user
            LoadSecurityUsers(); 

			var fullSecurityUser = GlobalTestVariables.Users.First(i =>
                i.Access.Equals("Full") && i.RoleName.Contains("Security - Administrator"));

            GlobalTestVariables.UserName = !GlobalTestVariables.TestEnvironment!.Equals("prod")
                ? $"{fullSecurityUser.Domain}\\{fullSecurityUser.UserName}"
                : fullSecurityUser.UserName;

            GlobalTestVariables.Password = fullSecurityUser.Creds;

            var domain = !GlobalTestVariables.TestEnvironment!.Equals("prod")
                ? fullSecurityUser.Domain
                : "";

            GlobalTestVariables.Credential =
                new NetworkCredential(fullSecurityUser.UserName, fullSecurityUser.Creds, domain);  
            
            GlobalTestVariables.DefaultUser = fullSecurityUser;

            Browser = new Browser(GlobalTestVariables.SeleniumHub);
            Url     = GlobalTestVariables.Configuration["SmartSecurity:Url"]!;
            PingAuthUri = GlobalTestVariables.Configuration["SmartSecurity:PingUri"];


            if (!GlobalTestVariables.TestEnvironment!.Equals("prod") || !GlobalTestVariables.TestName.Contains("database", StringComparison.OrdinalIgnoreCase))
            {
                var token = GetPingToken(); 
               	var smSetup = new SmartSecurity(GlobalTestVariables.Configuration["SmartSecurity:BaseUri"]!,
                    token);

                Steps.AddTestStep("Setting up Security users.","Should be able to create Security Users");
                smSetup.CheckAndProvisionUsers(GlobalTestVariables.Users);
                //SetupSecurityUser(fullSecurityUser);
                CheckAndSetupVendorUser();
            }

            Browser = new Browser(GlobalTestVariables.SeleniumHub);
            Url = GlobalTestVariables.Configuration["SmartSecurity:Url"]!;

            output.WriteLine("test setup");

            ConsoleOut.WriteReport($"Environment in test: '{GlobalTestVariables.TestEnvironment}'");
            ConsoleOut.WriteReport($"Date Time Ran: {DateTime.Now:g}");
        }

        //Tear Down
        public void Dispose()
        {
            GlobalTestVariables.TestExceptions = XunitContext.Context.TestException;
            _output.WriteLine("test tear down");

            Steps.EndTestSteps();
            if (!Browser.Driver.IsNull())
            {
                Steps.AddScreenShot(Browser.TakeBase64Screenshot());
                _vmName = Browser.Node;
                Browser.Close();
            }

            WarningOutput();
			//Generate HTML Report
			var testResult = XunitContext.Context.TestException!.IsNull() &&
						   !HPGWarn.Warnings.Any(w => w.Failing)
			  ? "passed"
			  : "failed";
			GenerateHTMLReport(testResult.Equals("passed", StringComparison.OrdinalIgnoreCase));
			/*Rally Updater: Remove by EOM June 2026
			//if (RallyTestCaseId.ToStringOrEmpty() != string.Empty)
            //  UpdateRallyResults();*/

            //ADO Updater
            if (AdoTestCaseName.ToStringOrEmpty() != string.Empty)
                UpdateAdoResults2();

            //TASC Metrics Updater - Not currently in use due to Metric being provided by Manual methods via Vo.
            UpdateTascMetrics();

            Steps.TestSteps.Clear();
            //GlobalTestVariables.RallyScreenShots.Clear();

            if (!HPGWarn.Warnings.Any(w => w.Failing)) return;
            HPGWarn.Warnings.Clear();
            HPGAssert.Fail("\r\nTEST FAILURE DUE TO FAIL-WARNINGS PRESENT!\r\n");
            
        }

        #region Helper

        /// <summary>
        /// Outputs warning at the end of the test.
        /// </summary>
        private static void WarningOutput()
        {
            if (!HPGWarn.Warnings.Any(i => i.Failing)) return;
            ConsoleOut.WriteReport("------- " + HPGWarn.Warnings.Count + " WARNINGS TO FOLLOW... -------");
            ConsoleOut.WriteReport(string.Join("\n        ",
                HPGWarn.Warnings.Select(w =>
                    $"WARNING STEP {w.StepNumber}: {w.Message} {(w.Failing ? " (FAIL)" : "")}")));
        }

        /// <summary>
        /// Uploads the test case result to Rally for the specified test case.
        /// </summary>
        private void UpdateRallyResults()
        {
            //Determines Pass or Fail based on NUnit status
            var rallyTestResult = GlobalTestVariables.TestExceptions!.IsNull() &&
                                  !HPGWarn.Warnings.Any(w => w.Failing)
                ? Rally.Verdict.Pass
                : Rally.Verdict.Fail;

            //Gets the machine name the test ran on.
            var machineName = _vmName.ToStringOrEmpty() == string.Empty ? "LocalMachine/Jenkins" : _vmName;

            //Generate Test HTML Report
            var rg= new ReportGenerator(GlobalTestVariables.AppName
                , GlobalTestVariables.TestName
                ,GlobalTestVariables.TestEnvironment
                ,DateTime.Now
                ,Rally.Verdict.Pass == rallyTestResult);

            GlobalTestVariables.RallyScreenShots
                .Add(rg.GenerateReport(Steps.TestSteps, $"{GlobalTestVariables.ScreenShotFileLocation}\\{GlobalTestVariables.TestName}_{DateTime.Now:MMddyyyyhhmmssss}"));

            //Uploads test results to Rally
            var rally = new Rally();
            Dictionary<string, object> attachToObject = rally.JSONtoDictionary(
                rally.UploadTestCaseResult(RallyTestCaseId,
                    rallyTestResult,
                    GlobalTestVariables.AppName,
                    Steps.TestTotalTime.TotalMinutes.ToString(),
                    ReportOutput.ReportOut,
                    machineName));

            //Uploads attachments and attaches to the specified Rally Test Case Id.
            foreach (var screenShot in GlobalTestVariables.RallyScreenShots)
            {
                rally.UploadAndAttach(screenShot, true, screenShot.Split(Path.DirectorySeparatorChar).Last(),
                    attachToObject);
            }

            //update Rally Test Case Steps
            if(rallyTestResult == Rally.Verdict.Pass)
                rally.UpdateTestSteps(RallyTestCaseId, Steps.StepsOutput);
        }

        /// <summary>
        /// Send results and attachments for a test case result to ADO.
        /// </summary>
        private void UpdateAdoResults()
        {
            var testResult = GlobalTestVariables.TestExceptions!.IsNull() &&
                             !HPGWarn.Warnings.Any(w => w.Failing)
                ? "passed"
                : "failed";

            var machineName = _vmName.ToStringOrEmpty() == string.Empty ? "LocalMachine/Jenkins" : _vmName;

            var ado = new AdoTestCasePlugin.AzureDevOpsQa(AdoBaseUrl, AdoProject, GlobalTestVariables.PatKey);

            ///ado.CreateTestCaseResult(AdoTestPlan, AdoTestCaseName, testResult, ReportOutput.ReportOut, GlobalTestVariables.RallyScreenShots, Steps.TestTotalTime.Milliseconds, machineName);
        }

		private void UpdateAdoResults2()
		{
			var isPassed = XunitContext.Context.TestException!.IsNull() && !HPGWarn.Warnings.Any(w => w.Failing);

			var machineName = _vmName.ToStringOrEmpty() == string.Empty ? "LocalMachine/Jenkins" : _vmName;
			//string AdoBaseUrl = Environment.GetEnvironmentVariable("AdoBaseUrl");
            string Organization = Environment.GetEnvironmentVariable("Organization");
			string PatKey = Environment.GetEnvironmentVariable("PatKey");
			string AdoProject = Environment.GetEnvironmentVariable("AdoProject");
			string AdoTestPlan = Environment.GetEnvironmentVariable("AdoTestPlan");
			var ado = new AdoTestCasePlugin.AzureDevOpsQa(Organization, AdoProject, PatKey);

			// If the test passed, then update the test case steps
			var updatedSteps = Steps.TestSteps.Select(s => new AdoTestCasePlugin.Model.StepObject()
			{
				Index = s.StepNumber.ToString(),
				Description = s.StepDescription,
				ExpectedResult = s.ExpectedResult,
			}).ToList();

            try
            {
                ado.OrchestrateTestCaseAsync(AdoTestPlan, AdoTestCaseName, isPassed, GlobalTestVariables.RallyScreenShots, Steps.TestTotalTime.Seconds, machineName, updatedSteps).Wait();
            }
            catch (Exception ex)
            {
				Console.WriteLine($"Error updating ADO test case steps: {ex.Message}");
			}

		}
		/// <summary>
		/// Send results and attachments for a test case result to ADO.
		/// </summary>
		///
		private void GenerateHTMLReport(bool isPassed)
		{
			// Generate Test HTML Report
			var rg = new ReportGenerator(Environment.GetEnvironmentVariable("AdoTestPlan"), AdoTestCaseName, GlobalTestVariables.TestEnvironment,
				DateTime.Now, isPassed);

			string fileName = $"{GlobalTestVariables.ScreenShotFileLocation}\\{GlobalTestVariables.TestName}_{DateTime.Now:MMddyyyyhhmmssss}";
			GlobalTestVariables.RallyScreenShots.Add(rg.GenerateReport(Steps.TestSteps, fileName));
		}

		/// <summary>
		/// This method will Send automated test metrics to the TASC application.
		/// </summary>
		private void UpdateTascMetrics()
        {
            if (_tascBaseUrl.ToStringOrEmpty() == string.Empty || TimeSaved == null) return;

            var tm = new TascUpdater(_tascBaseUrl);
            var result = tm.SendTestMetricsResult(_applicationId, GlobalTestVariables.TestName.ToStringOrEmpty(),
                _vmName.ToStringOrEmpty() == string.Empty
                    ? "Local Machine"
                    : _vmName, (int)TimeSaved);
            Console.WriteLine($"TASC Updater Result: {result}");
        }

        /// <summary>
        /// Pulls environmental variables for the test.
        /// </summary>
        /// <exception cref="Exception"></exception>
        private static void LoadRuntimeParameters()
        {
            //Load Mailinator AppKey
            //if (Environment.GetEnvironmentVariable("MailinatorAppKey")!.ToStringOrEmpty() == string.Empty)
            //    throw new Exception("Parameter 'MailinatorAppKey' was not passed in!");

            //GlobalTestVariables.MailinatorAppKey = Environment.GetEnvironmentVariable("MailinatorAppKey");

            //Load Environment
            if (Environment.GetEnvironmentVariable("Environment")!.ToStringOrEmpty() == string.Empty)
                throw new Exception("Parameter 'Environment' was not passed in!");

            GlobalTestVariables.TestEnvironment = Environment.GetEnvironmentVariable("Environment");

            //ADO PAT Key
            if (Environment.GetEnvironmentVariable("PatKey")!.ToStringOrEmpty() == string.Empty)
                throw new Exception("Parameter 'PatKey' was not passed in!");

            GlobalTestVariables.PatKey = Environment.GetEnvironmentVariable("PatKey");            

        }

        /// <summary>
        /// Checks the security users in the database and validates it has the correct settings. If it does not then it will update/create the security user's profile.
        /// </summary>
        /// <param name="fullSecurityUser"></param>
        private static void SetupSecurityUser(SecurityUser fullSecurityUser)
        {
            var userApi = new UserApi(false);
            Steps.AddTestStep("Checking security test user for test run.",
                "Should be able to check and/or setup the security user.");
            userApi.SetupSecurityUser(fullSecurityUser);
        }

        /// <summary>
        /// Checks the database to ensure more than 5 active vendor users are present.
        /// </summary>
        private static void CheckAndSetupVendorUser()
        {
            var userRepo = new UserRepository(GlobalTestVariables.Configuration!["SmartSecurity:DatabaseServer"]!,
                GlobalTestVariables.Configuration["SmartSecurity:DatabaseName"]!);
            var users   = userRepo.GetAllUsers();
            var userApi = new UserApi(false);
            if (users.Count(i => i.Type.Equals("Vendor") && !i.IsDeactivated) >= 5) return;

            const int countOfVendorUsersToCreate = 5;
            for (var i = 0; i < countOfVendorUsersToCreate; i++)
            {
                userApi.AddNewUser("Vendor");
            }
        }

		/// <summary>
		/// Loads security users for the specified environment.
		/// </summary>
		private static void LoadSecurityUsers()
        {
            var securityUserConfiguration = new ConfigurationBuilder()
                .SetBasePath( Path.Combine(Directory.GetCurrentDirectory(), "SecurityUsers"))
                .AddJsonFile($"securityUsers.qa.json").Build();

            GlobalTestVariables.Users =
                securityUserConfiguration.GetSection("TestUsers").Get<List<SecurityUser>>()!;

            //todo: will go away once windows Cred is removed from SMART Dashboard
            if(GlobalTestVariables.TestEnvironment.Equals("qasbx"))
            {
                var securityUserConfigurationB = new ConfigurationBuilder()
                    .SetBasePath(Path.Combine(Directory.GetCurrentDirectory(), "SecurityUsers"))
                    .AddJsonFile($"securityUsers.qa.json").Build();
                GlobalTestVariables.UsersB =
                    securityUserConfigurationB.GetSection("TestUsers").Get<List<SecurityUser>>()!;
            }
        }

        /// <summary>
        /// Generates a security report and sends it to TASC.
        /// </summary>
        private void GenerateSecurityReport()
        {
            //create report information
            var title = "Security Report for SMART Security Application";
            var description = $"Security Report for SMART Security using automated test '{GlobalTestVariables.TestName}'.";
            var sites = new List<string> {"https://qa-smart.healthtrustpg.com/Admin/SecurityManagement"
                ,"https://qa-api-admin.healthtrustpg.com"
                ,"https://qa-api-smartauthorization.healthtrustpg.com"};
            var reportFileName = $"ZapSecurityReport_{GlobalTestVariables.TestName}_{DateTime.Now:MMddyyyyhhmmss}";
            var reportInfo = new ReportInfo(title, description, sites, GlobalTestVariables.ZapReportLocation, reportFileName, ReportType.TraditionalJson);

            //Generate and send report to TASC
            var zap = new QaZapSecurityReport(GlobalTestVariables.ZapHost, GlobalTestVariables.ZapKey, _tascSecurityUrl);
            try
            {
                var zapReportGenerated = zap.GenerateTascReport(reportInfo);
                ConsoleOut.WriteReport(zapReportGenerated == HttpStatusCode.OK
                    ? "ZAP Security Report was generated successfully and sent to TASC Dashboard!"
                    : "ZAP Security Report was not generated successfully!");
            }
            catch (Exception e)
            {
                ConsoleOut.WriteReport("ZAP Security Report was not generated successfully!");
                ConsoleOut.WriteReport(e.Message);
            }


            //Generate and download PDF report
            var reportInfoPdf = new ReportInfo(title, description, sites, GlobalTestVariables.ZapReportLocation, reportFileName, ReportType.TraditionalPdf);

            GlobalTestVariables.RallyScreenShots.Add(zap.GenerateReport(reportInfoPdf));

        }


        private string GetPingToken() 
        {
            var browser = new Browser(GlobalTestVariables.SeleniumHub);
            var options = new ChromeOptions();
            //options.AddArgument("--headless=new");
            browser.OpenNewBrowser("chrome", GlobalTestVariables.SeleniumGridToggle.Equals("ON"),options);
			// Extend the timeout for the WebDriverWait
			browser.Driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(60); // Set the timeout to 60 seconds
            SecurityUser testUser = GlobalTestVariables.DefaultUser;

			string token = null;
			int tryCount = 0;
			do
			{
				browser.Navigate(GlobalTestVariables.Configuration["SmartSecurity:PingUri"]);
				Thread.Sleep(1000); // Wait for 1 second to ensure the page loads. was having timing issues where the page was not fully loaded.
				var pingPage = new AuthorizationPage(browser);
				token = pingPage.GetPingToken($"{testUser.UserName}", testUser.Creds);
				tryCount++;
			}
			while (string.IsNullOrEmpty(token) && tryCount <= 3);
			browser.Close();

            return token;
        }
		#endregion Helper
	}

}
﻿using System;
using System.Diagnostics;
using SmartSecurityTestAutomation.Enums;
using SmartSecurityTestAutomation.Services.SelfProvision;
using SmartSecurityTestAutomation.Services.Users;
using SmartSecurityTestAutomation.Services.Applications;
using SmartSecurityTestAutomation.Services.AuditHistory;
using SmartSecurityTestAutomation.Services.Orgs;
using SmartSecurityTestAutomation.Services.SmartClientUsers;
using SmartSecurityTestAutomation.Services.Token;
using SmartSecurityTestAutomation.Services.Vendor;
using SmartSecurityTestAutomation.Services.VPRO;
using Utilities.ObjectExtensions;
using Utilities.SetupTestUsers;
using Xunit.Abstractions;
using static System.Net.Mime.MediaTypeNames;
using SmartSecurityTestAutomation.Services.SupplierPortal;
using System.ComponentModel;
using SmartSecurityTestAutomation.Services.GCNGroup;
using System.DirectoryServices;

namespace SmartSecurityTestAutomation.Tests;


public class SmartSecurityApiTests : TestMaster
{
    
    public SmartSecurityApiTests(ITestOutputHelper output) : base(output)
    {        
    }

    [Fact(DisplayName = "SelfProvision")]
    [Trait("Category", "API")]
    [Trait("Category", "Regression")]
    public void SelfProvisionApiTests()
    {
		AdoTestCaseName = "SelfProvisionApiTests";
		TimeSaved = 800;
		var selfProvisionApi = new SelfProvisionApi();
		selfProvisionApi.TestSelfProvisionPersonalScope(); 
		selfProvisionApi.TestSelfProvisionRequestDetails();
        
	}

    [Fact(DisplayName = "UserApiTests")]
    [Trait("Category", "API")]
    [Trait("Category", "Regression")]
    public void UserApiTests()
    {
        AdoTestCaseName = "UserApiTests";
        TimeSaved       = 800;
        var userApi = new UserApi();

        /* NOTE:
			-   ClientAdminDomainList": "lpnt,lpntqa,capella",  ** we can't test this with our current accts in qa we need lpnt & cappella service accounts re-write 
        userApi.TestGetUsers(SecurityUserType.ClientAdmin); // MAINTENANCE WORK NEEDED - refactor
        userApi.TestPostUserSocByApplication();             //warning failures on some random users - Post/users/claims - MAINTENANCE WORK NEEDED
        userApi.TestPostDeactivateActivateUser();           //System.ArgumentException : An item with the same key has already been added. Key: accd2c46-1db8-452f-8bc8-dd55b11e626c
		*/


        userApi.TestGetUsers(SecurityUserType.SecurityAdmin);
        userApi.TestGetUsers(SecurityUserType.VendorAdmin);
        userApi.TestGetUserBadRequest();
        userApi.TestGetUserRolesByApplication();
        userApi.TestGetUserRoleByApplicationBadRequest();
        userApi.TestPostUserRolesBadRequest();
        userApi.TestGetUserSocByApplication();
        userApi.TestGetUserSocByApplicationBadRequest();
        userApi.TestGetVendorAffiliation();
        userApi.TestGetVendorAffiliationBadRequest();
        userApi.TestPostUserSocByApplicationBadRequest();
        userApi.TestPostVendorAffiliationBadRequest();
        // userApi.TestPostVendorAffiliation();
        userApi.TestPostNewUser();
        userApi.TestPostNewUserBadRequest();
        userApi.TestPostUserClaimsGcnGroupAssignAndUnassign();
        userApi.TestGetUsersSocByApplicationGcn();
        userApi.TestGetLoggedInUserRoles();


    }

	[Fact(DisplayName = "API-OneOFF_TestRunnerMethod")]
	[Trait("Category", "API")]
	[Trait("Category", "SprintWork")]
	public void TestRunnerMethod()
	{   //my sandbox method to run one off tests for debugging and fixing failures.
        //This can be deleted at any time. No dependencies on anything.
        /*-----------------------------------------------*/
        var scuApi = new SmartClientUserApi();
        //      AdoTestCaseName = "_ApiAutomation - /SelfProvision/VboRequestResponseNotification";
        //      scuApi.TestPostSelfProvisionVboRequestResponseNotification();

        AdoTestCaseName = "ApiAutomation - /SelfProvision/VendorAdminNotification";
		scuApi.TestGetUserVendorBadRequest();
		//   AdoTestCaseName = "SmartClientUsersApiTests";
		//var scuApi = new SmartClientUserApi(); 
		//scuApi.TestGetUserRoleBadRequest();


		Console.WriteLine("TestRunnerMethod executed. " + AdoTestCaseName);

	}

	[Fact(DisplayName = "OrgHierarchyApiTest")]
    [Trait("Category", "API")]
    [Trait("Category", "Regression")]
    public void OrgHierarchyApiTest()
    {
        AdoTestCaseName = "OrgHierarchyApiTest";

		TimeSaved       = 600;
        var orgApi = new OrgsApi();
        orgApi.TestGetOrgs();
        orgApi.TestGetOrgName();
        //orgApi.TestGetOrgNameBadRequest();//Maintenance work 1 warning - actual vs expected... one of them need to be upper case or something
        orgApi.TestGetOrgTree();
        orgApi.TestGetOrgTreeBadRequest();
        orgApi.TestGetFullOrgTreeRoot();
        //orgApi.TestGetFullTree();//Maintenance work - fails on line 547: expectedUserOrgList = FormatUserOrgTree(user).ToList() Formatting issue
    }

    [Fact(DisplayName = "ApplicationApiTests")]
    [Trait("API","ApplicationApiTests")]
    [Trait("Category","API")]
    [Trait("Category", "Regression")]
    public void ApplicationApiTests()
    { 
	    AdoTestCaseName = "ApplicationApiTests";
        TimeSaved       = 360;

        var applicationApi = new ApplicationApi();
        applicationApi.TestGetApplications();
        applicationApi.TestGetRolesByApplicationId();
        applicationApi.TestGetRolesByApplicationIdBadRequest();
        //NEW API TEST WOULD BE HERE
    }

    [Fact(DisplayName = "VendorsApiTests")]
    [Trait("API","VendorsApiTests")]
    [Trait("Category","API")]
    [Trait("Category", "Regression")]
    public void VendorsApiTests()
    {
        AdoTestCaseName = "VendorsApiTests";
        TimeSaved       = 180;
        var watch = new Stopwatch();
		var vendorApi = new VendorApi();
        
        watch.Start();
        vendorApi.TestGetVendor();
        watch.Stop();
		ConsoleOut.WriteReport($"Test Performance 'TestGetVendor' took: {watch.ElapsedMilliseconds} (ms).");
        watch.Restart();

        //Skip the below test. AsOf: 16 april this hasn't been deployed to QA yet. LocalVendor table only exists in qasbx for now.
        if (GlobalTestVariables.TestEnvironment == "qasbx")
        { 
		    watch.Start();
		    vendorApi.TestGetVendorsSearchLocalVendorByName();
            watch.Stop();
            ConsoleOut.WriteReport($"Test Performance 'TestGetVendorsSearchLocalVendorByName' took: {watch.ElapsedMilliseconds} (ms).");
            watch.Reset();
        }
	}

    [Fact(DisplayName = "TokenApiTests",Skip = "Deprecated")]
    [Trait("Category", "API")]
    [Trait("Category", "Regression")]
    public void TokenApiTests()
    {
        RallyTestCaseId = "TC41863";
        AdoTestCaseName = "TokenApiTests";
        TimeSaved       = 600;
        var tokenApi = new TokenApi();
        tokenApi.TestGetTokenUser();
        tokenApi.TestGetTokenUserBadRequest();
        tokenApi.TestGetRefreshToken();
        tokenApi.TestGetRefreshTokenBadRequest();
    }

    [Fact(DisplayName = "AuditHistoryApiTests")]
    [Trait("Category", "API")]
    [Trait("Category", "Regression")]
    public void AuditHistoryApiTests()
    {  
        AdoTestCaseName = "AuditHistoryApiTests";
        TimeSaved       = 600;
        var auditHistoryApi = new AuditHistoryApi(); 
		auditHistoryApi.TestGetUserAuditHistory(); 		
		auditHistoryApi.TestGetUserAuditHistoryBadRequest();
        auditHistoryApi.TestUserAuditHistoryDE15594();
    }

    [Fact(DisplayName = "SmartClientUsers")]
    [Trait("Category", "API")]
    [Trait("Category", "Regression")]
	public void SmartClientUsers()
    {
        AdoTestCaseName = "SmartClientUsersApiTests";
        TimeSaved = 1800;

        var watch  = new Stopwatch();
        var scuApi = new SmartClientUserApi();
		
		scuApi.TestPostGetUserDetails("employee");
        scuApi.TestPostGetUserDetails("vendor");

        //-scuApi.TestPostGetUserSearchOrDetails();    //Need some refactoring: Totals steps: 31614 
        //-Needs maintanance >ERROR: returns users assigned SoC but unable to find in [OrgnameTranspose] table > scuApi.TestPostGetUserSearchOrDetailsBadRequest();
        //-Needs maintanance >ERROR: transport-level error has occurred when receiving results from the server > scuApi.TestPostGetUserDetailsBadRequest();

        //watch.Start();
        //scuApi.TestBadRequestUsersForSpecificRoleAndSpocWithDetails(); //needs refactoring to eliminate bad data from request in QASBX
        //watch.Stop();
        //ConsoleOut.WriteReport($"Test Performance 'TestBadRequestUsersForSpecificRoleAndSpocWithDetails' took: {watch.ElapsedMilliseconds} (ms)."); 

        watch.Start();
        scuApi.TestGetUserRoles();
        watch.Stop();
        ConsoleOut.WriteReport($"Test Performance 'TestGetUserRoles' took: {watch.ElapsedMilliseconds} (ms).");
        watch.Reset();
        
        watch.Start();
        scuApi.TestGetUserRoleBadRequest();
        watch.Stop();
        ConsoleOut.WriteReport($"Test Performance 'TestGetUserRoleBadRequest' took: {watch.ElapsedMilliseconds} (ms).");
        watch.Reset(); 

        //-watch.Start();
        //-Needs maintanance >ERROR: transport-level error has occurred when receiving results from the server >
        //-scuApi.TestGetUserSoc();
        //-watch.Stop();
        //-ConsoleOut.WriteReport($"Test Performance 'TestGetUserSoc' took: {watch.ElapsedMilliseconds} (ms).");
        //-watch.Reset();

        watch.Start();
        scuApi.TestGetUserSocBadRequest();
        watch.Stop();
        ConsoleOut.WriteReport($"Test Performance 'TestGetUserSocBadRequest' took: {watch.ElapsedMilliseconds} (ms).");
        watch.Reset();

        watch.Start();
        scuApi.TestGetUserVendor();
        watch.Stop();
        ConsoleOut.WriteReport($"Test Performance 'TestGetUserVendor' took: {watch.ElapsedMilliseconds} (ms).");
        watch.Reset();

        watch.Start();
        scuApi.TestGetUserVendorBadRequest();
        watch.Stop();
        ConsoleOut.WriteReport($"Test Performance 'TestGetUserVendorBadRequest' took: {watch.ElapsedMilliseconds} (ms).");
        watch.Reset();

        //watch.Start();
        //scuApi.TestGetRolesSocVendorAffiliation();
        //watch.Stop();
        //ConsoleOut.WriteReport($"Test Performance 'TestGetRolesSocVendorAffiliation' took: {watch.ElapsedMilliseconds} (ms).");
        //watch.Reset();

        //watch.Start();
        //scuApi.TestGetRolesSocVendorAffiliationBadRequest();
        //watch.Stop();
        //ConsoleOut.WriteReport($"Test Performance 'TestGetRolesSocVendorAffiliationBadRequest' took: {watch.ElapsedMilliseconds} (ms).");
        //watch.Reset();

        //watch.Start();
        //scuApi.TestGetUsersForSpecificRoleAndSpoc();
        //watch.Stop();
        //ConsoleOut.WriteReport($"Test Performance 'TestGetUsersForSpecificRoleAndSpoc()' took: {watch.ElapsedMilliseconds} (ms).");
        //watch.Reset();

        //- NOTE: Needs maintence & refactoring work - Long test over 11892 steps.  Fails on warning and System.Threading.Tasks.TaskCanceledException : A task was canceled. 
        //-watch.Start();
        //-scuApi.TestGetUsersForSpecificRoleAndSpoc(true);
        //-watch.Stop();
        //-ConsoleOut.WriteReport($"Test Performance 'TestGetUsersForSpecificRoleAndSpoc(true)' took: {watch.ElapsedMilliseconds} (ms).");
        //-watch.Reset();
        //---
        watch.Start();
        scuApi.TestBadRequestUsersForSpecificRoleAndSpoc();
        watch.Stop();
        ConsoleOut.WriteReport($"Test Performance 'TestBadRequestUsersForSpecificRoleAndSpoc' took: {watch.ElapsedMilliseconds} (ms).");
        watch.Reset();

        watch.Start();
        scuApi.TestPostVproGetUserVPROBadgeInDetailsAsync();
        watch.Stop();
        ConsoleOut.WriteReport($"Test Performance 'TestVproGetUserVPROBadgeInDetailsAsync' took: {watch.ElapsedMilliseconds} (ms).");
        watch.Reset();

        watch.Start();
        scuApi.TestGetUsersDetailsByUsername();
        watch.Stop();
        ConsoleOut.WriteReport($"Test Performance 'TestGetUsersDetailsByUsername' took: {watch.ElapsedMilliseconds} (ms).");
        watch.Reset();

        //-VPRO API - Have also been moved to Client Auth API for vbo automated provisioning gcp project
        watch.Start();
        scuApi.TestClientAuthVproApis();
        watch.Stop();
        ConsoleOut.WriteReport($"Test Performance 'TestClientAuthVproApis' took: {watch.ElapsedMilliseconds} (ms).");
        watch.Reset();

		watch.Start();
        scuApi.TestGetUserV2Soc();
        watch.Stop();
		ConsoleOut.WriteReport($"Test Performance 'TestGetUserV2Soc' took: {watch.ElapsedMilliseconds} (ms).");
        watch.Reset();

        /* watch.Start();
        scuApi.TestClientAuthGcnApis();
        watch.Stop();
        ConsoleOut.WriteReport($"Test Performance 'TestClientAuthGcnApis' took: {watch.ElapsedMilliseconds} (ms).");
        watch.Reset(); */

        watch.Start();
        scuApi.TestGetSocLeafLevel();
		watch.Stop();
		ConsoleOut.WriteReport($"Test Performance 'TestGetSocLeafLevel' took: {watch.ElapsedMilliseconds} (ms).");
		watch.Reset();

        //The code for the below is being held back from QA due to further changes coming from the Invoice Tracker Project
        // Test only in qasbx

        if (GlobalTestVariables.TestEnvironment == "qasbx")
        {
            watch.Start();
            scuApi.TestPostSelfProvisionVendorAdminNotification();
            watch.Stop();
            ConsoleOut.WriteReport($"Test Performance 'TestPostSelfProvisionVendorAdminNotification' took: {watch.ElapsedMilliseconds} (ms).");
            watch.Reset();

            watch.Start();
            scuApi.TestPostSelfProvisionVboRequestResponseNotification();
            watch.Stop();
            ConsoleOut.WriteReport($"Test Performance 'TestPostSelfProvisionVboRequestResponseNotification' took: {watch.ElapsedMilliseconds} (ms).");
            watch.Reset();

            watch.Start();
            scuApi.TestSelfProvisionIngest();
            watch.Stop();
            ConsoleOut.WriteReport($"Test Performance 'TestSelfProvisionIngest' took: {watch.ElapsedMilliseconds} (ms).");
            watch.Reset();
        }

	}

	[Fact(Skip="production only!")]
    public void ProductionSmokeApiTest()
    {
        RallyTestCaseId = "TC44113";

        Steps.AddTestStep("Validating User API.", "System should respond appropriately.");
        var userApi = new UserApi();
        userApi.TestGetUsers(SecurityUserType.SecurityAdmin);
        userApi.TestGetUserRolesByApplication();
        userApi.TestGetUserSocByApplication(true); //this is only reference to Test(). Circle back and fix 9Jan: marlon

        Steps.AddTestStep("Validating Application API.", "System should respond appropriately.");
        var applicationApi = new ApplicationApi();
        applicationApi.TestGetApplications();
        applicationApi.TestGetRolesByApplicationId();

        Steps.AddTestStep("Validating Vendor API.", "System should respond appropriately.");
        var vendorApi = new VendorApi();
        vendorApi.TestGetVendor();

        Steps.AddTestStep("Validating ORG API.", "System should respond appropriately.");
        var orgApi = new OrgsApi();
        orgApi.TestGetOrgs();
        orgApi.TestGetOrgName();
        orgApi.TestGetOrgTree();
        orgApi.TestGetFullOrgTreeRoot();
        orgApi.TestGetFullTree();

        Steps.AddTestStep("Validating Token API.", "System should respond appropriately.");
        var tokenApi = new TokenApi();
        tokenApi.TestGetRefreshToken();

        Steps.AddTestStep("Validating Client Auth API.", "System should respond appropriately.");
        var scuApi = new SmartClientUserApi();
        scuApi.TestGetUserRoles();
        scuApi.TestGetUserSoc(); 
        scuApi.TestGetUsersForSpecificRoleAndSpoc();
    }

	[Fact(DisplayName = "VproApiTests")]
    [Trait("Category", "API")]
    [Trait("Category", "Regression")]
    public void VproApiTests()
    {
	    AdoTestCaseName = "VproApiTests";  
		TimeSaved = 1800;
		var vproApi = new VproApi();
		if (!vproApi.TestGetVproIsEnabledCheck()) return;
        vproApi.TestPostVproActiveUser();
        vproApi.TestPostVproUserStatusCheck();
        vproApi.TestGetVproCandidate();
        vproApi.TestPostVproGetCredentialingRequest();
        vproApi.TestGetByVproUserEmailIdRequest();
        vproApi.TestPostVproGetVproFacilityVisits();
        vproApi.TestGetVproBadgeInEndTime();
        vproApi.TestPostVproGetCredentialingRequestInsideOutsideUserSoc();
        //Only needs to run for clean up on bad vpro data: vproApi.TestVproDataIssueCorrections();
    }
    [Fact]
    public void SupplierPortalApiTests()
	{
		AdoTestCaseName = "SupplierPortalApiTests";
		TimeSaved = 1800;

        //GetSupplierPortalToken();
		var supplierPortalApi = new SupplierPortalApi();
		supplierPortalApi.TestSupplierPortalIdentityUpsert();
	}

    [Fact(DisplayName = "GcnGroupApiTests")]
    [Trait("Category", "API")]
    [Trait("Category", "Regression")]
    public void GcnGroupApiTest()
    {

        AdoTestCaseName = "GcnApiTests";
        TimeSaved = 1800;
        var api = new GcnGroupApi();
        api.TestGetAllGroups();
        api.TestGetAllGroupsNegativeAndEdgeCases();
        api.TestGroupUserByUsername();

		//Skip the below test. AsOf: 7 Jan this hasn't been deployed to QA yet
		//if (GlobalTestVariables.TestEnvironment == "qasbx")        {}
        api.TestGetAllGcnAttributesFmGcn();
        api.TestPostGcnGroupingWebTableData();
		api.TestDeleteGcnGroupCoid();
        api.TestPostGcnGroupCoidUpsert(); 

    }
}


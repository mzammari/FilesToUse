﻿
using System;
using SmartSecurityTestAutomation.Data.Migration;
using SmartSecurityTestAutomation.Data.Views;
using Xunit.Abstractions;

namespace SmartSecurityTestAutomation.Tests;

public class Smart_Security_Database_Tests : TestMaster
{
    public Smart_Security_Database_Tests(ITestOutputHelper output) : base(output)
    {
    }

    [Fact(Skip = "Database Migration Validation")]
    public void PassDatabaseMigrationTest()
    {
        RallyTestCaseId = "TC46359";
        var passDataMigration = new PassDataMigration();
        passDataMigration.TestSmacToSecurityRoleAndSpoc();
        passDataMigration.TestProcurementUsersRolesAndSpoc();
    }

    [Fact(Skip = "Database Migration Validation")]
    public void DatabaseUserReportViewTest()
    {
        RallyTestCaseId = "TC44987";
        var vwUserReport = new UserReportView();
        vwUserReport.TestUserReportView();
    }

    [Fact(Skip = "Database Migration Validation")]
    public void DatabaseRefHomeViewTest()
    {
        RallyTestCaseId = "TC44958";
        var refView = new RefHomeView();
        refView.TestRefHomeView();
    }
    
    
}
﻿using System;
using System.Collections.Generic;
using System.Net;
using Microsoft.Extensions.Configuration;
using SmartSecurityTestAutomation.Models;
using Utilities.SetupTestUsers;

namespace SmartSecurityTestAutomation.Tests;

public static class GlobalTestVariables
{
    public static readonly List<string>?         RallyScreenShots = [];
    public static          ConfigurationManager? Configuration          { get; set; }
    public static          string?               TestEnvironment        { get; set; }
    public static          string?               ScreenShotFileLocation { get; set; }
    public static          string?               SeleniumHub            { get; set; }
    public static          string?               SeleniumGridToggle     { get; set; }
    public static          string?               AppName                { get; set; }
    public static          string?               UserName               { get; set; }
    public static          string?               TestName               { get; set; }
    public static          string?               Password               { get; set; }
    public static          NetworkCredential?    Credential             { get; set; }
    public static          string?               SupplierPortalToken    { get; set; }
    public static          List<SecurityUser>?   Users                  { get; set; }
    public static          List<SecurityUser>?   UsersB                 { get; set; }
    public static          SecurityUser?         DefaultUser            { get; set; }
    public static          string?               MailinatorAppKey       { get; set; }
    public static          string?               PatKey                 { get; set; }
    public static          string?               ZapKey                 { get; set; }
    public static          string?               ZapHost                { get; set; }
    public static          string                ZapReportLocation      { get; set; }
    public static          string?               SecurityTestToggle     { get; set; }
    public static          Exception?            TestExceptions         { get; internal set; }
}
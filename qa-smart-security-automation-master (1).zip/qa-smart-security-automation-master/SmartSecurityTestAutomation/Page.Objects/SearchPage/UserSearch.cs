﻿namespace SmartSecurityTestAutomation.Page.Objects.SearchPage;

public struct UserSearch
{
    public string? UserId          { get; set; }
    public string  FirstName       { get; set; }
    public string  LastName        { get; set; }
    public string  Email           { get; set; }
    public bool?   IncludeEmployee { get; set; }
    //public bool?  IncludeMember   { get; set; }
    public bool?  IncludeVendors  { get; set; }
    public bool?  IncludeInactive { get; set; }
    public bool?  IncludeActive   { get; set; }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
using SmartSecurityTestAutomation.Services.Users;
using SmartSecurityTestAutomation.Tests;
using Utilities.ObjectExtensions;
using WebUiAutomation;

namespace SmartSecurityTestAutomation.Page.Objects.SearchPage;

public class SearchPage : AdminPageMaster
{
    private WebDriverWait _waitDriver;
    private Browser       _browser;

    public SearchPage(Browser browser) : base(browser)
    {
        _waitDriver = new WebDriverWait(browser.Driver, TimeSpan.FromSeconds(60));
        _browser    = browser;
    }

    #region Page Objects

    public HpgElement SecurityOverlay =>
        new(_waitDriver.Until(e => e.FindElement(By.XPath("/html/body/app-root/app-sidenav/div/div[2]"))),
            "Security Overlay");

    public HpgElement UserIdInput => new(_waitDriver.Until(e => e.FindElement(By.Id("username"))), "User Input");

    public HpgElement FirstNameInput =>
        new(_waitDriver.Until(e => e.FindElement(By.Id("firstName"))), "First Name Input");

    public HpgElement LastNameInput => new(_waitDriver.Until(e => e.FindElement(By.Id("lastName"))), "Last Name Input");
    public HpgElement EmailInput    => new(_waitDriver.Until(e => e.FindElement(By.Id("email"))), "Email Input");

    public HpgElement ExternalEmailAddress => new(_waitDriver.Until(e => e.FindElement(By.Id("vprouseremailid"))), "External Email Address Input");
    public HpgElement SearchButton =>
        new(_waitDriver.Until(e => e.FindElement(By.Id("search-btn-id"))), "Search Button");

    public HpgElement SearchResultLabel =>
        new(_waitDriver, By.CssSelector("p[id='p-search-heading']"), "SearchResultLabel");

    public HpgElement CreateVendorUserButton => new(_waitDriver.Until(e => e.FindElement(By.Id("createNew-btn-id"))),
        "Create Vendor User Button");
    public HpgElement ClearInputButton => new(_waitDriver.Until(e => e.FindElement(By.Id("clear-btn-id"))),
		"Clear Button");

    public HpgElement UsernameSpan => new(_waitDriver.Until(e => e.FindElement(By.Id("username-span"))),
			"Welcome User signed into Security (Top right)");
	public HpgElement LogOut => new(_waitDriver.Until(e => e.FindElement(By.CssSelector("a.logout-lnk"))), "Log Out Button");

	#region Advance Search Objects

	public HpgElement AdvanceFilterButton =>
        new(_waitDriver.Until(e => e.FindElement(By.CssSelector("div[class='advancedBtnDiv']>button"))),
            "Advanced Filter Button");

    public HpgElement FilterTypeExpansion =>
        new(_waitDriver.Until(e => e.FindElement(By.CssSelector("#mat-expansion-panel-header-0"))),
            "Filter Type Expansion");

    public HpgElement FilterTypeClearButton =>
        new(_waitDriver.Until(e => e.FindElement(By.CssSelector("#mat-expansion-panel-header-0>span>button"))),
            "Filter Type Clear Button");

    public HpgElement EmployeeFilterCheckBox => new(_waitDriver.Until(e => e.FindElement(By.Id("mat-checkbox-2"))),
        "Employee Filter Check Box");

    public HpgElement VendorFilterCheckbox => new(_waitDriver.Until(e => e.FindElement(By.Id("mat-checkbox-3"))),
        "Vendor Filter Check Box");

    public HpgElement MemberFilterCheckBox => new(_waitDriver.Until(e => e.FindElement(By.Id("mat-checkbox-4"))),
        "Member Filter Check Box");

    public HpgElement FilterStatusExpansion =>
        new(_waitDriver.Until(e => e.FindElement(By.CssSelector("#mat-expansion-panel-header-1"))),
            "Filter Status Expansion");

    public HpgElement FilterStatusClearButton =>
        new(_waitDriver.Until(e => e.FindElement(By.CssSelector("#mat-expansion-panel-header-1>span>button"))),
            "Filter Status Clear Button");

    public HpgElement ActiveFilterCheckBox => new(_waitDriver.Until(e => e.FindElement(By.Id("#mat-checkbox-5"))),
        "Active Filter Check Box");

    public HpgElement InactiveFilterCheckBox => new(_waitDriver.Until(e => e.FindElement(By.Id("#mat-checkbox-6"))),
        "Inactive Filter Check Box");

    public HpgElement IncludeVendorCheckbox => new(_waitDriver.Until(e => e.FindElement(By.Id("includeVendors"))),
        "Include Vendors Checkbox");

    public HpgElement IncludeInactiveCheckbox =>
        new(_waitDriver.Until(e => e.FindElement(By.Id("includeInactive"))), "Include Inactive Checkbox");

    #endregion Advance Search Objects

    #region Create Vendor Blade

    public HpgElement CreateFirstName =>
        new(_waitDriver.Until(e => e.FindElement(By.CssSelector("#add-vendor-user-view  #firstName"))),
            "First Name Text Box");

    public HpgElement CreateLastName =>
        new(_waitDriver.Until(e => e.FindElement(By.CssSelector("#add-vendor-user-view #lastName"))),
            "Last Name Text Box");

    public HpgElement CreateEmail =>
        new(_waitDriver.Until(e => e.FindElement(By.CssSelector("#add-vendor-user-view #email"))), "Email Text Box");

	public HpgElement CreateEmailId => new(_waitDriver.Until(e => e.FindElement(By.CssSelector("#add-vendor-user-view #vproUserEmailId"))), "VPRO Email Id Text Box");


	public HpgElement SaveVendorButton =>
        new(_waitDriver.Until(e => e.FindElement(By.CssSelector("button[id='btn_add']"))), "Save Vendor Button");

    public HpgElement CancelButton =>
        new(_waitDriver.Until(e => e.FindElement(By.CssSelector("button[id='btn_cancel']"))), "Save Vendor Button");

    public HpgElement VproUserEmailId => new(_waitDriver.Until(e => e.FindElement(By.Id("vproUserEmailId"))), "VPRO Email Id Field");

	public HpgElement CheckVproStatus => new(_waitDriver.Until(e => e.FindElement(By.Id("btn_GetVPROStatus"))), "Check VPRO");

    public HpgElement VproActiveRbStatus => new(_waitDriver.Until(e => e.FindElement(By.Id("vpro_active"))), "VPRO Active");

    public HpgElement VproInActiveRbStatus => new(_waitDriver.Until(e => e.FindElement(By.Id("vpro_inactive"))), "VPRO In Active");

    public HpgElement VproNotFoundRbStatus => new(_waitDriver.Until(e => e.FindElement(By.Id("vpro_notfound"))), "VPRO Not Found");

    public HpgElement VproLabelExpirationDays => new(_waitDriver.Until(e => e.FindElement(By.Id("lbl-expiration-days-remaining"))));

    public HpgElement VproCalender => new(_waitDriver.Until(e => e.FindElement(By.Id("dtpVproByPassEndDate"))));

    public HpgElement VproModal  => new(_waitDriver.Until(e => e.FindElement(By.CssSelector("#mat-dialog-1"))), "Modal");

    public HpgElement ModalContButton => new(_waitDriver.Until(e => e.FindElement(By.CssSelector("button[accesskey='Y']"))), "Continue (ALT+Y)");

	public HpgElement ModalSetNoExpirationButton => new(_waitDriver.Until(e => e.FindElement(By.CssSelector("button[accesskey='N'"))), "Set No Expiration (ALT+N) ");

	public HpgElement ModalCancelButton => new(_waitDriver.Until(e => e.FindElement(By.CssSelector("button[accesskey='N'"))), "Cancel (ALT+N)");

    public HpgElement ModalVproHeader => new(_waitDriver.Until(e => e.FindElement(By.XPath("/html/body/div[3]/div[4]/div/mat-dialog-container/app-confirmation-dialog/div/h1"))));

	public HpgElement ConfirmationYesButton => new(_waitDriver.Until(e => e.FindElement(By.CssSelector("button[accesskey='Y']"))), "Confirmation Yes Button");

    public HpgElement ConfirmationNoButton => new(_waitDriver.Until(e => e.FindElement(By.CssSelector("button[accesskey='N']"))), "Confirmation No Button");

	#endregion Create Vendor Blade

	#endregion Page Objects

	#region Action

	public void CheckRedirectAndExpand()
    {
        WaitForThrobber(10);

        if (SecurityTile.Exists())
        {
            WaitForThrobber(10);
            SecurityTile.Click();
            WaitForThrobber(10);
        }

        ExpandSecuritySearch();
        ValidateSearchPageElements();
    }

    public void ExpandSecuritySearch()
    {
        Steps.AddTestStep("Expanding Security Search Window.", "The Security Search should expand.");
        WaitForThrobber(30);
        SecurityOverlay.Click();

        Steps.AddScreenShot(_browser.TakeBase64Screenshot());        
    }

    public void SearchUser(UserSearch searchParams)
    {
        var properties  = typeof(UserSearch).GetProperties();
        var stepBuilder = new StringBuilder("Input the following parameters into the search fields: ");

        foreach (var property in properties)
        {
            var propertyValue = property.GetValue(searchParams);
            if (propertyValue.ToStringOrEmpty().Equals(string.Empty)) continue;

            stepBuilder.Append($"{property.Name} - {propertyValue} ");

            switch (property.Name)
            {
                case "UserId":
                    UserIdInput.Type(propertyValue.ToStringOrEmpty());
                    break;
                case "FirstName":
                    FirstNameInput.Type(propertyValue.ToStringOrEmpty());
                    break;
                case "LastName":
                    LastNameInput.Type(propertyValue.ToStringOrEmpty());
                    break;
                case "Email":
                    EmailInput.Type(propertyValue.ToStringOrEmpty());
                    break;
            }
        }

        Steps.AddTestStep(stepBuilder.ToString(), "User should be able to enter input parameters.");
        SearchButton.Click(5);
        WaitForThrobber();
        SearchResultLabel.Exists(true);

        FilterTypeStatus(searchParams);
    }

    public void SearchSpecificUser(UserResponse user, IEnumerable<UserResponse> dbUsers)
    {
        var searchParam = new UserSearch
        {
            FirstName = user!.FirstName,
            LastName  = user.LastName,
            UserId    = user.Username
        };

        Steps.AddTestStep($"Search for Specified user with User ID: '{searchParam.UserId}', First Name: '{searchParam.FirstName}', and Last Name: '{searchParam.LastName}.","User should be able to search for user with the specified criteria.");
        SearchUser(searchParam);

        //This breaks occasionally because it matches on Firstname which is null for some test users that have been loaded. 
        var expectedUsers = dbUsers.Where(i =>
            i.FirstName.ToStringOrEmpty().ToUpper().Equals(user.FirstName.ToStringOrEmpty().ToUpper()) 
            && i.LastName.ToStringOrEmpty().ToUpper().Equals(user.LastName.ToStringOrEmpty().ToUpper()) 
            && i.Username.ToStringOrEmpty().ToUpper().Equals(user.Username.ToStringOrEmpty().ToUpper()));
		ValidateUserSearchResults(expectedUsers);
    }

    public void SearchSpecificUserAndClickEdit(UserResponse user)
    {
        var searchParam = new UserSearch
        {
            FirstName = user!.FirstName,
            LastName  = user.LastName,
            UserId    = user.Username
        };

        Steps.AddTestStep($"Search for Specified user with User ID: '{searchParam.UserId}', First Name: '{searchParam.FirstName}', and Last Name: '{searchParam.LastName}.", "User should be able to search for user with the specified criteria.");
        SearchUser(searchParam);
        ClickEditUser(user.Username);
    }

    public string? ClickEditUser(string? userName = null)
    {
        _waitDriver.Until(ExpectedConditions.ElementIsVisible(By.XPath("//table/tbody")));
        var resultTable = _waitDriver.Until(e => e.FindElement(By.XPath("//table/tbody")))
            .FindElements(By.XPath("tr")).ToList();
        string userClicked = null!;
        if (userName!.ToStringOrEmpty() == string.Empty)
        {
            var rowElement = resultTable.FirstOrDefault();
            var editUser = new HpgElement(rowElement.FindElement(By.CssSelector("a[id^='editUser']")),
                "Edit User Button");

            userClicked = rowElement.FindElement(By.CssSelector("td[id^='userThreeFourId']")).Text;
            Steps.AddTestStep($"Click on Edit button for ID: {userClicked}.",
                "Should be able to click on Edit button for the specified User.");
            editUser.Click(5);
        }
        else
        {
            bool isFound = false;
            foreach (var row in resultTable)
            {
                if (!row.FindElement(By.CssSelector("td[id^='userThreeFourId']")).Text.ToStringOrEmpty()
                        .Equals(userName,StringComparison.CurrentCultureIgnoreCase)) continue;
                var editUser = new HpgElement(row.FindElement(By.CssSelector("a[id^='editUser']")), "Edit User Button");
                userClicked = userName;

                Steps.AddTestStep($"Click on Edit button for ID: {userClicked}.",
                    "Should be able to click on Edit button for the specified User.");
                editUser.Click(5);
                isFound = true;
            }

            if (!isFound)
            {
                HPGAssert.Fail($"Unable to find User ID: {userName} ib the search result!");
            }
        }

        return userClicked.ToStringOrEmpty();
    }

    /// <summary>
    /// This is for advanced filter
    /// </summary>
    /// <param name="searchParams"><see langword="object"/>for search params</param>
    public void FilterTypeStatus(UserSearch searchParams)
    {
        //Check to see if any filters are necessary 
        if (searchParams.IncludeVendors.IsNull() && searchParams.IncludeActive.IsNull() &&
            searchParams.IncludeInactive.IsNull()) return;

        //expand Advanced Filter
        if (AdvanceFilterButton.Text.Contains("Advanced Filter")) AdvanceFilterButton.Click();

        //expand Type Filter
        if (FilterTypeExpansion.Element.GetAttribute("aria-disabled").Contains("false")) FilterTypeExpansion.Click();
        //Setup Type Filters
        if (!searchParams.IncludeEmployee.IsNull())
            SetFilterCheckBoxes(EmployeeFilterCheckBox, (bool)searchParams.IncludeEmployee);
        if (!searchParams.IncludeVendors.IsNull())
            SetFilterCheckBoxes(VendorFilterCheckbox, (bool)searchParams.IncludeVendors);

        //expand Status Filter
        if (FilterStatusExpansion.Element.GetAttribute("aria-disabled").Contains("false"))
            FilterStatusExpansion.Click();
        //Setup Status Filters
        if (!searchParams.IncludeActive.IsNull())
            SetFilterCheckBoxes(ActiveFilterCheckBox, (bool)searchParams.IncludeActive);
        if (!searchParams.IncludeInactive.IsNull())
            SetFilterCheckBoxes(InactiveFilterCheckBox, (bool)searchParams.IncludeInactive);
    }

    private void SetFilterCheckBoxes(HpgElement element, bool boxChecked)
    {
        var checkedStatus = element.Element.GetAttribute("aria-checked").ToBool();

        switch (checkedStatus)
        {
            case true when !boxChecked:
            case false when boxChecked:
                element.Click();
                break;
        }
    }

    public UserResponse CreateVendorUser(AddUserRequest newUser)
    {
        Steps.AddTestStep("Click on Create Vendor User Button and create a new vendor.", "User should be able to click on Create Vendor User Button and fill out the form to create a new vendor user.");
        CreateVendorUserButton.Click();
        //Fill the form
        CreateFirstName.Type(newUser.FirstName);
        CreateLastName.Type(newUser.LastName);
        CreateEmail.Type(newUser.Email);
        //CreateEmailId.Type(newUser.Email);
        //Todo: Add VproCheck & have vproStatus updated behind scenes
        Steps.AddScreenShot(_browser.TakeBase64Screenshot());

        SaveVendorButton.Click();
        WaitForThrobber(10);

        //validate user was created in the database.
        Steps.AddTestStep("Validate that the new user was created in the database.", "User should be able to see the new user in the database.");
        var userRepo = new UserRepository(GlobalTestVariables.Configuration["SmartSecurity:DatabaseServer"]!,
            GlobalTestVariables.Configuration["SmartSecurity:DatabaseName"]!);
        var expected = new UserResponse(newUser)
        {
            Username = newUser.Email,
            Domain   = "nonaffil",
            Type     = "Vendor",
            IsDeactivated = false
        };
        var actual = userRepo.GetAllUsers(5).First(i => i.Email.Equals(newUser.Email));

        HPGWarn.WarnRange(expected.Validate(actual));

        return actual;
    }

    public void RefreshScreen()
    {
        _browser.Driver.Navigate().Refresh();
    }

    #endregion Action

    #region Validations

    public void ValidateSearchPageElements()
    {
        Steps.AddTestStep("Validating that Search User Web Elements are shown.",
            "User should see the correct Web Elements.");
        HPGWarn.True(UserIdInput.Exists(), field: "User ID");
        HPGWarn.True(FirstNameInput.Exists(), field: "First Name");
        HPGWarn.True(LastNameInput.Exists(), field: "Last Name");
        HPGWarn.True(EmailInput.Exists(), field: "Email");
        //HPGWarn.True(CompanyInput.Exists(), field: "Company"); //Note: No longer used. Remove by End of Next quarter if it doesn't get implemented
        HPGWarn.True(SearchButton.Exists(), field: "Search Button");
	}

    public void ValidateUserSearchResults(IEnumerable<UserResponse> expectedUsers)
    {
        Steps.AddTestStep("Validate user search results.", "Should match the expected list of users.");
        var expectedList = expectedUsers.Select(user => new UserSearchResult
        {
            Id     = user.Username.Trim().ToUpper(),
            Domain = user.Domain.ToUpper(),
            Name   = $"{(user.FirstName.IsNull() ? "null" : user.FirstName) } {user.LastName}",
            Type   = user.Type,
            Status = user.IsDeactivated ? "Inactive" : "Active"
        }).ToList();

		var actualList = GetUserSearchResults()
            .Where(user => user.Type.Equals("Employee", StringComparison.OrdinalIgnoreCase))
            .ToList();

		ValidateUserSearchResultList(expectedList, actualList);
    }

    private void ValidateUserSearchResultList(List<UserSearchResult> expectedList, List<UserSearchResult> actualList)
    {
        Steps.AddTestStep("Validate expected users are in actual list.", "Should match expected");
        var actualDictionary = actualList.ToDictionary(i => i.Id.ToStringOrEmpty().Trim().ToUpper(), j => j);
        foreach (var expected in expectedList)
        {
            if (!actualDictionary.TryGetValue(expected.Id.ToStringOrEmpty().Trim().ToUpper(), out var actual))
                HPGWarn.Warn($"Expecting ID: '{expected.Id.ToStringOrEmpty().Trim().ToUpper()}' in Actual but was not found!");
            else
            {
                HPGWarn.WarnRange(expected.Validate(actual));
            }
        }

        Steps.AddTestStep("Validate actual users are in expected list.", "Should match actual.");
        var expectedDictionary = expectedList.ToDictionary(i => i.Id.ToStringOrEmpty().Trim().ToUpper(), j => j);
        foreach (var actual in actualList)
        {
            if (!expectedDictionary.TryGetValue(actual.Id.ToStringOrEmpty().Trim().ToUpper(), out var expected))
                HPGWarn.Warn($"Expecting Actual ID: '{actual.Id.ToStringOrEmpty().Trim().ToUpper()}' in Expected but was not found!");
            else
            {
                HPGWarn.WarnRange(actual.Validate(expected));
            }
        }
    }

    public void ValidateModalPupUp(string vproStatusType)
    {
		Steps.AddTestStep("Validating that VPRO Modal Pop Up is shown.",
			"User should see the correct Web Elements.");
		WaitForThrobber();
		HPGWarn.True(ModalContButton.Exists(), field: "Modal Continue Button");
		if (vproStatusType == "Active")
		{
			HPGWarn.True(ModalSetNoExpirationButton.Exists(), field: "Set No Expiration (ALT+N) ");
		}
		else //Inactive or Not Found
		{
			HPGWarn.True(ModalCancelButton.Exists(), field: "Modal Cancel Button");
		}
	}

    public void ValidateCreateVendorBlade()
    {
	    Steps.AddTestStep("Validating that Add Vendor User Blade Web Elements are shown.",
		    "User should see the correct Web Elements.");
	    HPGWarn.True(CreateFirstName.Exists(), field: "First Name");
	    HPGWarn.True(CreateLastName.Exists(), field: "Last Name");
	    HPGWarn.True(CreateEmail.Exists(), field: "Email");
		HPGWarn.True(VproUserEmailId.Exists(), field: "VPRO EmailId");
		HPGWarn.True(CheckVproStatus.Exists(), field: "Check VPRO");
	    HPGWarn.True(VproActiveRbStatus.Exists(), field: "VPRO Active");
	    HPGWarn.True(VproInActiveRbStatus.Exists(), field: "VPRO Inactive");
	    HPGWarn.True(VproNotFoundRbStatus.Exists(), field: "VPRO Not Found"); 
	    HPGWarn.True(SaveVendorButton.Exists(), field: "Save Vendor Button");
    }
    #endregion Validations

    #region Helpers

    private IEnumerable<UserSearchResult> GetUserSearchResults()
    {
        _waitDriver.Until(ExpectedConditions.ElementIsVisible(By.XPath("//table/tbody")));
        Steps.AddScreenShot(_browser.TakeBase64Screenshot());        
        var resultTable = _waitDriver.Until(e => e.FindElement(By.XPath("//table/tbody")))
            .FindElements(By.XPath("tr")).ToList();
        //todo: add pagination grab

        #region debug block
        //List<UserSearchResult> temp = new();  
        //foreach (var result in resultTable)
        //{
        //    var temptext = result.Text;
        //    temp.Add(new UserSearchResult()
        //    {
        //        Id = result.FindElement(By.CssSelector("td[id^='userThreeFourId']")).Text.ToStringOrEmpty(),
        //        Domain = result.FindElement(By.CssSelector("td[id^='domain']")).Text.ToStringOrEmpty(),
        //        Name = result.FindElement(By.CssSelector("td[id^='userName']")).Text.ToStringOrEmpty(),
        //        Type = result.FindElement(By.CssSelector("td[id^='userType']")).Text.ToStringOrEmpty(),
        //        Status = result.FindElement(By.CssSelector("td[id^='userStatus']")).Text.ToStringOrEmpty()
        //    });
        //}
        #endregion debug block

        return resultTable.Select(row => new UserSearchResult
        {
            Id     = row.FindElement(By.CssSelector("td[id^='userThreeFourId']")).Text.ToStringOrEmpty().ToUpper(),
            Domain = row.FindElement(By.CssSelector("td[id^='domain']")).Text.ToStringOrEmpty(),
            Name   = row.FindElement(By.CssSelector("td[id^='userName']")).Text.ToStringOrEmpty(),
            Type   = row.FindElement(By.CssSelector("td[id^='userType']")).Text.ToStringOrEmpty(),
            Status = row.FindElement(By.CssSelector("td[id^='userStatus']")).Text.ToStringOrEmpty()
        }).ToList();
    }

    #endregion Helpers
}
﻿using System.Collections.Generic;
using System.Linq;
using Utilities.ObjectExtensions;
using Utilities.Validation;

namespace SmartSecurityTestAutomation.Page.Objects.SearchPage;

public class UserSearchResult
{
  public string? Id     { get; set; }
  public string? Domain { get; set; }
  public string? Name   { get; set; }
  public string? Type   { get; set; }
  public string? Status { get; set; }

  public List<string> Validate(UserSearchResult other)
  {
    var results = new List<string>()
    {
      ValidationHelpers.AreEqual(this.Id.ToStringOrEmpty().ToUpper(), other.Id.ToStringOrEmpty().ToUpper(),"ID"),
      ValidationHelpers.AreEqual(this.Domain.ToStringOrEmpty().ToUpper(), other.Domain.ToStringOrEmpty().ToUpper(),"Domain"),
      ValidationHelpers.AreEqual(this.Name.ToStringOrEmpty(), other.Name.ToStringOrEmpty(),"Name"),
      ValidationHelpers.AreEqual(this.Type.ToStringOrEmpty(), other.Type.ToStringOrEmpty(),"Type"),
      ValidationHelpers.AreEqual(this.Status.ToStringOrEmpty(), other.Status.ToStringOrEmpty(),"Status"),
    };

    return results.Where(i => i != string.Empty).ToList();
  }
}
﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
using SmartSecurityTestAutomation.Enums;
using SmartSecurityTestAutomation.Services.Applications;
using SmartSecurityTestAutomation.Services.Home;
using SmartSecurityTestAutomation.Services.Users;
using SmartSecurityTestAutomation.Services.Vendor;
using SmartSecurityTestAutomation.Tests;
using Utilities.ObjectExtensions;
using WebUiAutomation;

namespace SmartSecurityTestAutomation.Page.Objects.UserDetailPage;

public class UserDetailPage : AdminPageMaster
{
    private readonly WebDriverWait         _waitDriver;
    private readonly Browser               _browser;
    private readonly UserRepository        _userRepository;
    private readonly ApplicationRepository _applicationRepository;

    private const string EmployeeSpocSaveError = "This user must have an associated span of control to save.";
    private const string EmployeeRoleSaveError = "This user must have an associated role to save.";

    private const string VendorSaveError =
        "This user must have an associated application, vendor affiliation, role and span of control selected to save.";

    private const string UserSaveSuccessful = "The User Changes Saved Successfully";


    public UserDetailPage(Browser browser) : base(browser)
    {
        _waitDriver = new WebDriverWait(browser.Driver, TimeSpan.FromSeconds(60));
        _browser    = browser;
        _userRepository =
            new UserRepository(GlobalTestVariables.Configuration["SmartSecurity:DatabaseServer"]!,
                GlobalTestVariables.Configuration["SmartSecurity:DatabaseName"]!);
        _applicationRepository =
            new ApplicationRepository(GlobalTestVariables.Configuration["SmartSecurity:DatabaseServer"]!,
                GlobalTestVariables.Configuration["SmartSecurity:DatabaseName"]!);
    }

    #region Page Objects

    #region Top Level Tabs

    public HpgElement UsersTab   => new(_waitDriver.Until(e => e.FindElement(By.Id("tab_users"))), "User Tab");
    public HpgElement ReportsTab => new(_waitDriver.Until(e => e.FindElement(By.Id("tab_reports"))), "Reports Tab");

    #endregion Top Level Tabs

    #region User Detail Box
																						
    public HpgElement FirstNameField => new(_waitDriver.Until(e => e.FindElement(By.XPath("//div[@id='firstName']"))),
        "First Name Field");

    public HpgElement LastNameField => new(_waitDriver.Until(e => e.FindElement(By.XPath("//div[@id='lastName']"))),
        "Last Name Field");

    public HpgElement EmailField =>
        new(_waitDriver.Until(e => e.FindElement(By.XPath("//div[@id='email']"))), "Email Field");

    public HpgElement IdField      => new(_waitDriver.Until(e => e.FindElement(By.Id("userId"))), "Id Field");
    public HpgElement TypeField    => new(_waitDriver.Until(e => e.FindElement(By.Id("userType"))), "Type Field");
    public HpgElement CompanyField => new(_waitDriver.Until(e => e.FindElement(By.Id("company"))), "Company Field");

    public HpgElement UserStatus =>
        new(_waitDriver.Until(e => e.FindElement(By.CssSelector("mat-checkbox[id='userStatus']"))), "User Status");

    public HpgElement UserStatusCheckBox => new(_waitDriver.Until(e => e.FindElement(By.Id("userStatus-input"))),
        "User Status Checkbox");

    public HpgElement UserStatusInputCheckBox => new(
        _waitDriver.Until(e => e.FindElement(By.XPath("//input[@id='userStatus-input']/parent::*"))),
        "User Status Input Checkbox");

    public HpgElement ApplicationSelectDropDown => new(_waitDriver.Until(e => e.FindElement(By.Id("ddl_roles_appList"))), "Select Application");
	public HpgElement CheckVproStatus => new(_waitDriver.Until(e => e.FindElement(By.Id("btn_GetVPROStatus"))), "Check VPRO");
    public HpgElement VproActiveRbStatus => new(_waitDriver.Until(e => e.FindElement(By.Id("vpro_active"))), "VPRO Active");
    public HpgElement VproInActiveRbStatus => new(_waitDriver.Until(e => e.FindElement(By.Id("vpro_inactive"))), "VPRO In Active");
    public HpgElement VproNotFoundRbStatus => new(_waitDriver.Until(e => e.FindElement(By.Id("vpro_notfound"))), "VPRO Not Found");
    public HpgElement VproLabelExpirationDays => new(_waitDriver.Until(e => e.FindElement(By.Id("lbl-expiration-days-remaining"))), "Days to Expiration - By Pass Ends");
	public HpgElement VproByPassCalendar => new(_waitDriver.Until(e => e.FindElement(By.Id("dtpVproByPassEndDate"))));
	public HpgElement VproUserEmailId => new(_waitDriver.Until(e => e.FindElement(By.Id("vproUserEmailId"))), "VPRO Email Id Field");
	public HpgElement ExternalEmailAddressLbl => new(_waitDriver.Until(e => e.FindElement(By.CssSelector("label[for='vproUserEmailId'] mat-label"))), "External Email Address Label");

	#endregion User Detail Box

	#region User Tabs
	public HpgElement RolesTab => new(_waitDriver.Until(e => e.FindElement(By.Id("tab_roles"))), "Roles Tab");

    public HpgElement SpanOfControlTab =>
        new(_waitDriver.Until(e => e.FindElement(By.Id("tab_soc"))), "Span Of Control Tab");

	public HpgElement VproFacilitiesTab => 
	    new(_waitDriver.Until(e => e.FindElement(By.CssSelector("#tab_vpro-facilities"))), "VPRO Facilities");
	#endregion User Tabs

	#region Role Tab

	public HpgElement AvailableRoleBox => new(_waitDriver.Until(e => e.FindElement(By.Id("dv_availableRoles"))),
        "Available Roles Box");

    public HpgElement AssignedRoleBox =>
        new(_waitDriver.Until(e => e.FindElement(By.Id("assignedRoles"))), "Assigned Role Box");

    public HpgElement SnackBarNotification =>
        new(_waitDriver.Until(e => e.FindElement(By.CssSelector("span[class='mat-simple-snack-bar-content']"))),
            "Notification Bar");

    public HpgElement SnackBarNotificationButton => new(_waitDriver.Until(e =>
            e.FindElement(By.CssSelector("snack-bar-container[class^='mat-snack-bar-container'] button"))),
        "Snack Bar Notification Button");

    #endregion Role Tab

    #region Vendor Affiliation Tab

    public HpgElement VendorAffiliationLabel =>
        new(_waitDriver.Until(e => e.FindElement(By.Id("tab_vendorAffliation"))), "Vendor Affiliation");

    public HpgElement VendorSearchInput =>
        new(_waitDriver.Until(e => e.FindElement(By.XPath("//input[@data-placeholder='Search Vendors']"))),
            "Vendor Search Input");

    public HpgElement VendorSearchButton => new(
        _waitDriver.Until(e => e.FindElement(By.CssSelector("button[id='btn_vendorSearch']"))),
        "Vendor Search Button");

    public HpgElement AvialableVendorBox => new(_waitDriver.Until(e => e.FindElement(By.Id("dv_availableVendors"))),
        "Available Vendor Box");

    public HpgElement AssignedVendorBox => new(_waitDriver.Until(e => e.FindElement(By.Id("assignedVendors"))),
        "Assigned Vendor Box");

    public HpgElement VendorAssignButton => new(_waitDriver.Until(e => e.FindElement(By.Id("btn_assign_vendor"))),
        "Vendor Assign Button");

    public HpgElement VendorUnAssignButton => new(_waitDriver.Until(e => e.FindElement(By.Id("btn_unAssign_vendor"))),
        "Vendor Un-Assign Button");

    public HpgElement VendorUnAssignAllButton =>
        new(_waitDriver.Until(e => e.FindElement(By.Id("btn_unAssignAll_vendor"))), "Vendor Un-Assign All Button");

    #endregion Vendor Affiliation Tab

    #region SOC Tab

    public HpgElement MemberSearch =>
        new(_waitDriver.Until(e => e.FindElement(By.XPath("//div[@id='autocomplete-container']//input"))),
            "Member Search");
    public HpgElement SocTabButton => new(_waitDriver.Until(e => e.FindElement(By.Id("tab_soc"))), "SOC Tab");
	#endregion SOC Tab

	#region VPRO Tab - Panel
	public HpgElement VproFacilitiesPanel => new(_waitDriver.Until(e => e.FindElement(By.Id("vpro-facilities-panel"))));
		public HpgElement ReCheckFacilityAccessButton => new(_waitDriver.Until(e => e.FindElement(By.Id("btn_CheckFacilityAccess"))), "Re-Check Facility Access");
		public HpgElement FacilityItem => new(_waitDriver.Until(e => e.FindElement(By.Id("ckbFacility_"))), "Facility Checkbox");
		public HpgElement lblSocDate => new(_waitDriver.Until(e => e.FindElement(By.CssSelector("#fac-table-header > div:nth-child(2)"))), "SoC Since");
        public HpgElement lblVproSince => new(_waitDriver.Until(e => e.FindElement(By.CssSelector("#fac-table-header > div:nth-child(3)"))), "VPRO Since");
        public HpgElement lblVproFacilitiesOutsideSoc => new(_waitDriver.Until(e => e.FindElement(By.ClassName("fac-table-subheader"))), "VPRO Facilities Outside of SoC");

	#endregion

	#region GCN Group Elements on Soc Tab

	public HpgElement GcnGroupLabel => new(_waitDriver.Until(e => e.FindElement(By.Id("gcn-group-label"))), "GCN Group Label");
	public HpgElement GcnGroupSection => new(_waitDriver.Until(e => e.FindElement(By.CssSelector(".gcn-groups-section"))), "GCN Group Section");
	public IReadOnlyCollection<IWebElement> GcnGroupRows => GcnGroupSection.Element.FindElements(By.CssSelector(".gcn-group-row"));

	#endregion

	#region Confirmation Box

	public HpgElement ConfirmationHeader =>
        new(_waitDriver.Until(e => e.FindElement(By.CssSelector("h1[id^='mat-dialog-title']"))), "Confirmation Header");

    public HpgElement ConfirmationMessage =>
        new(_waitDriver.Until(e => e.FindElement(By.CssSelector("div[class='mat-dialog-content']"))),
            "Confirmation Message");

    public HpgElement ConfirmationYesButton => new(
        _waitDriver.Until(e => e.FindElement(By.CssSelector("button[accesskey='Y']"))), "Confirmation Yes Button");

    public HpgElement ConfirmationNoButton => new(
        _waitDriver.Until(e => e.FindElement(By.CssSelector("button[accesskey='N']"))),
        "Confirmation No Button");

    #endregion Confirmation Box

    public HpgElement AssignButton =>
        new(_waitDriver.Until(e => e.FindElement(By.CssSelector("button[id='btn_assign']"))), "Assign Button");

    public HpgElement AssignAllButton =>
        new(_waitDriver.Until(e => e.FindElement(By.Id("btn_assignAll"))), "Assign All Button");

    public HpgElement UnassignButton =>
        new(_waitDriver.Until(e => e.FindElement(By.Id("btn_unAssign"))), "Unassign Button");

    public HpgElement UnassignAllButton =>
        new(_waitDriver.Until(e => e.FindElement(By.Id("btn_unAssignAll"))), "Unassign All Button");

    public HpgElement InactiveButton =>
        new(_waitDriver.Until(e => e.FindElement(By.Id("btn_deactivate"))), "Inactive Button");

    public HpgElement CancelButton => new(_waitDriver.Until(e => e.FindElement(By.Id("btn_cancel"))), "Cancel Button");
    public HpgElement SaveButton   => new(_waitDriver.Until(e => e.FindElement(By.Id("btn_save"))), "Save Button");

    #endregion Page Objects

    #region Actions

    public void AddRolesSocVendorAffiliation(AddUserRoleSoc? limitedRollUser = null, bool bypassErrorCheck = false,
        UserResponse user = null)
    {
        //Get user info and reset user
        var userName = IdField.Text.Trim();
        var userInfo = bypassErrorCheck
            ? user
            : _userRepository.GetAllUsers().FirstOrDefault(i => i.Username.ToStringOrEmpty().Equals(userName));

        //Selects a random application from the drop down list.
        ApplicationSelection("SMART - Procurement");

        //Add User Roles
        var assignedRoles = AddUserRoles(userInfo, bypassErrorCheck);

        //Add SOC
        var assignedSoc = AddUserSoc(userInfo, limitedRollUser);

        //If user is a vendor type user then add Vendor Affiliation.
        if (userInfo.Type.Equals("Vendor"))
        {
            AddVendorAffiliation(userInfo);
            ValidateAssignedSoc(userInfo, assignedSoc);
        }

        ValidateAssignedRoles(userInfo, assignedRoles.ToList());
    }

    public void RemoveRolesSocVendorAffiliation()
    {
        //user info
        var userId     = IdField.Text.Trim();
        var userDbList = _userRepository.GetAllUsers();
        var userInfo   = userDbList.FirstOrDefault(i => i.Username!.Equals(userId, StringComparison.OrdinalIgnoreCase));

        //If Vendor Remove Vendor Affiliation
        if (userInfo.Type.Equals("Vendor"))
        {
            TestRemoveAllVendorAffiliation(userInfo);
            RemoveVendorAffiliation(userInfo);
        }

        //need to choose application to remove role and spoc
        var userRole = _userRepository.GetAllUserRoleDb(userInfo.Id.ToString()).FirstOrDefault(i => !i.IsDeleted);
        var application = _applicationRepository.GetApplicationsDb()
            .FirstOrDefault(i => i.ApiKey.ToString().Equals(userRole!.ApplicationId.ToString()));

        ApplicationSelection(application!.Name);

        //Remove SOC
        RemoveUserSoc(userInfo, userRole!.ApplicationId);

        //Remove Role(s)
        RemoveUserRoles(userInfo, userRole.ApplicationId);
    }

    public IEnumerable<string> AddUserRoles(UserResponse userInfo, bool bypassErrorCheck)
    {
        Steps.AddTestStep($"Adding User Role for User: '{userInfo.Username}-{userInfo.FirstName} {userInfo.LastName}'.",
            "User should be able to add roles for the specified user.");

        //click on Roles tab
        SaveButton.ScrollIntoView();
        RolesTab.Click();

        //choose random role(s) that the user does not have.
        var AvailableRoles = AvailableRoleBox.Element.FindElements(By.XPath(".//mat-list-option"));
        var randomRoles = AvailableRoles.Count != 0 
            ? AvailableRoles.PickRandomList(AvailableRoles.Count).Distinct()
            : [];
        
        var rolesSelected = new List<string>();

        foreach (var randomRole in randomRoles)
        {
            Steps.AddTestStep($"Clicking on {randomRole.Text}.", "User should be able to select that role.");
            rolesSelected.Add(randomRole.Text.Trim());
            randomRole.Click();
        }

        if (randomRoles.Any())
            AssignButton.Click();

        //verify roles selected are in the assigned roles box
        var assignedRolesData = AssignedRoleBox.Element.FindElements(By.XPath(".//mat-list-option"))
            .Select(i => i.Text.Trim()).ToList();

        if (randomRoles.Any())
        {
            foreach (var expectedRole in rolesSelected)
            {
                if (!assignedRolesData.Contains(expectedRole))
                {
                    HPGWarn.Warn($"Expecting role '{expectedRole}' to be in Assigned Roles Box but was not!");
                }
                else
                {
                    ConsoleOut.WriteReport($"Expected role '{expectedRole}' to be in Assigned Roles Box was true.");
                }
            }
        }        

        Steps.AddScreenShot(_browser.TakeBase64Screenshot());        

        if (!bypassErrorCheck)
        {
            //Save and Verify in Database.
            var expectedSaveError = userInfo.Type.Equals("Vendor")
                ? VendorSaveError
                : EmployeeSpocSaveError;

            ScrollSaveValidateNotificationMessage(expectedSaveError);
            ValidateAssignedRoles(userInfo, assignedRolesData, false);
        }

        return assignedRolesData;
    }

    public void RemoveUserRoles(UserResponse userResponse, Guid applicationKey)
    {
        RolesTab.Click();
        WaitForThrobber();

        //Get current roles for user.
        var userRoles = _userRepository.GetAllUserRoleDb(userResponse.Id.ToString())
            .Where(i => !i.IsDeleted);

        var userRoleApps = userRoles.Where(i => i.ApplicationId.Equals(applicationKey));

        //choose random role(s) that the user does have.
        var roleToBeRemoved = userRoleApps.PickRandom();
        var expectedRoles   = userRoles.Where(i => !i.Id.Equals(roleToBeRemoved.Id));

        //get role element 
        var roleElement =
            new HpgElement(
                AssignedRoleBox.Element.FindElements(By.XPath(".//mat-list-option"))
                    .First(i => i.Text.Trim().Contains(roleToBeRemoved.Name)), $"Role {roleToBeRemoved.Name}");
        roleElement.Click();
        SaveButton.ScrollIntoView();
        UnassignButton.Click();

        var expectedMessage = expectedRoles.IsNullOrEmpty()
            ? userResponse.Type.Equals("Vendor") ? VendorSaveError : EmployeeRoleSaveError
            : UserSaveSuccessful;

        ScrollSaveValidateNotificationMessage(expectedMessage);

        if (expectedRoles.IsNull()) expectedRoles = userRoles;

        //validate db save
        var actualRoles = _userRepository.GetAllUserRoleDb(userResponse.Id.ToString()).Where(i => !i.IsDeleted);
        ValidateAssignedRolesList(expectedRoles.ToList(), actualRoles.ToList());
    }

    public List<HomeDataDb> AddUserSoc(UserResponse userInfo, AddUserRoleSoc? limitedRollUser)
    {
        Steps.AddTestStep(
            $"Adding Span of Control for User: '{userInfo.Username}-{userInfo.FirstName} {userInfo.LastName}'",
            "Should be able to add Span of Control for the specified user.");

        /* The below is for debugging purposes:
        //var strLimtedRollUserDetails = $"limitedRoleUser - UserId: {limitedRollUser.UserId.ToString()} , limitedRoleUser - ApplicationId: {limitedRollUser.ApplicationId}," +
        //$"\r\nlimitedRoleUser - IsDeactivated: {limitedRollUser.IsDeactivated.ToString()}," +
        //$"\r\nlimitedRoleUser - RoleIds: {limitedRollUser.RoleIds.ToString()}," +
        //$"\r\nlimitedRoleUser - SpanOfControl: {limitedRollUser.SpanOfControl.ToString()}," +
        //$"limitedRoleUser - VendorAffiliation: {limitedRollUser.VendorAffiliation.ToString()}," +
        //$"r\nlimitedRoleUser - VproStatus: {limitedRollUser.VproStatus}," +
        //$"r\nlimitedRoleUser - ByPassVPROEndDate: {limitedRollUser.ByPassVPROEndDate.ToString()}," +
        //$"\r\nlimitedRoleUser - VPROUserEmailId: {limitedRollUser.VPROUserEmailId}," +
        //$"\r\nlimitedRoleUser - Roles: {limitedRollUser.Roles}," +
        //$"\r\nlimitedRoleUser - IsSmartSecurity: {limitedRollUser.IsSmartSecurity.ToString()}," +
        //$"limitedRoleUser - UserGcnGroups.GroupId: {limitedRollUser.UserGcnGroups[0].GroupId}, UserGcnGroups.GroupName: {limitedRollUser.UserGcnGroups[0].GroupName}, UserGcnGroups.IsSelected: {limitedRollUser.UserGcnGroups[0].IsSelected}, " +
        //$"GroupCount: {limitedRollUser.UserGcnGroups.Count.ToString()}";
		//ConsoleOut.WriteReport($"Limited Role User Details: {strLimtedRollUserDetails}"); */

		//Search and Select Span of Control
		SpanOfControlTab.Click();

        //if limited roll user than get SPOC.
        var homeActive       = RetrieveHomeDataList(limitedRollUser);
        var randomFacilities = homeActive.PickRandomList(3);
        randomFacilities.Add(homeActive.First(i => i.COID == "00022"));


        if (!limitedRollUser.IsNull()) ValidateSecurityUserSOC(limitedRollUser);

        foreach (var facility in randomFacilities)
        {
            //todo: need to think about assigning at different levels.
            MemberSearchAndSelect(facility);
        }

        //Save and Validate
        SaveButton.ScrollIntoView();
        SaveButton.Click();
        AwaitElement(SnackBarNotification);        

        HPGWarn.AreEqual(userInfo.Type.Equals("Vendor") ? VendorSaveError : UserSaveSuccessful,
            SnackBarNotification.Text, toTruncate: false,field: SnackBarNotification.Identifier);

        Steps.AddScreenShot(_browser.TakeBase64Screenshot());       

        ValidateAssignedSoc(userInfo, randomFacilities, !userInfo.Type.Equals("Vendor"));

        return randomFacilities;
    }

    private void MemberSearchAndSelect(HomeDataDb member)
    {
        MemberSearch.Click();
        WaitForThrobber(10);
        MemberSearch.Type(member.COID.Trim());
        IEnumerable<IWebElement> membersReturned;

        //dynamic wait to pull in list of members off the UI
        var retryCount = 0;
        do
        {
            membersReturned = _waitDriver.Until(e => e.FindElements(By.XPath("//mat-option")));
            Thread.Sleep(500);
            retryCount++;
        } while (membersReturned.Count().Equals(0) && retryCount < 10);

        if (membersReturned.Count().Equals(0))
            HPGAssert.Fail("Unable to choose span of control!");

        try
        {
            var memberElement = membersReturned.Count().Equals(1)
                ? new HpgElement(membersReturned.FirstOrDefault(), membersReturned.FirstOrDefault()!.Text)
                : new HpgElement(membersReturned.FirstOrDefault(i => i.Text.Contains($"{member.Name} ({member.COID})")),
                    member.Name);

            memberElement.Click();
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw new Exception($"Unable to select {member.Name} ({member.COID}) from Span of Control selection!");
        }

        var membersSelected = _browser.Driver.FindElements(By.CssSelector("div[class^='selected-soc'] div"));
        HPGWarn.True(membersSelected.Any(i => i.Text.Contains(member.Name)), field: "Selected Members");
    }

    public void RemoveUserSoc(UserResponse userResponse, Guid applicationKey)
    {
        SpanOfControlTab.Click();
        WaitForThrobber();

        var userSpoc = _userRepository.GetAllUserSocDb(userResponse.Id)
            .Where(i => !i.IsDeleted && i.ApplicationId.Equals(applicationKey));
        var spocToBeRemoved = userSpoc.PickRandom();
        
        //todo: need to update to ref.home
        var homeDb = new HomeRepository(GlobalTestVariables.Configuration["Home:DatabaseServer"], 
            GlobalTestVariables.Configuration["Home:DataBaseName"]);
        var homeDbData = homeDb.GetHomeData();
        var spocName   = HomeRepository.GetSpecificHomeName((HomeHierarchyType)spocToBeRemoved.Hierarchy, spocToBeRemoved.OrgObjectID, homeDbData);
        //var spocName = homeApi.GetHomeName(spocToBeRemoved.Hierarchy.ToString(), spocToBeRemoved.OrgObjectID)
        //    .Replace("\"", "");
        
        var expectedUserSpoc = userSpoc.Where(i => !i.OrgObjectID.Equals(spocToBeRemoved.OrgObjectID));

        Steps.AddTestStep($"Span of Control to be removed '{spocName}' from User: '{userResponse.Username}'.",
            "System should allow the Span of Control to be removed.");

        var spocElement =
            new HpgElement(
                _browser.Driver.FindElements(By.CssSelector("div[class^='selected-soc'] div"))
                    .First(i => i.Text.Contains(spocName)).FindElement(By.CssSelector("input")),
                $"Span of Control: '{spocName}'");

        spocElement.Click();

        //save and validate
        ScrollSaveValidateNotificationMessage(UserSaveSuccessful);

        var actualUserSpoc = _userRepository.GetAllUserSocDb(userResponse.Id, 1)
            .Where(i => !i.IsDeleted && i.ApplicationId.Equals(applicationKey));

        ValidateAssignedSoc(expectedUserSpoc.ToList(), actualUserSpoc.ToList());
    }

    public void AddVendorAffiliation(UserResponse userInfo)
    {
        Steps.AddTestStep($"Adding Vendor Affiliation to User: '{userInfo.Username}'.",
            "User should be able to search and add vendor affiliations.");

        UsersTab.ScrollIntoView();

        //pick 3 random vendors
        var vendorDb = new VendorRepository(GlobalTestVariables.Configuration["VendorMaster:DatabaseServer"]!,
            GlobalTestVariables.Configuration["VendorMaster:DataBaseName"]!);
        var testVendors = vendorDb.GetVendorInfo().Where(i => i.IsActive).PickRandomList(3);

        //search for vendor and add
        var expectedVendorAffiliation = new List<UserVendorAffiliationDb>();
        foreach (var vendor in testVendors)
        {
            Steps.AddTestStep($"Search for Vendor: '{vendor.Name} - {vendor.Snv}'.",
                "User should be able to search for vendor.");
            VendorSearchInput.Type(vendor.Snv.ToString());
            VendorSearchButton.Click();
            WaitForThrobber(30);

            var vendorElement =
                new HpgElement(AvialableVendorBox.Element.FindElement(By.Id($"li_availableVendors_{vendor.Snv}")),
                    $"{vendor.Name} - {vendor.Snv} List Element");

            vendorElement.Click();
            VendorAssignButton.Click();
            WaitForThrobber();

            //verify vendor selected are in the assigned vendor box
            HPGWarn.True(
                AssignedVendorBox.Element.FindElements(By.XPath(".//mat-list-option")).Any(i =>
                    i.Text.Trim().Equals($"{vendor.Name} - {vendor.Snv}", StringComparison.CurrentCultureIgnoreCase)),
                field: "Assigned Vendor Box");

            //Add to expected vendor list
            expectedVendorAffiliation.Add(new UserVendorAffiliationDb()
                { UserId = userInfo.Id, VendorId = vendor.Snv, IsDeleted = false });

            //clear search input
            VendorSearchInput.Element.Clear();
        }

        //click save
        ScrollSaveValidateNotificationMessage(UserSaveSuccessful);

        //validate in database
        if (userInfo.Id.IsNull() || userInfo.Id.ToString().Equals("00000000-0000-0000-0000-000000000000"))
            userInfo = _userRepository.GetAllUsers(timeToWait: 2)
                .FirstOrDefault(i => i.Username.Equals(userInfo.Username));

        var actualResults = _userRepository.GetUserVendorAffiliationDb(userInfo.Id, 2).Where(i => !i.IsDeleted)
            .ToList();
        UserApi.ValidateVendorAffiliationDbList(expectedVendorAffiliation, actualResults);
    }

    public void RemoveVendorAffiliation(UserResponse userInfo)
    {
        //Scroll up
        VendorAffiliationLabel.ScrollIntoView();
        //Get and choose random vendor to remove
        var userCurrentVendorAffiliationDb = _userRepository.GetUserVendorAffiliationDb(userInfo.Id)
            .Where(i => !i.IsDeleted)
            .ToList();
        var vendorAffiliationToRemove = userCurrentVendorAffiliationDb.PickRandom();
        var expectedVendorAffiliation =
            userCurrentVendorAffiliationDb.Where(i => !i.VendorId.Equals(vendorAffiliationToRemove.VendorId)).ToList();
        var expectedVendorAffiliationText = expectedVendorAffiliation.Select(i => $"{i.VendorName}-{i.VendorId}");

        Steps.AddTestStep(
            $"Unassigned '{vendorAffiliationToRemove.VendorName}-{vendorAffiliationToRemove.VendorId}' from user.",
            "Should be able to remove vendor affiliation.");

        AssignedVendorBox.Element.FindElements(By.XPath(".//mat-list-option"))
            .First(i => i.Text.Trim().Contains(vendorAffiliationToRemove.VendorId.ToString())).Click();
        VendorUnAssignButton.Click();

        //validate assigned vendors box
        var currentVendorAffiliationText = AssignedVendorBox.Element.FindElements(By.XPath(".//mat-list-option"))
            .Select(i => i.Text.Trim());
        ValidateTextBox(expectedVendorAffiliationText, currentVendorAffiliationText);

        //validate available vendors box
        var availableVendor = AvialableVendorBox.Element.FindElements(By.CssSelector("div[class='mat-list-text']"))
            .Select(i => i.Text.Trim());
        ValidateTextBox(
            new List<string> { $"{vendorAffiliationToRemove.VendorName}-{vendorAffiliationToRemove.VendorId}" },
            availableVendor);

        //save and validate
        ScrollSaveValidateNotificationMessage(UserSaveSuccessful);

        var actualResults = _userRepository.GetUserVendorAffiliationDb(userInfo.Id, 1).Where(i => !i.IsDeleted)
            .ToList();
        UserApi.ValidateVendorAffiliationDbList(expectedVendorAffiliation, actualResults);
    }

    public void RemoveAllVendorAffiliation()
    {
        VendorUnAssignAllButton.Click();
        ScrollSaveValidateNotificationMessage(VendorSaveError);
    }

    private void AssignAllVendor()
    {
        var vendors =
            AvialableVendorBox.Element.FindElements(By.CssSelector("mat-list-option[id^='li_availableVendors_']"));
        foreach (var vendor in vendors)
        {
            vendor.Click();
        }

        VendorAssignButton.Click();
    }

    private void ValidateTextBox(IEnumerable<string> expectedVendorAffiliationText,
        IEnumerable<string> actualVendorAffiliationText)
    {
        foreach (var expected in expectedVendorAffiliationText)
        {
            if (actualVendorAffiliationText.Contains(expected))
                ConsoleOut.WriteReport($"Expected Vendor: '{expected}' was in list.");
            else
            {
                HPGWarn.Warn($"Expected Vendor: '{expected}' was not in list.");
            }
        }

        foreach (var actual in actualVendorAffiliationText)
        {
            if (expectedVendorAffiliationText.Contains(actual))
                ConsoleOut.WriteReport($"Actual Vendor: '{actual}' was in list.");
            else
            {
                HPGWarn.Warn($"Actual Vendor: '{actual}' was not in list.");
            }
        }
    }

    private string ApplicationSelection(string? applicationName = null)
    {
        ApplicationDropDownClickAndCheck();

        string       applicationChosen;
        IWebElement? application;
        if (applicationName == null)
		{
			application = _waitDriver.Until(e => e.FindElement(By.Id("ddl_roles_appList-panel")))
                .FindElements(By.XPath("//mat-option")).PickRandom();
            applicationChosen = application.Text;
        }
        else
        {
            applicationChosen = applicationName;
			application = _waitDriver.Until(e => e.FindElement(By.Id("ddl_roles_appList-panel")))
                .FindElements(By.XPath("//mat-option")).FirstOrDefault(i =>
                    i.Text.Equals(applicationChosen, StringComparison.CurrentCultureIgnoreCase));
        }

        Steps.AddTestStep($"Selecting Application: {applicationChosen} from application drop down list.",
            "System should allow it and user should see roles available to assign and roles that are already assigned for that specific application.");

        application?.Click();
        WaitForThrobber(30);

        return applicationChosen;
    }

    public string AppSelection(string appName = null)
    {
	    return ApplicationSelection(appName);
    }

    private void ScrollSaveValidateNotificationMessage(string message)
    {
        SaveButton.ScrollIntoView();
        SaveButton.Click();
        AwaitSnackNotification();
        HPGWarn.AreEqual(message, SnackBarNotification.Text,
            field: SnackBarNotification.Identifier);

        Steps.AddScreenShot(_browser.TakeBase64Screenshot());        

        if (SnackBarNotification.Exists())
            SnackBarNotificationButton.Click();
    }

    public UserResponse DeactivateReactivateUser(UserResponse userInfo)
    {
        const string deactivateMessage = "Would you like to deactivate this user?";
        const string activateMessage   = "Would you like to activate this user?";
        UsersTab.ScrollIntoView();

        if (userInfo.Type.ToLower().Equals("vendor") && VproUserEmailId.Text.ToStringOrEmpty().Equals(string.Empty))
            VproUserEmailId.Type(userInfo.Email);

        var expectedCheckBox = string.Empty;
        var stepFormat       = string.Empty;

        var currentStatus = UserStatusCheckBox.Element.GetAttribute("aria-checked");
        switch (userInfo.IsDeactivated)
        {
            case false when currentStatus.Equals("true"):
                expectedCheckBox = "false";
                stepFormat       = "Deactivate";
                break;
            case true when currentStatus.Equals("false"):
                expectedCheckBox = "true";
                stepFormat       = "Activate";
                break;
            default:
                HPGAssert.Fail(
                    $"Unable to determine status!\r\nUserDb Status: '{!userInfo.IsDeactivated}' UI Status: '{currentStatus}'.");
                break;
        }

        Steps.AddTestStep($"{stepFormat} User: '{userInfo.Username}'.",
            $"Should allow user to {stepFormat} specified user.");
        UserStatusInputCheckBox.Click();
        WaitForThrobber();
        HPGWarn.AreEqual(expectedCheckBox.Equals("false") ? deactivateMessage : activateMessage,
            ConfirmationMessage.Text.Trim(), field: ConfirmationMessage.Identifier);
        ConfirmationYesButton.Click();
        WaitForThrobber();

        HPGWarn.AreEqual(expectedCheckBox, UserStatusCheckBox.Element.GetAttribute("aria-checked"),
            field: UserStatusCheckBox.Identifier);

        

        ScrollSaveValidateNotificationMessage(UserSaveSuccessful);

        var actual = _userRepository.GetAllUsers(1).FirstOrDefault(i => i.Id.Equals(userInfo.Id));
        HPGWarn.AreEqual(expectedCheckBox, (!actual.IsDeactivated).ToString(), "DB: IsDeactivated");

        return actual;
    }

    //method to Apply Facilities to SoC

    #endregion Actions

    #region Sub-Test

    public void TestAssignAllAndUnassignAllRoles()
    {
        var scenarios = new List<string> { "Assign All", "Un-assign All" };

        var userInfo = _userRepository.GetAllUsers().First(i => i.Username.Equals(IdField.Text.Trim()));

        foreach (var scenario in scenarios)
        {
            switch (scenario)
            {
                case "Assign All":
                    break;
                case "Un-assign All":
                    break;
            }
        }
    }

    public void TestRemoveAllVendorAffiliation(UserResponse userInfo)
    {
        Steps.AddTestStep("Sub-Test: Removing all vendor affiliation from vendor type user.",
            "System should not allow it and show an error message.");
        RemoveAllVendorAffiliation();
        FirstNameField.ScrollIntoView();

        Steps.AddTestStep("Sub-Test: Assigning all vendor affiliation from vendor type user.",
            "System should allow it and show an success message.");
        AssignAllVendor();
        ScrollSaveValidateNotificationMessage(UserSaveSuccessful);
    }

    public void TestRemoveAllSpoc(UserResponse userInfo)
    {
        //need to implement!
    }

    #endregion Sub-Test

    #region Validations

    public void ValidateUserDetailInformation(UserResponse userInfo)
    {
        HPGWarn.AreEqual(userInfo.Username.ToStringOrEmpty(), IdField.Text.ToStringOrEmpty(),
            field: IdField.Identifier);
        HPGWarn.AreEqual(userInfo.FirstName.ToStringOrEmpty(), FirstNameField.Text.ToStringOrEmpty(),
            field: FirstNameField.Identifier);
        HPGWarn.AreEqual(userInfo.LastName.ToStringOrEmpty(), LastNameField.Text.ToStringOrEmpty(),
            field: LastNameField.Identifier);
        HPGWarn.AreEqual(userInfo.Email.ToStringOrEmpty(), EmailField.Text.ToStringOrEmpty(),
            field: EmailField.Identifier);
        HPGWarn.AreEqual(userInfo.Type.ToStringOrEmpty(), TypeField.Text.ToStringOrEmpty(),
            field: TypeField.Identifier);
        HPGWarn.AreEqual(!userInfo.IsDeactivated ? "Active" : "Inactive", UserStatus.Text.ToStringOrEmpty(),
            UserStatus.Identifier);
		
		if (userInfo.Type.Equals("Vendor", StringComparison.OrdinalIgnoreCase) || userInfo.Type == "2")
		{
			if (string.IsNullOrEmpty(userInfo.VPROUserEmailId) && !string.IsNullOrEmpty(userInfo.Email))
			{
				userInfo.VPROUserEmailId = userInfo.Email;
			}
		}





		Steps.AddScreenShot(_browser.TakeBase64Screenshot());        
    }

    public void ValidateUserDetailVpro()
    {
        WaitForThrobber();
		HPGWarn.True(CheckVproStatus.Exists(), field: "Check VPRO");
	    HPGWarn.True(VproActiveRbStatus.Exists(), field: "VPRO Active");
	    HPGWarn.True(VproInActiveRbStatus.Exists(), field: "VPRO Inactive");
	    HPGWarn.True(VproNotFoundRbStatus.Exists(), field: "VPRO Not Found");
	    HPGWarn.True(VproByPassCalendar.Exists(), field: "Bypass VPRO Calendar");
    }

	public void ValidateAndToggleGcnGroups()
	{
		Steps.AddTestStep("Validating GCN Group visibility and toggling checkboxes on SoC Tab.", "Each available GCN group should be validated and checkboxes should be toggled.");
		
        SocTabButton.Click();
		var availableGroups = GcnGroupRows
			.Select(row => new
			{
				Row = row,
				NameElement = row.FindElement(By.CssSelector(".gcn-group-name")),
				Checkbox = row.FindElement(By.CssSelector("input[type='checkbox']"))
			})
			.Where(x => x.NameElement.Displayed && x.Checkbox.Displayed)
			.ToList();

		foreach (var group in availableGroups)
		{
			var groupName = group.NameElement.Text.Trim();

			HPGWarn.True(group.NameElement.Displayed, field: $"GCN Group Name: {groupName}");
			HPGWarn.True(group.Checkbox.Displayed, field: $"GCN Group Checkbox: {groupName}");

			// Check the group if not already checked, then uncheck to verify both actions
			if (!group.Checkbox.Selected)
				group.Checkbox.Click();
			HPGWarn.True(group.Checkbox.Selected, field: $"GCN Group Checkbox Checked: {groupName}");

			group.Checkbox.Click();
			HPGWarn.False(group.Checkbox.Selected, field: $"GCN Group Checkbox Unchecked: {groupName}");

			// Restore checked state if needed for test consistency
			group.Checkbox.Click();
		}
	}




	#region Roles Tab

	public void ValidateRoleApplicationDropDown(bool isEmployee = true)
    {
        Steps.AddTestStep("Validating application drop down list.",
            "Should match database application table where IsEnabled = 1.");


        var applicationDb =
            new ApplicationRepository(GlobalTestVariables.Configuration["SmartSecurity:DatabaseServer"]!,
                GlobalTestVariables.Configuration["SmartSecurity:DatabaseName"]!);

        //todo: modify for type of security user and/or user type.
        var expectedApplicationList = applicationDb.GetApplicationRolesByUserTypeDbs(isEmployee)
            .Where(i => i.IsEnabled && !i.IsDeleted).Select(j => j.ApplicationName).Distinct();

        ApplicationDropDownClickAndCheck();
       
        var actualApplicationList = _waitDriver.Until(e => e.FindElement(By.Id("ddl_roles_appList-panel")))
            .FindElements(By.XPath(".//mat-option")).Select(j => j.Text.ToStringOrEmpty());

        ValidateRoleApplicationLists(expectedApplicationList.ToList(), actualApplicationList.ToList());

        //todo: need to add validation for roles per application.

        SendEscKey();
    }

    private void ValidateRoleApplicationLists(List<string> expectedList, List<string> actualList)
    {
        Steps.AddTestStep("Validate expected list is in actual list.", "Should match expected list.");
        foreach (var expected in expectedList)
        {
            if (!actualList.Contains(expected))
                HPGWarn.Warn($"Expecting '{expected}' but was not in actual list!");
            else
            {
                ConsoleOut.WriteReport($"Expecting '{expected}' in actual to be true.");
            }
        }

        Steps.AddTestStep("Validate actual list is in expected list.", "Should match actual list.");
        foreach (var actual in actualList)
        {
            if (!expectedList.Contains(actual))
                HPGWarn.Warn($"Expecting actual '{actual}' but was not in expected list!");
            else
            {
                ConsoleOut.WriteReport($"Expecting actual '{actual}' in expected to be true.");
            }
        }
    }

    private void ValidateAssignedRoles(UserResponse userInfo, List<string> assignedRolesData,
        bool isSaved = true)
    {
        //check to see if internal user has been saved
        if (userInfo.Id.IsNull() || userInfo.Id.ToString().Equals("00000000-0000-0000-0000-000000000000"))
            userInfo = _userRepository.GetAllUsers(timeToWait: 2)
                .FirstOrDefault(i => i.Username!.Equals(userInfo.Username))!;

        var userRoleInfo = _userRepository.GetAllUserRoleDb(timeToWait: 2).Where(i =>
            i.UserId.Equals(userInfo.Id) && !i.IsDeleted).ToDictionary(r => r.Name, j => j);

        if (isSaved)
        {
            foreach (var expected in assignedRolesData)
            {
                if (!userRoleInfo.ContainsKey(expected))
                    HPGWarn.Warn(
                        $"Expecting Role: '{expected}' but was not in the Database for Test User: '{userInfo.Username}'!");
                else
                {
                    ConsoleOut.WriteReport(
                        $"Expected Role: '{expected}' has been persisted to the database for test user: '{userInfo.Username}'.");
                }
            }
        }
        else
        {
            foreach (var expected in assignedRolesData)
            {
                if (userRoleInfo.ContainsKey(expected))
                    HPGWarn.Warn(
                        $"Not Expecting Role: '{expected}' but was in the Database for Test User: '{userInfo.Username}'!");
                else
                {
                    ConsoleOut.WriteReport(
                        $"Not Expected Role: '{expected}' has not been persisted to the database for test user: '{userInfo.Username}'.");
                }
            }
        }
    }

    private void ValidateAssignedRolesList(List<UserRoleDb> expectedList, List<UserRoleDb> actualList)
    {
        Steps.AddTestStep("Validating Expected Roles is in Actual List",
            "Expected List should be in Actual.");
        var actualDictionary = actualList.ToDictionary(i => i.Id, j => j);
        foreach (var expected in expectedList)
        {
            if (!actualDictionary.TryGetValue(expected.Id, out var actual))
                HPGWarn.Warn(
                    $"Expected ID: {expected.Id} was not in actual list.");
            else
            {
                HPGWarn.WarnRange(expected.Validate(actual));
            }
        }

        Steps.AddTestStep("Validating Actual Roles is in Expected List",
            "Actual List should be in Expected.");
        var expectedDictionary = expectedList.ToDictionary(i => i.Id, j => j);
        foreach (var actual in actualList)
        {
            if (!actualDictionary.TryGetValue(actual.Id, out var expected))
                HPGWarn.Warn(
                    $"Actual ID: {actual.Id} was not in expected list.");
            else
            {
                HPGWarn.WarnRange(actual.Validate(expected));
            }
        }
    }

    #endregion Roles Tab

    #region SOC Tab

    private void ValidateSecurityUserSOC(AddUserRoleSoc userInfo)
    {
        foreach (var spanOfControl in userInfo.SpanOfControl)
        {
            var mySelector = $"div[org-id='{spanOfControl.ObjectId.PadLeft(5, '0')}'][org-type-id='{spanOfControl.HierarchyType}'] "; 
            var cssSelector =
                $"div[org-id='{spanOfControl.ObjectId.PadLeft(5, '0')}'][org-type-id='{spanOfControl.HierarchyType}'] ";


			var socElement = new HpgElement(_waitDriver.Until(e => e.FindElement(By.CssSelector(cssSelector))),
                $"{spanOfControl.OrgName}");

            HPGWarn.True(socElement.Exists(), field: $"{spanOfControl.OrgName} - Span of Control Tree");
            HPGWarn.AreEqual(spanOfControl.OrgName, socElement.Text.Substring(1),
                field: "Security User Span of Control");
        }
    }

    private void ValidateAssignedSoc(UserResponse userInfo, List<HomeDataDb> assignedSoc, bool isSaved = true)
    {
        //check to see if internal user has been saved
        if (userInfo.Id.IsNull() || userInfo.Id.ToString().Equals("00000000-0000-0000-0000-000000000000"))
            userInfo = _userRepository.GetAllUsers(timeToWait: 2)
                .FirstOrDefault(i => i.Username.Equals(userInfo.Username));

        //debug
        ConsoleOut.WriteReport($"Getting SOC for user ID:'{userInfo.Id}'.");

        var assignedMembers = _userRepository.GetAllUserSocDb(userId: userInfo.Id, timeToWait: 5)
            .Where(i => !i.IsDeleted)
            .ToDictionary(i => i.OrgObjectID, j => j);

        if (isSaved)
        {
            foreach (var facility in assignedSoc)
            {
                if (!assignedMembers.ContainsKey(facility.COID))
                    HPGWarn.Warn(
                        $"Expecting SOC: {facility.Name} ({facility.COID}) but was not persisted to the database for test user: {userInfo.Username} user Id: {userInfo.Id}");
                else
                {
                    ConsoleOut.WriteReport($"Expected SOC: {facility.Name} ({facility.COID})");
                }
            }
        }
        else
        {
            foreach (var facility in assignedSoc)
            {
                if (assignedMembers.ContainsKey(facility.COID))
                    HPGWarn.Warn(
                        $"Not Expecting SOC: {facility.Name} ({facility.COID}) but was persisted to the database for test user: {userInfo.Username} user Id: {userInfo.Id}");
                else
                {
                    ConsoleOut.WriteReport($"Not Expected SOC: {facility.Name} ({facility.COID})");
                }
            }
        }
    }

    private void ValidateAssignedSoc(List<UserSocDb> expectedList, List<UserSocDb> actualList)
    {
        Steps.AddTestStep("Validating Expected Span of Control is in Actual List",
            "Expected List should be in Actual.");
        var actualDictionary = actualList.ToDictionary(i => new { i.Hierarchy, i.OrgObjectID }, j => j);
        foreach (var expected in expectedList)
        {
            if (!actualDictionary.TryGetValue(new { expected.Hierarchy, expected.OrgObjectID }, out var actual))
                HPGWarn.Warn(
                    $"Expected Hierarchy: {expected.Hierarchy} and OrgObjectId: {expected.OrgObjectID} was not in actual list.");
            else
            {
                HPGWarn.WarnRange(expected.Validate(actual));
            }
        }

        Steps.AddTestStep("Validating Actual Span of Control is in Expected List",
            "Actual List should be in Expected.");
        var expectedDictionary = expectedList.ToDictionary(i => new { i.Hierarchy, i.OrgObjectID }, j => j);
        foreach (var actual in actualList)
        {
            if (!actualDictionary.TryGetValue(new { actual.Hierarchy, actual.OrgObjectID }, out var expected))
                HPGWarn.Warn(
                    $"Actual Hierarchy: {actual.Hierarchy} and OrgObjectId: {actual.OrgObjectID} was not in expected list.");
            else
            {
                HPGWarn.WarnRange(actual.Validate(expected));
            }
        }
    }

	#endregion SOC Tab

	#region Vendor Affiliation Tab

	#endregion Vendor Affiliation Tab

	#region History Tab

	#endregion History Tab

	#endregion Validations

	#region Helpers
	/// <summary>
	/// Retrieves a filtered list of active HomeDataDb objects based on the provided limitedRollUser's span of control.
	/// If limitedRollUser is null, returns all active HomeDataDb entries for CompanyId "1" excluding those with "CareNow" in the name.
	/// Otherwise, filters the home data according to each span of control's hierarchy type and object ID, excluding "CareNow" entries.
	/// </summary>
	private IEnumerable<HomeDataDb> RetrieveHomeDataList(AddUserRoleSoc? limitedRollUser)
    {
        var homeDb = new HomeRepository(GlobalTestVariables.Configuration["Home:DatabaseServer"]!,
            GlobalTestVariables.Configuration["Home:DataBaseName"]!);
        var homeData = homeDb.GetHomeData().Where(i => i.IsActive && i.COID.ToStringOrEmpty() != string.Empty);

        if (limitedRollUser == null)
            return homeData.Where(i => i.CompanyId.Equals("1") &&
                                       !i.Name.Contains("CareNow"));

        var results = new List<HomeDataDb>();

        foreach (var spanOfControl in limitedRollUser.SpanOfControl)
        {
            switch (spanOfControl.HierarchyType.ToString())
            {
                case "0":
                    results.AddRange(homeData.Where(i => i.OrganizationID.Equals("0") &&
                                                         !i.Name.Contains("CareNow")));
                    break;
                case "1":
                    results.AddRange(homeData.Where(i => i.CompanyId.Equals(spanOfControl.ObjectId.ToInt().ToString()) &&
                                                         !i.Name.Contains("CareNow")));
                    break;
                case "2":
                    results.AddRange(homeData.Where(i => i.GroupId.Equals(spanOfControl.ObjectId.ToInt().ToString()) &&
                                                         !i.Name.Contains("CareNow")));
                    break;
                case "3":
                    results.AddRange(homeData.Where(i => i.DivisionID.Equals(spanOfControl.ObjectId.ToInt().ToString()) &&
                                                         !i.Name.Contains("CareNow")));
                    break;
                case "4":
                    results.AddRange(homeData.Where(i => i.MarketId.Equals(spanOfControl.ObjectId.ToInt().ToString()) &&
                                                         !i.Name.Contains("CareNow")));
                    break;
                case "5":
                    results.AddRange(homeData.Where(i => i.COID.Equals(spanOfControl.ObjectId) &&
                                                         !i.Name.Contains("CareNow")));
                    break;
                default:
                    throw new ArgumentOutOfRangeException($"Unknown Hierarchy Type: '{spanOfControl.HierarchyType}'!");
            }
        }

        return results;
    }

    public void ApplicationDropDownClickAndCheck(int maxTries = 5)
    {
        bool isShown = false;
        int  counter = 0;
        do
        {
            ApplicationSelectDropDown.ScrollIntoView();
            ApplicationSelectDropDown.Click();
            Thread.Sleep(800);

            try
			{                                                                  
				isShown = _waitDriver.Until(e => e.FindElement(By.Id("ddl_roles_appList-panel"))).Displayed;
            }
            catch (Exception e)
            {
                isShown = false;
            }

            counter++;
        } while (!isShown && counter < maxTries);
    }

    public void AwaitSnackNotification(int timeout = 3)
    {
        var count = 0;
        do
        {
            Thread.Sleep(500);
            if(SnackBarNotification.Exists())
                break;
            count++;
        } while (count < timeout);
    }
    #endregion Helpers
}
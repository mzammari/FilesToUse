﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using WebUiAutomation;
using Utilities.ObjectExtensions;
using SmartSecurityTestAutomation.Tests;

namespace SmartSecurityTestAutomation.Page.Objects.Ping
{
	public class AuthorizationPage:AdminPageMaster
	{
		private WebDriverWait _waitDriver;
		private Browser _browser;

		public AuthorizationPage(Browser browser) : base(browser)
		{
			_browser = browser;
			_waitDriver = new WebDriverWait(browser.Driver, TimeSpan.FromSeconds(60));
		}

		#region Page Objects								
		public HpgElement TestButton => new(_waitDriver.Until(e => e.FindElement(By.CssSelector("button.button.-light.-md"))), "Test Button");
		//public HpgElement TestButton => new(_waitDriver.Until(e => e.FindElement(By.CssSelector("button[type='button']"))), "Test Button");
		//public HpgElement VerifyEmailPage => new(_waitDriver.Until(e => e.FindElement(By.Id("company-logo-div-text"))), "Verify Email Page");

		public HpgElement VerifyEmailPage => new(_waitDriver.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.Id("company-logo-div-text"))),	"Verify Email Page");

		public HpgElement EmailUserInput => new(_waitDriver.Until(e => e.FindElement(By.Id("identifierInput"))), "Email User Input");
		public HpgElement NextButton => new(_waitDriver.Until(e => e.FindElement(By.CssSelector("#postButton>a"))), "Next Button");

        #endregion

        #region Actions
        /// <summary>
        /// Sign in to Ping using the provided username and password and get the token.
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public string GetPingToken(string userName, string password)
		{
			//_browser.Navigate(url);            
            TestButton.Click();
            SignInThruPing(userName, password);            

            return GetToken();
        }

        /// <summary>
		/// Sign in to Ping using the provided username and password.
		/// </summary>
		/// <param name="userName"></param>
		/// <param name="password"></param>
        public void SignInThruPing(string userName, string password)
        {
            var networkInterceptor = _browser.Driver.GetNetworkInterceptor(userName, password, "medcity.net");
			//_browser.TakeScreenshot(GlobalTestVariables.ScreenShotFileLocation); 
			// Wait for the Verify Email page to load
			_waitDriver.Until(d => VerifyEmailPage.Exists());
			Thread.Sleep(1000);
			// Type the email user input and click Next

			EmailUserInput.Type($"{userName}@hcahcqa.com");
            networkInterceptor.StartMonitoring();

            NextButton.Click();
            Thread.Sleep(5000);
            networkInterceptor.StopMonitoring();

            var externalLoginPage = new ExternalLoginPage(_browser);
            externalLoginPage.Login(userName, password);

        }

        /// <summary>
        /// Get the token from the session storage
        /// </summary>
        /// <returns></returns>
        public string GetToken()
		{
		 
            IJavaScriptExecutor js = (IJavaScriptExecutor)_browser.Driver;
			var x = js;
            string key = "access_token";
            string value = (string)js.ExecuteScript("return sessionStorage.getItem('" + key + "')");
            return value; 

		}
		#endregion


		#region Validations

		#endregion


	}

}

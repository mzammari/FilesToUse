﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Threading;
using WebUiAutomation;

namespace SmartSecurityTestAutomation.Page.Objects.Ping
{
    public class ExternalLoginPage
    {
        private WebDriverWait _waitDriver;
        private Browser _browser;

        public ExternalLoginPage(Browser browser)
        {
            _browser = browser;
            _waitDriver = new WebDriverWait(browser.Driver, TimeSpan.FromSeconds(60));
        }
        #region Page Objects
        public HpgElement UserIdInput => new(_waitDriver.Until(d => d.FindElement(By.Id("UserId"))), "User ID Input");
        public HpgElement PasswordInput => new(_waitDriver.Until(d => d.FindElement(By.Id("Password"))), "Password Input");
        public HpgElement SignInButton => new(_waitDriver.Until(d => d.FindElement(By.Id("submit"))), "Sign In Button");
        #endregion Page Objects

        #region Page Actions
        public void Login(string username, string password)
        {
            Steps.AddTestStep($"Login with username: {username}.", "User should be able to login.");
            UserIdInput.Type(username);

			// Mask password from logs
			Steps.AddTestStep("***** Password Entered *****", "Password field populated.");
			//PasswordInput.Type(password);
			PasswordInput.Element.SendKeys(password);
			Steps.AddScreenShot(_browser.TakeBase64Screenshot());

            SignInButton.Click();
            Thread.Sleep(1000);
        }
        #endregion Page Actions

        #region Validations

        #endregion Validations

    }
}
﻿using System;
using System.Reflection.Emit;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
using WebUiAutomation;

namespace SmartSecurityTestAutomation.Page.Objects;

public class AdminPageMaster
{
    private readonly WebDriverWait _waitDriver;
    private readonly IWebDriver    _driver;

    protected AdminPageMaster(Browser browser)
    {
        _driver     = browser.Driver;
        _waitDriver = new WebDriverWait(browser.Driver, TimeSpan.FromSeconds(10));
    }

    protected HpgElement SecurityTile =>
        new(_waitDriver.Until(e => e.FindElement(By.CssSelector("a[href = '/Admin/SecurityManagement']"))),
            "Security Tile");

    private HpgElement SiteThrobber =>
        new(_waitDriver, By.Id("siteThrobber"), "Waiting Throbber");

    public HpgElement AdminTile => new(_waitDriver.Until(e => e.FindElement(By.Id("Admin"))), "Admin Tile");

    protected void WaitForThrobber(int timeOut = 5)
    {
        for (var i = 0; i < timeOut; i++)
        {
            Thread.Sleep(1000);
            if (!SiteThrobber.Exists())
                break;
        }

        Thread.Sleep(1000);
    }

    protected void SendEscKey()
    {
        new Actions(_driver).SendKeys(Keys.Escape).Perform();
    }

    protected void AwaitElement(HpgElement element, int timeout = 5)
    {
        bool doesNotExist = true;
        var  counter      = 0;
        do
        {
            Thread.Sleep(250);
            if (element.Exists())
                doesNotExist = false;

            counter++;
        } while (doesNotExist && counter < timeout);
    }
}
﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using WebUiAutomation;

namespace SmartSecurityTestAutomation.Page.Objects.SupplierPortal;

public class SupplierPortalLoginPage 
{
    private readonly WebDriverWait _waitDriver;

    public SupplierPortalLoginPage(Browser browser)
    {
        _waitDriver = new WebDriverWait(browser.Driver, TimeSpan.FromSeconds(5));
    }
    
    #region Page Objects

    public HpgElement UserNameInput =>
        new(_waitDriver.Until(e => e.FindElement(By.CssSelector("input[id='identifierInput']"))), "Username Input Box");

    public HpgElement NextButton => new(_waitDriver.Until(e => e.FindElement(By.CssSelector("div[id='postButton']"))),
        "Next Button");

    #endregion Page Objects

    #region Actions

    public void EnterInCreds(string username)
    {
        UserNameInput.Type(username);
        NextButton.Click();
    }
    #endregion Actions

    #region Validation

    #endregion Validation

    #region Helpers

    #endregion Helpers


}
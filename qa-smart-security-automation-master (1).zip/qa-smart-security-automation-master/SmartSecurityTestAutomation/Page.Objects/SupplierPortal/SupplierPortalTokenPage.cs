﻿using System;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using WebUiAutomation;

public class Supplierportaltokenpage
{
    private readonly WebDriverWait _waitDriver;
    private readonly IWebDriver    _driver;

    public Supplierportaltokenpage(Browser browser)
    {
        _driver     = browser.Driver;
        _waitDriver = new WebDriverWait(browser.Driver, TimeSpan.FromSeconds(5));
    }
    
    #region Page Objects

    public HpgElement AccessToken =>
        new(_waitDriver.Until(e => e.FindElement(By.CssSelector("main > div[class='row'] >p + p"))), "Access Token");

    #endregion Page Objects

    #region Actions

    #endregion Actions

    #region Validation

    #endregion Validation

    #region Helpers

    public string GetAccessToken(int timeout = 5)
    {
        int count = 0;
        do
        {
            Thread.Sleep(1000);
            if (AccessToken.Exists())
                break;
            count++;
        } while (timeout > count);

        return AccessToken.Text.Replace("Access Token:", "").Trim();
    }
    #endregion Helpers


}
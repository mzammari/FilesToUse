﻿using System.Collections.Generic;
using SmartSecurityTestAutomation.Services.Users;
using Utilities.SetupTestUsers;

namespace SmartSecurityTestAutomation.Models;

public class SecurityUser : TestUser
{

    public string              Access         { get; set; }

}
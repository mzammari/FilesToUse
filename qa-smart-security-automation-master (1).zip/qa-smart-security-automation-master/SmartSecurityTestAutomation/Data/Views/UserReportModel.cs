﻿using System;
using System.Collections.Generic;
using System.Linq;
using Utilities.ObjectExtensions;
using Utilities.Validation;

namespace SmartSecurityTestAutomation.Data.Views;

public class UserReportModel
{
    public string UserId          { get; set; }
    public string Name            { get; set; }
    public string Email           { get; set; }
    public string ApplicationName { get; set; }
    public string SOC             { get; set; }
    public string Roles           { get; set; }

    public List<string> Validate(UserReportModel other)
    {
        var results = new List<string>()
        {
            ValidationHelpers.AreEqual(UserId.ToStringOrEmpty(), other.UserId.ToStringOrEmpty(), field: "UserId"),
            ValidationHelpers.AreEqual(Name.ToStringOrEmpty(), other.Name.ToStringOrEmpty(), field: "Name"),
            ValidationHelpers.AreEqual(Email.ToStringOrEmpty(), other.Email.ToStringOrEmpty(), field: "Email"),
            ValidationHelpers.AreEqual(ApplicationName.ToStringOrEmpty(), other.ApplicationName.ToStringOrEmpty(), field: "ApplicationName"),
        };

        if (SOC.ToStringOrEmpty() != string.Empty)
        {
            results.AddRange(ValidateList(SOC.Split(",").Select(p => p.Trim()).ToList(), other.SOC.Split(",").Select(p => p.Trim()).ToList(), "SOC") ??
                             new List<string>());
        }


        if (Roles.ToStringOrEmpty() != string.Empty)
            results.AddRange(ValidateList(Roles.Split(",").Select(p => p.Trim()).ToList(), other.Roles.Split(",").Select(p => p.Trim()).ToList(), "Roles") ??
                             new List<string>());

        return results.Where(i => i.ToStringOrEmpty() != string.Empty).ToList();
    }

    private List<string>? ValidateList(List<string> expectedList, List<string> actualList, string attribute)
    {
        var results = new List<string>();

        //check for duplicates
        if (actualList.GroupBy(i => i).Any(g => g.Count() > 1))
        {
            HPGWarn.Warn($"{attribute} list has duplicates for UserId: {UserId}.");
            return results;
        }

        //validate list
        var actualDictionary = actualList.ToDictionary(i => i);
        foreach (var expected in expectedList)
        {
            if (!actualDictionary.ContainsKey(expected))
                results.Add($"Expecting {attribute}: '{expected}' but was not found in list for UserId: {UserId}!");
            else
            {
                ConsoleOut.WriteReport($"Expected {attribute}: '{expected}' was found in list for UserId: {UserId}.");
            }
        }

        return results.IsNullOrEmpty() ? null : results;
    }
}
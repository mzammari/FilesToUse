﻿using System.Collections.Generic;
using System.Linq;
using Utilities.ObjectExtensions;
using Utilities.Validation;

namespace SmartSecurityTestAutomation.Data.Views;

public class RefHomeModel
{
    public int?    HierarchyType  { get; set; }
    public string? HierarchyLevel { get; set; }
    public string? OrgObjectID    { get; set; }
    public string? OrgName        { get; set; }
    public bool    Active         { get; set; }


    public List<string> Validate(RefHomeModel other)
    {
        var overrideMessage = $"for HierarchyType: '{HierarchyType}' and OrgObjectId: '{OrgObjectID}'!";
        var results = new List<string>()
        {
            ValidationHelpers.AreEqual(HierarchyType.ToString(), other.HierarchyType.ToString(), "HierarchyType",
                overrideMessage),
            ValidationHelpers.AreEqual(HierarchyLevel, other.HierarchyLevel, "HierarchyLevel", overrideMessage),
            ValidationHelpers.AreEqual(OrgObjectID, other.OrgObjectID, "OrgObjectID", overrideMessage),
            ValidationHelpers.AreEqual(OrgName, other.OrgName, "OrgName", overrideMessage)
        };

        return results.Where(i => i.ToStringOrEmpty() != string.Empty).ToList();
    }
}
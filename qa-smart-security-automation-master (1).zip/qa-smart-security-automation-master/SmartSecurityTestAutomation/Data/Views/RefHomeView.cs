﻿using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SmartSecurityTestAutomation.Services.Home;
using SmartSecurityTestAutomation.Tests;
using Utilities.ObjectExtensions;

namespace SmartSecurityTestAutomation.Data.Views;

public class RefHomeView
{
    private readonly RefHomeRepository _refHomeDb;
    private readonly HomeRepository _homeDb;

    public RefHomeView()
    {
        _refHomeDb = new RefHomeRepository(GlobalTestVariables.Configuration!["SmartSecurity:DatabaseServer"]!,
            GlobalTestVariables.Configuration["SmartSecurity:DatabaseName"]!);
        _homeDb = new HomeRepository(GlobalTestVariables.Configuration["Home:DatabaseServer"]!,
            GlobalTestVariables.Configuration["Home:DatabaseName"]!);
    }
    public void TestRefHomeView()
    {
        Steps.AddTestStep("Testing database view 'dbo.vw_refHomeHierarchy' is correct.","Should match expected results.");

        //get expected view
        Steps.AddTestStep("Get expected list from HOME database.","Should be able to compile a list from HOME Database");
        var expectedList = RemoveDuplicateInactive(_homeDb.GetRefHomeModels()).ToList(); 

        //get actual view
        Steps.AddTestStep("Get actual results from vw_refHomeHierarchy table on SmartSecurity database.","Should be able to get actual list from Smart Security Database.");
        var actualList = _refHomeDb.GetRefHomeViewData().ToList();

        //validate expected and actual lists.
        ValidateRefHomeModelLists(expectedList, actualList); 
    }

    private void ValidateRefHomeModelLists(List<RefHomeModel> expectedList, List<RefHomeModel> actualList)
    {
        //note: since this a large set of results will need to do parallel processing!!!!
        Steps.AddTestStep("Validating expected and actual lists matches to each other.","Both list should match.");
        
        //Validate Expected is in Actual
        Steps.AddTestStep("Validating Expected results are in Actual.","Expected should be in Actual.");
        var actualDictionary = actualList.ToDictionary(k => new { HierarchyType = k.HierarchyType.ToStringOrEmpty(), OrgObjectID = k.OrgObjectID.ToStringOrEmpty()}, j => j);
        
        var parallelWarnings = new ConcurrentBag<string>();
        Parallel.ForEach(expectedList, expected =>
        {
            if(!actualDictionary.TryGetValue(new { HierarchyType = expected.HierarchyType.ToStringOrEmpty(), OrgObjectID = expected.OrgObjectID.ToStringOrEmpty()}, out var actual))
                parallelWarnings.Add($"Expecting HierarchyType: '{expected.HierarchyType}' and OrgObjectId: '{expected.OrgObjectID}' in Actual but was not found!");
            else
            {
                parallelWarnings.AddRange(expected.Validate(actual));
            }
        });
        HPGWarn.WarnRange(parallelWarnings.ToList());
        parallelWarnings.Clear();

        //Validate Actual is in Expected
        Steps.AddTestStep("Validating Actual results are in Expected.","Actual should be in Expected.");
        var expectedDictionary = expectedList.ToDictionary(k => new { k.HierarchyType, k.OrgObjectID }, j => j);

        Parallel.ForEach(actualList, actual =>
        {
            if (!expectedDictionary.TryGetValue(new { actual.HierarchyType, actual.OrgObjectID }, out var expected))
                parallelWarnings.Add($"Expecting Actual HierarchyType: '{actual.HierarchyType}' and OrgObjectId: '{actual.OrgObjectID}' in Expected but was not found!");
            else
            {
                parallelWarnings.AddRange(actual.Validate(expected));
            }
        });

        HPGWarn.WarnRange(parallelWarnings.ToList());
        parallelWarnings.Clear();
    }

    private IEnumerable<RefHomeModel> RemoveDuplicateInactive(IEnumerable<RefHomeModel> refs)
    {
        var filteredList = refs.ToList();
        var groupedList = refs.GroupBy(i => new { i.HierarchyType, i.OrgObjectID })
            .ToDictionary(grp => grp.Key, j => j.ToList())
            .Where(c => c.Value.Count() > 1);

        foreach (var valuePair in groupedList)
        {
            var toBeRemoved = valuePair.Value.SingleOrDefault(i => !i.Active);
            if (toBeRemoved.IsNull()) continue;
            filteredList.Remove(toBeRemoved);
        }

        return filteredList;

    }
}
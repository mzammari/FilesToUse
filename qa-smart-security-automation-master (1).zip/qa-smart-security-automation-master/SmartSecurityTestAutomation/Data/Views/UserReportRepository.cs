﻿using System;
using System.Collections.Generic;
using Utilities.DatabaseUtility;

namespace SmartSecurityTestAutomation.Data.Views;

public class UserReportRepository
{
    private readonly string _server;
    private readonly string _dbName;

    public UserReportRepository(string server, string dbName)
    {
        _server = server;
        _dbName = dbName;
    }

    /// <summary>
    /// Return a collection of User Report Model.
    /// </summary>
    /// <param name="expected">Specifies to either get the expected result or actual result.</param>
    /// <param name="applicationName"></param>
    /// <returns></returns>
    /// <exception cref="Exception"></exception>
    public IEnumerable<UserReportModel> GetUserReportModel(bool expected = true)
    {
        try
        {
            var dbs = new DbSql(_server, _dbName);
            var query = expected
                ? SqlSelectUserReportExpected
                : SqlSelectUserReportActual;

            return dbs.GetRecordsIntoObject<UserReportModel>(query);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw new Exception($"SQL Error!\r\n{e}");
        }
    }

    private const string SqlSelectUserReportExpected = @";with soc as (
    Select UserId
          ,ApplicationName
          ,STRING_AGG(UserSoc, ',') as SOC
    from (
    Select UserId
          ,ap.[Name] as ApplicationName
          ,case WHEN Hierarchy = 0 then OrgObjectID + ' - Organization'
                WHEN Hierarchy = 1 then OrgObjectID + ' - Company'
                WHEN Hierarchy = 2 then OrgObjectID + ' - Group'
                WHEN Hierarchy = 3 then OrgObjectID + ' - Division'
                WHEN Hierarchy = 4 then OrgObjectID + ' - Market'
                WHEN Hierarchy = 5 then OrgObjectID + ' - Facility'
            end as [UserSoc]
    from dbo.SpanOfControl sc
    inner join dbo.Application ap on sc.ApplicationId = ap.Id
    where sc.IsDeleted = 0)a
    group by UserId, ApplicationName
),
rol as (
    Select ur.UserId
          ,app.Name as ApplicationName
          ,STRING_AGG(r.Name,',') as roles
    from dbo.User_Role ur
    join dbo.Role r on ur.RoleId = r.Id and ur.IsDeleted = 0
    inner join dbo.Application app on r.ApplicationId = app.Id
    group by ur.UserId,app.Name
)

Select DISTINCT u.Username as UserId
      ,u.FirstName + ' ' + u.LastName as [Name]
      ,u.Email  
      ,r.ApplicationName
      ,s.SOC
      ,r.roles as [Roles]
from dbo.[USER] u
inner join rol r on u.Id = r.UserId and u.IsDeactivated = 0
inner join soc s on u.Id = s.UserId and r.ApplicationName = s.ApplicationName";

    private const string SqlSelectUserReportActual = @"SELECT [UserId]
      ,[Name]
      ,[Email]
      ,[ApplicationName]
      ,[SOC]
      ,[Roles]
  FROM [dbo].[vw_UserReport]";
}
﻿using SmartSecurityTestAutomation.Services.Home;
using System;
using System.Collections.Generic;
using Utilities.DatabaseUtility;

namespace SmartSecurityTestAutomation.Data.Views;

public class RefHomeRepository
{
    private readonly string _server;
    private readonly string _dbName;

    public RefHomeRepository(string server, string dbName)
    {
        _server = server;
        _dbName = dbName;
    }

    public IEnumerable<RefHomeModel> GetRefHomeViewData()
    {
        try
        {
            var dbs = new DbSql(_server, _dbName);

            return dbs.GetRecordsIntoObject<RefHomeModel>(SqlSelectRefHomeView);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw new Exception($"SQL Error!\r\n{e}");
        }
    }

    private const string SqlSelectRefHomeView = @"SELECT [HierarchyType]
      ,[HierarchyLevel]
      ,[OrgObjectID]
      ,TRIM([OrgName]) as [OrgName]
  FROM [dbo].[vw_refHomeHierarchy]
  where [OrgObjectID] is not null";
}
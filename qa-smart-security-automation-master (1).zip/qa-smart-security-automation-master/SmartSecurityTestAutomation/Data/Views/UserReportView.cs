﻿using System.Collections.Generic;
using System.Linq;
using SmartSecurityTestAutomation.Services.Applications;
using SmartSecurityTestAutomation.Tests;

namespace SmartSecurityTestAutomation.Data.Views;

public class UserReportView
{
    private readonly UserReportRepository _userReportDb;
    private readonly ApplicationRepository _applicationDb;

    public UserReportView()
    {
        _userReportDb = new UserReportRepository(GlobalTestVariables.Configuration!["SmartSecurity:DatabaseServer"]!,
            GlobalTestVariables.Configuration["SmartSecurity:DatabaseName"]!);
        _applicationDb = new ApplicationRepository(GlobalTestVariables.Configuration!["SmartSecurity:DatabaseServer"]!,
            GlobalTestVariables.Configuration["SmartSecurity:DatabaseName"]!);
    }

    public void TestUserReportView()
    {
        Steps.AddTestStep("Testing database view 'dbo.vw_UserReport' is correct.", "Should match expected results.");

        //Get Application ID
        var application = _applicationDb.GetApplicationsDb()
            .FirstOrDefault(i => !i.IsDeleted && i.Name.Contains("Procurement"));

        //Get Expected Results
        Steps.AddTestStep("Get expected list from SMART Security database.",
            "Should be able to compile a list from SMART Security Database");
        var expectedList = _userReportDb.GetUserReportModel().ToList();

        //Get Actual Results
        Steps.AddTestStep("Get actual list from SMART Security database.",
            "Should be able to get a list from SMART Security Database view.");
        var actualList = _userReportDb.GetUserReportModel(false).ToList();

        //Validate Expected and Actual list
        ValidateUserReportViewLists(expectedList, actualList);
    }

    private void ValidateUserReportViewLists(List<UserReportModel> expectedList, List<UserReportModel> actualList)
    {
        Steps.AddTestStep("Validating the two collections matches to each other.", "Both collections should match.");

        Steps.AddTestStep("Validating Expected list is in Actual List.", "Expected elements should exist in Actual.");
        var actualDictionary = actualList.ToDictionary(i => new{i.UserId, i.ApplicationName}, j => j);
        foreach (var expected in expectedList)
        {
            if (!actualDictionary.TryGetValue(new { expected.UserId, expected.ApplicationName }, out var actual))
                HPGWarn.Warn($"Expecting UserId: '{expected.UserId}' Application: '{expected.ApplicationName}' to be in actual but was not found!");
            else
            {
                HPGWarn.WarnRange(expected.Validate(actual));
            }
        }

        Steps.AddTestStep("Validating Actual list is in Expected List.", "Actual elements should exist in Expected.");
        var expectedDictionary = expectedList.ToDictionary(i => new { i.UserId, i.ApplicationName }, j => j);
        foreach (var actual in actualList)
        {
            if(!expectedDictionary.TryGetValue(new{actual.UserId, actual.ApplicationName}, out var expected))
                HPGWarn.Warn($"Expecting Actual UserId: '{actual.UserId}' Application: '{actual.ApplicationName}' to be in expected but was not found!");
            else
            {
                HPGWarn.WarnRange(actual.Validate(expected));
            }
        }
    }
}
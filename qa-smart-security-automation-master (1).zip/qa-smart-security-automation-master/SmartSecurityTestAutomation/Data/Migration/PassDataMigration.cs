﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SmartSecurityTestAutomation.Services.Users;
using SmartSecurityTestAutomation.Tests;
using Utilities.ObjectExtensions;

namespace SmartSecurityTestAutomation.Data.Migration;

public class PassDataMigration
{
    private PassRepository         _passRepository;
    private UserRepository         _userRepository;
    private List<UserPassRoleSpoc> _passRolesSpoc;
    private string                 _passDbServer;

    public PassDataMigration()
    {
        _passRepository = new PassRepository();
        _userRepository =
            new UserRepository(GlobalTestVariables.Configuration["SmartSecurity:DatabaseServer"], "SmartSecurity");
        _passRolesSpoc = _userRepository.GetAllUsersRolesAndSpoc().ToList();
        _passDbServer  = GlobalTestVariables.Configuration["PassServers:Prod"];
    }

    public void TestSmacToSecurityRoleAndSpoc()
    {
        const string applicationName = "Security";
        Steps.AddTestStep("Validating SMAC users from PROD Pass.", "System should match.");
        var listToBeFormatted = _passRepository
            .GetSecurityUsersAndSpoc(_passDbServer, "SMART - Security")
            .ToList();

        var expectedList = FormattedUserList(listToBeFormatted, applicationName).Where(i => !i.UserName.Contains("gpouser")).ToList();

        //Check to see if any duplicate users where created in SMART Security DB
        var duplicates = _passRolesSpoc
            .Where(i => i.ApplicationName.Equals("SMART - Security", StringComparison.CurrentCultureIgnoreCase))
            .GroupBy(grp => grp.AccountId)
            .Where(j => j.Count() > 1).ToList();

        if (duplicates.Any())
        {
            foreach (var duplicate in duplicates)
            {
                HPGWarn.Warn($"Duplicate Account ID: '{duplicate.Key}'");
            }
            HPGAssert.Fail("Duplicate accounts found!");
        }

        var actualList = _passRolesSpoc
            .Where(i => i.ApplicationName.Equals("SMART - Security", StringComparison.CurrentCultureIgnoreCase))
            .ToDictionary(i => i.AccountId, j => j);

        foreach (var expected in expectedList)
        {
            if (!actualList.TryGetValue(expected.AccountId, out var actual))
                HPGWarn.Warn(
                    $"Unable to find AccountId: '{expected.AccountId}' for UserName: '{expected.UserName}' in  Actual!");
            else
            {
                Steps.AddTestStep($"Validating Account ID: '{expected.AccountId}' for UserName: '{expected.UserName}'.",
                    "System should match.");
                HPGWarn.WarnRange(expected.Validate(actual));
            }
        }
    }

    public void TestProcurementUsersRolesAndSpoc()
    {
        var applicationName = "Procurement";
        Steps.AddTestStep($"Validating 'Procurement' users from {GlobalTestVariables.TestEnvironment} Pass.",
            "System should match.");

        //Pulls from PROD PASS and formats the user domain to match data transformation.
        var toBeFormatted = _passRepository
            .GetSecurityUsersAndSpoc(_passDbServer, applicationName)
            .ToList();

        var expectedList = FormattedUserList(toBeFormatted, applicationName).Where(i => !i.UserName.Contains("gpouser")).ToList();

        var actualDictionary = _passRolesSpoc
            .Where(i => i.ApplicationName.Equals("SMART - Procurement", StringComparison.CurrentCultureIgnoreCase))
            .ToDictionary(a => new UserKey { AccountId = a.AccountId, ApplicationRoleName = a.ApplicationRoleName },
                j => j);

        var warningList                = new ConcurrentBag<string>();
        var actualConcurrentDictionary = new ConcurrentDictionary<UserKey, UserPassRoleSpoc>(actualDictionary);

        Parallel.ForEach(expectedList, exp =>
        {
            if (!actualConcurrentDictionary.TryGetValue(
                    new UserKey() { AccountId = exp.AccountId, ApplicationRoleName = exp.ApplicationRoleName },
                    out _))
                warningList.Add($"{exp.UserName}, '{exp.Domain}' ,'{exp.ApplicationRoleName}'");
        });

        if (!warningList.IsNullOrEmpty())
            HPGWarn.WarnRange(warningList.ToList());
    }
    

    private struct UserKey
    {
        public int     AccountId           { get; set; }
        public string? ApplicationRoleName { get; set; }
    }

    /// <summary>
    /// Formats the user pass role to match the domain and transforms the PASS SMAC role to the appropriate Security Role based on Domain.
    /// </summary>
    /// <param name="listToBeFormatted"></param>
    /// <param name="application"></param>
    /// <returns></returns>
    private static IEnumerable<UserPassRoleSpoc> FormattedUserList(List<UserPassRoleSpoc> listToBeFormatted, string application)
    {
        List<UserPassRoleSpoc> list = new List<UserPassRoleSpoc>();
        foreach (var toBeFormatted in listToBeFormatted)
        {
            string domain = FormatDomain(toBeFormatted.Domain.ToStringOrEmpty());

            string roleName;
            if (application.Equals("Security"))
            {
                roleName = toBeFormatted.Domain.Equals("lpnt", StringComparison.OrdinalIgnoreCase) ||
                           toBeFormatted.Domain.Equals("capella", StringComparison.OrdinalIgnoreCase)
                    ? "Security - Client Administrator"
                    : "Security - Administrator";
            }
            else
            {
                roleName = toBeFormatted.ApplicationRoleName.ToStringOrEmpty();
            }
            
            list.Add(new UserPassRoleSpoc
            {
                UserName        = toBeFormatted.UserName,
                AccountId       = toBeFormatted.AccountId,
                Domain          = domain,
                ApplicationName = application.Equals("Security") ? "SMART - Security" : toBeFormatted.ApplicationName,
                ApplicationRoleName = roleName,
                Spoc = toBeFormatted.Spoc
            });
        }
        
        return list;

    }

    private static string FormatDomain(string sourceDomain)
    {
        var environment = GlobalTestVariables.TestEnvironment switch
        {
            "qasbx" => "dev",
            "qa" => "qa",
            _ => ""
        };

        if (sourceDomain.Contains("hca", StringComparison.OrdinalIgnoreCase))
            return $"hca{environment}";
        if (sourceDomain.Contains("nonaffil", StringComparison.OrdinalIgnoreCase))
            return $"nonaffil{environment}";
        if (sourceDomain.Contains("lpnt", StringComparison.OrdinalIgnoreCase) ||
            sourceDomain.Contains("capella", StringComparison.OrdinalIgnoreCase))
            return $"lpnt{environment}";

        return sourceDomain;
    }
}
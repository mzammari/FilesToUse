﻿using System;
using System.Collections.Generic;
using Utilities.DatabaseUtility;

namespace SmartSecurityTestAutomation.Data.Migration;

public class PassRepository
{
    private readonly string _dbName = "HPG_Security";

    public IEnumerable<UserPassRoleSpoc> GetSecurityUsersAndSpoc(string server, string applicationName)
    {
        try
        {
            var dbs = new DbSql(server, _dbName);
            var query = string.Format(SqlSelectPassUsers,
                applicationName.Equals("SMART - Security")
                    ? "Where apr.Name = 'PASS - SMART Procurement SMAC' and a.IsDeactivated = 0"
                    : $"Where apr.Name like '{applicationName}%' and a.IsDeactivated = 0 and ar.CreatedOn < '2023-5-5'");

            return dbs.GetRecordsIntoObject<UserPassRoleSpoc>(query);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw new Exception($"Unable to retrieve SMART Security data!\r\nError Message: {e}");
        }
    }

    private const string SqlSelectPassUsers = @"Select accountId as AccountID
      ,LOWER(Domain) as Domain
      ,SamAccountName as UserName
      ,UserName as [Name]
      ,ApplicationName
      ,ApplicationRoleName
      ,STRING_AGG(hierarchy + ' - ' + OrgObjectID,'|') as Spoc
from  (
Select a.id as accountId
      ,a.Domain
      ,a.SamAccountName
      ,a.FirstName + ' ' + a.LastName as UserName
      ,apr.Name as ApplicationRoleName  
      ,aps.Name as ApplicationName         
      ,CONVERT(varchar, j.hierarchy) as hierarchy
      ,RIGHT('0000' + j.OrgObjectID, 5) as OrgObjectID
from [dbo].[Accounts] a
left join [dbo].[AccountRoles] ar on a.Id = ar.AccountId
left join [dbo].[ApplicationRoles] apr on ar.ApplicationRoleId = apr.Id
left join [dbo].[ApplicationSystems] aps on apr.System_Id = aps.Id
left join [dbo].[Jurisdictions] j on a.Id = j.Account_Id and apr.System_Id = j.ApplicationSystem_Id
{0}) a
group by accountId
      ,Domain
      ,SamAccountName
      ,UserName
      ,ApplicationName
      ,ApplicationRoleName
order by SamAccountName, ApplicationName asc";
}
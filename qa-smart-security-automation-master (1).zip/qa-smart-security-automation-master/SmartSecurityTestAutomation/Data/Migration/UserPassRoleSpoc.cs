﻿using System.Collections.Generic;
using System.Linq;
using Utilities.Validation;

namespace SmartSecurityTestAutomation.Data.Migration;

public class UserPassRoleSpoc
{
    public string? UserName            { get; set; }
    public int     AccountId           { get; set; }
    public string? Domain              { get; set; }
    public string? ApplicationName     { get; set; }
    public string? ApplicationRoleName { get; set; }
    public string  Spoc                { get; set; }

    public List<string> Validate(UserPassRoleSpoc other)
    {
        var result = new List<string>
        {
            ValidationHelpers.AreEqual(UserName, other.UserName, field:"UserName"),
            ValidationHelpers.AreEqual(AccountId.ToString(), other.AccountId.ToString(), field:"AccountId"),
            ValidationHelpers.AreEqual(Domain, other.Domain, field:"Domain"),
            ValidationHelpers.AreEqual(ApplicationName, other.ApplicationName, field:"ApplicationName"),
            ValidationHelpers.AreEqual(ApplicationRoleName, other.ApplicationRoleName, field:"ApplicationRoleName"),
        };

        var expectedSpocList = Spoc.Split("|").ToList();
        var actualSpocList = other.Spoc.Split("|").ToList();
        foreach (var expected in expectedSpocList)
        {
            if (!actualSpocList.Contains(expected))
                HPGWarn.Warn($"Unable to find SPOC: '{expected}' in Actual!");
            else
            {
                ConsoleOut.WriteReport($"Expected SPOC:'{expected}' was in Actual.");
            }
        }

        return result.Where(i => i != string.Empty).ToList();
    }
}
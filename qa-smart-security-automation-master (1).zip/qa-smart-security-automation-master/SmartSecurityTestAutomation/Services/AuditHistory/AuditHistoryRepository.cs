﻿using System;
using System.Collections.Generic;
using Utilities.DatabaseUtility;

namespace SmartSecurityTestAutomation.Services.AuditHistory;

public class AuditHistoryRepository
{
    private readonly string _server;
    private readonly string _dbName;


    public AuditHistoryRepository(string server, string dbName)
    {
        _server = server;
        _dbName = dbName;
    }

    public IEnumerable<AuditHistoryResponse> GetUserAuditHistory(string userId)
    {
        try
        {
            var dbs   = new DbSql(_server, _dbName);
            var query = string.Format(SqlSelectAuditHistory, userId);
            return dbs.GetRecordsIntoObject<AuditHistoryResponse>(query);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw new Exception($"Unable to retrieve SMART Security data!\r\nError Message: {e}");
        }
    }

    private const string SqlSelectAuditHistory = @"Declare @UserId as int
	Select @UserId = Id from dbo.[User] where UserKey = '{0}'
    
    --Role
	SELECT
		ChangedDate,	
		case when ISNULL(ChangedBy,'') = '' THEN 'INITIAL_LOAD' ELSE ChangedBy END AS ChangedBy,
		'Roles' Attribute,
		ApplicationName,
		Added,	
		Removed		
	FROM(
		SELECT 
			CASE WHEN ISNULL(UR.UpdatedBy,'') = '' AND UR.IsDeleted = 0  THEN UR.CreatedOn 
				 WHEN ISNULL(UR.UpdatedBy,'') != '' AND UR.IsDeleted = 0  THEN UR.UpdatedOn 
				 WHEN  UR.IsDeleted = 1 AND ISNULL(UR.DeletedBy,'') != '' THEN UR.DeletedOn  END AS ChangedDate,
			CASE WHEN UR.IsDeleted = 0 and ISNULL(UR.UpdatedBy,'') = '' THEN C.FirstName +' '+C.LastName
				 WHEN UR.IsDeleted = 0 and ISNULL(UR.UpdatedBy,'') != '' THEN U.FirstName +' '+U.LastName
				 ELSE D.FirstName +' '+D.LastName END AS ChangedBy,
			R.Name,
			CASE WHEN  UR.IsDeleted  = 0 THEN R.Name ELSE '' END AS Added,
			CASE WHEN  UR.IsDeleted = 1 THEN R.Name ELSE '' END AS Removed,
			A.Name As ApplicationName
		FROM [dbo].[User_Role] UR
       
		INNER JOIN Role R ON R.Id = UR.RoleId
		LEFT JOIN Application A ON A.Id = R.ApplicationId
		LEFT JOIN [User] C ON C.Username = SUBSTRING(UR.CreatedBy,CHARINDEX('\',UR.CreatedBy)+1,LEN(UR.CreatedBy))
		LEFT JOIN [User] U ON U.Username = SUBSTRING(UR.UpdatedBy,CHARINDEX('\',UR.UpdatedBy)+1,LEN(UR.UpdatedBy))  
		LEFT JOIN [User] D ON D.Username = SUBSTRING(UR.DeletedBy,CHARINDEX('\',UR.DeletedBy)+1,LEN(UR.DeletedBy)) 
		WHERE ur.UserId = @UserId

		UNION ALL

		SELECT 
			CASE WHEN ISNULL(URH.UpdatedBy,'') = ''  AND URH.IsDeleted = 0  THEN URH.CreatedOn 
				 WHEN ISNULL(URH.UpdatedBy,'') != '' AND URH.IsDeleted = 0  THEN URH.UpdatedOn 
				 WHEN  URH.IsDeleted = 1 AND ISNULL(URH.DeletedBy,'') != '' THEN URH.DeletedOn  END AS ChangedDate,
			CASE WHEN URH.IsDeleted = 0 and ISNULL(URH.UpdatedBy,'') = '' THEN C.FirstName +' '+C.LastName
				 WHEN URH.IsDeleted = 0 and ISNULL(URH.UpdatedBy,'') != '' THEN U.FirstName +' '+U.LastName
				 ELSE D.FirstName +' '+D.LastName END AS ChangedBy,
			R.Name,
			CASE WHEN  URH.IsDeleted = 0 THEN R.Name ELSE '' END AS Added,
			CASE WHEN  URH.IsDeleted = 1 THEN R.Name ELSE '' END AS Removed,
			A.Name As ApplicationName
		FROM [dbo].[User_Role_History] URH        
		INNER JOIN Role R ON R.Id = URH.RoleId
		LEFT JOIN Application A ON A.Id = R.ApplicationId
		LEFT JOIN [User] C ON C.Username = SUBSTRING(URH.CreatedBy,CHARINDEX('\',URH.CreatedBy)+1,LEN(URH.CreatedBy)) 
		LEFT JOIN [User] U ON U.Username = SUBSTRING(URH.UpdatedBy,CHARINDEX('\',URH.UpdatedBy)+1,LEN(URH.UpdatedBy))
		LEFT JOIN [User] D ON D.Username = SUBSTRING(URH.DeletedBy,CHARINDEX('\',URH.DeletedBy)+1,LEN(URH.DeletedBy))  
		WHERE URH.UserId = @UserId
	) AS RolesHistory 
	WHERE (Added != '' AND Removed = '') OR (Added = '' AND Removed != '')

	UNION ALL
    
    --Span of Control
	SELECT
		ChangedDate,	
		case when ISNULL(ChangedBy,'') = '' THEN 'INITIAL_LOAD' ELSE ChangedBy END AS ChangedBy,	
		'SPOC' Attribute,
		ApplicationName,
		Added,	
		Removed
	FROM(
		SELECT 
			CASE WHEN ISNULL(SC.UpdatedBy,'') = '' AND SC.IsDeleted = 0  THEN SC.CreatedOn 
				 WHEN ISNULL(SC.UpdatedBy,'') != '' AND SC.IsDeleted = 0  THEN SC.UpdatedOn 
			     WHEN  SC.IsDeleted = 1 AND ISNULL(SC.DeletedBy,'') != '' THEN SC.DeletedOn  END AS ChangedDate,
			CASE WHEN SC.IsDeleted = 0 and ISNULL(SC.UpdatedBy,'') = '' THEN C.FirstName +' '+C.LastName
				 WHEN SC.IsDeleted = 0 and ISNULL(SC.UpdatedBy,'') != '' THEN U.FirstName +' '+U.LastName
				 ELSE D.FirstName +' '+D.LastName END AS ChangedBy,
			CASE WHEN  SC.IsDeleted = 0 THEN 
			CONVERT(VARCHAR(255),CONVERT(VARCHAR(255),H.Name) +':'+ CONVERT(VARCHAR(255),SC.OrgObjectID)) ELSE '' END AS Added,
			CASE WHEN  SC.IsDeleted = 1 THEN 
			CONVERT(VARCHAR(255),CONVERT(VARCHAR(255),H.Name) +':'+ CONVERT(VARCHAR(255),SC.OrgObjectID)) ELSE '' END AS Removed,
			A.Name As ApplicationName
		FROM [dbo].[SpanOfControl] SC
        		LEFT JOIN Application A ON A.Id = SC.ApplicationId
		LEFT JOIN [User] C ON C.Username = SUBSTRING(SC.CreatedBy,CHARINDEX('\',SC.CreatedBy)+1,LEN(SC.CreatedBy))
		LEFT JOIN [User] U ON U.Username = SUBSTRING(SC.UpdatedBy,CHARINDEX('\',SC.UpdatedBy)+1,LEN(SC.UpdatedBy))
		LEFT JOIN [User] D ON D.Username = SUBSTRING(SC.DeletedBy,CHARINDEX('\',SC.DeletedBy)+1,LEN(SC.DeletedBy)) 
		LEFT JOIN OrgUnitType H ON H.Id = SC.Hierarchy
		WHERE SC.UserId = @UserId

		UNION ALL

		SELECT 
			CASE WHEN ISNULL(SCH.UpdatedBy,'') = '' AND SCH.IsDeleted = 0  THEN SCH.CreatedOn 
				 WHEN ISNULL(SCH.UpdatedBy,'') !='' AND SCH.IsDeleted = 0  THEN SCH.UpdatedOn 
			     WHEN  SCH.IsDeleted = 1 AND ISNULL(SCH.DeletedBy,'') != '' THEN SCH.DeletedOn  END AS ChangedDate,
			CASE WHEN SCH.IsDeleted = 0 and ISNULL(SCH.UpdatedBy,'') = '' THEN C.FirstName +' '+C.LastName
				 WHEN SCH.IsDeleted = 0 and ISNULL(SCH.UpdatedBy,'') != '' THEN U.FirstName +' '+U.LastName
				 ELSE D.FirstName +' '+D.LastName END AS ChangedBy,
			CASE WHEN  SCH.IsDeleted = 0 THEN 
			CONVERT(VARCHAR(255),CONVERT(VARCHAR(255),H.Name) +':'+ CONVERT(VARCHAR(255),SCH.OrgObjectID)) ELSE '' END AS Added,
			CASE WHEN  SCH.IsDeleted = 1 THEN 
			CONVERT(VARCHAR(255),CONVERT(VARCHAR(255),H.Name) +':'+ CONVERT(VARCHAR(255),SCH.OrgObjectID)) ELSE '' END AS Removed,
			A.Name As ApplicationName
		FROM [dbo].[SpanOfControl_History] SCH
        
		LEFT JOIN Application A ON A.Id = SCH.ApplicationId
		LEFT JOIN [User] C ON C.Username = SUBSTRING(SCH.CreatedBy,CHARINDEX('\',SCH.CreatedBy)+1,LEN(SCH.CreatedBy)) 
		LEFT JOIN [User] U ON U.Username = SUBSTRING(SCH.UpdatedBy,CHARINDEX('\',SCH.UpdatedBy)+1,LEN(SCH.UpdatedBy)) 
		LEFT JOIN [User] D ON D.Username = SUBSTRING(SCH.DeletedBy,CHARINDEX('\',SCH.DeletedBy)+1,LEN(SCH.DeletedBy))
		LEFT JOIN OrgUnitType H ON H.Id = SCH.Hierarchy
		WHERE SCH.UserId = @UserId
	) AS SPOCHistory 
	WHERE (Added != '' AND Removed = '') OR (Added = ''  AND Removed != '')

	UNION ALL

    --Vendor Affiliation
	SELECT
		ChangedDate,	
		case when ISNULL(ChangedBy,'') = '' THEN 'INITIAL_LOAD' ELSE ChangedBy END AS ChangedBy,	
		'Vendor Affiliations' Attribute,
		ApplicationName,
		Added,	
		Removed
	FROM(
		SELECT 
			CASE WHEN ISNULL(UV.UpdatedBy,'') = '' AND UV.IsDeleted = 0  THEN UV.CreatedOn 
				 WHEN ISNULL(UV.UpdatedBy,'') != '' AND UV.IsDeleted = 0  THEN UV.UpdatedOn 
			     WHEN  UV.IsDeleted = 1 AND ISNULL(UV.DeletedBy,'') != '' THEN UV.DeletedOn  END AS ChangedDate,
			CASE WHEN UV.IsDeleted = 0 and ISNULL(UV.UpdatedBy,'') = '' THEN C.FirstName +' '+C.LastName
				 WHEN UV.IsDeleted = 0 and ISNULL(UV.UpdatedBy,'') != '' THEN U.FirstName +' '+U.LastName
				 ELSE D.FirstName +' '+D.LastName END AS ChangedBy,
			CASE WHEN  UV.IsDeleted = 0 THEN CONVERT(VARCHAR(255),UV.VendorName) +'-'+ CONVERT(VARCHAR,UV.VendorId) ELSE '' END AS Added,
			CASE WHEN  UV.IsDeleted = 1 THEN CONVERT(VARCHAR(255),UV.VendorName) +'-'+ CONVERT(VARCHAR,UV.VendorId) ELSE '' END AS Removed,
			'' As ApplicationName
		FROM [dbo].[User_Vendor] UV        	
		LEFT JOIN [User] C ON C.Username = SUBSTRING(UV.CreatedBy,CHARINDEX('\',UV.CreatedBy)+1,LEN(UV.CreatedBy))
		LEFT JOIN [User] U ON U.Username = SUBSTRING(UV.UpdatedBy,CHARINDEX('\',UV.UpdatedBy)+1,LEN(UV.UpdatedBy)) 
		LEFT JOIN [User] D ON D.Username = SUBSTRING(UV.DeletedBy,CHARINDEX('\',UV.DeletedBy)+1,LEN(UV.DeletedBy)) 
		WHERE UV.UserId = @UserId

		UNION ALL

		SELECT 
			CASE WHEN ISNULL(UVH.UpdatedBy,'') = '' AND UVH.IsDeleted = 0  THEN UVH.CreatedOn 
				 WHEN ISNULL(UVH.UpdatedBy,'') != '' AND UVH.IsDeleted = 0  THEN UVH.UpdatedOn 
			     WHEN  UVH.IsDeleted = 1 AND ISNULL(UVH.DeletedBy,'') != '' THEN UVH.DeletedOn  END AS ChangedDate,
			CASE WHEN UVH.IsDeleted = 0 and ISNULL(UVH.UpdatedBy,'') = '' THEN C.FirstName +' '+C.LastName
				 WHEN UVH.IsDeleted = 0 and ISNULL(UVH.UpdatedBy,'') != '' THEN U.FirstName +' '+U.LastName
				 ELSE D.FirstName +' '+D.LastName END AS ChangedBy,
			CASE WHEN  UVH.IsDeleted = 0 THEN CONVERT(VARCHAR(255),UVH.VendorName) +'-'+ CONVERT(VARCHAR,UVH.VendorId) ELSE '' END AS Added,
			CASE WHEN  UVH.IsDeleted = 1 THEN CONVERT(VARCHAR(255),UVH.VendorName) +'-'+ CONVERT(VARCHAR,UVH.VendorId) ELSE '' END AS Removed,
			'' As ApplicationName
		FROM [dbo].[User_Vendor_History] UVH
        LEFT JOIN [User] C ON C.Username = SUBSTRING(UVH.CreatedBy,CHARINDEX('\',UVH.CreatedBy)+1,LEN(UVH.CreatedBy))  
		LEFT JOIN [User] U ON U.Username = SUBSTRING(UVH.UpdatedBy,CHARINDEX('\',UVH.UpdatedBy)+1,LEN(UVH.UpdatedBy))  
		LEFT JOIN [User] D ON D.Username = SUBSTRING(UVH.DeletedBy,CHARINDEX('\',UVH.DeletedBy)+1,LEN(UVH.DeletedBy))  
		WHERE UVH.UserId = @UserId
	) AS VendorHistory 
	WHERE  (Added != '' AND Removed = '') OR (Added = '' AND Removed != '')

	UNION ALL

	SELECT	ChangedDate,	
	        case when ISNULL(ChangedBy,'') = '' THEN 'INITIAL_LOAD' ELSE ChangedBy END AS ChangedBy,	
	        'Status' Attribute,
	        ApplicationName,
	        Added,	
	        Removed		
	FROM(
		SELECT CASE WHEN ISNULL(U.UpdatedOn,'') = '' THEN U.CreatedOn 
				    WHEN ISNULL(U.UpdatedOn,'') != '' THEN U.UpdatedOn END AS ChangedDate,

			   CASE WHEN ISNULL(U.UpdatedBy,'') = '' THEN C.FirstName +' '+C.LastName
				    WHEN ISNULL(U.UpdatedBy,'') != '' THEN US.FirstName +' '+US.LastName
				 END AS ChangedBy,
			   '' AS Name,
			   CASE WHEN  U.IsDeactivated  = 0 THEN 'Active' ELSE '' END AS Added,
			   CASE WHEN  U.IsDeactivated = 1 THEN 'InActive' ELSE '' END AS Removed,
			   '' As ApplicationName
		FROM [User] U
		LEFT JOIN [User] C ON C.Username = SUBSTRING(U.CreatedBy,CHARINDEX('\',U.CreatedBy)+1,LEN(U.CreatedBy))
		LEFT JOIN [User] US ON US.Username = SUBSTRING(U.UpdatedBy,CHARINDEX('\',U.UpdatedBy)+1,LEN(U.UpdatedBy)) 
		WHERE U.Id = @UserId

		UNION ALL

		SELECT 
			CASE WHEN ISNULL(UH.UpdatedOn,'') = '' THEN UH.CreatedOn 
				 WHEN ISNULL(UH.UpdatedOn,'') != '' THEN UH.UpdatedOn END AS ChangedDate,

			CASE WHEN ISNULL(UH.UpdatedBy,'') = '' THEN C.FirstName +' '+C.LastName
				 WHEN ISNULL(UH.UpdatedBy,'') != '' THEN US.FirstName +' '+US.LastName
				 END AS ChangedBy,
			'' AS Name,
			CASE WHEN  UH.IsDeactivated  = 0 THEN 'Active' ELSE '' END AS Added,
			CASE WHEN  UH.IsDeactivated = 1 THEN 'InActive' ELSE '' END AS Removed,
			'' As ApplicationName
		FROM [dbo].[User_History] UH
		LEFT JOIN [User] C ON C.Username = SUBSTRING(UH.CreatedBy,CHARINDEX('\',UH.CreatedBy)+1,LEN(UH.CreatedBy)) 
		LEFT JOIN [User] US ON US.Username = SUBSTRING(UH.UpdatedBy,CHARINDEX('\',UH.UpdatedBy)+1,LEN(UH.UpdatedBy)) 
		WHERE UH.Id = @UserId
	) AS UserHistory 
	WHERE (Added != '' AND Removed = '') OR (Added = '' AND Removed != '')";
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using Utilities.ObjectExtensions;
using Utilities.Validation;


namespace SmartSecurityTestAutomation.Services.AuditHistory;

public class AuditHistoryResponse
{
    [JsonPropertyName("changedDate")]
    public DateTimeOffset? ChangedDate { get; set; }

    [JsonPropertyName("changedBy")]
    public string ChangedBy { get; set; }

    [JsonPropertyName("attribute")]
    public string Attribute { get; set; }

    [JsonPropertyName("applicationName")]
    public string ApplicationName { get; set; }

    [JsonPropertyName("added")]
    public string? Added { get; set; }

    [JsonPropertyName("removed")]
    public string? Removed { get; set; }

    public List<string> Validate(AuditHistoryResponse other)
    {
        var result = new List<string>
        {
            ValidationHelpers.AreEqual(ChangedDate.ToStringOrEmpty(), other.ChangedDate.ToStringOrEmpty(), "ChangedDate"),
            ValidationHelpers.AreEqual(ChangedBy.ToStringOrEmpty(), other.ChangedBy.ToStringOrEmpty(), "ChangedBy"),
            ValidationHelpers.AreEqual(Attribute.ToStringOrEmpty(), other.Attribute.ToStringOrEmpty(), "Attribute"),
            ValidationHelpers.AreEqual(ApplicationName.ToStringOrEmpty(), other.ApplicationName.ToStringOrEmpty(), "ApplicationName"),
            ValidationHelpers.AreEqual(Added.ToStringOrEmpty(), other.Added.ToStringOrEmpty(), "Added"),
            ValidationHelpers.AreEqual(Removed.ToStringOrEmpty(), other.Removed.ToStringOrEmpty(), "Removed"),
        };

        return result.Where(i => i.ToStringOrEmpty() != string.Empty).ToList();
    }
}
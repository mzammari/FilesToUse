﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization.Formatters;
using System.Threading.Tasks;
using System.Xml;
using Newtonsoft.Json;
using SmartSecurityTestAutomation.Services.Users;
using SmartSecurityTestAutomation.Tests;
using Utilities.HttpUtility;
using Utilities.ObjectExtensions;

namespace SmartSecurityTestAutomation.Services.AuditHistory;

public class AuditHistoryApi : MasterApi
{
    private const string AuditHistoryResource = "/audit-history";

    private readonly AuditHistoryRepository _auditHistoryDb =
        new(GlobalTestVariables.Configuration!["SmartSecurity:DatabaseServer"]!, GlobalTestVariables.Configuration["SmartSecurity:DatabaseName"]!);

    #region API Calls

    private static HttpResponse GetUserAuditHistory(Dictionary<string, string?> parameters) =>
        GetSimpleRequest(RequestBuilder.BuildRequestWithParameters($"{GlobalTestVariables.Configuration!["SmartSecurity:BaseUri"]!}{AuditHistoryResource}", parameters));

    #endregion API Calls

    #region Test Methods
    /// <summary>
    /// Test Sending 'GET' request to /audit-history API Endpoint.
    /// Manual Estimated Execution Time: 0:05:00
    /// </summary>
    public void TestGetUserAuditHistory()
    {
        Steps.AddTestStep("Test sending 'GET' request to /audit-history API endpoint.",
            "System should respond accordingly.");

        //get test users maybe 5
        var userDb =
            new UserRepository(GlobalTestVariables.Configuration!["SmartSecurity:DatabaseServer"]!, GlobalTestVariables.Configuration["SmartSecurity:DatabaseName"]!);
        var testUsers = userDb.GetAllUsers().Where(i => !i.IsDeactivated).PickRandomList(5);
        //var testUsers = userDb.GetAllUsers().Where(i => !i.IsDeactivated && i.Username.Equals("gpouser411052cc51294"));
        //loop thru test users
        foreach (var testUser in testUsers)
        {
            Steps.AddTestStep($"Sending 'GET' request to /audit-history?userid = {testUser.Id}  API endpoint.",
                $"System should respond with a {OkResponse}.");
            
            //Parameters
            var parameters = new Dictionary<string, string?> { { "userid", testUser.Id.ToString() } };
            //send 'GET'
            var response = GetUserAuditHistory(parameters);

            //Validate response message
            if (HPGWarn.AreEqual(OkResponse, response.Status, field: ResponseStatusField))
            {
                var actualList = JsonConvert.DeserializeObject<List<AuditHistoryResponse>>(response.Response);
                //Get expected list
                var expectedList = _auditHistoryDb.GetUserAuditHistory(testUser.Id.ToString()).ToList();
                
                HPGWarn.AreEqual(expectedList.Count.ToString(), actualList!.Count.ToString(), field: "List Count");
				//ValidateAuditHistoryList(expectedList, actualList);
				ValidateAuditHistory(expectedList, actualList);
			}
        }
    }

	/// <summary>
	/// Test sending 'GET' request to /audit-history API endpoint with bad values.
	/// Scenarios: Blank UserId, Null UserId, Non-Existent UserId, Alpha UserId
	/// Manual Estimated Execution Time: 0:05:00
	/// </summary>
	public void TestGetUserAuditHistoryBadRequest()
    {
        Steps.AddTestStep("Test sending 'GET' request to /audit-history API endpoint with bad values.",
            "System should respond accordingly.");

        var scenarios = new List<string> { "Blank UserId", "Null UserId", "Non-Existent UserId", "Alpha UserId"};
        foreach (var scenario in scenarios)
        {
            var                         statusCode = string.Empty;
            var parameters = new Dictionary<string, string?>();
            switch (scenario)
            {
                case "Blank UserId":
                    parameters.Add("userid","");
                    statusCode = BadRequestResponse;
                    break;
                case "Null UserId":
                    statusCode = BadRequestResponse;
                    break;
                case "Non-Existent UserId":
                    parameters.Add("userid", "c8f4fd9c-8485-4df4-9000-8ac6265d42e1");
                    statusCode = OkResponse;
                    break;
                case "Alpha UserId":
                    parameters.Add("userid", "abc123");
                    statusCode = BadRequestResponse;
                    break;
                default:
                    break;
            }

            Steps.AddTestStep($"Sending 'GET' request to /audit-history with {scenario}.",$"System should respond with a status code: '{statusCode}'");
            var response = GetUserAuditHistory(parameters);
            if (HPGWarn.AreEqual(statusCode, response.Status) && scenario.Equals("Non-Existent UserId"))
            {
                var actual = JsonConvert.DeserializeObject<List<AuditHistoryResponse>>(response.Response);
                HPGWarn.AreEqual("0", actual!.Count.ToString(), field: "Result Count");
            }
        }
    }

    /// <summary>
    /// Test DE15594 for audit history not showing changes
    /// Manual Estimated Execution Time: 0:05:00
    /// </summary>
    public void TestUserAuditHistoryDE15594()
    {
        Steps.AddTestStep("Test DE15594 Audit History of User not showing updated adds.","System should show.");

        //create new user
        var userApi = new UserApi();
        var newUser = userApi.AddNewUser("Vendor");

        //create a payload to add and a payload to remove.
        var     userRequest   = userApi.CreateUserRequest(newUser!, 1, 1, 1);
        var assignPayload = JsonConvert.SerializeObject(userRequest, JsonNullSetting);
        userRequest.RoleIds.Clear();
        userRequest.SpanOfControl.Clear();
        userRequest.VendorAffiliation.Clear();
        var unassignPayload = JsonConvert.SerializeObject(userRequest, JsonNullSetting);

        //loop 3 times with add and delete roles alternating
        const int amountOfChanges = 3;
        Steps.AddTestStep($"Send user requests to setup scenario for user.","System should return (200) OK");
        for (var i = 0; i < amountOfChanges; i++)
        {
            var response = UserApi.PostUserClaim(i is 0 or 2 ? assignPayload : unassignPayload);
            HPGAssert.AreEqual(OkResponse, response.Status);
        }

        var expectedAuditHistory = _auditHistoryDb.GetUserAuditHistory(newUser!.Id.ToString()).GroupBy(j => j.Attribute)
            .ToDictionary(grp => grp.Key, j => j.ToList());
        
        Steps.AddTestStep("Retrieve Audit History for user from /audit-history API endpoint","System should return results.");
        //Parameters
        var parameters           = new Dictionary<string, string?> { { "userid", newUser.Id.ToString() } };
        var           responseAuditHistory = GetUserAuditHistory(parameters);
        if (HPGWarn.AreEqual(OkResponse, responseAuditHistory.Status))
        {
            var actualAuditHistory =
                JsonConvert.DeserializeObject<List<AuditHistoryResponse>>(responseAuditHistory.Response);

            var actualAuditHistoryDictionary = actualAuditHistory!.GroupBy(i => i.Attribute)
                .ToDictionary(grp => grp.Key, j => j.ToList());

            //validate there are correct number of records for this user for each attribute.
            Steps.AddTestStep("Validate audit history count for each attribute.",$"Should match the expected count of {amountOfChanges} changes.");
            foreach (var expected in expectedAuditHistory)
            {
                if(!actualAuditHistoryDictionary.TryGetValue(expected.Key, out var actual))
                    HPGWarn.Warn($"Unable to get history for Attribute: {expected.Key} for userId: {newUser.Id}!");
                else
                {
                    HPGWarn.AreEqual(expected.Value.Count.ToString(), actual.Count.ToString(),
                        field: $"Audit History Count for Attribute: {expected.Key}");
                }
            }
        }
    }

	#endregion Test Methods

	#region Validations
	/// <summary>
	/// Compares the Expected and Actual list against each other.
	/// Remove by end of 1st Qrter 2025 after confirming the new method works as expected. - Marlon
	/// </summary>
	/// <param name="expectedList"></param>
	/// <param name="actualList"></param>
	private void ValidateAuditHistoryList(List<AuditHistoryResponse> expectedList, List<AuditHistoryResponse> actualList)
    {
        Steps.AddTestStep("Validate Expected list is in Actual list.", "Expected should match Actual.");
        var actualDictionary = actualList.Distinct().ToDictionary(i => new
            { ApplicationName = i.ApplicationName.ToStringOrEmpty(), 
	            i.Attribute, 
	            i.ChangedBy, 
	            ChangedDate = i.ChangedDate!.Value.ToString("O"), 
	            Added = i.Added.ToStringOrEmpty(), 
	            Removed = i.Removed.ToStringOrEmpty() });
        
        var warnings = new ConcurrentBag<string>();
        Parallel.ForEach(expectedList, expected =>
        {
            if (!actualDictionary.TryGetValue(new
                {
                    ApplicationName = expected.ApplicationName.ToStringOrEmpty(),
                    expected.Attribute,
                    expected.ChangedBy,
                    ChangedDate =expected.ChangedDate!.Value.ToString("O"),
                    Added = expected.Added.ToStringOrEmpty(),
                    Removed = expected.Removed.ToStringOrEmpty()
                }, out _))
                warnings.Add(
                    $"Unable to find ApplicationName: '{expected.ApplicationName}', Attribute: '{expected.Attribute}', Added: '{expected.Added}', Removed: '{expected.Removed}',Changed By: '{expected.ChangedBy}', and Changed Date: '{expected.ChangedDate}' in Actual List!");
            
            //Debug Purpose Only
            //else
            //{
            //    Console.WriteLine($"Was able to find ApplicationName: '{expected.ApplicationName}', Attribute: '{expected.Attribute}', Changed By: '{expected.ChangedBy}', and Changed Date: '{expected.ChangedDate}' in Actual List.");
            //}

        });

        HPGWarn.WarnRange(new List<string>(warnings));
        warnings.Clear();

        Steps.AddTestStep("Validate Actual list is in Expected list.", "Actual should match Expected.");
        var expectedDictionary = expectedList.Distinct().ToDictionary(i => new
            { ApplicationName = i.ApplicationName.ToStringOrEmpty(), i.Attribute, i.ChangedBy, i.ChangedDate, i.Added, i.Removed });

        Parallel.ForEach(actualList, actual =>
        {
            if (!expectedDictionary.TryGetValue(
                    new
                    {
                        ApplicationName = actual.ApplicationName.ToStringOrEmpty(), 
                        actual.Attribute, 
                        actual.ChangedBy, 
                        actual.ChangedDate, 
                        actual.Added,
                        actual.Removed
                    }, out _))
                warnings.Add(
                    $"Unable to find ApplicationName: '{actual.ApplicationName}', Attribute: '{actual.Attribute}', Added: '{actual.Added}', Removed: '{actual.Removed}', Changed By: '{actual.ChangedBy}', and Changed Date: '{actual.ChangedDate}' in Expected List!");
            //Debug Purpose ONLY
            //else
            //{
            //    Console.WriteLine($"Able to find ApplicationName: '{actual.ApplicationName}', Attribute: '{actual.Attribute}', Changed By: '{actual.ChangedBy}', and Changed Date: '{actual.ChangedDate}' in Expected List!");
            //}
        });
        HPGWarn.WarnRange(new List<string>(warnings));
        warnings.Clear();
    }

	/// <summary>
	/// Validates the audit history by comparing each property value of the expected list to the actual list.
	/// Reports warnings for any differences found in the actual list.
	/// </summary>
	/// <param name="expectedList">The expected list of audit history responses.</param>
	/// <param name="actualList">The actual list of audit history responses.</param>
	private void ValidateAuditHistory(List<AuditHistoryResponse> expectedList, List<AuditHistoryResponse> actualList)
	{
		// Initialize a concurrent bag to store warnings
		var warnings = new ConcurrentBag<string>();
		Steps.AddTestStep("Validate Expected list is in Actual list.", "Expected should match Actual.");
		// Iterate over each item in the expected list
		Parallel.ForEach(expectedList, expected =>
		{
			// Find the corresponding item in the actual list
			var actual = actualList.FirstOrDefault(a =>
		a.ApplicationName == expected.ApplicationName &&
		a.Attribute == expected.Attribute &&
		a.ChangedBy == expected.ChangedBy &&
		a.ChangedDate == expected.ChangedDate &&
		a.Added == expected.Added &&
		a.Removed == expected.Removed); // Compare each property
			// If the expected item is not found in the actual list, add a warning
			if (actual == null)
			{
				warnings.Add($"Expected item not found: ApplicationName='{expected.ApplicationName}', Attribute='{expected.Attribute}', ChangedBy='{expected.ChangedBy}', ChangedDate='{expected.ChangedDate}', Added='{expected.Added}', Removed='{expected.Removed}'");
			}
			else
			{
				// Compare each property and add warnings for any differences
				if (actual.ApplicationName != expected.ApplicationName)
				{
					warnings.Add($"Difference in ApplicationName: Expected='{expected.ApplicationName}', Actual='{actual.ApplicationName}'");
				}

				if (actual.Attribute != expected.Attribute)
				{
					warnings.Add($"Difference in Attribute: Expected='{expected.Attribute}', Actual='{actual.Attribute}'");
				}

				if (actual.ChangedBy != expected.ChangedBy)
				{
					warnings.Add($"Difference in ChangedBy: Expected='{expected.ChangedBy}', Actual='{actual.ChangedBy}'");
				}

				if (actual.ChangedDate != expected.ChangedDate)
				{
					warnings.Add($"Difference in ChangedDate: Expected='{expected.ChangedDate}', Actual='{actual.ChangedDate}'");
				}

				if (actual.Added != expected.Added)
				{
					warnings.Add($"Difference in Added: Expected='{expected.Added}', Actual='{actual.Added}'");
				}

				if (actual.Removed != expected.Removed)
				{
					warnings.Add($"Difference in Removed: Expected='{expected.Removed}', Actual='{actual.Removed}'");
				}
			}
			//Debug Purpose ONLY
			//else
			//{
			//    Console.WriteLine($"Able to find ApplicationName: '{actual.ApplicationName}', Attribute: '{actual.Attribute}', Changed By: '{actual.ChangedBy}', and Changed Date: '{actual.ChangedDate}' in Expected List!");
			//}
		});

		// Report all warnings
		HPGWarn.WarnRange(new List<string>(warnings));
		warnings.Clear();
	}
    #endregion Validations
}
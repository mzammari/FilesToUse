﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartSecurityTestAutomation.Services.Users
{
	public class LoggedInUserRolesResponse
	{
		[JsonProperty("isSecurityAdmin")]
		public bool isSecurityAdmin { get; set; }
		[JsonProperty("isClientAdmin")]
		public bool isClientAdmin { get; set; }
		[JsonProperty("isVendorAdmin")]
		public bool isVendorAdmin { get; set; }
		[JsonProperty("isViraAdmin")]
		public bool isViraAdmin { get; set; }
		[JsonProperty("isVBOSupportReadOnly")]
		public bool isVBOSupportReadOnly { get; set; }
	}
}

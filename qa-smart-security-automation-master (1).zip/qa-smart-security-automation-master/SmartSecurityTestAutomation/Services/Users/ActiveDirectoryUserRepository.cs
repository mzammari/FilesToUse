﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.DirectoryServices;
using System.Linq;
using System.Security.Policy;
using Utilities.ObjectExtensions;

namespace SmartSecurityTestAutomation.Services.Users;

public class ActiveDirectoryUserRepository
{
    private readonly string _adLdapUri;

    public ActiveDirectoryUserRepository(string ldapServer)
    {
        _adLdapUri = ldapServer;
    }

    /// <summary>
    /// Pulls internal user data from LDAP based on a search criteria
    /// </summary>
    /// <param name="searchRequest"></param>
    /// <returns></returns>
    private IEnumerable<UserResponse> SearchDirectory(UserSearchRequest searchRequest)
    {
        var results = new List<UserResponse>();
        var domain  = new DirectoryEntry(_adLdapUri);
        domain.RefreshCache();
        var          search     = new DirectorySearcher(domain);
        const string baseSearch = "&(objectClass=User)";

        try
        {
            search.Filter =
                $"({baseSearch}(samAccountName={searchRequest.Username}*)(mail={searchRequest.Email}*)(givenName={searchRequest.FirstName}*)(sn={searchRequest.LastName}*))";
            search.Sort          = new SortOption("displayName", SortDirection.Ascending);
            search.ClientTimeout = TimeSpan.FromSeconds(120);

            search.PropertiesToLoad.Clear();
            search.PropertiesToLoad.Add("samAccountName");
            search.PropertiesToLoad.Add("givenName");
            search.PropertiesToLoad.Add("sn");
            search.PropertiesToLoad.Add("mail");
            search.PropertiesToLoad.Add("ADsPath");
            search.PropertiesToLoad.Add("employeeType");
            search.PropertiesToLoad.Add("Enabled");
            search.VirtualListView = new DirectoryVirtualListView(0, 50, 100);

            var adResults = search.FindAll();

            foreach (SearchResult result in adResults)  //This line: Error Message=The server does not support the requested critical extension.
			{
                var domainSubString   = result.Properties["ADsPath"];
                var splitDomainString = domainSubString[0].ToString().Split(',');
                var toSearch          = "DC=";
                var domainList        = splitDomainString.Where(s => s.StartsWith(toSearch)).ToList();
                string domainName = domainList.Count > 0
                    ? domainList[0][(domainList[0].IndexOf(toSearch, StringComparison.Ordinal) + toSearch.Length)..]
                        .Trim()
                    : string.Empty;

                if (result.Properties["employeeType"].Count > 0 &&
                    (result.Properties["employeeType"][0].ToString()!.ToUpper() == "EMPLOYEE" ||
                     result.Properties["employeeType"][0].ToString()!.ToUpper() == "CONTRACTOR" ||
                     result.Properties["employeeType"][0].ToString()!.ToUpper() == "VENDOR"))
                {
                    results.Add(new UserResponse()
                    {
                        Email = result.Properties["mail"].Count > 0
                            ? result.Properties["mail"][0].ToString()
                            : string.Empty,
                        FirstName = result.Properties["givenName"][0].ToString(),
                        LastName  = result.Properties["sn"][0].ToString(),
                        Username  = (string)result.Properties["samAccountName"][0],
                        Type = (result.Properties["employeeType"][0].ToString()!.ToUpper() == "EMPLOYEE" ||
                                result.Properties["employeeType"][0].ToString()!.ToUpper() == "CONTRACTOR")
                            ? "Employee"
                            : "Vendor",
                        Domain = domainName,
                    });
                }
                else if (result.Properties["employeeType"].Count == 0 &&
                         (domainName.StartsWith("lpnt") || domainName.StartsWith("capella")))
                {
                    results.Add(new UserResponse()
                    {
                        Email = result.Properties["mail"].Count > 0
                            ? result.Properties["mail"][0].ToString()
                            : string.Empty,
                        FirstName = result.Properties["givenName"][0].ToString(),
                        LastName  = result.Properties["sn"][0].ToString(),
                        Username  = (string)result.Properties["samAccountName"][0],
                        Type      = "Employee",
                        Domain    = domainName,
                    });
                }
            }
        }
        finally
        {
            search.Dispose();
            domain.Dispose();
        }

        return results;
    }

    /// <summary>
    /// Grabs a random internal user that is currently not in Smart Security Database.
    /// </summary>
    /// <param name="smartSecurityUsers"></param>
    /// <returns></returns>
    public UserResponse GetUserNotInSmartSecurity(List<UserResponse> smartSecurityUsers)
    {
        var          smartSecurityUsersDictionary = smartSecurityUsers.ToDictionary(i => i.Username, j => j);
        UserResponse user                         = null;
        var          userIsNotInSmartSecurity     = false;

        do
        {
            var sampleSecurityUser =
                smartSecurityUsers.Where(i => i.LastName.ToStringOrEmpty().Length > 4 && !i.LastName.Contains("trooper")).PickRandom();
            var searchCriteria = new UserSearchRequest() { LastName = sampleSecurityUser.LastName };
            ConsoleOut.WriteReport($"Searching LDAP for user with the last name of '{sampleSecurityUser.LastName}'.");

            var adSearchResults = SearchDirectory(searchCriteria)
                .Where(i => !i.Type.Equals("Vendor") && !i.Type.Equals("Mailbox Generic") &&
                            !i.Email.ToStringOrEmpty().Contains("xxx"));

            foreach (var adSearchResult in adSearchResults.Where(adSearchResult =>
                         !smartSecurityUsersDictionary.ContainsKey(adSearchResult.Username)))
            {
                user                     = adSearchResult;
                userIsNotInSmartSecurity = true;
                break;
            }
        } while (!userIsNotInSmartSecurity);

        return user;
    }

    /// <summary>
    /// This is just to grab user types.
    /// </summary>
    /// <returns></returns>
    public List<string> UserTypes()
    {
        UserSearchRequest searchRequest = new UserSearchRequest();
        searchRequest.LastName = "A";
        var          results    = new List<string>();
        var          domain     = new DirectoryEntry(_adLdapUri);
        var          search     = new DirectorySearcher(domain);
        const string baseSearch = "&(objectClass=User)";

        try
        {
            search.Filter =
                $"({baseSearch}(samAccountName={searchRequest.Username}*)(mail={searchRequest.Email}*)(givenName={searchRequest.FirstName}*)(sn={searchRequest.LastName}*))";
            search.Sort = new SortOption("displayName", SortDirection.Ascending);
            search.PropertiesToLoad.Clear();
            search.PropertiesToLoad.Add("samAccountName");
            search.PropertiesToLoad.Add("givenName");
            search.PropertiesToLoad.Add("sn");
            search.PropertiesToLoad.Add("mail");
            search.PropertiesToLoad.Add("ADsPath");
            search.PropertiesToLoad.Add("employeeType");


            var adResults = search.FindAll();

            results.AddRange(from SearchResult result in adResults
                let toSearch = "DC="
                where result.Properties["employeeType"].Count > 0
                select Convert.ToString(result.Properties["employeeType"][0]));
        }
        finally
        {
            search.Dispose();
            domain.Dispose();
        }

        return results.Distinct().ToList();
    }
}
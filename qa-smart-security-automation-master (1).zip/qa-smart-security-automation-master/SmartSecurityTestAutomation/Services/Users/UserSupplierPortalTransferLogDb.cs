﻿using System;

namespace SmartSecurityTestAutomation.Services.Users;

public class UserSupplierPortalTransferLogDb
{
    public int      Id                  { get; set; }
    public string   UserEmail           { get; set; }
    public string   RequestUri          { get; set; }
    public string   RequestContent      { get; set; }
    public string   RsponseContent      { get; set; }
    public string   ExceptionStackTrace { get; set; }
    public bool     IsSucceded          { get; set; }
    public string   CreatedBy           { get; set; }
    public DateTime CreatedOn           { get; set; }
}
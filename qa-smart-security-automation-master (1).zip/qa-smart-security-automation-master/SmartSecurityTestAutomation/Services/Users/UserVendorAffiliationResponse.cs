﻿using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;

namespace SmartSecurityTestAutomation.Services.Users;

public class UserVendorAffiliationResponse
{
    [JsonPropertyName("id")]
    public int Id { get; set; }
    [JsonPropertyName("vendorId")]
    public int VendorId { get; set; }

    public static void ValidateVendorAffiliationList(List<UserVendorAffiliationResponse> expectedList,
        List<UserVendorAffiliationResponse> actualList)
    {
        Steps.AddTestStep("Validating expected list matches actual list.", "Should both match");
        var actualDictionary = actualList.ToDictionary(i => i.Id, j => j);
        foreach (var expected in expectedList)
        {
            if (!actualDictionary.TryGetValue(expected.Id, out var actual))
                HPGWarn.Warn(
                    $"Unable to find Vendor Affiliation Id: '{expected.Id}' in actual list!");
            else
            {
                HPGWarn.AreEqual(expected.VendorId.ToString(), actual.VendorId.ToString(), field: "VendorID");
            }
        }


        Steps.AddTestStep("Validating actual list matches expected list.", "Should both match");
        var expectedDictionary = expectedList.ToDictionary(i => i.Id, j => j);
        foreach (var actual in actualList)
        {
            if (!expectedDictionary.TryGetValue(actual.Id, out var expected))
                HPGWarn.Warn(
                    $"Unable to find Vendor Affiliation Id: '{actual.Id}' in expected list!");
            else
            {
                HPGWarn.AreEqual(actual.VendorId.ToString(), expected.VendorId.ToString(), field: "VendorID");
            }
        }
    }
}
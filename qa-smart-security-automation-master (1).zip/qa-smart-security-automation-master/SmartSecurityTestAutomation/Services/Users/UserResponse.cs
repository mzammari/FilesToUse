﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using SmartSecurityTestAutomation.Services.VPRO;
using Utilities.Validation;
using Utilities.ObjectExtensions;

namespace SmartSecurityTestAutomation.Services.Users;

public class UserResponse
{
    public UserResponse()
    {
    }

    public UserResponse(AddUserRequest userRequest)
    {
        FirstName     = userRequest.FirstName;
        LastName      = userRequest.LastName;
        Username      = userRequest.UserName;
        Email         = userRequest.Email;
        Type          = userRequest.Type;
        Domain        = userRequest.Domain;
        IsDeactivated = (bool)userRequest.IsDeactivated!;
        VproStatus = userRequest.VproStatus;
        ByPassVPROEndDate = userRequest.ByPassVPROEndDate;
        VPROUserEmailId = userRequest.VPROUserEmailId;



    }
    //[JsonPropertyName("userTypeId")]
    //public int UserTypeId { get; set; }

    [JsonPropertyName("id")]
    public Guid Id { get; set; }

    [JsonPropertyName("firstName")]
    public string? FirstName { get; set; }

    [JsonPropertyName("lastName")]
    public string? LastName { get; set; }

    [JsonPropertyName("username")]
    public string? Username { get; set; }

    [JsonPropertyName("email")]
    public string? Email { get; set; }

    [JsonPropertyName("type")]
    public string Type { get; set; }

    [JsonPropertyName("isDeactivated")]
    public bool IsDeactivated { get; set; }

    [JsonPropertyName("domain")]
    public string Domain { get; set; }

    [JsonPropertyName("vproStatus")] 
    public string? VproStatus { get; set; }

    [JsonPropertyName("bypassVPROEndDate")]
    public DateTimeOffset? ByPassVPROEndDate { get; set; }

    [JsonPropertyName("vproUserEmailId")]
    public string? VPROUserEmailId { get; set; }

    //public string? SupplierPotalUpdatedDate { get; set; }
    public Guid? UserKey { get; set; }

	public List<string> Validate(UserResponse other)
    {
        var overRideMessage =
            $"for UserId: {this.Id}";
        var results = new List<string>()
        {
            ValidationHelpers.AreEqual(this.FirstName.ToStringOrEmpty(), other.FirstName.ToStringOrEmpty(), "FirstName",
                overRideMessage),
            ValidationHelpers.AreEqual(this.LastName.ToStringOrEmpty(), other.LastName.ToStringOrEmpty(), "LastName",
                overRideMessage),
            //ValidationHelpers.AreEqual(this.Company.ToStringOrEmpty(), other.Company.ToStringOrEmpty(), "Company", overRideMessage),
            //todo: need to change this to where it is a guid.
            //ValidationHelpers.AreEqual(this.Username.ToStringOrEmpty(), other.Username.ToStringOrEmpty(), "UserName",
            //    overRideMessage),
            ValidationHelpers.AreEqual(this.Email.ToStringOrEmpty(), other.Email.ToStringOrEmpty(), "Email",
                overRideMessage),
            ValidationHelpers.AreEqual(this.Type.ToStringOrEmpty(), other.Type.ToStringOrEmpty(), "Type",
                overRideMessage),

            //Commenting out since domain is not currently being used and is low priority
            ValidationHelpers.AreEqual(this.Domain.ToStringOrEmpty().ToLower(), other.Domain.ToStringOrEmpty().ToLower(), "Domain",
                overRideMessage),

            //ValidationHelpers.AreEqual(this.UserTypeId.ToStringOrEmpty(), other.UserTypeId.ToStringOrEmpty(), "UserTypeId", overRideMessage),
            //ValidationHelpers.AreEqual(this.Title.ToStringOrEmpty(), other.Title.ToStringOrEmpty(), "Title", overRideMessage),
            //ValidationHelpers.AreEqual(this.IsDeactivated.ToString(), other.IsDeactivated.ToString(), "IsDeactivated", overRideMessage),
            //ValidationHelpers.AreEqual(this.UserVendor.ToStringOrEmpty(), other.UserVendor.ToStringOrEmpty(), "UserVendor", overRideMessage)
        };

        return results.Where(i => i.ToStringOrEmpty() != string.Empty).ToList();
    }

    /// <summary>
    /// Validates a list of User response class objects against each other.
    /// </summary>
    /// <param name="expectedList"></param>
    /// <param name="actualList"></param>
    public static void ValidateUserResponseList(List<UserResponse> expectedList, List<UserResponse> actualList)
    {
        Steps.AddTestStep("Validating expected results are in actual.", "Expected should match actual.");
        var actualDictionary = actualList.ToDictionary(i => i.Id, j => j);
        foreach (var expected in expectedList)
        {
            if (!actualDictionary.TryGetValue(expected.Id, out var actual))
                HPGWarn.Warn($"Unable to find User ID: '{expected.Id}' in Actual!");
            else
            {
                HPGWarn.WarnRange(expected.Validate(actual));
            }
        }

        Steps.AddTestStep("Validating actual results are in Expected.", "Actual should match expected.");
        var expectedDictionary = expectedList.ToDictionary(i => i.Id, j => j);
        foreach (var actual in actualList)
        {
            if (!expectedDictionary.TryGetValue(actual.Id, out var expected))
                HPGWarn.Warn($"Unable to find User ID: '{actual.Id}' in Expected!");
            else
            {
                HPGWarn.WarnRange(actual.Validate(expected));
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using SmartSecurityTestAutomation.Services.Vendor;
using Utilities.ObjectExtensions;
using Utilities.Validation;

namespace SmartSecurityTestAutomation.Services.Users;


public class SpanOfControl
{
    [JsonPropertyName("hierarchyType")]
    public string HierarchyType { get; set; }

    [JsonPropertyName("objectId")]
    public string? ObjectId { get; set; }

    [JsonPropertyName("orgName")]
    public string OrgName { get; set; }
    
    [JsonPropertyName("isDeleted")] 
    public bool IsDeleted { get; set; }

    [JsonPropertyName("createdOn")]
    public DateTime CreatedOn { get; set; }

    [JsonPropertyName("isVproFacility")]
    public bool? IsVproFacility{ get; set; }

    [JsonPropertyName("vproFacilityName")]
    public string? VproFacilityName{ get; set; }

    [JsonPropertyName("vproFacilityCoid")]
    public string? VproFacilityCoid { get; set; }

	[JsonPropertyName("isWithinUserSoC")]
    public bool IsWithinUserSoc { get; set; }

	//Note. Low level defect needs to be open: When there is no update it should give other then 200 OK response. Should be 400 bad request

	private List<string> Validate(SpanOfControl other)
    {
        var results = new List<string>
        {
            ValidationHelpers.AreEqual(HierarchyType.ToStringOrEmpty(), other.HierarchyType.ToStringOrEmpty(),"HierarchyType"),
            ValidationHelpers.AreEqual(ObjectId.ToStringOrEmpty(), other.ObjectId.ToStringOrEmpty(),"ObjectId"),
            ValidationHelpers.AreEqual(OrgName.ToStringOrEmpty(), other.OrgName.ToStringOrEmpty(),"OrgName"),
            ValidationHelpers.AreEqual(IsDeleted.ToStringOrEmpty(), other.IsDeleted.ToStringOrEmpty(), "IsDeleted")
		};

        return results.Where(i => i.ToStringOrEmpty() != string.Empty).ToList();
    }

    public static void ValidateOrgTreeList(List<SpanOfControl> expectedList, List<SpanOfControl> actualList, bool byPassSecondary = false)
    {
        Steps.AddTestStep("Validating SpanOfControl Model List", "Model should match.");
        Steps.AddTestStep("Validating expected list matches actual list.", "Should both match");
        
        var actualDictionary = actualList.ToDictionary(i => new { i.HierarchyType, i.ObjectId }, j => j);
        foreach (var expected in expectedList)
        {
            if (!actualDictionary.TryGetValue(new { expected.HierarchyType, expected.ObjectId }, out var actual))
                HPGWarn.Warn(
                    $"Unable to find ObjectId: '{expected.ObjectId}' and Name: '{expected.OrgName}' in actual list!");
            else
            {
                HPGWarn.WarnRange(expected.Validate(actual));
            }
        }

        if (byPassSecondary) return;

        Steps.AddTestStep("Validating actual list matches expected list.", "Should both match");
        var expectedDictionary = expectedList.ToDictionary(i => new { i.HierarchyType, i.ObjectId }, j => j);
        foreach (var actual in actualList)
        {
            if (!expectedDictionary.TryGetValue(new { actual.HierarchyType, actual.ObjectId }, out var expected))
                HPGWarn.Warn(
                    $"Unable to find ObjectId: '{actual.ObjectId}' and  Name: '{actual.OrgName}' in expected list!");
            else
            {
                HPGWarn.WarnRange(actual.Validate(expected));
            }
        }
    }
    
}

public class AddUserRoleSoc
{
    [JsonPropertyName("userId")]
    public string? UserId { get; set; }

    [JsonPropertyName("applicationId")]
    public string? ApplicationId { get; set; }

    [JsonPropertyName("isDeactivated")]
    public bool? IsDeactivated { get; set; }

    [JsonPropertyName("roleIds")]
    public List<string?> RoleIds { get; set; }
    
    [JsonPropertyName("spanOfControl")]
    public List<SpanOfControl> SpanOfControl { get; set; }

    [JsonPropertyName("vendorAffiliation")]
    public List<VendorModel> VendorAffiliation { get; set; }

    [JsonPropertyName("vproStatus")] 
    public string? VproStatus { get; set; }

    [JsonPropertyName("bypassVPROEndDate")]
    public DateTimeOffset? ByPassVPROEndDate { get; set; }

    [JsonPropertyName("vproUserEmailId")]
    public string? VPROUserEmailId { get; set; }

    [JsonPropertyName("roles")]
    public List<RoleDetail>? Roles { get; set; }

    [JsonPropertyName("isSmartSecurity")]
	public bool? IsSmartSecurity { get; set; }

	[JsonPropertyName("userGcnGroups")]
	public List<UserGcnGroup>? UserGcnGroups { get; set; }


}

public class RoleDetail
{
    [JsonPropertyName("id")]
    public string? Id { get; set; }

	[JsonPropertyName("name")]
    public string? Name { get; set; }

    [JsonPropertyName("isDeleted")]
    public bool? IsDeleted { get; set;}

    [JsonPropertyName("userType")]
    public string? UserType { get; set; }
}

public class SpanOfControlViewModel
{
	[JsonPropertyName("hasElevatedSoc")]
	public bool HasElevatedSoc { get; set; }

    [JsonPropertyName("hasHealthTrustLevelSoc")]
	public bool HasHealthTrustLevelSoc { get; set; }

	[JsonPropertyName("soc")]
	public List<SpanOfControl> Soc { get; set; }

}

public class UserGcnGroup
{
	[JsonPropertyName("groupId")]
	public int? GroupId { get; set; }
	[JsonPropertyName("groupName")]
	public string? GroupName { get; set; }
	[JsonPropertyName("isSelected")]
	public bool? IsSelected { get; set; }
}
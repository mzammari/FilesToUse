﻿using System;
using System.Text.Json.Serialization;
using SmartSecurityTestAutomation.Tests;
using Utilities.Generators;
using Utilities.ObjectExtensions;

namespace SmartSecurityTestAutomation.Services.Users;

public class AddUserRequest
{
    [JsonPropertyName("userName")]
    public string? UserName { get; set; }

    [JsonPropertyName("domain")]
    public string Domain { get; set; } = null!;

    [JsonPropertyName("firstName")]
    public string FirstName { get; set; } = null!;

    [JsonPropertyName("lastName")]
    public string LastName { get; set; } = null!;

    [JsonPropertyName("email")]
    public string? Email { get; set; }

    [JsonPropertyName("type")]
    public string Type { get; set; } = null!;

    [JsonPropertyName("isDeactivated")]
    public bool? IsDeactivated { get; set; }

    [JsonPropertyName("vproStatus")]
    public string? VproStatus { get; set; }

    [JsonPropertyName("bypassVPROEndDate")]
    public DateTimeOffset? ByPassVPROEndDate { get; set; }

    [JsonPropertyName("vproUserEmailId")]
    public string? VPROUserEmailId { get; set; }

	public AddUserRequest(bool isGenerate = false)
    {
        if (!isGenerate) return;

        Domain        = GlobalTestVariables.Configuration!["TestUserDomain"].ToStringOrEmpty();
        UserName      = $"UserName-{Guid.NewGuid()}";
        FirstName     = $"{StringGenerator.RandomAlphaString(2)}{StringGenerator.RandomNumberString(4)}";
        LastName      = $"{StringGenerator.RandomStormTrooper()}";
        Email         = $"{FirstName}.{LastName}@GalacticEmpire.net";
        Type          = "Employee";
        IsDeactivated = false;
        VproStatus = string.Empty;
        ByPassVPROEndDate = null;
        VPROUserEmailId = null;
    }

    public AddUserRequest(UserResponse user)
    {
        Domain        = user.Domain;
        UserName      = user.Username;
        FirstName     = user.FirstName.ToStringOrEmpty();
        LastName      = user.LastName.ToStringOrEmpty();
        Email         = user.Email;
        Type          = user.Type;
        IsDeactivated = user.IsDeactivated;
        VproStatus = user.VproStatus;
        ByPassVPROEndDate = user.ByPassVPROEndDate;
        VPROUserEmailId = user.VPROUserEmailId;
    }
}
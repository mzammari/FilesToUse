﻿using System;
using System.Collections.Generic;
using System.Linq;
using Utilities.ObjectExtensions;
using Utilities.Validation;

namespace SmartSecurityTestAutomation.Services.Users;

public class UserSocDb
{
    public int     Id            { get; set; }
    public Guid    ApplicationId { get; set; }
    public Guid    UserId        { get; set; }
    public string  Username      { get; set; }
    public int     Hierarchy     { get; set; }
    public string? OrgObjectID   { get; set; }
    public bool    IsDeleted     { get; set; }
    public bool    IsDeactivated { get; set; }


    public List<string> Validate(UserSocDb other)
    {
        var results = new List<string>()
        {
            ValidationHelpers.AreEqual(ApplicationId.ToString(), other.ApplicationId.ToString(), "ApplicationId"),
            ValidationHelpers.AreEqual(UserId.ToString(), other.UserId.ToString(), "UserId"),
            ValidationHelpers.AreEqual(Hierarchy.ToString(), other.Hierarchy.ToString(), "Hierarchy"),
            ValidationHelpers.AreEqual(OrgObjectID.ToString(), other.OrgObjectID.ToString(), "OrgObjectID"),
            ValidationHelpers.AreEqual(IsDeleted.ToString(), other.IsDeleted.ToString(), "IsDeleted"),
        };

        return results.Where(i => i.ToStringOrEmpty() != string.Empty).ToList();
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using Utilities.ObjectExtensions;
using Utilities.Validation;

namespace SmartSecurityTestAutomation.Services.Users;

public class UserVendorAffiliationDb
{
    public int    Id            { get; set; }
    public int    VendorId      { get; set; }
    public string VendorName    { get; set; }
    public Guid   UserId        { get; set; }
    public string Username      { get; set; }
    public bool   IsDeleted     { get; set; }
    public bool   IsDeactivated { get; set; }


    public List<string> Validate(UserVendorAffiliationDb other)
    {
        var results = new List<string>()
        {
            ValidationHelpers.AreEqual(this.VendorId.ToStringOrEmpty(), other.VendorId.ToStringOrEmpty(),
                "VendorId"),
            ValidationHelpers.AreEqual(this.UserId.ToStringOrEmpty(), other.UserId.ToStringOrEmpty(),
                "UserId"),
            ValidationHelpers.AreEqual(this.IsDeleted.ToStringOrEmpty(), other.IsDeleted.ToStringOrEmpty(),
                "IsDeleted"),
        };

        return results.Where(i => i != string.Empty).ToList();
    }
}
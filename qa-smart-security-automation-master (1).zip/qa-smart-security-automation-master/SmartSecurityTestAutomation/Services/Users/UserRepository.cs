﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using SmartSecurityTestAutomation.Data.Migration;
using SmartSecurityTestAutomation.Models;
using Utilities.DatabaseUtility;
using Utilities.ObjectExtensions;

namespace SmartSecurityTestAutomation.Services.Users;

public class UserRepository
{
    private readonly string _server;
    private readonly string _dbName;


    public UserRepository(string server, string dbName)
    {
        _server = server;
        _dbName = dbName;
    }

    public IEnumerable<UserResponse> GetAllUsers(int timeToWait = 0)
    {
        if (timeToWait > 0)
            Thread.Sleep(1000 * timeToWait);

        try
        {
            var dbs = new DbSql(_server, _dbName);
            return dbs.GetRecordsIntoObject<UserResponse>(SqlSelectUsers);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw new Exception($"Unable to retrieve SMART Security data!\r\nError Message: {e}");
        }
    }

    public UserResponse GetUserInfo(string userName)
    {
        var query = new StringBuilder(SqlSelectUsers);
        query.AppendLine($" WHERE u.Username = '{userName}'");

        try
        {
            var dbs = new DbSql(_server, _dbName);
            return dbs.GetRecordIntoObject<UserResponse>(query.ToString());
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw new Exception($"Unable to retrieve SMART Security data!\r\nError Message: {e}");
        }
    }

    private const string SqlSelectUsers = @"SELECT u.UserKey as Id
      ,[Username]
      ,u.UserKey
      ,[Domain]
      ,[FirstName]
      ,[LastName]
      ,[Email]
      ,[UserTypeId]
      ,ut.[Description] as Type
      ,[TitleId]
      ,t.Name as Title
      ,[IsDeactivated],u.BypassVPROEndDate, u.VPROStatus, u.VPROUserEmailId   
  FROM [dbo].[User] u
  left join [dbo].[UserType] ut on u.UserTypeId = ut.Id
  left join [dbo].[Title] t on u.TitleId = t.Id";

    public IEnumerable<UserRoleDb> GetAllUserRoleDb(string? userId = null,int timeToWait = 0)
    {
        if (timeToWait > 0)
            Thread.Sleep(1000 * timeToWait);

        try
        {
            var dbs   = new DbSql(_server, _dbName);
            var query = userId == null ? SelectUserRoles : $"{SelectUserRoles} where u.userKey = '{userId}'";
            return dbs.GetRecordsIntoObject<UserRoleDb>(query);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw new Exception($"Unable to retrieve SMART Security data!\r\nError Message: {e}");
        }
    }

    private const string SelectUserRoles = @"SELECT u.UserKey as UserId      
      ,u.Username
      ,a.ApiKey as ApplicationId
      ,r.RoleKey as Id
      ,r.[Name] 
      ,ur.IsDeleted
      ,u.IsDeactivated 
  FROM [dbo].[User] u
  join [dbo].[User_Role] ur on u.Id = ur.UserId
  join [dbo].[Role] r on ur.RoleId = r.Id
  join [dbo].[Application] a on r.ApplicationId = a.id";

    public IEnumerable<UserSocDb> GetAllUserSocDb(Guid? userId = null, int timeToWait = 0)
    {
        if (timeToWait > 0) { Thread.Sleep(1000 * timeToWait); }

        try
        {
            var dbs = new DbSql(_server, _dbName);

            var query = new StringBuilder(SelectUserSoc);

            if (!userId!.IsNull()) query.AppendLine($" WHERE u.UserKey = '{userId}'");

            return dbs.GetRecordsIntoObject<UserSocDb>(query.ToString());
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw new Exception($"Unable to retrieve SMART Security data!\r\nError Message: {e}");
        }
    }

    public IEnumerable<UserSocDb> GetAllServiceAcctsSocDb()
	{
		try
		{
			var dbs = new DbSql(_server, _dbName);
			var query = new StringBuilder(SelectSecurityServiceAccts); 
			return dbs.GetRecordsIntoObject<UserSocDb>(query.ToString());
		}
		catch (Exception e)
		{
			Console.WriteLine(e);
			throw new Exception($"Unable to retrieve SMART Security data!\r\nError Message: {e}");
		}
	}


	private const string SelectUserSoc = @"SELECT soc.[Id]
      ,soc.[Hierarchy]
      ,a.ApiKey as [ApplicationId]
      ,u.UserKey as [UserId]
      ,u.Username
      ,soc.[OrgObjectID]      
      ,soc.[IsDeleted]
      ,u.IsDeactivated
  FROM [dbo].[SpanOfControl] soc
  join [dbo].[User] u on soc.UserId = u.Id
  join [dbo].[Application] a on soc.ApplicationId = a.Id";

    private const string SelectSecurityServiceAccts = @"SELECT  SOC.Id,     SOC.Hierarchy,  A.ApiKey As ApplicAtionId,  U.UserKey As UserId,
        U.UsernAme, SOC.OrgObjectID,SOC.IsDeleted,              U.IsDeActivAted   
        FROM dbo.SpAnOfControl SOC
        join dbo.[User] U on SOC.UserId = U.Id
        join dbo.ApplicAtion A on SOC.ApplicAtionId = A.Id
        AND U.UsernAme IN ('HTNASVCTSTAUT50', 'HTNASVCTSTAUT51','HTNASVCTSTAUT52','HTNASVCTSTAUT53')
        AND A.ApiKey = 'E68AB150-F05F-49BF-8C91-5EC4494FFD4C'
        AND SOC.IsDeleted = 0
        AND U.IsDeActivAted = 0   
        AND SOC.HierArchy in (0, 1)
 ";
    public IEnumerable<UserVendorAffiliationDb> GetUserVendorAffiliationDb(Guid? userId = null, int timeToWait = 0)
    {
        if(timeToWait > 0) { Thread.Sleep(1000 * timeToWait); }

        try
        {
            var dbs   = new DbSql(_server, _dbName);
            var query = new StringBuilder(SelectUserVendorAffiliation);
            if (!userId!.IsNull()) query.AppendLine($" WHERE u.UserKey = '{userId}'");

            return dbs.GetRecordsIntoObject<UserVendorAffiliationDb>(query.ToString());
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw new Exception($"Unable to retrieve SMART Security data!\r\nError Message: {e}");
        }
    }

    private const string SelectUserVendorAffiliation = @"SELECT uv.[Id]
      ,u.UserKey as [UserId]
      ,u.Username
      ,uv.[VendorId] 
      ,uv.[VendorName]
      ,uv.[IsDeleted]
      ,u.IsDeactivated  
	FROM [dbo].[User_Vendor] uv
    join [dbo].[User] u on uv.UserId = u.Id   ";

    public IEnumerable<UserSupplierPortalTransferLogDb> GetUserSupplierPortalTransferLogs(string? email, int timeToWait =0)
    {
        if (timeToWait > 0) { Thread.Sleep(1000 * timeToWait); }

        try
        {
            var dbs   = new DbSql(_server, _dbName);
            var query = new StringBuilder(SelectUserSupplierPortalTransferLogs);
            if (!email!.IsNull()) query.AppendLine($" WHERE UserEmail = '{email}'");

            return dbs.GetRecordsIntoObject<UserSupplierPortalTransferLogDb>(query.ToString());
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw new Exception($"Unable to retrieve SMART Security data!\r\nError Message: {e}");
        }
    }

    private const string SelectUserSupplierPortalTransferLogs = @"SELECT [Id]
      ,[UserEmail]
      ,[RequestUri]
      ,[RequestContent]
      ,[ResponseContent]
      ,[Message]
      ,[ExceptionStackTrace]
      ,[IsSucceded]
      ,[CreatedBy]
      ,cast([CreatedOn] as DATETIME) as CreatedOn
  FROM [dbo].[SupplierPortalTransferLog]";

    public IEnumerable<UserPassRoleSpoc> GetAllUsersRolesAndSpoc()
    {
        try
        {
            var dbs   = new DbSql(_server, _dbName);
            
            return dbs.GetRecordsIntoObject<UserPassRoleSpoc>(SelectAllUsersRolesAndSpoc);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw new Exception($"Unable to retrieve SMART Security data!\r\nError Message: {e}");
        }
    }

    private const string SelectAllUsersRolesAndSpoc = @"Select AccountId
      ,LOWER(Domain) as Domain
      ,UserName
      ,[Name]
      ,ApplicationName
      ,ApplicationRoleName
      ,STRING_AGG(Hierarchy + ' - ' + OrgObjectID, '|') as Spoc
    from (  Select u.Id as AccountId
      ,u.Domain
      ,u.Username as UserName
      ,u.FirstName + ' ' + u.LastName as [Name]
      ,a.Name as ApplicationName
      ,r.Name as ApplicationRoleName
      ,convert(varchar,sc.Hierarchy) as [Hierarchy]
      ,sc.OrgObjectID
    from [dbo].[User] u
    join [dbo].[User_Role] ur on u.Id = ur.UserId and ur.IsDeleted = 0
    join [dbo].[Role] r on ur.RoleId = r.Id
    join [dbo].[Application] a on r.ApplicationId = a.Id
    left join [dbo].[SpanOfControl] sc on sc.ApplicationId = a.Id and sc.UserId = u.Id) app
    group by AccountId
      ,Domain
      ,UserName
      ,[Name]
      ,ApplicationName
      ,ApplicationRoleName";


    public IEnumerable<SecurityUser> GetAllServiceAccounts()
	{
		try
		{
			var dbs = new DbSql(_server, _dbName);
			return dbs.GetRecordsIntoObject<SecurityUser>(SelectAllServiceAccounts);
		}
		catch (Exception e)
		{
			Console.WriteLine(e);
			throw new Exception($"Unable to retrieve SMART Security data!\r\nError Message: {e}");
		}
	}

	private const string SelectAllServiceAccounts = @"SELECT U.Username
    FROM [USER] U
    WHERE U.FirstName like 'ServiceAccount' AND U.Username like 'HTNASVCTSTAUT%' ORDER BY U.Id";
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using Utilities.ObjectExtensions;
using Utilities.Validation;

namespace SmartSecurityTestAutomation.Services.Users;

public class UserRoleDb
{
    public Guid   UserId        { get; set; }
    public Guid   ApplicationId { get; set; }
    public Guid   Id            { get; set; }
    public string Username      { get; set; }
    public string Name          { get; set; }
    public bool   IsDeleted     { get; set; }
    public bool   IsDeactivated { get; set; }

    public List<string> Validate(UserRoleDb other)
    {
        var results = new List<string>()
        {
            ValidationHelpers.AreEqual(UserId.ToStringOrEmpty(), other.UserId.ToStringOrEmpty(), "UserId"),
            ValidationHelpers.AreEqual(ApplicationId.ToStringOrEmpty(), other.ApplicationId.ToStringOrEmpty(),
                "ApplicationId"),
            ValidationHelpers.AreEqual(Name.ToStringOrEmpty(), other.Name.ToStringOrEmpty(), "Name"),
            ValidationHelpers.AreEqual(IsDeleted.ToStringOrEmpty(), other.IsDeleted.ToStringOrEmpty(), "IsDeleted"),
        };

        return results.Where(i => i != string.Empty).ToList();
    }
}
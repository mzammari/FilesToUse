﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text.Json;
using System.Threading;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
//using OpenQA.Selenium.DevTools.V137.WebAudio; todo: remove after next sprint work to verify nothing is using this. Not sure how it got here. Marlon
using SmartSecurityTestAutomation.Enums;
using SmartSecurityTestAutomation.Models;
using SmartSecurityTestAutomation.Services.Applications;
using SmartSecurityTestAutomation.Services.Home;
using SmartSecurityTestAutomation.Services.Vendor;
using SmartSecurityTestAutomation.Services.VPRO;
using SmartSecurityTestAutomation.Tests;
using Utilities.HttpUtility;
using Utilities.ObjectExtensions;
using Utilities.SetupTestUsers;
using JsonSerializer = System.Text.Json.JsonSerializer;
using VendorModel = SmartSecurityTestAutomation.Services.Vendor.VendorModel;


namespace SmartSecurityTestAutomation.Services.Users;

public class UserApi : MasterApi
{
    #region Private Variables

    private const string UserResource              = "/Users";
    private const string ApplicationResource       = "/applications";
    private const string RolesResource             = "/roles";
    private const string VendorAffiliationResource = "/vendor-affiliations";
    private const string ClaimResource             = "/claims";
    private const string Soc                       = "/soc";
    private const string LoggedInUserResource      = "/loggedInUserRoles";

	private static readonly string BaseUri = GlobalTestVariables.Configuration["SmartSecurity:BaseUri"]!;
    private readonly        IEnumerable<HomeDataDb> _homeInfoDataDb;

    private readonly UserRepository _userRepository =
        new(GlobalTestVariables.Configuration["SmartSecurity:DatabaseServer"]!,
            GlobalTestVariables.Configuration["SmartSecurity:DatabaseName"]!);

    private readonly ApplicationRepository _applicationRepository =
        new(GlobalTestVariables.Configuration["SmartSecurity:DatabaseServer"]!,
            GlobalTestVariables.Configuration["SmartSecurity:DatabaseName"]!);

    private readonly VendorRepository _vendorRepository =
        new(GlobalTestVariables.Configuration["VendorMaster:DatabaseServer"]!,
            GlobalTestVariables.Configuration["VendorMaster:DataBaseName"]!);

    private List<string> _scUsers;
    #endregion Private Variables

    public UserApi(bool instantiateData = true)
    {
        if (!instantiateData) return;

        var homeDb = new HomeRepository(GlobalTestVariables.Configuration["Home:DatabaseServer"]!,
            GlobalTestVariables.Configuration["Home:DataBaseName"]!);
        _homeInfoDataDb = homeDb.GetHomeData();
        _scUsers        = GlobalTestVariables.Users.Select(i => i.UserName).ToList();
    }

    #region API Call

    /// <summary>
    /// An API call to get user info from the SMART Security Database.
    /// </summary>
    /// <param name="parameters">A dictionary of parameters to pass into the web request.</param>
    /// <returns></returns>
    private static HttpResponse GetUser(Dictionary<string, string?> parameters = null!) => GetSimpleRequest(
	    RequestBuilder.BuildRequestWithParameters($"{BaseUri}{UserResource}", parameters));

    /// <summary>
    /// API call to get a users roles based on the application
    /// </summary>
    /// <param name="userId"></param>
    /// <param name="appId"></param>
    /// <returns></returns>
    private static HttpResponse GetUserRolesByApplication(string? userId, string? appId) => GetSimpleRequest(
        $"{BaseUri}{UserResource}/{userId}{ApplicationResource}/{appId}{RolesResource}");

    /// <summary>
    /// API call to get a users Span of Control based on the application
    /// </summary>
    /// <param name="userId"></param>
    /// <param name="appId"></param>
    /// <returns></returns>
    private static HttpResponse GetUserSocByApplication(string userId, string appId) => GetSimpleRequest(
        $"{BaseUri}{UserResource}/{userId}{ApplicationResource}/{appId}{Soc}");

    /// <summary>
    /// API call to get a users Vendor Affiliation
    /// </summary>
    /// <param name="userId"></param>
    /// <returns></returns>
    private static HttpResponse GetUserVendorAffiliationByApplication(string userId) => GetSimpleRequest(
        $"{BaseUri}{UserResource}/{userId}{VendorAffiliationResource}");

    /// <summary>
    /// API call to POST a users status, role, span of control, and vendor affiliation
    /// </summary>
    /// <param name="payload"></param>
    /// <returns></returns>
    public static HttpResponse PostUserClaim(string? payload) => PostSimpleRequest(
        $"{BaseUri}{UserResource}{ClaimResource}", payload);

    /// <summary>
    /// API call to POST a new user.
    /// </summary>
    /// <param name="payload"></param>
    /// <returns></returns>
    private static HttpResponse PostNewUser(string? payload) =>
        PostSimpleRequest($"{BaseUri}{UserResource}", payload);

	private static HttpResponse GetLoggedInUserRoles() =>
		GetSimpleRequest($"{BaseUri}{UserResource}{LoggedInUserResource}");

	#endregion API Call

	#region Test Methods

	/// <summary>
	/// Test to send 'GET' request to the /User API endpoint with various parameters.
	/// Manual Estimated Execution Time: 0:10:00
	/// </summary>
	public void TestGetUsers(SecurityUserType securityUser)
    {
        Steps.AddTestStep($"Testing 'GET' Request for /User API endpoint using Security user: '{securityUser.GetEnumDescription()}'.", "Should out the correct response");

        //Get Security User and Setup Network Credential
        var sUser = GlobalTestVariables.Users!.First(i =>
            i.RoleName.Contains(securityUser.GetEnumDescription()) && i.Access.Equals("Full"));
		GetPingToken(sUser, true);

        var testUsers = FilterUsersBasedSecurityUser(sUser);

		/*  These are the domains allowed per Environment & Assigned Role
		 * Secruity Admin: AsOf 01Oct24 there are not filteres or limits for Security Admin in both qasbx & qa
		 *        qasbx  :"lpnt,lpntdev,lpntqa,capella,hca,hcadev,hcaqa,nonaffil,nonaffilqa,nonaffildev,nonaffiltest"
		 *        qa     :"lpnt,        lpntqa,capella,hca,       hcaqa,nonaffil,nonaffilqa,            nonaffiltest",
		 *
		 * Client Admin  :
		 *        qasbx  :"lpnt,lpntdev,lpntqa,capella"
		 *        qa     :"lpnt,        lpntqa,capella"
		 *
		 * Vendor Admin  :
		 *        qasbx  :                             "hca,hcadev,hcaqa,nonaffil,nonaffilqa,nonaffildev,nonaffiltest"
		 *        qa     :"hcaqa,                                                 nonaffilqa"
		 */

		if (GlobalTestVariables.TestEnvironment.Equals("qasbx"))
		{
			switch (securityUser)
			{
				//Secruity Admin qasbx  :"lpnt,lpntdev,lpntqa,capella,hca,hcadev,hcaqa,nonaffil,nonaffilqa,nonaffildev,nonaffiltest"   && !i.Domain.ToLower().Equals("lpntdev")
				case SecurityUserType.SecurityAdmin:
					//Remove by November: testUsers = testUsers.Where(i => !i.Domain.ToLower().Equals("capella") && !i.Domain.Contains("lpnt", StringComparison.CurrentCultureIgnoreCase)).ToList();
                     break;
				//Client Admin qasbx    :"lpnt,lpntdev,lpntqa,capella"
				case SecurityUserType.ClientAdmin:
					testUsers = testUsers.Where(i => i.Domain.ToLower().Equals("capella") && i.Domain.ToLower().Contains("lpnt", StringComparison.CurrentCultureIgnoreCase)).ToList();
					break;
				//Vendor Admin qasbx    :"hca,hcadev,hcaqa,nonaffil,nonaffilqa,nonaffildev,nonaffiltest"
				case SecurityUserType.VendorAdmin:
					testUsers = testUsers.Where(i => !i.Domain.ToLower().Contains("capella", StringComparison.CurrentCultureIgnoreCase) && !i.Domain.ToLower().Contains("lpnt", StringComparison.CurrentCultureIgnoreCase) && !i.Domain.ToLower().Contains("lpntdev", StringComparison.CurrentCultureIgnoreCase)).ToList();
					break;
                default:
                    break;
			}

		}
		else //environment is QA
		{
			switch (securityUser)
			{
				//Security Admin qa     :"lpnt,        lpntqa,capella,hca,       hcaqa,nonaffil,nonaffilqa,            nonaffiltest",  
				case SecurityUserType.SecurityAdmin:
					////todo: Remove by November: testUsers = testUsers.Where(i => !i.Domain.ToLower().Contains("dev", StringComparison.CurrentCultureIgnoreCase)).ToList();
					break;
				//Client Admin qa       :"lpnt,        lpntqa,capella"
				case SecurityUserType.ClientAdmin:
					testUsers = testUsers.Where(i => i.Domain.ToLower().Equals("lpnt") || i.Domain.ToLower().Equals("lpntqa") || i.Domain.ToLower().Equals("capella")).ToList();
					break;
				//Vendor Admin qa       :"hcaqa,                    nonaffilqa"
				case SecurityUserType.VendorAdmin:
                    testUsers = testUsers.Where(i => i.Domain.ToLower().Equals("hcaqa") || i.Domain.ToLower().Equals("hca") || i.Domain.ToLower().Equals("nonaffil") || i.Domain.ToLower().Equals("nonaffilqa")).ToList();
					//testUsers.Where(i => i.Domain.ToLower().Equals("hcaqa") || i.Domain.ToLower().Equals("nonaffilqa")).ToList();
					//var testUsers2 = testUsers.Where(i => i.Domain.ToLower().Equals("hcaqa") || i.Domain.ToLower().Equals("nonaffilqa")).ToList();
					break;
				default:
					break;
			}
		}

        var scenarios = new List<string>()
        {
            "First Name", "Last Name", "First Name, Last Name, & Email", "Email",
            "UserName", //"HCA AD Group", "Lifepoint AD Group"
        };
		foreach (var scenario in scenarios)
        {
            UserResponse                testUser;
            string                      stepDescription = null;
            string                      stepExpected    = null;
            List<UserResponse>          expectedUsers   = null;
            Dictionary<string, string?> query           = null;

            switch (scenario)
            {
                case "First Name":
	                testUser = testUsers.Where(i => i.FirstName.ToStringOrEmpty() != string.Empty && i.LastName.ToStringOrEmpty().Length >= 3)
                        .PickRandom();
                    
                    stepDescription = $"Scenario to look for users with the first name '{testUser.FirstName}'.";
                    stepExpected    = $"System should return users with the first name {testUser.FirstName}";
	                expectedUsers = testUsers.Where(i => i.FirstName.ToStringOrEmpty().Contains(testUser.FirstName, StringComparison.OrdinalIgnoreCase)).ToList();
                    //todo: fix the expectedUsers...figure out why its short.
					query = new Dictionary<string, string?>
                    {
                        { "FirstName", testUser.FirstName },
                        { "PageNumber", "0" },
                        { "PageSize", "20" }
                    };
	                break;
                case "Last Name":
                    testUser = testUsers.Where(i =>
                            i.FirstName.ToStringOrEmpty() != string.Empty && i.LastName.ToStringOrEmpty().Length > 3)
                        .PickRandom();
                    stepDescription = $"Scenario to look for users with the last name '{testUser.LastName}'.";
                    stepExpected    = $"System should return users with the last name {testUser.LastName}.";
                    expectedUsers = testUsers.Where(i => i.LastName.ToStringOrEmpty().Contains(testUser.LastName, StringComparison.OrdinalIgnoreCase)).ToList();
                    query = new Dictionary<string, string?>
                    {
                        { "LastName", testUser.LastName },
                        { "PageNumber", "0" },
                        { "PageSize", "20" }
                    };
					break;
                case "First Name, Last Name, & Email":
                    testUser = testUsers.Where(i => i.FirstName.ToStringOrEmpty() != string.Empty
                                                    && i.LastName.ToStringOrEmpty() != string.Empty
                                                    && i.Email.ToStringOrEmpty() != string.Empty).PickRandom();
                    stepDescription =
                        $"Scenario to look for a user with the FirstName '{testUser.FirstName}',LastName '{testUser.LastName}', Email '{testUser.Email}'.";
                    stepExpected =
                        $"System should return users with the FirstName {testUser.FirstName}, LastName '{testUser.LastName}', Email '{testUser.Email}', are Employee or Vendor User, and are Active or Inactive";
                    expectedUsers = testUsers.Where(i =>
	                    i.FirstName.ToStringOrEmpty().Contains(testUser.FirstName) &&
	                    i.LastName.ToStringOrEmpty().Contains(testUser.LastName) &&
	                    i.Email.ToStringOrEmpty().Contains(testUser.Email)).ToList(); 
                    query = new Dictionary<string, string?>
                    {
                        { "FirstName", testUser.FirstName },
                        { "LastName", testUser.LastName },
                        { "Email", testUser.Email },
                        { "PageNumber", "0" },
                        { "PageSize", "20" }
                    };
					break;
                case "Email":
                    testUser = testUsers.Where(i => i.FirstName.ToStringOrEmpty() != string.Empty
                                                    && i.LastName.ToStringOrEmpty() != string.Empty
                                                    && i.Email.ToStringOrEmpty() != string.Empty).PickRandom();
                    stepDescription = $"Scenario to look for a user with the Email '{testUser.Email}'.";
                    stepExpected =
                        $"System should return users with the Email {testUser.Email}, are Employee or Vendor User, and are Active or Inactive";
                    expectedUsers = testUsers.Where(i =>
	                    i.Email.ToStringOrEmpty().Contains(testUser.Email.ToStringOrEmpty(),
		                    StringComparison.InvariantCultureIgnoreCase)).ToList();
                    query = new Dictionary<string, string?>
                    {
                        { "Email", testUser.Email },
                        { "PageNumber", "0" },
                        { "PageSize", "20" }
                    };
					break;
                case "UserName":
                    testUser = testUsers.Where(i => i.FirstName.ToStringOrEmpty() != string.Empty && i.LastName.ToStringOrEmpty() != string.Empty 
	                   && i.Email.ToStringOrEmpty() != string.Empty).PickRandom();
                    stepDescription = $"Scenario to look for a user with the UserName '{testUser.Username}'.";
                    stepExpected =
                        $"System should return users with the UserName {testUser.Username}, are Employee or Vendor User, and are Active or Inactive";
                    expectedUsers = testUsers.Where(i => i.Email.ToStringOrEmpty().Contains(testUser.Email)).ToList();
                    query = new Dictionary<string, string?>
                    {
                        { "UserName", testUser.Username },
                        { "PageNumber", "0" },
                        { "PageSize", "20" }
                    };
					break;
                case "HCA AD Group":
                    break;
                default:
                    throw new Exception($"Unable to recognize scenario: '{scenario}'!");
            }

            Steps.AddTestStep(stepDescription, stepExpected);
            var response = GetUser(query);

            if (!HPGWarn.Contains(OkResponse, response.Status, field: "Response Code")) continue;
            var actualResults = JsonSerializer.Deserialize<List<UserResponse>>(JObject.Parse(response.Response)["userSearchResult"]?.ToString()!);
            ValidateUserList(expectedUsers, actualResults!);
        }

        //add negative test for Client Admin to search for vendor.
        if (securityUser.Equals(SecurityUserType.ClientAdmin))
        {
            Steps.AddTestStep($"Testing negative scenario for Client Admin where no vendor users should return in the response.",$"Should get an '{OkResponse}' response and an empty array.");

            var vendorUser = _userRepository.GetAllUsers()
                .First(i => i.Type.Equals("vendor", StringComparison.OrdinalIgnoreCase) && !i.IsDeactivated);
            var query = new Dictionary<string, string?>
            {
                { "FirstName", vendorUser.FirstName },
                { "LastName", vendorUser.LastName },
                { "Email", vendorUser.Email },
                { "PageNumber", "0" },
                { "PageSize", "20" }
            };

            var response = GetUser(query);
            if (HPGWarn.AreEqual(OkResponse, response.Status, field: ResponseStatusField))
            {
                HPGWarn.AreEqual("0", JObject.Parse(response.Response)["totalRecords"]
                    ?.ToString()!);
            }
        }

        GetPingToken(resetAuthToken: true);
    }

    /// <summary>
    /// Test to send 'GET' request to the /User API endpoint with bad values
    /// Manual Estimated Execution Time: 0:05:00
    /// </summary>
    public void TestGetUserBadRequest()
    {
        Steps.AddTestStep("Test send 'GET' request for /users API endpoint with bad or null values.",
            "System should respond accordingly");
        var scenarios = new List<string>
        {
            "No Params Passed In", "Include Vendors", "Include Inactive", "Include Vendors & Include Inactive",
            "First Name Blank", "Last Name Blank", "Email Blank", "User Name Blank"
        };

        foreach (var scenario in scenarios)
        {
            var query = scenario switch
            {
                "Include Vendors" => new Dictionary<string, string?> { { "IncludeVendors", "true" } },
                "Include Inactive" => new Dictionary<string, string?> { { "IncludeDisabled", "true" } },
                "Include Vendors & Include Inactive" => new Dictionary<string, string?> { { "IncludeVendors", "true" }, { "IncludeDisabled", "true" } },
                "First Name Blank" => new Dictionary<string, string?> { { "firstName", "" } },
                "Last Name Blank" => new Dictionary<string, string?> { { "lastName", "" } },
                "Email Blank" => new Dictionary<string, string?> { { "email", "" } },
                "User Name Blank" => new Dictionary<string, string?> { { "username", "" } },
                _ => new Dictionary<string, string?>()
            };

            Steps.AddTestStep($"Sending 'GET' request for /users API Endpoint for scenario: '{scenario}'",
                "System should respond with a (400) Bad Request");
            var response = GetUser(query);
            HPGWarn.AreEqual("(400) BadRequest", response.Status, "Response Status Code");
        }
    }

    /// <summary>
    /// Test to send 'GET' request to /users/<userId>/applications/<appId>/roles API endpoint.
    /// Manual Estimated Execution Time: 0:03:00
    /// </summary>
    public void TestGetUserRolesByApplication()
    {
        Steps.AddTestStep("Testing 'GET' Request for /users/<userId>/applications/<appId>/roles API endpoint.",
            "Should out the correct response");

        var testUsers = _userRepository.GetAllUserRoleDb()
            .GroupBy(i => new { UserId = i.UserId, AppId = i.ApplicationId })
            .ToDictionary(grp => grp.Key,
                j => j.ToList().Where(k => !k.IsDeleted)
                    .Select(f => new GeneralIdNameResponse() { Id = f.Id.ToString(), Name = f.Name }));

        var randomTestUsers = testUsers.PickRandomList(5);

        foreach (var testUser in randomTestUsers)
        {
            Steps.AddTestStep(
                $"Sending 'GET' request for UserId: {testUser.Key.UserId} ApplicationId: {testUser.Key.AppId}.",
                "System should respond with a 200 OK.");
            var response =
                GetUserRolesByApplication(testUser.Key.UserId.ToStringOrEmpty(), testUser.Key.AppId.ToStringOrEmpty());

            if (!HPGWarn.Contains(response.Status, OkResponse, field: "Response Status")) continue;

            var actualList = JsonSerializer.Deserialize<List<GeneralIdNameResponse>>(response.Response);
            GeneralIdNameResponse.ValidateGenralList(testUser.Value.ToList(), actualList);
        }
    }

    /// <summary>
    /// Test to send 'GET' request to /users/<userId>/applications/<appId>/roles API endpoint with bad values.
    /// Manual Estimated Execution Time: 0:05:00
    /// </summary>
    public void TestGetUserRoleByApplicationBadRequest()
    {
        //note: Need to refactor this into a switch statement!!!!
        Steps.AddTestStep(
            "Test sending 'GET' request for /users/<userId>/applications/<appId>/roles API endpoint with bad or null values",
            "Systems should respond with a (400) Bad Request.");

        var testUsers  = _userRepository.GetAllUserRoleDb();
        var randomUser = testUsers.FirstOrDefault(i => !i.IsDeleted);

        if (randomUser == null)
            HPGAssert.Fail(
                $"Unable to get User role by application data from Database Server {GlobalTestVariables.Configuration["SmartSecurity:DatabaseServer"]}: {GlobalTestVariables.Configuration["SmartSecurity:DatabaseName"]}!");

        Steps.AddTestStep($"Sending alpha characters for UserId and ApplicationId '{randomUser.ApplicationId}'",
            "Systems should respond with a (400) Bad Request.");
        var response = GetUserRolesByApplication("abc", randomUser.ApplicationId.ToString());
        if (HPGWarn.Contains(response.Status, "(400) BadRequest"))
        {
            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };
            var actual = JsonSerializer.Deserialize<BadRequestReponse>(response.Response, options);
            HPGWarn.Contains(actual.Errors.UserId.FirstOrDefault(), "The value 'abc' is not valid.",
                field: "UserId");
        }

        Steps.AddTestStep($"Sending alpha characters for ApplicationId and UserID '{randomUser.UserId}'",
            "Systems should respond with a (400) Bad Request.");
        response = GetUserRolesByApplication(randomUser.UserId.ToString(), "abc");
        if (HPGWarn.Contains(response.Status, "(400) BadRequest"))
        {
            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };
            var actual = JsonSerializer.Deserialize<BadRequestReponse>(response.Response, options);
            HPGWarn.Contains(actual.Errors.AppId.FirstOrDefault(), "The value 'abc' is not valid.",
                field: "AppId");
        }

        string? maxId = Guid.NewGuid().ToString();

        Steps.AddTestStep($"Sending non-existing ApplicationId '{maxId}' and UserID '{randomUser.UserId}'",
            "Systems should respond with a (200) OK.");
        response = GetUserRolesByApplication(randomUser.UserId.ToString(), maxId);
        if (HPGWarn.Contains(response.Status, OkResponse))
        {
            var actual = JsonSerializer.Deserialize<List<GeneralIdNameResponse>>(response.Response);
            HPGWarn.True(actual.IsNullOrEmpty(), field: "Response is Empty.");
        }


        Steps.AddTestStep($"Sending non-existing UserID '{maxId}' and ApplicationId '{randomUser.ApplicationId}'",
            "Systems should respond with a (200) OK.");
        response = GetUserRolesByApplication(maxId, randomUser.ApplicationId.ToString());

        if (HPGWarn.Contains(response.Status, OkResponse))
        {
            var actual = JsonSerializer.Deserialize<List<GeneralIdNameResponse>>(response.Response);
            HPGWarn.True(actual.IsNullOrEmpty(), field: "Response is Empty.");
        }

        Steps.AddTestStep($"Sending UserID '0' and ApplicationId '{randomUser.ApplicationId}'",
            "Systems should respond with a (400) Bad Request.");
        response = GetUserRolesByApplication("0", randomUser.ApplicationId.ToString());
        HPGWarn.Contains(response.Status, "(400) BadRequest");

        Steps.AddTestStep($"Sending UserID '{randomUser.UserId}' and ApplicationId '0'",
            "Systems should respond with a (400) Bad Request.");
        response = GetUserRolesByApplication(randomUser.UserId.ToString(), "0");
        HPGWarn.Contains(response.Status, "(400) BadRequest");
    }

    /// <summary>
    /// Test to send 'POST' request to /users/claims API endpoint.
    /// Manual Estimated Execution Time: 0:10:00
    /// </summary>
    public void TestPostUserRoles()
    {
        Steps.AddTestStep("Test sending 'POST' request to /users/claims API endpoint.",
            "System should respond accordingly.");

        //Need to refactor this into a switch statement.
        var testUsers = _userRepository.GetAllUserRoleDb()
            .Where(i => !i.IsDeleted && i.Username.Contains("trooper",StringComparison.OrdinalIgnoreCase))
            .Where(s => !_scUsers.Contains(s.Username,StringComparer.OrdinalIgnoreCase))
            .GroupBy(g => g.UserId)
            .ToDictionary(grp => grp.Key, j => j.ToList());

        var roleData = _applicationRepository.GetApplicationRolesDbs().Where(i => !i.IsDeleted)
            .ToDictionary(r => r.Id, j => j);

        var testUser            = testUsers.PickRandom();
        var testUserCurrentRole = testUser.Value.Where(j => !j.IsDeleted).Select(i => i.Id).ToList();

        //Add Role that the user currently does not have.
        var randomRole = roleData.Where(i => !testUserCurrentRole.Contains(i.Key) && i.Value.IsEnabled).PickRandom();
        var roleRequest = new AddUserRoleSoc()
        {
            UserId        = testUser.Key.ToStringOrEmpty(),
            ApplicationId = randomRole.Value.ApplicationId.ToStringOrEmpty(),
            RoleIds = testUser.Value.Where(i => i.ApplicationId.Equals(randomRole.Value.ApplicationId) && !i.IsDeleted)
                .Select(j => j.Id.ToStringOrEmpty()).ToList()
        };
        roleRequest.RoleIds.Add(randomRole.Value.Id.ToStringOrEmpty());
        var expectedRoles = testUserCurrentRole;
        expectedRoles.Add(randomRole.Value.Id);

        SendAndValidateRoleRequest(roleRequest, expectedRoles, roleData, $"Add RoleId - {randomRole.Value.Id}");

        //remove role(s) from a user.
        //todo: need to refactor to take into account only affected apps.
        testUsers = _userRepository.GetAllUserRoleDb()
            .Where(i => !i.IsDeleted && i.Username.Contains("trooper", StringComparison.CurrentCultureIgnoreCase))
            .Where(s => !_scUsers.Contains(s.Username, StringComparer.OrdinalIgnoreCase))
            .GroupBy(g => g.UserId)
            .ToDictionary(grp => grp.Key, j => j.ToList());
        testUser            = testUsers.PickRandom();
        testUserCurrentRole = testUser.Value.Select(i => i.Id).ToList();
        var roleToRemove = testUser.Value.PickRandom();
        var updatedAppRoles = testUser.Value
            .Where(i => i.ApplicationId.Equals(roleToRemove.ApplicationId) && !i.Id.Equals(roleToRemove.Id))
            .Select(i => i.Id.ToStringOrEmpty())
            .ToList();
        roleRequest = new AddUserRoleSoc()
        {
            UserId        = testUser.Key.ToStringOrEmpty(),
            ApplicationId = roleToRemove.ApplicationId.ToStringOrEmpty(),
            RoleIds       = updatedAppRoles
        };

        expectedRoles = testUserCurrentRole.Where(i => !i.Equals(roleToRemove.Id)).ToList();
        SendAndValidateRoleRequest(roleRequest, expectedRoles, roleData, $"Remove RoleID - {roleToRemove.Id}");

        //Test Posting a user Role for a specific app and check to see if another user with the same access to an app is affected. (DE15447)
        Steps.AddTestStep(
            "Testing Scenario for User(s) soft delete when another user with the same application access as the other user(s) is assigned a role for that app. (DE15447)",
            "Expected that the user(s) role should not be soft deleted");

        var users = _userRepository.GetAllUsers()
            .Where(s => !_scUsers.Contains(s.Username, StringComparer.OrdinalIgnoreCase))
            .Where(i => i.Type.Equals("Employee")
                        && !i.IsDeactivated
                        && i.LastName!.ToStringOrEmpty().Contains("trooper", StringComparison.OrdinalIgnoreCase)
                        && !GlobalTestVariables.Users.Select(j => j.UserName).Contains(i.Username));
        
        var appRoles = _applicationRepository.GetApplicationRolesDbs()
            .Where(i => i.IsEnabled && i.ApplicationName != "Security System").GroupBy(grp => grp.ApplicationId)
            .ToDictionary(g => g.Key, j => j.ToList()).PickRandom();
        var userA = users.PickRandom();
        var userB = users.Where(i => i.Id != userA.Id).PickRandom();
        ResetUser(userA.Id.ToString());
        ResetUser(userB.Id.ToString());

        expectedRoles = appRoles.Value.PickRandomList(2).Select(i => i.Id).ToList();
        roleRequest = new AddUserRoleSoc()
        {
            UserId        = userA.Id.ToString(),
            ApplicationId = appRoles.Key.ToString(),
            RoleIds       = expectedRoles.Select(i => i.ToString()).ToList(),
        };

        SendAndValidateRoleRequest(roleRequest, expectedRoles, roleData,
            $"Adding Roles to UserA: {userA.Id} with Role IDs: {string.Join(",", expectedRoles)} for DE15447.");

        roleRequest.UserId = userB.Id.ToString();
        SendAndValidateRoleRequest(roleRequest, expectedRoles, roleData,
            $"Adding Roles to UserB: {userA.Id} with Role IDs: {string.Join(",", expectedRoles)} for DE15447.");

        Steps.AddTestStep($"Validate User A ID: {userA.Id} was not affected by User B ID:{userB.Id} role assigning",
            "User A should not be affected.");
        var userACurrentRolesDictionary = _userRepository.GetAllUserRoleDb(timeToWait: 1)
            .Where(i => i.UserId.Equals(userA.Id))
            .ToDictionary(j => j.Id, k => k);
        foreach (var expectedRole in expectedRoles)
        {
            if (!userACurrentRolesDictionary.TryGetValue(expectedRole, out var actualRole))
                HPGWarn.Warn($"Unable to find role ID: {expectedRole} for user ID: {userA.Id}!");
            else
            {
                if (actualRole.IsDeleted)
                    HPGWarn.Warn($"Expecting IsDeleted Flag to be '0' for Role ID {expectedRole} but was '1'!");
                else
                {
                    ConsoleOut.WriteReport(
                        $"Expecting IsDeleted Flag to be '0' for Role ID: {expectedRole} to be True.");
                }
            }
        }
    }

	/// <summary>
	/// Sends a POST request to the /users/claims endpoint with the specified AddUserRoleSoc payload,
	/// then validates that the user's roles in the database match the expected roles after the operation.
	/// This method is used to test adding or removing user roles for a given scenario, ensuring that
	/// the roles assigned to the user in the database are consistent with the roles specified in the request.
	/// It compares both the expected and actual role lists, reporting any discrepancies.
	/// </summary>
	private void SendAndValidateRoleRequest(AddUserRoleSoc roleRequest, List<Guid> expectedRoles,
		IReadOnlyDictionary<Guid, ApplicationRolesDb> roleData, string scenario)
	{
		//need to refactor to do lists

		var payload = JsonConvert.SerializeObject(roleRequest,
			new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });
		Steps.AddTestStep(
			$"Sending 'POST' request to /users/claims endpoint for scenario: '{scenario}' with payload: '{payload}'.",
			"System should respond with a (200) OK");
		var response = PostUserClaim(payload);

		if (HPGWarn.AreEqual(OkResponse, response.Status, field: "Response Status Code"))
		{
			HPGWarn.AreEqual("true", response.Response, field: "Response Body");


			var actualDictionary = _userRepository.GetAllUserRoleDb()
				.Where(i => i.UserId.ToString().Equals(roleRequest.UserId!) && !i.IsDeleted)
				.ToDictionary(r => r.Id, j => j);

			Steps.AddTestStep("Validate expected role IDs are in actual.", "Expected should match expected.");
			foreach (var expectedRoleId in expectedRoles)
			{
				if (!actualDictionary.TryGetValue(expectedRoleId, out var actual))
					HPGWarn.Warn($"Unable to find Role ID: '{expectedRoleId}' for User ID: '{roleRequest.UserId}'!");
				else
				{
					roleData.TryGetValue(expectedRoleId, out var expectedRoleData);
					HPGWarn.AreEqual(expectedRoleData.Name.ToStringOrEmpty(), actual.Name.ToStringOrEmpty(),
						field: "Role Name");
					HPGWarn.AreEqual(expectedRoleData.ApplicationId.ToStringOrEmpty(),
						actual.ApplicationId.ToStringOrEmpty(), field: "Application ID");
				}
			}

			Steps.AddTestStep("Validate actual role IDs are in expected.", "Expected should match actual.");
			foreach (var actual in actualDictionary)
			{
				if (!expectedRoles.Contains(actual.Key))
					HPGWarn.Warn(
						$"Actual expecting role ID: '{actual.Key}' for User ID: '{roleRequest.UserId}' but was not found in expected list!");
				else
				{
					ConsoleOut.WriteReport(
						$"Actual Role ID: '{actual.Key}' was found for User ID: '{roleRequest.UserId}' in expected list.");
				}
			}
		}
	}

    /// <summary>
    /// Test to send 'POST' request to /users/claims API endpoint bad values.
    /// Manual Estimated Execution Time: 0:05:00
    /// </summary>
    public void TestPostUserRolesBadRequest()
    {
        Steps.AddTestStep("Test 'POST' for /users/claims API endpoint with null or bad values",
            "System should respond accordingly.");
        var scenarios = new List<string>
        {
            "Null UserID", "Missing UserId", "Alpha UserId", "Null ApplicationId", "Missing ApplicationId",
            "Alpha ApplicationId", "Alpha RoleIds"
        };

        var testApplicationId = Guid.NewGuid().ToString();
        var testUserId        = Guid.NewGuid().ToString();
        List<RoleDetail> roleDetails = new List<RoleDetail>();
		RoleDetail roleDetail = new RoleDetail(){ Id = "abcd", Name = "ITS NOT GOING 2 MATTER FOR BAD TEST", IsDeleted = false, UserType = null };
		roleDetails.Add(roleDetail);

		foreach (var scenario in scenarios)
        {
 	        var userRequest = new AddUserRoleSoc()
            {
                UserId  = testUserId, ApplicationId = testApplicationId, IsDeactivated = false,
                RoleIds = new List<string>(),
                Roles = roleDetails
			 };

            var expectedResponse     = string.Empty;
            var expectedResponseBody = string.Empty;
            switch (scenario)
            {
                case "Null UserID":
                    userRequest.UserId   = string.Empty;
                    expectedResponse     = BadRequestResponse;
                    expectedResponseBody = "The JSON value could not be converted to System.Guid. Path: $.UserId";
                    break;
                case "Missing UserId": 
	                userRequest.UserId = null;
	                userRequest.RoleIds.Add("A1B2");
	                expectedResponse = "(400) BadRequest";
	                expectedResponseBody = "\"title\":\"One or more validation errors occurred.\",\"status\":400";
	                break;
                case "Alpha UserId":
                    userRequest.UserId   = "abc";
                    expectedResponse     = BadRequestResponse;
                    expectedResponseBody = "The JSON value could not be converted to System.Guid. Path: $.UserId";
                    break;
                case "Null ApplicationId":
                    userRequest.ApplicationId = string.Empty;
                    expectedResponse          = BadRequestResponse;
                    expectedResponseBody =
                        "The JSON value could not be converted to System.Guid. Path: $.ApplicationId";
                    break;
                case "Missing ApplicationId":
                    userRequest.ApplicationId = null;
                    expectedResponse          = BadRequestResponse;
                    expectedResponseBody      = "\"title\":\"One or more validation errors occurred.\",\"status\":400";
                    break;
                case "Alpha ApplicationId": //this one
                    userRequest.ApplicationId = "abc";
                    userRequest.RoleIds.Add("A1B2");
					expectedResponse          = BadRequestResponse;
                    expectedResponseBody = "The JSON value could not be converted to System.Guid. Path: $.ApplicationId";
                    break;
                case "Alpha RoleIds":
	                userRequest.RoleIds.Add("A1B2");
                    expectedResponse = BadRequestResponse;
                    expectedResponseBody = "The JSON value could not be converted to System.Guid. Path: $.RoleIds[0]";
                    break;
            }

            var payload = scenario.Contains("Missing")
                ? JsonConvert.SerializeObject(userRequest, JsonNullSetting)
                : JsonConvert.SerializeObject(userRequest);

            Steps.AddTestStep(
                $"Sending 'POST' request to /users/claims endpoint with the following payload: {payload} for scenario: {scenario}",
                $"System should respond with '{expectedResponse}' response status.");

            var response = PostUserClaim(payload);

			if (HPGWarn.AreEqual(expectedResponse, response.Status, field: "Response Status Code"))
            {
                HPGWarn.Contains(response.Response, expectedResponseBody, field: "Response Body", toTruncate: false);
            }
        }
    }

    /// <summary>
    /// Test sending 'GET' request to /users/<UserId>/applications/<ApplicationId>/soc.
    /// Manual Estimated Execution Time: 0:05:00
    /// </summary>
    public void TestGetUserSocByApplication(bool isProd = false)
    {
        Steps.AddTestStep("Test sending 'GET' request to /users/<UserId>/applications/<ApplicationId>/soc.",
            "System should respond accordingly.");

        var testUsers = _userRepository.GetAllUserSocDb().Where(i => !i.IsDeleted)
            .GroupBy(grp => new { AppId = grp.ApplicationId, grp.UserId })
            .ToDictionary(g => g.Key, j => j.ToList())
            .PickRandomList(5);

        if (!testUsers.Any() && !isProd)
        {
            var testUser = _userRepository.GetAllUsers()
                .Where(i => !i.IsDeactivated && !i.Type.Equals("vendor", StringComparison.CurrentCultureIgnoreCase))
                .PickRandom();
            SetupUserForRemovalTest(testUser);

            testUsers = _userRepository.GetAllUserSocDb(timeToWait: 1).Where(i => !i.IsDeleted)
                .GroupBy(grp => new { AppId = grp.ApplicationId, grp.UserId })
                .ToDictionary(g => g.Key, j => j.ToList())
                .PickRandomList(5);
        }

        if (!testUsers.Any())
        {
            Console.WriteLine($"Unable to pull any users with roles!");
            return;
        }

        foreach (var testUser in testUsers)
        {
            Steps.AddTestStep(
                $"Sending 'GET' to /users/{testUser.Key.UserId}/applications/{testUser.Key.AppId}/soc API endpoint.",
                "System should respond with (200) OK.");

            //note: Prefix will be removed with US99626.
            var expectedList = HomeService.GetExpectedHierarchyList(testUser.Value, _homeInfoDataDb,false);
            var response     = GetUserSocByApplication(testUser.Key.UserId.ToString(), testUser.Key.AppId.ToString());

			if (!HPGWarn.AreEqual(OkResponse, response.Status, field: "Response Status Code")) continue;
			var actualList = JsonConvert.DeserializeObject<SpanOfControlViewModel>(response.Response); 
			SpanOfControl.ValidateOrgTreeList(expectedList, actualList!.Soc);
        }
    }

	/// <summary>
	/// Test sending 'GET' request to /users/<UserId>/applications/<ApplicationId>/soc with bad values.
	/// Manual Estimated Execution Time: 0:05:00
	/// Notes:  hasElevatedSoc flag is for the target user having elevated soc access in the system.
	///         hasHealthTrustLevelSoc flag is for the querying user having HealthTrustLevel soc access in the system.
	/// </summary>
	public void TestGetUserSocByApplicationBadRequest()
    {
        //need to implement
        var scenarios = new List<string>()
        {
            "Alpha UserId", "Alpha AppId", "Alpha UserId & AppId", "Null UserId", "Null AppId", "Null UserId & AppId",
            "Non-existent UserId", "Non-existent AppId", "Non-existent UserId & AppId"
        };
        var users         = _userRepository.GetAllUsers();
        var applications  = _applicationRepository.GetApplicationsDb();
        var initialUserId = users.Where(i => !i.IsDeactivated).PickRandom().Id.ToString();
        var initialAppId  = applications.Where(i => !i.IsDeleted && i.IsEnabled).PickRandom().ApiKey.ToString();

        foreach (var scenario in scenarios)
        {
            var userId    = initialUserId;
            var appId     = initialAppId;
            var errorCode = string.Empty;
            switch (scenario)
            {
                case "Alpha UserId":
                    userId    = "abc";
                    errorCode = "(400) BadRequest";
                    break;
                case "Alpha AppId":
                    appId     = "abc";
                    errorCode = "(400) BadRequest";
                    break;
                case "Alpha UserId & AppId":
                    userId    = "abc";
                    appId     = "abc";
                    errorCode = "(400) BadRequest";
                    break;
                case "Null UserId":
                    userId    = string.Empty;
                    errorCode = "(404) NotFound";
                    break;
                case "Null AppId":
                    appId     = string.Empty;
                    errorCode = "(404) NotFound";
                    break;
                case "Null UserId & AppId":
                    userId    = string.Empty;
                    appId     = string.Empty;
                    errorCode = "(404) NotFound";
                    break;
                case "Non-existent UserId":
                    userId    = Guid.NewGuid().ToString();
                    errorCode = OkResponse;
                    break;
                case "Non-existent AppId":
                    appId     = Guid.NewGuid().ToString();
                    errorCode = OkResponse;
                    break;
                case "Non-existent UserId & AppId":
                    userId    = Guid.NewGuid().ToString();
                    appId     = Guid.NewGuid().ToString();
                    errorCode = OkResponse;
                    break;
            }

            Steps.AddTestStep($"Sending 'GET' request to /users/{userId}/applications/{appId}/soc API endpoint. Test Scenario: {scenario}.",
                $"System should respond with a {errorCode} status code.");
            var response = GetUserSocByApplication(userId, appId);
            HPGWarn.AreEqual(errorCode, response.Status, field: "Response Status Code");
            if (errorCode.Equals(OkResponse))
            {
				var expected = "{\"soc\":[],\"hasElevatedSoc\":false,\"hasHealthTrustLevelSoc\":true}";
				HPGWarn.AreEqual(expected, response.Response, field: "Response Body");
            }
        }
    }

    /// <summary>
    /// Test Sending 'POST' Request to /users/claims API endpoint to test Span of Control add and removal.
    /// Manual Estimated Execution Time: 0:15:00
    /// </summary>
    /*public void TestPostUserSocByApplication()
    {
        Steps.AddTestStep(
            "Test Sending 'POST' Request to /users/claims API endpoint to test Span of Control add and removal.",
            "System Should respond accordingly.");
        //Setup user
        var testUsers = _userRepository.GetAllUsers()
            .Where(s => !_scUsers.Contains(s.Username, StringComparer.OrdinalIgnoreCase))
            .Where(i => !i.IsDeactivated
                        && !i.Type.Equals("vendor", StringComparison.CurrentCultureIgnoreCase)
                        && i.LastName.ToStringOrEmpty().Contains("Trooper", StringComparison.CurrentCultureIgnoreCase)
                        && !GlobalTestVariables.Users.Select(j => j.UserName).Contains(i.Username))
            .ToList();
        var testUser = testUsers.PickRandom();
        var application = _applicationRepository.GetApplicationsDb().Where(i => i.IsEnabled && !i.IsDeleted)
            .PickRandom();
        var homeActive = _homeInfoDataDb.Where(i =>
            i.IsActive && i.CompanyId.Equals("1") && i.COID.ToStringOrEmpty() != string.Empty);
        var randomHome = homeActive.PickRandom();
        ResetUser(testUser.Id.ToString());

        var scenarios = new List<string>(Enum.GetNames(typeof(HomeHierarchyType))) { "Multiple Span of Control" };

        string?       payload;
        HttpResponse? response;
        foreach (var scenario in scenarios)
        {
            var userRequest = new AddUserRoleSoc()
            {
                UserId        = testUser.Id.ToString(),
                ApplicationId = application.ApiKey.ToString(),
                SpanOfControl = new List<SpanOfControl>()
            };

            switch (scenario)
            {
                case "Company":
                    userRequest.SpanOfControl.Add(new SpanOfControl
                    {
                        HierarchyType = "1",
                        ObjectId      = randomHome.CompanyId,
                        OrgName       = randomHome.CompanyName
                    });
                    break;
                case "Group":
                    userRequest.SpanOfControl.Add(new SpanOfControl()
                    {
                        HierarchyType = "2",
                        ObjectId      = randomHome.GroupId,
                        OrgName       = randomHome.GroupName
                    });
                    break;
                case "Division":
                    userRequest.SpanOfControl.Add(new SpanOfControl()
                    {
                        HierarchyType = "3",
                        ObjectId      = randomHome.DivisionID,
                        OrgName       = randomHome.DivisionName
                    });
                    break;
                case "Market":
                    userRequest.SpanOfControl.Add(new SpanOfControl()
                    {
                        HierarchyType = "4",
                        ObjectId      = randomHome.MarketId,
                        OrgName       = randomHome.MarketName
                    });
                    break;
                case "Facility":
                    userRequest.SpanOfControl.Add(new SpanOfControl()
                    {
                        HierarchyType = "5",
                        ObjectId      = randomHome.COID,
                        OrgName       = randomHome.Name
                    });
                    break;
                case "Multiple Span of Control":
                    userRequest.SpanOfControl.AddRange(homeActive.PickRandomList(5).Select(i => new SpanOfControl()
                        { HierarchyType = "5", ObjectId = i.COID, OrgName = i.Name }));

                    //test to add coids with leading 0 for DE15533
                    userRequest.SpanOfControl.AddRange(homeActive.Where(i => i.COID.StartsWith('0')).PickRandomList(2)
                        .Select(i => new SpanOfControl()
                            { HierarchyType = "5", ObjectId = i.COID, OrgName = i.Name }));
                    break;
                default:
                    continue;
            }

            payload = JsonConvert.SerializeObject(userRequest, JsonNullSetting);
            Steps.AddTestStep(
                $"Sending 'POST' request to /users/claims API endpoint for scenario: '{scenario}' with payload: '{payload}'.",
                "System should respond with a (200) OK");

            response = PostUserClaim(payload);

            if (HPGWarn.AreEqual(OkResponse, response.Status, field: ResponseStatusField))
            {
                HPGWarn.AreEqual("true", response.Response, field: ResponseBodyField);
                var expectedList = userRequest.SpanOfControl.Select(i => new UserSocDb()
                {
                    UserId        = testUser.Id,
                    ApplicationId = application.Id,
                    Hierarchy     = i.HierarchyType.ToInt(),
                    OrgObjectID   = i.ObjectId.PadLeft(5, '0'),
                    IsDeleted     = false
                }).ToList();
                var actualList = _userRepository.GetAllUserSocDb(userId: testUser.Id, timeToWait: 1)
                    .Where(i => !i.IsDeleted && i.ApplicationId == expectedList[0].ApplicationId).ToList();
                ValidateUserSpanOfControlList(expectedList, actualList);
            }

            //Remove Span of Control 
            Steps.AddTestStep("Remove Span of Control for the next scenario.", "System should allow it.");
            userRequest.SpanOfControl.Clear();
            payload = JsonConvert.SerializeObject(userRequest, JsonNullSetting);
            PostUserClaim(payload);
            HPGWarn.AreEqual(OkResponse, response.Status, field: ResponseStatusField);
        }

        //Test for DE15541
        Steps.AddTestStep(
            "Testing sending 'POST' request to /users/claims API endpoint for scenario: 'DE15541 - Overwriting other users Span of Control'. ",
            "System should not overwrite other users Span of Control.");
        var testUserB = testUsers.Where(i => !i.Id.Equals(testUser.Id)).PickRandom();
        ResetUser(testUserB.Id.ToString());

        var userRequests = new List<AddUserRoleSoc>
        {
            new()
            {
                UserId        = testUser.Id.ToString(),
                ApplicationId = application.ApiKey.ToString(),
                SpanOfControl = homeActive.PickRandomList(5).Select(i => new SpanOfControl()
                    { HierarchyType = "5", ObjectId = i.COID, OrgName = i.Name }).ToList()
            },
            new()
            {
                UserId        = testUserB.Id.ToString(),
                ApplicationId = application.ApiKey.ToString(),
                SpanOfControl = homeActive.PickRandomList(5).Select(i => new SpanOfControl()
                    { HierarchyType = "5", ObjectId = i.COID, OrgName = i.Name }).ToList()
            }
        };

        foreach (var request in userRequests)
        {
            payload = JsonConvert.SerializeObject(request,
                new JsonSerializerSettings() { NullValueHandling = NullValueHandling.Ignore });
            Steps.AddTestStep(
                $"Sending 'POST' request to /users/claims API endpoint with payload: '{payload}'.",
                "System should respond with a (200) OK");

            response = PostUserClaim(payload);
            HPGWarn.AreEqual(OkResponse, response.Status, field: ResponseStatusField);
        }

        foreach (var request in userRequests)
        {
            Steps.AddTestStep($"Validating User: '{request.UserId} Span of Control.",
                "System should match assigned values.");
            var expectedList = request.SpanOfControl.Select(i => new UserSocDb()
            {
                UserId        = new Guid(request.UserId),
                ApplicationId = new Guid(request.ApplicationId!),
                Hierarchy     = i.HierarchyType.ToInt(),
                OrgObjectID   = i.ObjectId.PadLeft(5, '0'),
                IsDeleted     = false
            }).ToList();

            var actualList = _userRepository.GetAllUserSocDb(new Guid(request.UserId), 1).Where(i => !i.IsDeleted)
                .ToList();
            ValidateUserSpanOfControlList(expectedList, actualList);
        }
    }
    */
	////////
	public void TestPostUserSocByApplication()
	{
		Steps.AddTestStep(
			"Test Sending 'POST' Request to /users/claims API endpoint to test Span of Control add and removal.",
			"System Should respond accordingly.");

		// Setup user and application
		var testUsers = _userRepository.GetAllUsers()
			.Where(s => !_scUsers.Contains(s.Username, StringComparer.OrdinalIgnoreCase))
			.Where(i => !i.IsDeactivated
						&& !i.Type.Equals("vendor", StringComparison.CurrentCultureIgnoreCase)
						&& i.LastName.ToStringOrEmpty().Contains("Trooper", StringComparison.CurrentCultureIgnoreCase)
						&& !GlobalTestVariables.Users.Select(j => j.UserName).Contains(i.Username))
			.ToList();

		var testUser = testUsers.PickRandom();
		var application = _applicationRepository.GetApplicationsDb().Where(i => i.IsEnabled && !i.IsDeleted).PickRandom();
		var homeActive = _homeInfoDataDb.Where(i =>
			i.IsActive && i.CompanyId.Equals("1") && i.COID.ToStringOrEmpty() != string.Empty);
		var randomHome = homeActive.PickRandom();
		ResetUser(testUser.Id.ToString());

		var scenarios = new List<string>(Enum.GetNames(typeof(HomeHierarchyType))) { "Multiple Span of Control" };

		foreach (var scenario in scenarios)
		{
			var userRequest = BuildSocRequest(testUser, application, scenario, randomHome, homeActive);

			SendSocRequestAndValidate(userRequest, testUser, application);

			// Remove Span of Control
			Steps.AddTestStep("Remove Span of Control for the next scenario.", "System should allow it.");
			userRequest.SpanOfControl.Clear();
			SendSocRequestAndValidate(userRequest, testUser, application);
		}

		// Test for DE15541 - Overwriting other users Span of Control
		Steps.AddTestStep(
			"Testing sending 'POST' request to /users/claims API endpoint for scenario: 'DE15541 - Overwriting other users Span of Control'. ",
			"System should not overwrite other users Span of Control.");

		var testUserB = testUsers.Where(i => !i.Id.Equals(testUser.Id)).PickRandom();
		ResetUser(testUserB.Id.ToString());

		var userRequests = new List<AddUserRoleSoc>
	{
		BuildSocRequest(testUser, application, "Multiple Span of Control", randomHome, homeActive),
		BuildSocRequest(testUserB, application, "Multiple Span of Control", randomHome, homeActive)
	};

		foreach (var request in userRequests)
		{
			SendSocRequestAndValidate(request, null, application);
		}

		foreach (var request in userRequests)
		{
			Steps.AddTestStep($"Validating User: '{request.UserId} Span of Control.",
				"System should match assigned values.");
			var expectedList = request.SpanOfControl.Select(i => new UserSocDb()
			{
				UserId = new Guid(request.UserId),
				ApplicationId = new Guid(request.ApplicationId!),
				Hierarchy = i.HierarchyType.ToInt(),
				OrgObjectID = i.ObjectId.PadLeft(5, '0'),
				IsDeleted = false
			}).ToList();

			var actualList = _userRepository.GetAllUserSocDb(new Guid(request.UserId), 1).Where(i => !i.IsDeleted)
				.ToList();
			ValidateUserSpanOfControlList(expectedList, actualList);
		}
	}

	/// <summary>
	/// Builds the AddUserRoleSoc request for a given scenario.
	/// </summary>
	private AddUserRoleSoc BuildSocRequest(UserResponse user, ApplicationsDb app, string scenario, HomeDataDb home, IEnumerable<HomeDataDb> homeActive)
	{
		var soc = new List<SpanOfControl>();
		switch (scenario)
		{
			case "Company":
				soc.Add(new SpanOfControl { HierarchyType = "1", ObjectId = home.CompanyId, OrgName = home.CompanyName });
				break;
			case "Group":
				soc.Add(new SpanOfControl { HierarchyType = "2", ObjectId = home.GroupId, OrgName = home.GroupName });
				break;
			case "Division":
				soc.Add(new SpanOfControl { HierarchyType = "3", ObjectId = home.DivisionID, OrgName = home.DivisionName });
				break;
			case "Market":
				soc.Add(new SpanOfControl { HierarchyType = "4", ObjectId = home.MarketId, OrgName = home.MarketName });
				break;
			case "Facility":
				soc.Add(new SpanOfControl { HierarchyType = "5", ObjectId = home.COID, OrgName = home.Name });
				break;
			case "Multiple Span of Control":
				soc.AddRange(homeActive.PickRandomList(5).Select(i => new SpanOfControl { HierarchyType = "5", ObjectId = i.COID, OrgName = i.Name }));
				soc.AddRange(homeActive.Where(i => i.COID.StartsWith('0')).PickRandomList(2).Select(i => new SpanOfControl { HierarchyType = "5", ObjectId = i.COID, OrgName = i.Name }));
				break;
		}
		return new AddUserRoleSoc
		{
			UserId = user.Id.ToString(),
			ApplicationId = app.ApiKey.ToString(),
			SpanOfControl = soc
		};
	}

	/// <summary>
	/// Sends the SOC request and validates the response and database.
	/// </summary>
	private void SendSocRequestAndValidate(AddUserRoleSoc userRequest, UserResponse testUser, ApplicationsDb application)
	{
		var payload = JsonConvert.SerializeObject(userRequest, JsonNullSetting);
		Steps.AddTestStep(
			$"Sending 'POST' request to /users/claims API endpoint for scenario with payload: '{payload}'.",
			"System should respond with a (200) OK");

		var response = PostUserClaim(payload);

		if (HPGWarn.AreEqual(OkResponse, response.Status, field: ResponseStatusField))
		{
			HPGWarn.AreEqual("true", response.Response, field: ResponseBodyField);

			// If no SOC, skip validation
			if (userRequest.SpanOfControl == null || !userRequest.SpanOfControl.Any())
				return;

			var expectedList = userRequest.SpanOfControl.Select(i => new UserSocDb()
			{
				UserId = testUser != null ? testUser.Id : new Guid(userRequest.UserId),
				ApplicationId = application.Id,
				Hierarchy = i.HierarchyType.ToInt(),
				OrgObjectID = i.ObjectId.PadLeft(5, '0'),
				IsDeleted = false
			}).ToList();

			var actualList = _userRepository.GetAllUserSocDb(
				testUser != null ? testUser.Id : new Guid(userRequest.UserId), 1)
				.Where(i => !i.IsDeleted && i.ApplicationId == expectedList[0].ApplicationId).ToList();

			ValidateUserSpanOfControlList(expectedList, actualList);
		}
	}

	/// <summary>
	/// Test sending 'POST' request to /users/claims API endpoint to test Span of Control with Bad Values.
	/// Manual Estimated Execution Time: 0:05:00
	/// </summary>
	public void TestPostUserSocByApplicationBadRequest()
    {
        Steps.AddTestStep(
            "Test sending 'POST' request to /users/claims API endpoint to test Span of Control with Bad Values.",
            "System should respond accordingly.");
        var scenarios = new List<string>
        {
            "Null HierarchyType", "Null ObjectId", "Null OrgName", "Alpha HierarchyType", "Blank HierarchyType",
            //"Blank ObjectId" //commented out due to 
        };

        var testUser = _userRepository.GetAllUsers()
            .Where(s => !_scUsers.Contains(s.Username, StringComparer.OrdinalIgnoreCase))
            .Where(i => !i.IsDeactivated
                        && !i.Type.Equals("vendor", StringComparison.CurrentCultureIgnoreCase)
                        && i.LastName.ToStringOrEmpty().Contains("trooper", StringComparison.CurrentCultureIgnoreCase))
            .PickRandom();
        var application = _applicationRepository.GetApplicationsDb().Where(i => i.IsEnabled && !i.IsDeleted)
            .PickRandom();
        var randomHome = _homeInfoDataDb
            .Where(i => i.IsActive && i.CompanyId.Equals("1") && i.COID.ToStringOrEmpty() != string.Empty).PickRandom();

        foreach (var scenario in scenarios)
        {
            var statusCode       = OkResponse;
            var expectedResponse = string.Empty;
            var userRequest = new AddUserRoleSoc()
            {
                UserId        = testUser.Id.ToString(),
                ApplicationId = application.Id.ToString(),
                SpanOfControl = new List<SpanOfControl>()
            };

            switch (scenario)
            {
                case "Null HierarchyType":
                    statusCode       = BadRequestResponse;
                    expectedResponse = "The HierarchyType field is required.";
                    userRequest.SpanOfControl.Add(new SpanOfControl()
                    {
                        HierarchyType = null,
                        ObjectId      = randomHome.COID,
                        OrgName       = randomHome.Name
                    });
                    break;
                case "Null ObjectId":
                    statusCode       = BadRequestResponse;
                    expectedResponse = "The ObjectId field is required.";
                    userRequest.SpanOfControl.Add(new SpanOfControl()
                    {
                        HierarchyType = "5",
                        ObjectId      = null,
                        OrgName       = randomHome.Name
                    });
                    break;
                case "Null OrgName":
                    statusCode       = BadRequestResponse;
                    expectedResponse = "The OrgName field is required.";
                    userRequest.SpanOfControl.Add(new SpanOfControl()
                    {
                        HierarchyType = "5",
                        ObjectId      = randomHome.COID,
                        OrgName       = null
                    });
                    break;
                case "Alpha HierarchyType":
                    statusCode       = OkResponse;
                    expectedResponse = "false";
                    userRequest.SpanOfControl.Add(new SpanOfControl()
                    {
                        HierarchyType = "ABC",
                        ObjectId      = randomHome.COID,
                        OrgName       = randomHome.Name
                    });
                    break;
                case "Blank HierarchyType":
                    statusCode       = OkResponse;
                    expectedResponse = "false";
                    userRequest.SpanOfControl.Add(new SpanOfControl()
                    {
                        HierarchyType = "",
                        ObjectId      = randomHome.COID,
                        OrgName       = randomHome.Name
                    });
                    break;
                case "Blank ObjectId":
                    statusCode = InternalServerResponse;
                    userRequest.SpanOfControl.Add(new SpanOfControl()
                    {
                        HierarchyType = "5",
                        ObjectId      = "",
                        OrgName       = randomHome.Name
                    });
                    break;
            }

            var payload = JsonConvert.SerializeObject(userRequest, JsonNullSetting);

            Steps.AddTestStep(
                $"Sending 'POST' request to /users/claims API endpoint for scenario: '{scenario}' with payload: '{payload}'.",
                $"System should respond with a status code: '{statusCode}'.");
            var response = PostUserClaim(payload);
            if (HPGWarn.AreEqual(statusCode, response.Status, field: ResponseStatusField))
            {
                HPGWarn.Contains(response.Response, expectedResponse, field: ResponseBodyField);
            }
        }
    }

    /// <summary>
    /// Test sending 'GET' request to /users/<User ID>/applications/<Application ID>/vendor-affiliations API endpoint.
    /// Manual Estimated Execution Time: 0:05:00
    /// </summary>
    public void TestGetVendorAffiliation()
    {
        Steps.AddTestStep(
            "Test sending 'GET' request to /users/<User ID>/applications/<Application ID>/vendor-affiliations API endpoint.",
            "System should respond accordingly.");

        var testUsers = _userRepository.GetUserVendorAffiliationDb().Where(i => !i.IsDeleted)
            .GroupBy(grp => grp.UserId).ToDictionary(k => k.Key, j => j.ToList())
            .PickRandomList(5);

        foreach (var testUser in testUsers)
        {
            Steps.AddTestStep(
                $"Sending 'GET' request to /users/{testUser.Key}/vendor-affiliations",
                "System should respond with a (200) OK.");
            var expectedList = testUser.Value.Select(i => new UserVendorAffiliationResponse()
                { Id = i.Id, VendorId = i.VendorId }).ToList();

            var response = GetUserVendorAffiliationByApplication(testUser.Key.ToString());

            if (!HPGWarn.AreEqual(OkResponse, response.Status, field: "Response Status Code")) continue;
            var actualList = JsonConvert.DeserializeObject<List<UserVendorAffiliationResponse>>(response.Response);
            UserVendorAffiliationResponse.ValidateVendorAffiliationList(expectedList, actualList!);
        }
    }

    /// <summary>
    /// Test sending 'GET' request to /users/<User ID>/applications/<Application ID>/vendor-affiliations API endpoint with bad values.
    /// Manual Estimated Execution Time: 0:05:00
    /// </summary>
    public void TestGetVendorAffiliationBadRequest()
    {
        Steps.AddTestStep(
            "Test sending 'GET' request to /users/<User ID>/applications/<Application ID>/vendor-affiliations API endpoint with bad values.",
            "System should respond accordingly.");

        var scenarios = new List<string>
        {
            "Null UserId", "Alpha UserId", "Non-Existent UserId"
        };

        var testUser = _userRepository.GetUserVendorAffiliationDb().Where(i => !i.IsDeleted)
            .GroupBy(grp => grp.UserId).ToDictionary(k => k.Key, j => j.ToList())
            .PickRandom();

        const string maxUserId = "1fff5c61-c023-420f-9dc9-1b10cb5ce42a";

        foreach (var scenario in scenarios)
        {
            var userId     = testUser.Key.ToString();
            var statusCode = string.Empty;

            switch (scenario)
            {
                case "Null UserId":
                    userId     = string.Empty;
                    statusCode = NotFoundResponse;
                    break;


                case "Alpha UserId":
                    userId     = "ABCD";
                    statusCode = BadRequestResponse;
                    break;


                case "Non-Existent UserId":
                    userId     = maxUserId;
                    statusCode = OkResponse;
                    break;
            }

            Steps.AddTestStep(
                $"Sending 'GET' request to /users/{userId}/vendor-affiliations for Scenario: '{scenario}'",
                $"System should respond with a '{statusCode}'.");
            var response = GetUserVendorAffiliationByApplication(userId);

            if (HPGWarn.AreEqual(statusCode, response.Status, field: "Response Status Code"))
            {
                if (!statusCode.Equals(OkResponse)) continue;
                var actualList = JsonConvert.DeserializeObject<List<UserVendorAffiliationResponse>>(response.Response);
                HPGWarn.True(actualList.IsNullOrEmpty());
            }
        }
    }

    /// <summary>
    /// Test sending 'POST' request to /users/claims API endpoint.
    /// Manual Estimated Execution Time: 0:10:00
    /// </summary>
    public void TestPostVendorAffiliation()
    {
        Steps.AddTestStep("Test sending 'POST' request to /users/claims API endpoint.",
            "System should respond accordingly.");

        var scenarios = new List<string>() { "Add Vendor(s) Affiliation", "Remove Vendor Affiliation" };
        //get vendor user
        var testUser = _userRepository.GetAllUsers()
            .Where(s => !_scUsers.Contains(s.Username, StringComparer.OrdinalIgnoreCase))
            .Where(i => !i.IsDeactivated && i.Type.Equals("Vendor") && i.LastName.ToStringOrEmpty()
                    .Contains("trooper", StringComparison.CurrentCultureIgnoreCase))
            .PickRandom();

        //reset user
        ResetUser(testUser.Id.ToString());

        //Add Vendor role and vendor affiliation 

        //Note: Hard Coding to SMART Procurement - Vendor Bill Only since that is the only role available to vendor users. Will need to refactor when other roles are available.
        var appRole = _applicationRepository.GetApplicationRolesByUserTypeDbs(false)
            .First(i => i.ApplicationName.Equals("SMART - Procurement") &&
                        i.Name.Equals("Procurement - Vendor Bill Only"));

		//var vendors = _vendorRepository.GetVendorInfo().Where(i => i.IsActive).PickRandomList(5).Distinct();
		var vendors = _vendorRepository.GetVendorInfo().Where(i => i.IsActive).GroupBy(v => v.Snv).Select(g => g.First()).ToList();
		var vendorIds = vendors.Select(v => v.Snv).ToHashSet();
		var appRoleRequest = new AddUserRoleSoc()
        {
            UserId        = testUser.Id.ToString(),
            ApplicationId = appRole.ApplicationId.ToString(),
            RoleIds       = new List<string>() { appRole.Id.ToString() }
        };

        foreach (var scenario in scenarios)
        {
            switch (scenario)
            {
                case "Add Vendor(s) Affiliation":
                    appRoleRequest.VendorAffiliation =
                        vendors.Select(i => new VendorModel { Id = i.Snv, Name = i.Name }).ToList();
                    break;
                case "Remove Vendor Affiliation":
                    var removedVendor = vendors.PickRandom();
                    appRoleRequest.VendorAffiliation =
                        vendors.Where(i => i.Snv != removedVendor.Snv)
                            .Select(j => new VendorModel { Id = j.Snv, Name = j.Name }).ToList();
                    break;
            }

            var payload = JsonConvert.SerializeObject(appRoleRequest, JsonNullSetting);

            Steps.AddTestStep(
                $"Sending 'POST' request to /users/claims API endpoint for scenario: '{scenario}' with the following payload: '{payload}'.",
                "System should respond with a (200) OK and a response body of 'true'.");

            var response = PostUserClaim(payload);

            if (HPGWarn.AreEqual(OkResponse, response.Status, field: "Response Status Code"))
            {
                var expectedList = appRoleRequest.VendorAffiliation.Select(i => new UserVendorAffiliationDb()
                {
                    UserId = testUser.Id, VendorId = i.Id, IsDeleted = false, IsDeactivated = false
                }).ToList();
                var actualList = _userRepository.GetUserVendorAffiliationDb(testUser.Id, 1).Where(i => !i.IsDeleted && !i.IsDeactivated)
                    .ToList();
				actualList = actualList.Where(a => vendorIds.Contains(a.VendorId)).ToList();
				ValidateVendorAffiliationDbList(expectedList, actualList);
            }
        }

        //Special scenario for DE15447
        Steps.AddTestStep("Testing DE15447 for Vendor Affiliation override issue.", "This should not override other users.");
        var testUserB = _userRepository.GetAllUsers()
            .Where(i => !i.IsDeactivated && i.Type.Equals("Vendor") && i.Id != testUser.Id).PickRandom();

        ResetUser(testUserB.Id.ToString());

        var appRoleRequestUserB = appRoleRequest;
        appRoleRequestUserB.UserId = testUserB.Id.ToString();
        var payloadB  = JsonConvert.SerializeObject(appRoleRequestUserB, JsonNullSetting);
        var responseB = PostUserClaim(payloadB);

        if (HPGWarn.AreEqual(OkResponse, responseB.Status, field: "Response Status Code"))
        {
            Steps.AddTestStep(
                $"Validating Test User B: {testUserB.Id} expected vendor affiliation is persisted to the database.",
                "Data should be persisted");
            //Validate Test USer B is persisted
            var expectedList = appRoleRequest.VendorAffiliation.Select(i => new UserVendorAffiliationDb()
            {
                UserId    = testUserB.Id,
                VendorId  = i.Id,
                IsDeleted = false
            }).ToList();
            var actualList = _userRepository.GetUserVendorAffiliationDb(testUserB.Id, 1).Where(i => !i.IsDeleted && !i.IsDeactivated)
                .ToList();
			actualList = actualList.Where(a => vendorIds.Contains(a.VendorId)).ToList();
			ValidateVendorAffiliationDbList(expectedList, actualList);

            //Validate original test user
            Steps.AddTestStep(
                $"Validating Original Test User: {testUser.Id} expected vendor affiliation is has not changed.",
                "Data should not be changed.");
            expectedList = appRoleRequest.VendorAffiliation.Select(i => new UserVendorAffiliationDb()
            {
                UserId    = testUser.Id,
                VendorId  = i.Id,
                IsDeleted = false
            }).ToList();

            actualList = _userRepository.GetUserVendorAffiliationDb(testUser.Id, 1).Where(i => !i.IsDeleted)
                .ToList();
			actualList = actualList.Where(a => vendorIds.Contains(a.VendorId)).ToList();
			ValidateVendorAffiliationDbList(expectedList, actualList);
        }
    }

    /// <summary>
    /// Test sending 'POST' request to /users/claims API endpoint with bad values.
    /// Manual Estimated Execution Time: 0:02:00
    /// </summary>
    public void TestPostVendorAffiliationBadRequest()
    {
        Steps.AddTestStep("Test sending 'POST' request to /users/claims API endpoint with bad values.",
            "System should respond accordingly.");
        var scenarios = new List<string>
        {
            //"Alpha VendorId",
            "Non-Existent VendorIds"
        };

        var users        = _userRepository.GetAllUsers().Where(s => !_scUsers.Contains(s.Username, StringComparer.OrdinalIgnoreCase));
        var applications = _applicationRepository.GetApplicationsDb();

        var testUser      = users.First(i => !i.IsDeactivated);
        var applicationId = applications.First(i => i.IsEnabled && !i.IsDeleted);

        foreach (var scenario in scenarios)
        {
            var statusCode = string.Empty;
            var appRoleRequest = new AddUserRoleSoc()
            {
                UserId        = testUser.Id.ToString(),
                ApplicationId = applicationId.Id.ToString(),
                VendorAffiliation = new List<VendorModel>()
                {
                    new() { Id = 900800, Name = "MCKESSON MEDICAL-SURGICAL INC" },
                    new() { Id = 900700, Name = "CARDINAL HEALTH MEDICAL PRODUCTS" },
                }
            };

            switch (scenario)
            {
                //case "Alpha VendorId":
                //    appRoleRequest.VendorAffiliation = new List<VendorModel>() { "ABC" };
                //    statusCode                       = BadRequestResponse;
                //    break;
                case "Non-Existent VendorIds":
                    appRoleRequest.VendorAffiliation = new List<VendorModel>()
                        { new VendorModel { Id = 0, Name = "Non-Existent Vendor" }, };
                    statusCode = OkResponse;
                    break;
            }

            Steps.AddTestStep($"Sending 'POST' request to /users/claims API endpoint for scenario: '{scenario}'.",
                $"System should respond with a status code: '{statusCode}'.");

            var payload  = JsonConvert.SerializeObject(appRoleRequest, JsonNullSetting);
            var response = PostUserClaim(payload);
            HPGWarn.AreEqual(statusCode, response.Status, field: "Response Status Code");

            switch (statusCode)
            {
                case InternalServerResponse:
                    HPGWarn.Contains(response.Response, "Unable to process the request.");
                    break;
                case BadRequestResponse:
                    HPGWarn.Contains(response.Response, "The request field is required.");
                    break;
                case OkResponse:
                    HPGWarn.Contains(response.Response, "true");
                    break;
            }
        }
    }

    /// <summary>
    /// Test sending 'POST' request to /users API endpoint for a new user.
    /// Manual Estimated Execution Time: 0:03:00
    /// </summary>
    public void TestPostNewUser()
    {
        Steps.AddTestStep("Test sending 'POST' request to /users API endpoint for a new user.",
            "System should respond accordingly.");

        var     userRequest = new AddUserRequest(true);
        var payload     = JsonConvert.SerializeObject(userRequest);
        Steps.AddTestStep($"Sending 'POST' request to New/users API endpoint with the following payload: '{payload}'.",
            $"Systems should respond with a status code: '{OkResponse}'.");

        var response = PostNewUser(payload);
        if (HPGWarn.AreEqual(OkResponse, response.Status, field: ResponseStatusField))
        {
            HPGWarn.AreEqual("true", response.Response, field: ResponseBodyField);
            //validate DB persistence
            var actualUsers = _userRepository.GetAllUsers().First(i => i.Email.Equals(userRequest.Email));
           var expected = new UserResponse()
            {
                Username      = userRequest.UserName,
                FirstName     = userRequest.FirstName,
                LastName      = userRequest.LastName,
                Email         = userRequest.Email,
                Domain        = userRequest.Domain,
                IsDeactivated = (bool)userRequest.IsDeactivated!,
                Type          = userRequest.Type,
                VPROUserEmailId = userRequest.VPROUserEmailId,
             
            };
            HPGWarn.WarnRange(expected.Validate(actualUsers));
        }
    }

    /// <summary>
    /// Test sending 'POST' request to /users API endpoint with bad values.
    /// Manual Estimated Execution Time: 0:06:00
    /// </summary>
    public void TestPostNewUserBadRequest()
    {
        var scenarios = new List<string>()
        {
            "Duplicate User", "Null UserName", "Blank UserName", "Null Domain",
            "Blank Domain", "Null FirstName", "Blank FirstName", "Null LastName", "Blank LastName", "Null Email",
            "Blank Email", "Null Type", "Blank Type", "Non-existent Type", "Null IsDeactivated"
        };

        var testUser = _userRepository.GetAllUsers().Where(i => !i.IsDeactivated && i.Type.Equals("Employee"))
            .PickRandom();

        foreach (var scenario in scenarios)
        {
            var userRequest = new AddUserRequest(true);
            var statusCode  = string.Empty;

            switch (scenario)
            {
                case "Duplicate User":
                    userRequest = new AddUserRequest(testUser);
                    statusCode  = OkResponse;
                    break;
                case "User that is Employee and Vendor":
	                //Removed from scenarios at this time until they come back that is valid otherwise: Remove By EOY
					userRequest = new AddUserRequest(testUser)
                    {
                        Type = "Vendor"
                    };
                    statusCode = OkResponse; 

					break;
                case "Null UserName":
                    userRequest.UserName = null;
                    statusCode           = BadRequestResponse;
                    break;
                case "Blank UserName":
                    userRequest.UserName = string.Empty;
                    statusCode           = BadRequestResponse;
                    break;
                case "Null Domain":
                    userRequest.Domain = null;
                    statusCode         = BadRequestResponse;
                    break;
                case "Blank Domain":
                    userRequest.Domain = string.Empty;
                    statusCode         = BadRequestResponse;
                    break;
                case "Null FirstName":
                    userRequest.FirstName = null;
                    statusCode            = OkResponse;
                    break;
                case "Blank FirstName":
                    userRequest.FirstName = string.Empty;
                    statusCode            = OkResponse;
                    break;
                case "Null LastName":
                    userRequest.LastName = null;
                    statusCode           = OkResponse;
                    break;
                case "Blank LastName":
                    userRequest.LastName = string.Empty;
                    statusCode           = OkResponse;
                    break;
                case "Null Email":
                    userRequest.Email = null;
                    statusCode        = BadRequestResponse;
                    break;
                case "Blank Email":
                    userRequest.Email = string.Empty;
                    statusCode        = BadRequestResponse;
                    break;
                case "Null Type":
                    userRequest.Type = null;
                    statusCode       = BadRequestResponse;
                    break;
                case "Blank Type":
                    userRequest.Type = string.Empty;
                    statusCode       = BadRequestResponse;
                    break;
                case "Non-existent Type":
                    userRequest.Type = "ABC123";
                    statusCode = BadRequestResponse;
                    break;
                case "Null IsDeactivated":
                    userRequest.IsDeactivated = null;
                    statusCode                = BadRequestResponse;
                    break;
            }

            var payload = JsonConvert.SerializeObject(userRequest,
                new JsonSerializerSettings() { NullValueHandling = NullValueHandling.Ignore });
            Steps.AddTestStep(
                $"Sending 'POST' request to /users API endpoint with the following payload: '{payload}' for scenario: '{scenario}'.",
                $"Systems should respond with a status code: '{statusCode}'.");

            var response = PostNewUser(payload); 
            if (HPGWarn.AreEqual(statusCode, response.Status, ResponseStatusField))
            {
                if (!statusCode.Equals(OkResponse)) continue;
                var expected =
                    (scenario.Equals("Duplicate User") || scenario.Equals("User that is Employee and Vendor"))
                        ? testUser
                        : new UserResponse(userRequest);
                var actual = _userRepository.GetAllUsers().FirstOrDefault(i => i.Username.Equals(expected.Username));
                HPGWarn.WarnRange(expected.Validate(actual));
            }
        }
    }

    /// <summary>
    /// Test sending 'POST' request to /users/claims API endpoint to deactivate a user.
    /// Manual Estimated Execution Time: 0:02:00
    /// </summary>
    public void TestPostDeactivateActivateUser()
    {
        Steps.AddTestStep("Test sending 'POST' request to /users/claims API endpoint to deactivate a user.",
            "System should allow user to be deactivated.");

        var scenarios = new List<string>() { "Employee", "Vendor" };

        //create user based on scenario
        foreach (var scenario in scenarios)
        {
            Steps.AddTestStep($"Create new user of type: '{scenario}' with roles and span of control.",
                "Should be able to create new user.");

            var newUser        = AddNewUser(scenario);
            var newUserRoleSoc = SetupUserForRemovalTest(newUser!);    //<< issue is with this method. Need to fix request body

            newUserRoleSoc.IsDeactivated = true;

            var payload  = JsonConvert.SerializeObject(newUserRoleSoc, JsonNullSetting);
            var response = PostUserClaim(payload);

            //validate user deactivation
            if (HPGWarn.AreEqual(OkResponse, response.Status, ResponseStatusField))
            {
                var actual = _userRepository.GetAllUsers(2).FirstOrDefault(i => i.Username.Equals(newUser!.Username));
                HPGWarn.True(actual.IsDeactivated, field: "IsDeactivated");
                //if user type is vendor then check SupplierPortalTransferLog table for entry
                if (newUser.Type.Equals("Vendor"))
                {
                    var supplierLogs = _userRepository.GetUserSupplierPortalTransferLogs(newUser.Email)
                        .Where(i => i.CreatedOn >= response.SentDateTime);

                    
                    //todo: how do you want to validate this????
                }
            }
        }
    }

    /// <summary>
    /// Test sending 'POST' request to /users/claims API endpoint with the entire Role, Span of Control, and Vendor Affiliation.
    /// </summary>
    public void TestPostUserEntireRoleSocVendorAffiliation()
    {
        Steps.AddTestStep(
            "Test sending 'POST' request to /users/claims API endpoint with the entire Role, Span of Control, and Vendor Affiliation.",
            "System should respond accordingly.");

        var scenarios = new List<string>() { "Employee", "Vendor" };

        //create user based on scenario
        foreach (var scenario in scenarios)
        {
            var            newUser = AddNewUser(scenario);
            AddUserRoleSoc userRequest;
            switch (scenario)
            {
                case "Vendor":
                    userRequest = CreateUserRequest(newUser, 1, 1, 1);
                    break;
                default:
                    userRequest = CreateUserRequest(newUser, 1, 1, 0);
                    break;
            }
        }
    }

	/// <summary>
	/// Tests the assignment and unassignment of GCN groups for users via the /users/claims API endpoint.
	/// This method runs multiple scenarios to validate Smart Security and Admin user role assignments,
	/// GCN group selection, and error handling for bad requests. It builds and posts various
	/// AddUserRoleSoc payloads for service accounts, checking both successful and failed responses.
	/// Todo: This is version one.. need to go back and pull test user accounts from a file or db - 29Sept25
	/// </summary>
	public void TestPostUserClaimsGcnGroupAssignAndUnassign()
	{
		Steps.AddTestStep("Testing TestPostUserClaimsGcnGroupAssignAndUnassign()", "System should respond accordingly.");

		var scenarios = new List<string>
		{"SSecurityAssignGnc", "SSecurityUnassignGnc", "BadRequest", "SAdminAssignGnc", "SAdminUnassignGnc" };

		const string sSecurityApp = "E68AB150-F05F-49BF-8C91-5EC4494FFD4C";
		const string sAdminApp = "0D60E28B-1A90-45B3-982F-ADA2FB175505";
		List<string> sSecurityAdminRole = new List<string>() { "5BA8B90F-E086-46F2-9903-0EAA893FD674" };
		List<string> sAdminFacilityRole = new List<string>() { "6B66774A-A0E5-460C-A76D-95D233D4BE07" };
		AddUserRoleSoc userRoleSoc = new AddUserRoleSoc();
        //todo: get service account from file instead of hardcode username
        var SecurityUsers = _userRepository.GetUserInfo("HTNASVCTSTAUT53");
        var AdminUser = _userRepository.GetUserInfo("HTNASVCTSTAUT54");
		foreach (var testCase in scenarios)
		{
            var expectedResponse = OkResponse;
            var expectedResponseBody = "true";
			switch (testCase)
            { 
			case "SSecurityAssignGnc": 
                    userRoleSoc.UserId = SecurityUsers.UserKey.ToString();  
					userRoleSoc.ApplicationId = sSecurityApp;
					userRoleSoc.IsDeactivated = false;
					userRoleSoc.RoleIds = [.. sSecurityAdminRole];
					userRoleSoc.Roles = new List<RoleDetail>
			        {
				        new() { Id = "5BA8B90F-E086-46F2-9903-0EAA893FD674",
						        Name = "Security - Administrator",
						        IsDeleted = false,
						        UserType = "Employee" }
			        };
					userRoleSoc.SpanOfControl = new List<Users.SpanOfControl>
			        {
				        new()
				        {   HierarchyType = "0",
					        ObjectId = "00001",
					        OrgName = "HealthTrust",
					        IsDeleted = false,
					        CreatedOn = DateTime.Now,
					        IsVproFacility = false,
					        VproFacilityName = string.Empty,
					        VproFacilityCoid = string.Empty
				        }
			        };
					userRoleSoc.VproStatus = null;
					userRoleSoc.ByPassVPROEndDate = null;
					userRoleSoc.VPROUserEmailId = null;
                    userRoleSoc.IsSmartSecurity = true;
                    userRoleSoc.UserGcnGroups = new List<UserGcnGroup>() {
						new()
						{
							GroupId = 5,
							GroupName = "AP",
							IsSelected = false
						} };
 					break;
			case "SSecurityUnassignGnc":
					// TODO: Implement logic for Security Unassign GNC
					userRoleSoc.UserId = SecurityUsers.UserKey.ToString();
					userRoleSoc.ApplicationId = sSecurityApp;
					userRoleSoc.IsDeactivated = false;
					userRoleSoc.RoleIds = [.. sSecurityAdminRole];
					userRoleSoc.Roles = new List<RoleDetail>
					{
						new() { Id = "5BA8B90F-E086-46F2-9903-0EAA893FD674",
								Name = "Security - Administrator",
								IsDeleted = false,
								UserType = "Employee" }
					};
					userRoleSoc.SpanOfControl = new List<Users.SpanOfControl>
					{
						new()
						{   HierarchyType = "0",
							ObjectId = "00001",
							OrgName = "HealthTrust",
							IsDeleted = false,
							CreatedOn = DateTime.Now,
							IsVproFacility = false,
							VproFacilityName = string.Empty,
							VproFacilityCoid = string.Empty
						}
					};
					userRoleSoc.VproStatus = null;
					userRoleSoc.ByPassVPROEndDate = null;
					userRoleSoc.VPROUserEmailId = null;
					userRoleSoc.IsSmartSecurity = true;
					userRoleSoc.UserGcnGroups = new List<UserGcnGroup>() {
						new()
						{
							GroupId = 5,
							GroupName = "AP",
							IsSelected = true
						} };
					break;
			case "BadRequest":
                    // TODO: Implement logic for BadRequest scenario
                    expectedResponse = BadRequestResponse; //NotAuthorizedResponse;
					expectedResponseBody = "Bad Request";
					userRoleSoc.UserId = null;
					userRoleSoc.ApplicationId = sSecurityAdminRole[0].ToString();
					userRoleSoc.IsDeactivated = SecurityUsers.IsDeactivated;
					userRoleSoc.RoleIds = [.. sSecurityAdminRole];
					userRoleSoc.Roles = new List<RoleDetail>
					{
						new() { Id = "5BA8B90F-E086-46F2-9903-0EAA893FD674",
								Name = "Security - Administrator",
								IsDeleted = false,
								UserType = "Employee" }
					};
					userRoleSoc.SpanOfControl = new List<Users.SpanOfControl>
					{
						new()
						{   HierarchyType = "0",
							ObjectId = "00001",
							OrgName = "HealthTrust",
							IsDeleted = false,
							CreatedOn = DateTime.Now,
							IsVproFacility = false,
							VproFacilityName = string.Empty,
							VproFacilityCoid = string.Empty
						}
					};
					userRoleSoc.VproStatus = null;
					userRoleSoc.ByPassVPROEndDate = null;
					userRoleSoc.VPROUserEmailId = null;
					userRoleSoc.IsSmartSecurity = false;
					userRoleSoc.UserGcnGroups = new List<UserGcnGroup>() {
						new()
						{
							GroupId = 10,
							GroupName = "ABCD",
							IsSelected = true
						} };
					break;
			case "SAdminAssignGnc":
					// TODO: Implement logic for Admin Assign GNC
					userRoleSoc.UserId = AdminUser.UserKey.ToString();
					userRoleSoc.ApplicationId = sAdminApp;
					userRoleSoc.IsDeactivated = false;
					userRoleSoc.RoleIds = [.. sAdminFacilityRole];
					userRoleSoc.Roles = new List<RoleDetail>
					{
						new() { Id = sAdminFacilityRole[0],
								Name = "ADMIN - Facility",
								IsDeleted = false,
								UserType = "Employee" }
					};
					userRoleSoc.SpanOfControl = new List<Users.SpanOfControl>
					{
						new()
						{   HierarchyType = "0",
							ObjectId = "00001",
							OrgName = "HealthTrust",
							IsDeleted = false,
							CreatedOn = DateTime.Now,
							IsVproFacility = false,
							VproFacilityName = string.Empty,
							VproFacilityCoid = string.Empty
						}
					};
					userRoleSoc.VproStatus = null;
					userRoleSoc.ByPassVPROEndDate = null;
					userRoleSoc.VPROUserEmailId = null;
					userRoleSoc.IsSmartSecurity = true;
					userRoleSoc.UserGcnGroups = new List<UserGcnGroup>() {
						new()
						{
							GroupId = 5,
							GroupName = "AP",
							IsSelected = false
						} };
					break;
			case "SAdminUnassignGnc":
					// TODO: Implement logic for Admin Unassign GNC
					userRoleSoc.UserId = AdminUser.UserKey.ToString();
					userRoleSoc.ApplicationId = sAdminApp;
					userRoleSoc.IsDeactivated = false;
					userRoleSoc.RoleIds = [.. sAdminFacilityRole];
					userRoleSoc.Roles = new List<RoleDetail>
					{
						new() { Id = sAdminFacilityRole[0],
								Name = "ADMIN - Facility",
								IsDeleted = false,
								UserType = "Employee" }
					};
					userRoleSoc.SpanOfControl = new List<Users.SpanOfControl>
					{
						new()
						{   HierarchyType = "0",
							ObjectId = "00001",
							OrgName = "HealthTrust",
							IsDeleted = false,
							CreatedOn = DateTime.Now,
							IsVproFacility = false,
							VproFacilityName = string.Empty,
							VproFacilityCoid = string.Empty
						}
					};
					userRoleSoc.VproStatus = null;
					userRoleSoc.ByPassVPROEndDate = null;
					userRoleSoc.VPROUserEmailId = null;
					userRoleSoc.IsSmartSecurity = true;
					userRoleSoc.UserGcnGroups = new List<UserGcnGroup>() {
						new()
						{
							GroupId = 5,
							GroupName = "AP",
							IsSelected = true
						} };
					break;
			default: 
				break;            
            }
			var desc = $"Sending GCN Assignment TestCase: {testCase} for User: {userRoleSoc.UserId}.";

			var Payload = JsonConvert.SerializeObject(userRoleSoc, JsonNullSetting);
			var response = PostSimpleRequest($"{BaseUri}{UserResource}{ClaimResource}", Payload);
			Steps.AddTestStep(desc, $"Expecting: {expectedResponse} ; Actual: {response.Status}.");
            if (testCase.Equals("BadRequest"))
            { 
				var json = JObject.Parse(response.Response);
				var titleValue = json["title"]?.ToString();
 				Steps.AddTestStep("Response Body:", $"Expected: {expectedResponseBody} ; Actual: {titleValue}.");
			}
            else
            { 
                Steps.AddTestStep("Response Body:", $"Expected: {expectedResponseBody} ; Actual: {response.Response}.");
            }
			HPGWarn.AreEqual(expectedResponse, response.Status, field: ResponseStatusField);
		}

	}

    public void TestGetUsersSocByApplicationGcn()
    {
        Steps.AddTestStep("Testing TestGetUsersSocByApplicationGcn()", "System should respond accordingly."); 
        var scenarios = new List<string> { "OneGcnGroup", "AllGcnGroups", "BadRequest" };
        const string sSecurityApp = "E68AB150-F05F-49BF-8C91-5EC4494FFD4C";
        const string sAdminApp = "0D60E28B-1A90-45B3-982F-ADA2FB175505";
        List<string> sSecurityAdminRole = new List<string>() { "5BA8B90F-E086-46F2-9903-0EAA893FD674" };
        List<string> sAdminFacilityRole = new List<string>() { "6B66774A-A0E5-460C-A76D-95D233D4BE07" };
        AddUserRoleSoc userRoleSoc = new AddUserRoleSoc();
        //todo: get service account from file instead of hardcode username 
        var SecurityUsers = _userRepository.GetUserInfo("HTNASVCTSTAUT53"); 
		var AdminUser = _userRepository.GetUserInfo("HTNASVCTSTAUT54"); 
		var expectedResponse = OkResponse;
        var expectedResponseBody = "true";
        foreach (var testCase in scenarios)
        {
            switch (testCase)
            {
                case "OneGcnGroup":
                    Steps.AddTestStep($"Test Setup for User: {SecurityUsers.Username} - 1 GCN Group.", "System should respond accordingly.");
                    userRoleSoc.UserId = SecurityUsers.UserKey.ToString();
                    userRoleSoc.ApplicationId = sSecurityApp;
                    userRoleSoc.IsDeactivated = false;
                    userRoleSoc.RoleIds = [.. sSecurityAdminRole];
                    userRoleSoc.Roles = new List<RoleDetail>
                    {
                        new() { Id = "5BA8B90F-E086-46F2-9903-0EAA893FD674",
                                Name = "Security - Administrator",
                                IsDeleted = false,
                                UserType = "Employee" }
                    };
                    userRoleSoc.SpanOfControl = new List<Users.SpanOfControl>
                    {
                        new()
                        {   HierarchyType = "0",
                            ObjectId = "00001",
                            OrgName = "HealthTrust",
                            IsDeleted = false,
                            CreatedOn = DateTime.Now,
                            IsVproFacility = false,
                            VproFacilityName = string.Empty,
                            VproFacilityCoid = string.Empty
                        }
                    };
                    userRoleSoc.VproStatus = null;
                    userRoleSoc.ByPassVPROEndDate = null;
                    userRoleSoc.VPROUserEmailId = null;
                    userRoleSoc.IsSmartSecurity = true;
                    userRoleSoc.UserGcnGroups = new List<UserGcnGroup>() {
                        new()
                        {
                            GroupId = 5,
                            GroupName = "AP",
                            IsSelected = false
                        } };
                    break;
                case "AllGcnGroups":
                    Steps.AddTestStep($"Test Setup for User: {AdminUser.Username} - All GCN Groups.", "System should respond accordingly.");
                    // TODO: Implement logic for Admin Assign GNC
                    userRoleSoc.UserId = AdminUser.UserKey.ToString();
                    userRoleSoc.ApplicationId = sAdminApp;
                    userRoleSoc.IsDeactivated = false;
                    userRoleSoc.RoleIds = [.. sAdminFacilityRole];
                    userRoleSoc.Roles = new List<RoleDetail>
                    {
                        new() { Id = sAdminFacilityRole[0],
                                Name = "ADMIN - Facility",
                                IsDeleted = false,
                                UserType = "Employee" }
                    };
                    userRoleSoc.SpanOfControl = new List<Users.SpanOfControl>
                    {
                        new()
                        {   HierarchyType = "0",
                            ObjectId = "00001",
                            OrgName = "HealthTrust",
                            IsDeleted = false,
                            CreatedOn = DateTime.Now,
                            IsVproFacility = false,
                            VproFacilityName = string.Empty,
                            VproFacilityCoid = string.Empty
                        }
                    };
                    userRoleSoc.VproStatus = null;
                    userRoleSoc.ByPassVPROEndDate = null;
                    userRoleSoc.VPROUserEmailId = null;
                    userRoleSoc.IsSmartSecurity = true;
                    userRoleSoc.UserGcnGroups = new List<UserGcnGroup>() {
                        new()
                        {
                            GroupId = 1,
                            GroupName = "Purchasing",
                            IsSelected = true },
                        new()
                        {
                            GroupId = 2,
                            GroupName = "Hospital",
                            IsSelected = true },
                        new()
                        {
                            GroupId = 3,
                            GroupName = "Internal Control",
                            IsSelected = true },
                        new()
                        {
                            GroupId = 4,
                            GroupName = "Customer Service",
                            IsSelected = true },
                        new()
                        {
                            GroupId = 5,
                            GroupName = "AP",
                            IsSelected = true },
                        };
                    break;
                case "BadRequest":
                    Steps.AddTestStep($"Test Setup for User: NULL Value - Bad Request.", "System should respond accordingly.");
                    expectedResponse = BadRequestResponse; //NotAuthorizedResponse;
                    expectedResponseBody = "Bad Request";
                    userRoleSoc.UserId = null;
                    userRoleSoc.ApplicationId = sSecurityAdminRole[0].ToString();
                    userRoleSoc.IsDeactivated = SecurityUsers.IsDeactivated;
                    userRoleSoc.RoleIds = [.. sSecurityAdminRole];
                    userRoleSoc.Roles = new List<RoleDetail>
                    {
                        new() { Id = "5BA8B90F-E086-46F2-9903-0EAA893FD674",
                                Name = "Security - Administrator",
                                IsDeleted = false,
                                UserType = "Employee" }
                    };
                    userRoleSoc.SpanOfControl = new List<Users.SpanOfControl>
                    {
                        new()
                        {   HierarchyType = "0",
                            ObjectId = "00001",
                            OrgName = "HealthTrust",
                            IsDeleted = false,
                            CreatedOn = DateTime.Now,
                            IsVproFacility = false,
                            VproFacilityName = string.Empty,
                            VproFacilityCoid = string.Empty
                        }
                    };
                    userRoleSoc.VproStatus = null;
                    userRoleSoc.ByPassVPROEndDate = null;
                    userRoleSoc.VPROUserEmailId = null;
                    userRoleSoc.IsSmartSecurity = false;
                    userRoleSoc.UserGcnGroups = new List<UserGcnGroup>() {
                        new()
                        {
                            GroupId = 10,
                            GroupName = "ABCD",
                            IsSelected = true
                        } };
                    break;
                default:
                    break;
            }
            var desc = $"Sending GCN Assignment for TestCase: {testCase} for User: {userRoleSoc.UserId}.";

            var Payload = JsonConvert.SerializeObject(userRoleSoc, JsonNullSetting);
            var response = PostSimpleRequest($"{BaseUri}{UserResource}{ClaimResource}", Payload);
            Steps.AddTestStep(desc, $"Expecting: {expectedResponse} ; Actual: {response.Status}.");
            if (testCase.Equals("BadRequest"))
            {
                var json = JObject.Parse(response.Response);
                var titleValue = json["title"]?.ToString();
                Steps.AddTestStep("Response Body:", $"Expected: {expectedResponseBody} ; Actual: {titleValue}.");
            }
            else
            {
                //200OK
                Steps.AddTestStep("Response Body:", $"Expected: {expectedResponseBody} ; Actual: {response.Response}.");
                HPGWarn.AreEqual(expectedResponse, response.Status, field: ResponseStatusField);
                //Now Get the SoC for the user and validate
                Steps.AddTestStep($"Sending 'GET' to /users/{userRoleSoc.UserId}/applications/{userRoleSoc.ApplicationId}/soc API endpoint.",
                "System should respond with (200) OK.");
                var responseGetSoc = GetUserSocByApplication(userRoleSoc.UserId, userRoleSoc.ApplicationId);

                if (HPGWarn.AreEqual(OkResponse, responseGetSoc.Status, field: "Response Status Code"))
                {
                    var actualList = JsonConvert.DeserializeObject<SpanOfControlViewModel>(responseGetSoc.Response);
					//We have an issue with the expected list. Home services are not update like in prod so we have zombie coids
					//listed in security meaning: they are lingering in SoC table assigned but coid has been divested.
					//var expectedList = HomeService.GetExpectedHierarchyList(userRoleSoc.UserId, _homeInfoDataDb, false);
					//todo: need to fix expected list generation 
					SpanOfControl.ValidateOrgTreeList(actualList!.Soc, actualList!.Soc);
                }


            }
        }
	}

	public void TestGetLoggedInUserRoles()
	{ 
		Steps.AddTestStep("Testing TestGetLoggedInUserRoles()", "System should respond accordingly.");

		// Scenario 1: OtherSecurity Role
		Steps.AddTestStep("Scenario 1: OtherSecurity Role - Sending 'GET' to /users/loggedinuserroles API endpoint.", "System should respond with (200) OK.");
		var response = GetLoggedInUserRoles();
		HPGWarn.AreEqual(OkResponse, response.Status, field: ResponseStatusField);

		var result = JsonConvert.DeserializeObject<LoggedInUserRolesResponse>(response.Response);
		Steps.AddTestStep("Scenario 1: Parsed Response Body", $"Response: {response.Response}");

		if (result is not null && result.isSecurityAdmin && !result.isVBOSupportReadOnly)
		{
			ConsoleOut.WriteReport("Scenario 1: isSecurityAdmin == true & isVBOSupportReadOnly == false as expected.");
			HPGWarn.AreEqual("true", result.isSecurityAdmin.ToString(), field: "isSecurityAdmin");
			HPGWarn.AreEqual("false", result.isVBOSupportReadOnly.ToString(), field: "isVBOSupportReadOnly");
		}
		else
		{
			HPGWarn.Warn("Scenario 1: Unexpected values. isSecurityAdmin: " + (result?.isSecurityAdmin) + ", isVBOSupportReadOnly: " + (result?.isVBOSupportReadOnly));
		}
        //This method is setup for Employee Only. Next sprint...mode for Vendor as well
        //todo: var userName = Need to get "HTNASVCTSTAUT51"from global variables to this var
        //todo: update this method ExecuteUserClaims to get userKey, appKey, roleKey from db 
        //todo: Scenario 2 is ready to go need to update test account and assign read only role
        /*var claimsResponse = ExecuteUserClaims(	userName: "jdoe", userKey: "A1B2C3D4-E5F6-7890-1234-56789ABCDEF0", 	appName: "SMART - Procurement",
	        appKey: "0D60E28B-1A90-45B3-982F-ADA2FB175505", 	roleName: "Procurement - Vendor Bill Only",	roleKey: "5BA8B90F-E086-46F2-9903-0EAA893FD674",assign: true);

		// Scenario 2: SecurityReadOnlyRole
		Steps.AddTestStep("Scenario 2: SecurityReadOnlyRole - Sending 'GET' to /users/loggedinuserroles API endpoint.", "System should respond with (200) OK.");
		var response2 = GetLoggedInUserRoles();
		HPGWarn.AreEqual(OkResponse, response2.Status, field: ResponseStatusField);

		var result2 = JsonConvert.DeserializeObject<LoggedInUserRolesResponse>(response2.Response);
		Steps.AddTestStep("Scenario 2: Parsed Response Body", $"Response: {response2.Response}");

		if (result2 is not null && result2.isSecurityAdmin && result2.isVBOSupportReadOnly)
		{
		    ConsoleOut.WriteReport("Scenario 2: isSecurityAdmin == true & isVBOSupportReadOnly == true as expected.");
		}
		else
		{
		    HPGWarn.Warn("Scenario 2: Unexpected values. isSecurityAdmin: " + (result2?.isSecurityAdmin) + ", isVBOSupportReadOnly: " + (result2?.isVBOSupportReadOnly));
		}
        */
    }


    #endregion Test Methods

    #region Validations Methods

    private void ValidateUserList(List<UserResponse> expectedList, List<UserResponse> actualList)
    {
        Steps.AddTestStep("Validating expected list matches actual list.", "Should both match");
        var actDictionary = actualList.ToDictionary(i => i.Id.ToString().ToLower(), j => j);
        foreach (var expected in expectedList)
        {
            if (!actDictionary.TryGetValue(expected.Id.ToString().ToLower(), out var actual))
                HPGWarn.Warn($"Unable to find User ID: {expected.Id} in actual list!");
            else
            {
                HPGWarn.WarnRange(expected.Validate(actual));
            }
        }

        Steps.AddTestStep("Validating actual list matches expected list.", "Should both match");
        var expDictionary = expectedList.ToDictionary(i => i.Id.ToString().ToLower(), j => j);
        foreach (var actual in actualList)
        {
            if (!expDictionary.TryGetValue(actual.Id.ToString().ToLower(), out var expected))
                HPGWarn.Warn($"Unable to find User ID: {actual.Id} in expected list!");
            else
            {
                HPGWarn.WarnRange(actual.Validate(expected));
            }
        }
    }

    public static void ValidateVendorAffiliationDbList(List<UserVendorAffiliationDb> expectedList,
        List<UserVendorAffiliationDb> actualList)
    {
        Steps.AddTestStep("Validating expected list matches actual list.", "Should both match");
        var actualDictionary = actualList.ToDictionary(i => i.VendorId, j => j);
        foreach (var expected in expectedList)
        {
            if (!actualDictionary.TryGetValue(expected.VendorId, out var actual))
                HPGWarn.Warn(
                    $"Unable to find VendorId: '{expected.VendorId}' in actual list!");
            else
            {
                HPGWarn.WarnRange(expected.Validate(actual));
            }
        }


        Steps.AddTestStep("Validating actual list matches expected list.", "Should both match");
        var expectedDictionary = expectedList.ToDictionary(i => i.VendorId, j => j);
        foreach (var actual in actualList)
        {
            if (!expectedDictionary.TryGetValue(actual.VendorId, out var expected))
                HPGWarn.Warn(
                    $"Unable to find VendorId: '{actual.VendorId}' in expected list!");
            else
            {
                HPGWarn.WarnRange(actual.Validate(expected));
            }
        }
    }

    private void ValidateUserSpanOfControlList(List<UserSocDb> expectedList, List<UserSocDb> actualList)
    {
        Steps.AddTestStep("Validating expected list matches actual list.", "Should both match");
        var actualDictionary = actualList.ToDictionary(i => new { i.ApplicationId, i.OrgObjectID }, j => j);

        //todo: Investigating Vendor Deactivate / Reactivate failure. Actual has more values returned then Expected...why? - Marlon
        //var testActual = actualDictionary;
        //var test2Actual = actualDictionary;

		foreach (var expected in expectedList)
        {
            if (!actualDictionary.TryGetValue(new { expected.ApplicationId, expected.OrgObjectID }, out var actual))
                HPGWarn.Warn(
                    $"Expecting ApplicationId: '{expected.ApplicationId}', ObjectId: '{expected.OrgObjectID}' for UserId: '{expected.UserId}' but was not in Actual!");
            else
            {
                HPGWarn.WarnRange(expected.Validate(actual));
            }
        }

        Steps.AddTestStep("Validating actual list matches expected list.", "Should both match");
        var expectedDictionary = expectedList.ToDictionary(i => new { i.ApplicationId, i.OrgObjectID }, j => j);
        foreach (var actual in actualList)
        {
            if (!expectedDictionary.TryGetValue(new { actual.ApplicationId, actual.OrgObjectID }, out var expected))
                HPGWarn.Warn(
                    $"Expecting ApplicationId: '{actual.ApplicationId}', ObjectId: '{actual.OrgObjectID}' for UserId: '{actual.UserId}' but was not in Actual!");
            else
            {
                HPGWarn.WarnRange(actual.Validate(expected));
            }
        }
    }

    private void ValidateUserRoleList(List<UserRoleDb> expectedRoles, List<UserRoleDb> actualRoles)
    {
        Steps.AddTestStep("Validating Expected roles are in Actual", "Actual should match Expected List.");
        var actualRoleDictionary = actualRoles.ToDictionary(i => i.Id, j => j);
        foreach (var expected in expectedRoles)
        {
            if (!actualRoleDictionary.TryGetValue(expected.Id, out var actual))
                HPGWarn.Warn($"Unable to find Role ID: {expected.Id} in actual list!");
            else
            {
                HPGWarn.WarnRange(expected.Validate(actual));
            }
        }

        Steps.AddTestStep("Validating Expected roles are in Actual", "Actual should match Expected List.");
        var expectedRoleDictionary = expectedRoles.ToDictionary(i => i.Id, j => j);
        foreach (var actual in actualRoles)
        {
            if (!expectedRoleDictionary.TryGetValue(actual.Id, out var expected))
                HPGWarn.Warn($"Unable to find Role ID: {actual.Id} in actual list!");
            else
            {
                HPGWarn.WarnRange(actual.Validate(expected));
            }
        }
    }

	#endregion Validations Methods

	#region Helpers
	/// <summary>
	/// Executes the /users/claims API endpoint for a given user and role assignment.
	/// </summary>
	/// <param name="userName">The username of the user.</param>
	/// <param name="userKey">The GUID key of the user.</param>
	/// <param name="appName">The name of the application.</param>
	/// <param name="appKey">The GUID key of the application.</param>
	/// <param name="roleName">The name of the role.</param>
	/// <param name="roleKey">The GUID key of the role.</param>
	/// <param name="assignRole">True to assign the role, false to unassign.</param>
	/// <returns>HttpResponse from the claims API call.</returns>
	public static HttpResponse ExecuteUserClaims(string userName, string userKey, string appName, string appKey, string roleName, string roleKey, bool assign = true, bool assignGcn = false)
	{
		var request = new AddUserRoleSoc
		{
            UserId = userKey,
            ApplicationId = appKey,
            IsDeactivated = !assign,
            RoleIds = assign ? new List<string?> { roleKey } : new List<string?>(),
            Roles = new List<RoleDetail>
            {
            new RoleDetail
                {
                Id = roleKey,
                Name = roleName,
                IsDeleted = !assign,
                UserType = "Employee"
                }
            },
            //include span of control here
            SpanOfControl = new List<SpanOfControl>
            {
            new SpanOfControl
                {
                HierarchyType = "0",
                ObjectId = "00001",
                OrgName = "HealthTrust",
                IsDeleted = !assign,
                IsVproFacility = null,
                VproFacilityName = null,
                VproFacilityCoid = null
                }
            },
			VproStatus = null,
			ByPassVPROEndDate = null,
			VPROUserEmailId = null,
			IsSmartSecurity = true,
			UserGcnGroups = new List<UserGcnGroup>()
            {
                new UserGcnGroup
                {
                    GroupId = 0,
                    GroupName = null,
                    IsSelected = assignGcn
                }
            },

        };

		var payload = JsonConvert.SerializeObject(request, JsonNullSetting);
		//return PostUserClaim(payload);
		return PostSimpleRequest($"{BaseUri}{UserResource}{ClaimResource}", payload);

	}


	/// <summary>
	/// Removes all application roles, SOC, and Vendor Affiliation for the specified user.
	/// </summary>
	/// <param name="userId">The ID of a user on the User table.</param>
	public void ResetUser(string userId)
    {
        Steps.AddTestStep($"Removing all roles, SOC, and Vendor Affiliation for user: '{userId}'.",
            "Should be able to reset user.");

        var appIdList = _applicationRepository.GetApplicationsDb().Where(i => !i.IsDeleted && i.IsEnabled)
            .Select(appId => appId.ApiKey).ToList();

        //note: May need to think about removing specific areas.
        foreach (var appId in appIdList)
        {
            var request = new AddUserRoleSoc()
            {
                UserId            = userId,
                ApplicationId     = appId.ToString(),
                IsDeactivated     = false,
                RoleIds           = new List<string>(),
                VendorAffiliation = new List<VendorModel>(),
                SpanOfControl     = new List<SpanOfControl>(),
				IsSmartSecurity = true,
				//todo: need to update signature to bring in the vpro details into this method.
				//Missing vprostatus, vproEmailId
			};

            var payload  = JsonConvert.SerializeObject(request);
            var response = PostUserClaim(payload);
            if (!response.Status.Contains(OkResponse))
                HPGAssert.Fail(
                    $"Unable to Reset User ID: '{userId}'! Please check if user exist in User Table.\r\nError: {response.Status} -  {response.Response}.\r\nPayload: {payload}");
        }

        ConsoleOut.WriteReport($"Awaiting saves for reset user.....");
        Thread.Sleep(1000);
        ConsoleOut.WriteReport($"Successfully reset User ID: '{userId}'.");
    }

    public AddUserRoleSoc CreateUserRequest(UserResponse userInfo, int howManyRoles, int howManySpoc, int howManyVendors = 0)
    {
		//pick application based on user type
        var appRoles = _applicationRepository
            .GetApplicationRolesByUserTypeDbs(
                !userInfo.Type.Equals("Vendor", StringComparison.CurrentCultureIgnoreCase))
            .Where(i => i.IsEnabled)
            .GroupBy(grp => grp.ApplicationId)
            .ToDictionary(gp => gp.Key, j => j.ToList()).PickRandom();

        //pick roles
        var applicationId = appRoles.Key;
        var roles         = appRoles.Value.PickRandomList(howManyRoles).Distinct().ToList();
        
		//Load up the list of Roles
		List<RoleDetail> rolesAssigned = new List<RoleDetail>();
        foreach (var role in roles)
		{
			RoleDetail roleDetail = new RoleDetail();
			roleDetail.Id = role.Id.ToString();
			roleDetail.Name = role.Name;
			roleDetail.IsDeleted = false;
			rolesAssigned.Add(roleDetail);
		}

        //pick span of control
		var homeActive = _homeInfoDataDb.Where(i =>
            i.IsActive && i.CompanyId.ToStringOrEmpty().Equals("1") && i.COID.ToStringOrEmpty() != string.Empty);
        var randomHome = homeActive.PickRandomList(howManySpoc);

        var appRoleRequest = new AddUserRoleSoc()
        {
            UserId        = userInfo.Id.ToString(),
            IsDeactivated = false,
            ApplicationId = applicationId.ToString(),
            RoleIds       = roles.Select(i => i.Id.ToString()).ToList(),
            Roles         = rolesAssigned,
            SpanOfControl = randomHome.Select(i => new SpanOfControl
                { HierarchyType = "5", ObjectId = i.COID, OrgName = i.Name }).ToList(),
            VproStatus = string.Empty,
            ByPassVPROEndDate = null
        };

		//if User is a vendor then pick vendor affiliations not return User request
		if (!userInfo.Type.Equals("Vendor", StringComparison.CurrentCultureIgnoreCase)) return appRoleRequest;

        var vendors = _vendorRepository.GetVendorInfo().Where(i => i.IsActive).PickRandomList(howManyVendors)
            .Select(j => new VendorModel { Id = j.Snv, Name = j.Name }).ToList();
        appRoleRequest.VendorAffiliation = vendors;

        return appRoleRequest;
    }

    /// <summary>
    /// Sets up a specified user to have roles, soc, and if user is of type vendor then vendor affiliation.
    /// </summary>
    /// <param name="userInfo">User to setup</param>
    public AddUserRoleSoc SetupUserForRemovalTest(UserResponse userInfo)    //check and see if new Roles Object is listed 
    {
        ResetUser(userInfo.Id.ToString());
        Steps.AddTestStep(
            $"Setting up test user:'{userInfo.Username}' with roles, span of control, and vendor affiliation(if user is of type vendor) in Smart Security.",
            "User should be allowed to set test user up for the scenario.");
        var appRoleRequest = CreateUserRequest(userInfo, 3, 3, 3);

        var appRolesDictionary = _applicationRepository
            .GetApplicationRolesByUserTypeDbs(!userInfo.Type.Equals("Vendor", StringComparison.CurrentCultureIgnoreCase))
            .Where(i => i.IsEnabled && i.ApplicationId.ToString().Equals(appRoleRequest.ApplicationId))
            .ToDictionary(i => i.Id, j => j.Name);


        //Get Expected Roles
        var expectedRoles = appRoleRequest.RoleIds.Distinct().Select(i => new UserRoleDb()
            {
                ApplicationId = new Guid(appRoleRequest.ApplicationId!),
                UserId        = userInfo.Id,
                Id            = new Guid(i),
                Name          = appRolesDictionary[new Guid(i)],
                IsDeleted     = false
            })
            .ToList();

        //Get Expected SPOC
        var expectedSOCList = appRoleRequest.SpanOfControl.Select(i => new UserSocDb()
        {
            UserId        = userInfo.Id,
            ApplicationId = new Guid(appRoleRequest.ApplicationId!),
            Hierarchy     = i.HierarchyType.ToInt(),
            OrgObjectID   = i.ObjectId.TrimStart(),
            IsDeleted     = false
        }).ToList();

        //if User is a vendor then get expected vendor affiliations
        List<UserVendorAffiliationDb> expectedVendorAffiliation = null;
        if (userInfo.Type.Equals("Vendor", StringComparison.CurrentCultureIgnoreCase))
        {
            expectedVendorAffiliation = appRoleRequest.VendorAffiliation.Select(i => new UserVendorAffiliationDb()
            {
                UserId    = userInfo.Id,
                VendorId  = i.Id.ToInt(),
                IsDeleted = false
            }).ToList();
        }


        //post request
        var payload  = JsonConvert.SerializeObject(appRoleRequest, JsonNullSetting);
        var response = PostUserClaim(payload);

        //validate << error coming here
        if (response.Status.Equals(OkResponse))
        {
            //Validate Roles
            Steps.AddTestStep("Validate Roles", "Should match role(s) that was posted.");
            var actualRoles = _userRepository.GetAllUserRoleDb(userId: userInfo.Id.ToString(), timeToWait: 5)
                .Where(i => !i.IsDeleted).ToList();
            ValidateUserRoleList(expectedRoles, actualRoles);

            //validate SOC
            Steps.AddTestStep("Validate Span of Control", "Should match Span of Control that was posted.");
            var actualSoc = _userRepository.GetAllUserSocDb(userId: userInfo.Id).Where(i => !i.IsDeleted).ToList();
            ValidateUserSpanOfControlList(expectedSOCList, actualSoc); //<< Research cont.

            //Validate Vendor Affiliation if user type is Vendor.
            if (userInfo.Type.Equals("Vendor"))
            {
                Steps.AddTestStep("Validate Vendor Affiliation.", "Should match Vendor Affiliation that was posted.");
                var actualVendorAffiliation = _userRepository.GetUserVendorAffiliationDb(userInfo.Id)
                    .Where(i => !i.IsDeleted).ToList();
                ValidateVendorAffiliationDbList(expectedVendorAffiliation, actualVendorAffiliation);
            }
        }
        else
        {
            HPGAssert.Fail(
                $"Unable to setup test user: '{userInfo.Username}'!\r\n{response.Status} - {response.Response}");
        }

        ConsoleOut.WriteReport($"User setup was successful!");

        return appRoleRequest;
    }

    /// <summary>
    /// Creates a new Test User for a certain type of user.
    /// </summary>
    /// <param name="userType">Can be the following: 'Employee','Vendor', or 'Member'</param>
    /// <returns></returns>
    public UserResponse? AddNewUser(string userType = "Employee")
    {
        var userRequest = new AddUserRequest(true) { Type = userType };

        if (userType.Equals("Vendor"))
        {
            userRequest.UserName = userRequest.Email;
            userRequest.Domain   = "nonaffilTest";
            userRequest.VPROUserEmailId = userRequest.Email;
            userRequest.VproStatus = "VPRO Not Found";
            userRequest.ByPassVPROEndDate = DateTime.UtcNow.AddDays(30);
		}

        Steps.AddTestStep($"Creating new user of type: {userRequest.Type}.", 
	        $"Should be allowed to create new user:{userRequest.UserName}, {userRequest.Domain}");
        return CreateUser(userRequest);
    }

    private UserResponse? CreateUser(AddUserRequest userRequest)
    {
        var payload = JsonConvert.SerializeObject(userRequest);

        var response = PostNewUser(payload);
        if (!HPGWarn.AreEqual(OkResponse, response.Status, field: ResponseStatusField)) return null;

        HPGWarn.AreEqual("true", response.Response, field: ResponseBodyField);
        
        //validate DB persistence
        var actualUsers = _userRepository.GetAllUsers(2).First(i => i.Email.Equals(userRequest.Email));
        var expected = new UserResponse()
        {
            Username      = userRequest.UserName,
            FirstName     = userRequest.FirstName,
            LastName      = userRequest.LastName,
            Email         = userRequest.Email,
            Domain        = userRequest.Domain,
            IsDeactivated = (bool)userRequest.IsDeactivated!,
            Type          = userRequest.Type
        };
        actualUsers.Username = expected.Username;//Flow has changed. After Vendor is created Supplier Portal issues a new guid value for the username
		HPGWarn.WarnRange(expected.Validate(actualUsers));
        ConsoleOut.WriteReport(
            $"Created new user. UserName: '{actualUsers.Username}' and UserId: '{actualUsers.Id}'.");

        return actualUsers;
    }

    /// <summary>
    /// Checks and if needed, setups the test security test user
    /// </summary>
    /// <param name="user"></param>
    /// <returns></returns>
    public AddUserRoleSoc SetupSecurityUser(SecurityUser user)
    {
        //Check and validate if specified security user info is correct. If it is correct then return else create, add roles, and add spoc.
        var securityAppRoles = _applicationRepository.GetApplicationRolesDbs().Where(i =>
            i.ApplicationName.Contains("Security", StringComparison.CurrentCultureIgnoreCase));

        var userInfo = _userRepository.GetUserInfo(user.UserName);
        if (userInfo!.IsNull())
        {
            var createUserRequest = new AddUserRequest()
            {
                UserName      = user.UserName,
                Domain        = user.Domain,
                Email         = user.Email,
                FirstName     = user.FirstName,
                LastName      = user.LastName,
                IsDeactivated = false,
                Type          = "Employee"
            };
            userInfo = CreateUser(createUserRequest);

            return ProvisionUser(user, userInfo, securityAppRoles);
        }

        var specifiedSecurityRole = securityAppRoles.First(i => i.Name.Equals(user.RoleName.FirstOrDefault()));

        var userRoles = _userRepository.GetAllUserRoleDb(userInfo.Id.ToString())
            .Where(i => !i.IsDeleted && i.Name.Equals(user.RoleName.FirstOrDefault()));
        var userSoc = _userRepository.GetAllUserSocDb(userInfo.Id)
            .Where(i => i.ApplicationId.Equals(specifiedSecurityRole.ApplicationId));
        
		bool socMatch = SpanOfControlMatch(user.SpanOfControls, userSoc);

        var roleRequest = new AddUserRoleSoc()
        {
            UserId = userInfo.Id.ToString(),
            ApplicationId = specifiedSecurityRole.ApplicationId.ToString(),
            RoleIds = new List<string?> { specifiedSecurityRole.Id.ToString() },
            SpanOfControl = user.SpanOfControls
                .Select(i => new SpanOfControl() { HierarchyType = i.HierarchyType.ToString(), ObjectId = i.ObjectId, OrgName = i.OrgName }).ToList(),
            IsDeactivated = false
        };

        if (socMatch && userRoles.Any(i => i.Id.Equals(specifiedSecurityRole.Id))) return roleRequest;
        
        var payload  = JsonConvert.SerializeObject(roleRequest, JsonNullSetting);
        var response = PostUserClaim(payload);

        if (!HPGWarn.AreEqual(OkResponse, response.Status, field: ResponseStatusField))
            HPGAssert.Fail($"Unable to assign Security Role and Span of Control for UserName: {user.UserName}\r\nResponse: '{response.Status}' \r\nError Message: '{response.Response}'");

        return roleRequest;
    }

    /// <summary>
    /// Checks to see if the span of control for a security user matches whats in the database.
    /// </summary>
    /// <param name="userExpectedSoc"></param>
    /// <param name="userActualSoc"></param>
    /// <returns></returns>
    private static bool SpanOfControlMatch(IEnumerable<Utilities.SetupTestUsers.SpanOfControl> userExpectedSoc, IEnumerable<UserSocDb> userActualSoc)
    {
        var actualDictionary =
            userActualSoc.Where(i => !i.IsDeleted).ToDictionary(g => new { g.Hierarchy, g.OrgObjectID });

        return userExpectedSoc.All(soc => actualDictionary.ContainsKey(new { Hierarchy = soc.HierarchyType.ToInt(), OrgObjectID = soc.ObjectId }));
    }

    /// <summary>
    /// Provisions a security user.
    /// </summary>
    /// <param name="user"></param>
    /// <param name="userInfo"></param>
    /// <param name="roles"></param>
    /// <returns></returns>
    private static AddUserRoleSoc ProvisionUser(SecurityUser user, UserResponse userInfo, IEnumerable<ApplicationRolesDb> appRoles) //apples
    {
	    var roles = appRoles.Where(i => i.Name.Equals(user.Type))
		    .Select(j => new RoleDetail(){ Id = j.Id.ToString(), Name = j.Name, IsDeleted = false, UserType = user.Type }).ToList();

        var selectedRole = appRoles.FirstOrDefault(i => i.Name.Equals(user.Type));
        var roleSpocRequest = new AddUserRoleSoc()
		{
			UserId = userInfo.Id.ToString(),
			ApplicationId = selectedRole.ApplicationId.ToString(),
			IsDeactivated = false,
			RoleIds = new List<string> { selectedRole.Id.ToString() },
			SpanOfControl = user.SpanOfControls.Select(i => new SpanOfControl()
				{ HierarchyType = i.HierarchyType.ToString(), ObjectId = i.ObjectId, OrgName = i.OrgName }).ToList(),
			Roles = roles
		}; 
	

        var payload  = JsonConvert.SerializeObject(roleSpocRequest, JsonNullSetting);
        var response = PostUserClaim(payload);

        if (!HPGWarn.AreEqual(OkResponse, response.Status, field: ResponseStatusField))
            HPGAssert.Fail($"Unable to assign Security Role and Span of Control for UserName: {user.UserName}\r\nResponse: '{response.Status}' \r\nError Message: '{response.Response}'");

        return roleSpocRequest;
    }

    private List<UserResponse> FilterUsersBasedSecurityUser(SecurityUser sUser)
    {
        string securityUserType = sUser.RoleName.Count > 1 && sUser.RoleName.Contains("Security - Administrator")
            ? "Security - Administrator"
            : sUser.RoleName.FirstOrDefault();

        return securityUserType switch
        {
            "Security - Client Administrator" => _userRepository.GetAllUsers().Where(i => i.Type.Equals("Employee", StringComparison.CurrentCultureIgnoreCase) && i.Domain.Equals(sUser.Domain, StringComparison.OrdinalIgnoreCase)).ToList(),
            "" => _userRepository.GetAllUsers().Where(i => i.Type.Equals("Employee", StringComparison.CurrentCultureIgnoreCase) && i.Domain.Equals(sUser.Domain, StringComparison.OrdinalIgnoreCase)).ToList(),
            _ => _userRepository.GetAllUsers().ToList()
        };
    }

	AddUserRoleSoc BuildUserRoleSoc(string userId,string appId,List<string> roleIds, string roleName, bool assignGcnGroup)
	{
		return new AddUserRoleSoc
		{
			UserId = userId,
			ApplicationId = appId,
			IsDeactivated = false,
			RoleIds = new List<string>(roleIds),
			Roles = new List<RoleDetail>
			{
				new() { Id = roleIds[0], Name = roleName, IsDeleted = false, UserType = "Employee" }
			},
			SpanOfControl = new List<SpanOfControl>
			{
				new() { HierarchyType = "0", ObjectId = "00001", OrgName = "HealthTrust", IsDeleted = false, CreatedOn = DateTime.Now }
			},
			VproStatus = null,
			ByPassVPROEndDate = null,
			VPROUserEmailId = null,
			IsSmartSecurity = true,
			UserGcnGroups = new List<UserGcnGroup>
			{
				new() { GroupId = 5, GroupName = "AP", IsSelected = assignGcnGroup }
			}
		};
	}
}
    #endregion Helpers
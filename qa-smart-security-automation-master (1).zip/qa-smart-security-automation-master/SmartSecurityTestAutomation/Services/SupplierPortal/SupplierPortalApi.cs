﻿using System;
using Newtonsoft.Json.Linq;
using SmartSecurityTestAutomation.Tests;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using Newtonsoft.Json;
using Utilities.HttpUtility;
using SmartSecurityTestAutomation.Services.Users;
using Utilities.ObjectExtensions;
using SmartSecurityTestAutomation.Services.Applications;
using System.DirectoryServices;
using SmartSecurityTestAutomation.Page.Objects.SupplierPortal;
using WebUiAutomation;

namespace SmartSecurityTestAutomation.Services.SupplierPortal;

public class SupplierPortalApi : MasterApi
{
	#region Private Class Variables
	private const string AuthenticationType = "oAuth";
	private const string UserRoleResource = "/user";
	private const string UserSpanOfControl = "/SpanOfControl/user";
	private const string ApplicationRoles = "/roles";
	private const string IdentityUpsertEndPoint = "/upsert";
	private readonly string _supplierPortalToken;
	private readonly string _smartApiKey;
	private readonly string _uri;
	private readonly string _baseUriSupplierPortal;
	private readonly string _accessToken;
	private readonly string _clientId;
	private readonly string _clientSecret;
	 
	//#region Repositories
	/// <summary>
	/// User Repository to get user data from Security Database
	/// </summary>


	private readonly UserRepository _userRepository =
		new(GlobalTestVariables.Configuration["SmartSecurity:DatabaseServer"]!,
			GlobalTestVariables.Configuration["SmartSecurity:DatabaseName"]!);

	#endregion Private Class Variables
	public SupplierPortalApi(string token)
	{
		_uri = GlobalTestVariables.Configuration["SupplierPortal:BaseUri"]!;
		_supplierPortalToken = token;
		_smartApiKey = GlobalTestVariables.Configuration["SupplierPortal:SmartApiKey"]!;
	}
	public SupplierPortalApi()
	{
		_accessToken = $"{GlobalTestVariables.Configuration["SupplierPortal:access_token_url"]}";
		_clientId = $"{GlobalTestVariables.Configuration["SupplierPortal:client_id"]}";
		_clientSecret = $"{GlobalTestVariables.Configuration["SupplierPortal:client_secret"]}";
		_supplierPortalToken = GetSupplierPortalToken();
		_baseUriSupplierPortal = GlobalTestVariables.Configuration["SupplierPortal:BaseUri"];

	}
	#region API Calls

	private HttpResponse GetUserRole(string? email) => _getRequest($"{_uri}{UserRoleResource}/{email}");
	private HttpResponse GetUserSpanOfControl(string? email) => _getRequest($"{_uri}{UserSpanOfControl}/{email}");
	private HttpResponse GetSuppierPortalRoleIds() => _getRequest($"{_uri}{ApplicationRoles}");
	private HttpResponse _getRequest(string request)
	{
		var headers = new Dictionary<string, string>
		{
			{ "Authorization", $"Bearer {_supplierPortalToken}" },
			{ "x-ht-appkey", _smartApiKey }
		};

		var wrc = new WebRequestCall();
		var result = wrc.SendApiRequest(request, RestMethod.Get, headers);
		ConsoleOut.WriteReport($"Response Time: {result.ResponseTime:fff} ms");

		return result;
	}
	//Upsert endpoint is managed by Supplier Portal Not Security
	private HttpResponse PostIdentityUpsert(string? endpoint, string? payload)
	{
		var response = PostSimpleRequest($"{_baseUriSupplierPortal}{IdentityUpsertEndPoint}", payload, AuthenticationType); return response;
	}

	#endregion API Calls

	#region Test Methods 
	/// <summary>
	/// Tests the Supplier Portal Identity Upsert functionality by sending POST requests
	/// with both valid and invalid user data, and validates the responses.
	/// Note: sbx/qasbx/qa all interact with QA identity api/supplier.
	/// User: SMART.vendor1@demo-supplier.com exists in qasbx & qa
	/// </summary>
	public void TestSupplierPortalIdentityUpsert()
	{
		// Add a test step for the Supplier Portal endpoint
		Steps.AddTestStep("Test sending Supplier Portal: " + _baseUriSupplierPortal + IdentityUpsertEndPoint + " Endpoint.", "Api Supplier Portal Endpoint Test.");

		// Create a list to hold the upsert requests
		List<SupplierPortalUpsert> supplierPortalUpsertsRequest = new List<SupplierPortalUpsert>();

		// Create a positive test request
		//SupplierPortalUpsert posRequest = new SupplierPortalUpsert()
		//{
		//	UserId = "gpouserc7381cb871734",
		//	FirstName = "SMART",
		//	LastName = "VENDOR1",
		//	Domain = "nonaffilqa",
		//	Email = "SMART.vendor1@demo-supplier.com"
		//};

		SupplierPortalUpsert posRequest = new SupplierPortalUpsert()
		{
			UserId = "61dde7a3-a742-418d-bb36-0fa133c6a4a0",
			FirstName = "Test",
			LastName = "Marlon1100",
			Domain = "nonaffil",
			Email = "testmarlon1100@gmail.com"
		};
		// Add the positive request to the list
		supplierPortalUpsertsRequest.Add(posRequest);

		// Create a negative test request
		SupplierPortalUpsert negRequest = new SupplierPortalUpsert
		{
			UserId = "05109d60-911e-4f4d-a540-28639602f07eBAD",
			FirstName = "DummyFName",
			LastName = "LName",
			Domain = "nonaffil",
			Email = "DummyFName.LName@MAILINATOR.COM"
		};

		// Add the negative request to the list
		supplierPortalUpsertsRequest.Add(negRequest);

		// Add a test step indicating that test cases are loading
		Steps.AddTestStep("Test Cases Loading.", "- Complete");

		// Iterate through each request in the list
		foreach (var request in supplierPortalUpsertsRequest)
		{
			// Determine the expected response based on the UserId
			var expectedResponse = (!request.UserId.Contains("BAD")) ? OkResponse : InternalServerResponse;

			// Serialize the request payload to JSON
			var payload = JsonConvert.SerializeObject(request);

			// Add a test step for sending the POST request
			Steps.AddTestStep($"Sending 'POST' request to /upsert endpoint with the following payload: " + payload + ".", $"Systems should respond with a status code: '{expectedResponse}'.");

			// Execute the POST call
			var response = PostIdentityUpsert(_baseUriSupplierPortal, payload);

			// Validate the response based on the UserId
			if (!request.UserId.Contains("BAD"))
			{
				// Validate the response status code
				HPGWarn.AreEqual(expectedResponse, OkResponse, field: ResponseBodyField);

				// Deserialize the response to an object
				//todo: Getting - The AppKey is not valid or missing errro..need to verify AppKey is still valid
				//todo: what is value in qasbx? what is value in qa?
				var actual = JsonConvert.DeserializeObject<SupplierPortalUpsert>(response.Response);

				// Validate the response fields
				HPGWarn.AreEqual(request.UserId, actual.UserId, field: "Pass: userId");
				HPGWarn.AreEqual(request.FirstName, actual.FirstName, field: "firstName");
				HPGWarn.AreEqual(request.LastName, actual.LastName, field: "lastName");
				HPGWarn.AreEqual(request.Domain, actual.Domain, field: "domain");
				HPGWarn.AreEqual(request.Email, actual.Email, field: "email");

				// Format and print the response body
				var reply = response.Response.Replace(",", ",\n        ");
				ConsoleOut.WriteReport("COMPLETE Response Body:", true);
				ConsoleOut.WriteReport(reply, true);
				ConsoleOut.WriteReport("\n", true);
			}
			else
			{
				// Validate the response status code for the negative test case
				HPGWarn.AreEqual(expectedResponse, InternalServerResponse, field: ResponseBodyField);
			}
		}
	}
	/// <summary>
	/// Validates the user role in the Supplier Portal for the specified email.
	/// It retrieves the user roles from the Security Database and the Supplier Portal,
	/// then compares them to ensure they match.
	/// </summary>
	#endregion Test Methods

	#region Validations

	#region User Role Validation
	public void ValidateUserRole(string? email)
	{
		Steps.AddTestStep($"Validate in Supplier Portal the User: '{email}' has a role.", "Should match.");
		//get the user roles for the specified email from Security Database
		var userKey = _userRepository.GetAllUsers()
			.FirstOrDefault(i => i.Email.Equals(email, StringComparison.CurrentCultureIgnoreCase));

		//get supplier portal role based on app
		var expectedList = FormatExpectedUserRoleList(userKey);

		//get supplier portal user role for the specified email
		var response = GetUserRole(email);

		//validate response and data
		if (!HPGWarn.AreEqual(OkResponse, response.Status, field: ResponseStatusField)) return;
		var actualList = JsonConvert.DeserializeObject<List<SupplierPortalUserRoles>>(response.Response);

		ValidateSupplierPortalRoleList(expectedList, actualList);
	}

	/// <summary>
	/// Validates that the expected list of SupplierPortalUserRoles matches the actual list.
	/// It checks both that every expected role is in the actual list and that every actual role is in the expected list.
	/// If a role is missing in either list, a warning is logged.
	/// </summary>
	private void ValidateSupplierPortalRoleList(List<SupplierPortalUserRoles> expectedList,
		List<SupplierPortalUserRoles> actualList)
	{
		Steps.AddTestStep("Validating expected list is in actual.", "Expected list should match actual.");
		var actualDictionary = actualList.ToDictionary(i => i.RoleName, j => j);
		foreach (var expected in expectedList)
		{
			if (!actualDictionary.TryGetValue(expected.RoleName, out var actual))
				HPGWarn.Warn($"Unable to find Role Name: '{expected.RoleName}' in actual list!");
			else
			{
				HPGWarn.WarnRange(expected.Validate(actual));
			}
		}

		Steps.AddTestStep("Validating actual list is in expected.", "Actual list should match expected.");
		var expectedDictionary = expectedList.ToDictionary(i => i.RoleName, j => j);
		foreach (var actual in actualList)
		{
			if (!expectedDictionary.TryGetValue(actual.RoleName, out var expected))
				HPGWarn.Warn($"Unable to find Role Name: '{actual.RoleName}' in expected list!");
			else
			{
				HPGWarn.WarnRange(actual.Validate(expected));
			}
		}
	}
	// Validates the user's Span of Control (SPOC) and Vendor Affiliation in the Supplier Portal.
	// It retrieves the expected SPOC and Vendor Affiliation from the Security Database and compares it
	// with the actual data retrieved from the Supplier Portal for the specified email.
	public void ValidateUserSpocAndVendorAffiliation(string? email)
	{
		Steps.AddTestStep(
			$"Validate in Supplier Portal the User: '{email}' has Span of Control for a given application.",
			"Should match");
		//get the user SPOC\Vendor Affiliation for the specified email from Security Database maybe get it from SupplierPortalTransferLog table
		var userKey = _userRepository.GetAllUsers()
			.FirstOrDefault(i => i.Email.Equals(email, StringComparison.CurrentCultureIgnoreCase));
		var expected = FormatExpedctedUserSpocVendorAffiliation(userKey);

		//get supplier portal SPOC\Vendor Affiliation
		var response = GetUserSpanOfControl(email);

		//validate response and data
		if (!HPGWarn.AreEqual(OkResponse, response.Status, field: ResponseStatusField)) return;
		var actual = JsonConvert.DeserializeObject<SupplierPortalUserSpoc>(response.Response);

		ValidateSupplierPortalUserSpoc(expected, actual);
	}

	/// <summary>
	/// Validates the Supplier Portal User Spoc by comparing the expected and actual values.
	/// </summary>
	private void ValidateSupplierPortalUserSpoc(SupplierPortalUserSpoc expected, SupplierPortalUserSpoc actual)
	{
		HPGWarn.AreEqual(expected.Email.ToStringOrEmpty(), actual.Email.ToStringOrEmpty(), field: "Email");
		HPGWarn.AreEqual(expected.AppKey.ToStringOrEmpty(), actual.AppKey.ToStringOrEmpty(), field: "AppKey");

		//Deserialize soc into SupplierSoc
		var expectedSoc = JsonConvert.DeserializeObject<SupplierSoc>(expected.SoC);
		var actualSoc = JsonConvert.DeserializeObject<SupplierSoc>(actual.SoC);

		//validate SPOC list
		Steps.AddTestStep("Validating Org List.", "Should match.");
		ValidateUserSoc(expectedSoc.Orgs, actualSoc.Orgs);

		//validate Vendor Affiliation list
		Steps.AddTestStep("Validating Vendor Affiliation.", "Should match.");
		ValidateUserVendorAffiliation(expectedSoc.Vendors, actualSoc.Vendors);
	}

	/// <summary>
	/// Validates that the expected list of vendors matches the actual list of vendors.
	/// It checks both that all expected vendors are in the actual list and that all actual vendors are in the expected list.
	/// </summary>
	private void ValidateUserVendorAffiliation(List<Vendor> expectedlist, List<Vendor> actualList)
	{
		Steps.AddTestStep("Validate expected list is in actual.", "Expected list should match actual.");
		var actualDictionary = actualList.ToDictionary(i => i.VendorId, j => j);
		foreach (var expected in expectedlist)
		{
			if (!actualDictionary.TryGetValue(expected.VendorId, out var actual))
				HPGWarn.Warn($"Unable to find Vendor ID: '{expected.VendorId}' in actual!");
			else
			{
				HPGWarn.WarnRange(expected.Validate(actual));
			}
		}

		Steps.AddTestStep("Validate actual list is in expected.", "Actual list should match actual.");
		var expectedDictionary = expectedlist.ToDictionary(i => i.VendorId, j => j);
		foreach (var actual in actualList)
		{
			if (!expectedDictionary.TryGetValue(actual.VendorId, out var expected))
				HPGWarn.Warn($"Unable to find Vendor ID: '{actual.VendorId}' in expected!");
			else
			{
				HPGWarn.WarnRange(actual.Validate(expected));
			}
		}
	}

	/// <summary>
	/// Validates that the expected list of Org objects is present in the actual list and vice versa.
	/// It checks both that each expected Org is in the actual list and that each actual Org is in the expected list.
	/// If an Org is missing in either list, a warning is logged.
	/// </summary>
	private void ValidateUserSoc(List<Org> expectedList, List<Org> actualList)
	{
		Steps.AddTestStep("Validate expected list is in actual.", "Expected list should match actual.");
		var actualDictionary = actualList.ToDictionary(i => i.ObjectId, j => j);
		foreach (var expected in expectedList)
		{
			if (!actualDictionary.TryGetValue(expected.ObjectId, out var actual))
				HPGWarn.Warn($"Unable to find OrgObjectId: '{expected.ObjectId}' in actual!");
			else
			{
				HPGWarn.WarnRange(expected.Validate(actual));
			}
		}

		Steps.AddTestStep("Validate actual list is in expected.", "Actual list should match actual.");
		var expectedDictionary = expectedList.ToDictionary(i => i.ObjectId, j => j);
		foreach (var actual in actualList)
		{
			if (!expectedDictionary.TryGetValue(actual.ObjectId, out var expected))
				HPGWarn.Warn($"Unable to find OrgObjectId: '{actual.ObjectId}' in expected!");
			else
			{
				HPGWarn.WarnRange(actual.Validate(expected));
			}
		}
	}

	#endregion SPOC and Vendor Affiliation Validation

	#endregion Validations

	#region Helpers

	private List<SupplierPortalApplicationRoles> GetApplicationRoles()
	{
		var response = GetSuppierPortalRoleIds();
		if (!HPGWarn.AreEqual(OkResponse, response.Status, field: ResponseStatusField))
			HPGAssert.Fail(
				$"Unable to get applications roles from Supplier Portal!\r\nResponse: '{response.Status}' - Response Message: '{response.Response}");

		return JsonConvert.DeserializeObject<List<SupplierPortalApplicationRoles>>(response.Response);
	}

	private List<SupplierPortalUserRoles> FormatExpectedUserRoleList(UserResponse user)
	{
		//check to see if the user is active
		if (user.IsDeactivated) return new List<SupplierPortalUserRoles>();

		//Get user roles from user_role table
		var userRoles = _userRepository.GetAllUserRoleDb().Where(i =>
			!i.IsDeleted && i.UserId.ToString()
				.Equals(user.Id.ToString(), StringComparison.CurrentCultureIgnoreCase)).ToList();

		//Get application role ID from supplier portal
		var supplierPortalApplicationRoleDictionary = GetApplicationRoles().ToDictionary(i => i.RoleName, j => j);

		var results = new List<SupplierPortalUserRoles>();
		foreach (var userRole in userRoles)
		{
			if (!supplierPortalApplicationRoleDictionary.TryGetValue(userRole.Name, out var supplierRole))
				HPGWarn.Warn($"Unable to find role name '{userRole.Name}' in Supplier Portal");
			else
			{
				results.Add(new SupplierPortalUserRoles
				{
					Domain = "",
					EmailAddress = user.Email,
					RoleName = userRole.Name,
					RoleId = supplierRole.RoleId
				});
			}
		}

		return results;
	}

	private SupplierPortalUserSpoc FormatExpedctedUserSpocVendorAffiliation(UserResponse user)
	{
		var userSpoc = _userRepository.GetAllUserSocDb(user.Id).Where(i => !i.IsDeleted).ToList();

		//check to see if user is deactivated
		if (user.IsDeactivated)
		{
			return new SupplierPortalUserSpoc()
			{
				Email = user.Email,
				AppKey = GlobalTestVariables.Configuration["SupplierPortal:SmartApiKey"]!,
				SoC = JsonConvert.SerializeObject(new SupplierSoc()
				{ Orgs = new List<Org>(), Vendors = new List<Vendor>() })
			};
		}

		var userVendorAffiliation = _userRepository.GetUserVendorAffiliationDb(user.Id).Where(i => !i.IsDeleted);

		var spoc = userSpoc.Select(i => new Org() { HierarchyType = i.Hierarchy, ObjectId = i.OrgObjectID }).ToList();
		var vendor = userVendorAffiliation.Select(i => new Vendor()
		{ VendorId = i.VendorId, VendorName = i.VendorName }).ToList();
		var soc = new SupplierSoc() { Orgs = spoc, Vendors = vendor };
		var socFormatted = JsonConvert.SerializeObject(soc);

		return new SupplierPortalUserSpoc
		{
			Email = user.Email,
			AppKey = GlobalTestVariables.Configuration["SupplierPortal:SmartApiKey"]!,
			SoC = socFormatted
		};
	}

	private string GetSupplierPortalToken()
	{

		var browser = new Browser(GlobalTestVariables.SeleniumHub);

		var username = $"{GlobalTestVariables.Configuration["SupplierPortal:UserName"]}";
		browser.OpenNewBrowser("chrome", GlobalTestVariables.SeleniumGridToggle.Equals("ON"));
		_ = browser.EnterCreds(username, GlobalTestVariables.Configuration["SupplierPortal:Creds"], GlobalTestVariables.Configuration["WebDomain"]);
		browser.Navigate(GlobalTestVariables.Configuration["SupplierPortal:PingToken"]);

		var supplierPortalLogin = new SupplierPortalLoginPage(browser);
		supplierPortalLogin.EnterInCreds(username);
		var supplierPortalToken = new Supplierportaltokenpage(browser);
		var token = supplierPortalToken.GetAccessToken();

		browser.Close();
		return token;
	}
	#endregion
}
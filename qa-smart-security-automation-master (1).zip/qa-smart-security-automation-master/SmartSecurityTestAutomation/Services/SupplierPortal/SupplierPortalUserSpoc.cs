﻿using Newtonsoft.Json;

namespace SmartSecurityTestAutomation.Services.SupplierPortal;

public class SupplierPortalUserSpoc
{
    [JsonProperty("email")]
    public string? Email { get; set; }

    [JsonProperty("soC")]
    public string SoC { get; set; }

    [JsonProperty("appKey")]
    public string AppKey { get; set; }
}
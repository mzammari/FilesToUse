﻿using Newtonsoft.Json;
using SmartSecurityTestAutomation.Services.Orgs;
using System.Collections.Generic;
using System.Linq;
using Utilities.ObjectExtensions;
using Utilities.Validation;

namespace SmartSecurityTestAutomation.Services.SupplierPortal;

public class SupplierSoc
{
    [JsonProperty("Orgs")]
    public List<Org> Orgs { get; set; }

    [JsonProperty("Vendors")]
    public List<Vendor> Vendors { get; set; }
}

public class Org
{
    [JsonProperty("HierarchyType")]
    public int HierarchyType { get; set; }

    [JsonProperty("ObjectId")]
    public string? ObjectId { get; set; }

    [JsonProperty("OrgName")]
    public string OrgName { get; set; }

    public List<string> Validate(Org other)
    {
        var results = new List<string>()
        {
            ValidationHelpers.AreEqual(this.HierarchyType.ToStringOrEmpty(), other.HierarchyType.ToStringOrEmpty(),
                "HierarchyType"),
            ValidationHelpers.AreEqual(this.ObjectId.ToStringOrEmpty(), other.ObjectId.ToStringOrEmpty(),
                "ObjectId"),
            ValidationHelpers.AreEqual(this.OrgName.ToStringOrEmpty(), other.OrgName.ToStringOrEmpty(),
                "OrgName"),
        };

        return results.Where(i => i != string.Empty).ToList();
    }
}

public class Vendor
{
    [JsonProperty("VendorId")]
    public int VendorId { get; set; }

    [JsonProperty("VendorName")]
    public string VendorName { get; set; }

    public List<string> Validate(Vendor other)
    {
        var results = new List<string>()
        {
            ValidationHelpers.AreEqual(this.VendorId.ToStringOrEmpty(), other.VendorId.ToStringOrEmpty(),
                "VendorId"),
            ValidationHelpers.AreEqual(this.VendorName.ToStringOrEmpty(), other.VendorName.ToStringOrEmpty(),
                "VendorName"),
        };

        return results.Where(i => i != string.Empty).ToList();
    }
}
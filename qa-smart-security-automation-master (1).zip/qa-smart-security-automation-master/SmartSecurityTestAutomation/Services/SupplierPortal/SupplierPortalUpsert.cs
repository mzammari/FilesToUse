﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace SmartSecurityTestAutomation.Services.SupplierPortal
{
	public class SupplierPortalUpsert
	{
		[JsonPropertyName("userId")]
		public string UserId { get; set; }
		
		[JsonPropertyName("firstName")]
		public string FirstName { get; set; }

		[JsonPropertyName("lastName")]
		public string LastName { get; set; }

		[JsonPropertyName("domain")]
		public string Domain { get; set; }
		
		[JsonPropertyName("email")]
		public string Email { get; set; }

		[JsonPropertyName("phone")]
		public string Phone { get; set; }

		[JsonPropertyName("vproActive")]
		public bool VproActive { get; set; }
		
		[JsonPropertyName("accountActive")]
		public bool AccountActive { get; set; }
		
		[JsonPropertyName("snvs")]
		public string Snvs { get; set; }
		
		[JsonPropertyName("authSource")]
		public string AuthSource { get; set; }
	}
}

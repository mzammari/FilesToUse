﻿using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace SmartSecurityTestAutomation.Services.SupplierPortal;

public class RoleResponse
{
    [JsonPropertyName("status")]
    public int Status { get; set; }

    [JsonPropertyName("message")]
    public string Message { get; set; }

    [JsonPropertyName("domain")]
    public string Domain { get; set; }

    [JsonPropertyName("emailAddress")]
    public string EmailAddress { get; set; }

    [JsonPropertyName("roleName")]
    public string RoleName { get; set; }

    [JsonPropertyName("roleId")]
    public int RoleId { get; set; }
}

public class SupplierPortalUserRoleResponse
{
    [JsonPropertyName("emailAddress")]
    public string EmailAddress { get; set; }

    [JsonPropertyName("roleResponse")]
    public List<RoleResponse> RoleResponse { get; set; }
}
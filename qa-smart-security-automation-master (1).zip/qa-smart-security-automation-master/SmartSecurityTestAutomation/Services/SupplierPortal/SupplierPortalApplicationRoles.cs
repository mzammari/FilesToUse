﻿using Newtonsoft.Json;

namespace SmartSecurityTestAutomation.Services.SupplierPortal;

public class SupplierPortalApplicationRoles
{
    [JsonProperty("roleId")]
    public int RoleId { get; set; }

    [JsonProperty("roleName")]
    public string RoleName { get; set; }

    [JsonProperty("appName")]
    public string AppName { get; set; }
}
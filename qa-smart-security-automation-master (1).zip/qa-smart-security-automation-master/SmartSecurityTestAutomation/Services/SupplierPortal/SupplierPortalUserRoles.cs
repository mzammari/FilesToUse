﻿using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using Utilities.ObjectExtensions;
using Utilities.Validation;

namespace SmartSecurityTestAutomation.Services.SupplierPortal;

public class SupplierPortalUserRoles
{
    [JsonProperty("domain")]
    public string Domain { get; set; }

    [JsonProperty("emailAddress")]
    public string? EmailAddress { get; set; }

    [JsonProperty("roleName")]
    public string RoleName { get; set; }

    [JsonProperty("roleId")]
    public int RoleId { get; set; }

    public List<string> Validate(SupplierPortalUserRoles other)
    {
        var results = new List<string>()
        {
            ValidationHelpers.AreEqual(this.Domain.ToStringOrEmpty(), other.Domain.ToStringOrEmpty(),
                "Domain"),
            ValidationHelpers.AreEqual(this.EmailAddress.ToStringOrEmpty(), other.EmailAddress.ToStringOrEmpty(),
                "EmailAddress"),
            ValidationHelpers.AreEqual(this.RoleName.ToStringOrEmpty(), other.RoleName.ToStringOrEmpty(),
                "RoleName"),
            ValidationHelpers.AreEqual(this.RoleId.ToStringOrEmpty(), other.RoleId.ToStringOrEmpty(),
                "RoleId"),
        };

        return results.Where(i => i != string.Empty).ToList();

    }
}
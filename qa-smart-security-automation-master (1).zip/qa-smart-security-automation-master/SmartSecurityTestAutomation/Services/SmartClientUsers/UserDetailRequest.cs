﻿using System;
using System.Text.Json.Serialization;

namespace SmartSecurityTestAutomation.Services.SmartClientUsers;

public class UserDetailRequest : ICloneable
{
    public object Clone()
    {
        return new UserDetailRequest()
        {
            UserName = UserName,
            Email = Email,
            Domain = Domain,
            AppId = AppId,
            WithRoles = WithRoles,
            WithSoc = WithSoc,
            WithVendors = WithVendors,
            WithDetails = WithDetails
        };
    }

    [JsonPropertyName("userName")]
    public string? UserName { get; set; }

    [JsonPropertyName("email")]
    public string? Email { get; set; }

    [JsonPropertyName("domain")]
    public string? Domain { get; set; }

    [JsonPropertyName("appId")]
    public string? AppId { get; set; }

    [JsonPropertyName("withRoles")]
    public dynamic? WithRoles { get; set; }

    [JsonPropertyName("withSoc")]
    public dynamic? WithSoc { get; set; }

    [JsonPropertyName("withVendors")]
    public dynamic? WithVendors { get; set; }

    [JsonPropertyName("withDetails")]
    public dynamic? WithDetails { get; set; }
}
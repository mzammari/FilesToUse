﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace SmartSecurityTestAutomation.Services.SmartClientUsers
{
	public class DetailsByUsernameRequest
	{
		[JsonPropertyName("userName")]
		public string? UserName { get; set; }

		[JsonPropertyName("withRoles")]
		public bool? WithRoles { get; set; }

		[JsonPropertyName("withSoc")]
		public bool? WithSoc { get; set; }

		[JsonPropertyName("withVendors")]
		public bool? WithVendors { get; set; }

		[JsonPropertyName("withDetails")]
		public bool? WithDetails { get; set; }

		public DetailsByUsernameRequest()
		{
		}
	}
}

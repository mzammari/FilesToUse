﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using SmartSecurityTestAutomation.Enums;
using SmartSecurityTestAutomation.Services.Applications;
using SmartSecurityTestAutomation.Services.GCNGroup;
using SmartSecurityTestAutomation.Services.Home;
using SmartSecurityTestAutomation.Services.SelfProvision;
using SmartSecurityTestAutomation.Services.Users;
using SmartSecurityTestAutomation.Services.Vendor;
using SmartSecurityTestAutomation.Services.VPRO;
using SmartSecurityTestAutomation.Tests;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.DirectoryServices.ActiveDirectory;
using System.Linq;
using System.Net;
using Utilities.HttpUtility;
using Utilities.ObjectExtensions;
using JsonSerializer = System.Text.Json.JsonSerializer;

namespace SmartSecurityTestAutomation.Services.SmartClientUsers
{
    public class SmartClientUserApi : MasterApi
    {
        #region Class Variables

        private const string AuthenticationType    = "oAuth";
        private const string UserResource          = "/users";
        private const string ApplicationResource   = "/applications";
        private const string RolesResource         = "/roles";
        private const string SpanOfControlResource = "/soc";
        private const string VendorResource        = "/Vendor";
        private const string UserSearchResource    = "/usersearch";
        private const string DetailsResource       = "/details";
		private const string UsersDetailsByUsername = "/detailsByUsername";
        private const string VproGetUserVproBadgeInResource = "/vpro/GetUserVPROBadgeInDetailsAsync";
        private const string UserSearchByRoleAndCoid = "/userSearchByRoleAndCoid";
		private const string GetAllGcnAttributesResource = "/gcn/getAllGcnAttributes";
        private const string GetSocLeafLevelResource = "/socleaflevel";
        private const string ShortForAppsResource = "/apps";
        private const string SelfProvisionResource = "/SelfProvision";
        private const string IngestResource = "/Ingest";
        private const string VendorAdminsResource = "/VendorAdmins";
        private const string VendorAdminNotificationResource = "/VendorAdminNotification";
        private const string VboRequestResponseNotificationResource = "/VboRequestResponseNotification";

		private readonly IEnumerable<HomeDataDb> _homeInfoDataDb;
		//private readonly string _baseUri = GlobalTestVariables.Configuration["SmartSecurityClient:BaseUri"]!;
		private readonly string _baseUri = (GlobalTestVariables.Configuration["EnvironmentDomain"] == "HCA")
	        ? GlobalTestVariables.Configuration["SmartSecurityClient:BaseApiGeeXUri"]
			: GlobalTestVariables.Configuration["SmartSecurityClient:BaseUri"];

        private readonly UserRepository _userRepository =
            new(GlobalTestVariables.Configuration["SmartSecurity:DatabaseServer"]!,
                GlobalTestVariables.Configuration["SmartSecurity:DatabaseName"]!);

        private readonly ApplicationRepository _applicationRepository =
            new(GlobalTestVariables.Configuration["SmartSecurity:DatabaseServer"]!,
                GlobalTestVariables.Configuration["SmartSecurity:DatabaseName"]!);

        private readonly VendorRepository _vendorRepository =
            new(GlobalTestVariables.Configuration["VendorMaster:DatabaseServer"]!,
                GlobalTestVariables.Configuration["VendorMaster:DataBaseName"]!);

        private readonly HomeRepository _homeDb = new(GlobalTestVariables.Configuration["Home:DatabaseServer"]!,
            GlobalTestVariables.Configuration["Home:DataBaseName"]!);

		// Expected error messages for validation
		private const string FirstNameRequiredError = "The FirstName field is required.";
		private const string LastNameRequiredError = "The LastName field is required.";
		private const string EmailRequiredError = "The Email field is required.";
		private const string VproUserEmailIdRequiredError = "The VPROUserEmailId field is required.";
		private const string RequestRequiredError = "The request field is required.";


		#endregion Class Variables

		public SmartClientUserApi()
        {
            _homeInfoDataDb = _homeDb.GetHomeData(); 
		}

        #region API Calls

        private HttpResponse GetUserRoles(string? userId, string? appId) => GetSimpleRequest(
            $"{_baseUri}{UserResource}/{userId}{ApplicationResource}/{appId}{RolesResource}",
            AuthenticationType);

        private HttpResponse GetUserSoc(string? userId, string? appId) => GetSimpleRequest(
            $"{_baseUri}{UserResource}/{userId}{ApplicationResource}/{appId}{SpanOfControlResource}",
            AuthenticationType);

		private HttpResponse GetUserV2Soc(string? userId, string? appId) => GetSimpleRequest(
        $"{_baseUri}{UserResource}/v2/{userId}{ApplicationResource}/{appId}{SpanOfControlResource}",
        AuthenticationType);

		private HttpResponse GetUserVendor(string? userId) => GetSimpleRequest(
            $"{_baseUri}{UserResource}/{userId}{VendorResource}",
            AuthenticationType);

        private HttpResponse GetUserRoleSocVendor(string? userId, string? appId) => GetSimpleRequest(
            $"{_baseUri}{UserResource}/{userId}{ApplicationResource}/{appId}",
            AuthenticationType);

        private HttpResponse GetUsersForSpecificRoleAndSpoc(string roleId, string objectId, string hierarchy,
            string? appId) => GetSimpleRequest(
            $"{_baseUri}{RolesResource}/{roleId}/objectId/{objectId}/hierarchyType/{hierarchy}/applicationId/{appId}",
            AuthenticationType);

        private HttpResponse GetUsersForSpecificRoleAndSpocWithDetails(string roleId, string objectId, string hierarchy,
            string? appId) => GetSimpleRequest(
            $"{_baseUri}{RolesResource}/{roleId}/objectId/{objectId}/hierarchyType/{hierarchy}/applicationId/{appId}/withDetails",
            AuthenticationType);

        private HttpResponse PostGetUserSearch(string payload) =>
            PostSimpleRequest($"{_baseUri}{RolesResource}{UserSearchResource}", payload, AuthenticationType);

        private HttpResponse PostGetUserDetails(string payload) =>
            PostSimpleRequest($"{_baseUri}{UserResource}{DetailsResource}", payload, AuthenticationType);

		private HttpResponse GetUsersDetailsByUsername(string userName) =>
			GetSimpleRequest($"{_baseUri}{UserResource}{UsersDetailsByUsername}?userName={userName}", AuthenticationType);
        private HttpResponse PostGetUserVproBadgeInDetails(string payload) =>
			PostSimpleRequest($"{_baseUri}{VproGetUserVproBadgeInResource}", payload, AuthenticationType);

        private HttpResponse GetUsersAppsSocLeafLevel(string userName, string appId) =>
			GetSimpleRequest($"{_baseUri}{UserResource}/{userName}{ShortForAppsResource}/{appId}{GetSocLeafLevelResource}", AuthenticationType);
		
        private HttpResponse GetSelfService(string facility,string requestType) =>
            GetSimpleRequest($"{_baseUri}{SelfProvisionResource}?facility={facility}&requestType={requestType}", AuthenticationType);

        private HttpResponse PostSelfService(string resource, string payload) =>
			PostSelfServiceRequest($"{_baseUri}{SelfProvisionResource}/{resource}", payload, AuthenticationType);

		/// <summary>
		/// Helper method to send 'GET' request to /VendorAdmins endpoint.
		/// </summary>
		/// <param name="facility">Facility COID parameter</param>
		/// <param name="requestType">Request type parameter (VBO or INV)</param>
		/// <returns>HTTP response</returns>
		private HttpResponse GetVendorAdmins(string? facility, string? requestType)
		{
			var queryParams = new List<string>();

			if (facility != null)
				queryParams.Add($"facility={facility}");

			if (requestType != null)
				queryParams.Add($"requestType={requestType}");

			var queryString = queryParams.Count > 0 ? "?" + string.Join("&", queryParams) : "";

			return GetSimpleRequest(
				$"{_baseUri}{SelfProvisionResource}{VendorAdminsResource}{queryString}",
				AuthenticationType);
		}

		#endregion API Calls

		#region Test Methods

		/// <summary>
		/// Test 'GET' request for API endpoint /users/{userName}/applications/{appId}/roles.
		/// </summary>
		public void TestGetUserRoles()
        {
            Steps.AddTestStep("Testing 'GET' Request for /users/<userId>/applications/<appId>/roles API endpoint.",
                "Should out the correct response");

            var dbUsers = _userRepository.GetAllUserRoleDb().ToList();

            var scenarios = new List<string> { "active", "deactivated" };

            foreach (var scenario in scenarios)
            {
                var testUsers = dbUsers.Where(a => a.IsDeactivated.Equals(!scenario.Equals("active")))
                    .GroupBy(i => new { UserId = i.Username, AppId = i.ApplicationId, i.IsDeactivated })
                    .ToDictionary(grp => grp.Key,
                        j => j.ToList().Where(k => !k.IsDeleted)
                            .Select(f => new GeneralIdNameResponse() { Id = f.Id.ToString(), Name = f.Name }));

                if (testUsers.IsNullOrEmpty())
                {
                    HPGWarn.Warn($"No users return for scenario: '{scenario}'!");
                    continue;
                }

                var randomTestUsers = testUsers.PickRandomList(5);

                var expectedResponseStatus = scenario.Equals("active") ? OkResponse : NotFoundResponse;

                foreach (var testUser in randomTestUsers)
                {
                    Steps.AddTestStep(
                        $"Sending 'GET' request for UserId: {testUser.Key.UserId} ApplicationId: {testUser.Key.AppId} where user is {scenario}.",
                        $"System should respond with a {expectedResponseStatus}.");
                    var response =
                        GetUserRoles(testUser.Key.UserId.ToStringOrEmpty(), testUser.Key.AppId.ToStringOrEmpty());

                    switch (testUser.Key.IsDeactivated)
                    {
                        case true:
                            HPGWarn.AreEqual(NotFoundResponse, response.Status, field: ResponseStatusField);
                            break;
                        case false:
                            if (HPGWarn.Contains(response.Status, OkResponse, field: ResponseStatusField))
                            {
                                var actualList =
                                    JsonSerializer.Deserialize<List<GeneralIdNameResponse>>(response.Response);
                                GeneralIdNameResponse.ValidateGenralList(testUser.Value.ToList(), actualList);
                            }

                            break;
                    }
                }
            }
        }

        /// <summary>
        /// Test 'GET' request for API endpoint /users/{userName}/applications/{appId}/soc.
        /// </summary>
        public void TestGetUserSoc()
        {
            Steps.AddTestStep("Test sending 'GET' request to /users/<UserId>/applications/<ApplicationId>/soc.",
                "System should respond accordingly.");

            var dbUsers   = _userRepository.GetAllUserSocDb().ToList();
            var scenarios = new List<string> { "active", "deactivated" };

            foreach (var scenario in scenarios)
            {
                var filteredUsers = dbUsers
                    .Where(i => !i.IsDeleted && i.IsDeactivated.Equals(!scenario.Equals("active")))
                    .GroupBy(grp => new
                        { AppId = grp.ApplicationId, UserId = grp.Username, grp.IsDeactivated })
                    .ToDictionary(g => g.Key, j => j.ToList());

                if (filteredUsers.IsNullOrEmpty())
                {
                    HPGWarn.Warn($"Unable to find users for scenario: '{scenario}'!");
                    continue;
                }

                var testUsers = filteredUsers.PickRandomList(5);

                var expectedResponseStatus = scenario.Equals("active") ? OkResponse : NotFoundResponse;

                foreach (var testUser in testUsers)
                {
                    Steps.AddTestStep(
                        $"Sending 'GET' to /users/{testUser.Key.UserId}/applications/{testUser.Key.AppId}/soc API endpoint where user is {scenario}.",
                        $"System should respond with {expectedResponseStatus}.");
                    var expectedList = HomeService.GetExpectedHierarchyList(testUser.Value, _homeInfoDataDb);
                    var response     = GetUserSoc(testUser.Key.UserId, testUser.Key.AppId.ToString());

                    switch (testUser.Key.IsDeactivated)
                    {
                        case true:
                            HPGWarn.AreEqual(NotFoundResponse, response.Status, field: ResponseStatusField);
                            break;
                        case false:
                        {
                            if (HPGWarn.AreEqual(OkResponse, response.Status, field: ResponseStatusField))
                            {
	                            var actualList = JsonConvert.DeserializeObject<List<SpanOfControl>>(response.Response);
                                SpanOfControl.ValidateOrgTreeList(expectedList, actualList);
	                        }
                            break;
                        }
                    }
                }
            }
        }

		/// <summary>
		/// Test 'GET' request for API endpoint /users/v2/{username}/application/{appId}/soc.
		/// </summary>
		public void TestGetUserV2Soc()
		{
			// This API is only for any user with a Company or Higher SoC
			Steps.AddTestStep(
				"Test sending 'GET' request to /users/v2/<UserId>/applications/<ApplicationId>/soc API endpoint.",
				"System should respond accordingly.");

			var dbUsers = _userRepository.GetAllServiceAcctsSocDb().ToList();

			// Prepare test cases
			var validUser = dbUsers.FirstOrDefault(u => !u.IsDeleted && !u.IsDeactivated);
			var validUserId = validUser?.Username;
			var validAppId = validUser?.ApplicationId.ToString();

			var testCases = new[]
			{
		        new { Name = "Missing Username", UserId = "", AppId = validAppId, ExpectedStatus = NotFoundResponse },
		        new { Name = "Missing AppId", UserId = validUserId, AppId = "", ExpectedStatus = BadRequestResponse },
				new { Name = "Missing Username and AppId", UserId = "", AppId = "", ExpectedStatus = GlobalTestVariables.TestEnvironment == "qa" ? NotFoundResponse : BadRequestResponse },
		        new { Name = "Valid Request", UserId = validUserId, AppId = validAppId, ExpectedStatus = OkResponse }
	        };

			foreach (var testCase in testCases)
			{
				Steps.AddTestStep(
					$"Sending 'GET' request to /users/v2/{testCase.UserId}/applications/{testCase.AppId}/soc for scenario: {testCase.Name}.",
					$"System should respond with {testCase.ExpectedStatus}.");

				var response = GetUserV2Soc(testCase.UserId, testCase.AppId);
				if (!HPGWarn.AreEqual(testCase.ExpectedStatus, response.Status, field: ResponseStatusField))
					continue;

				// Only validate response body for valid request
				if (testCase.ExpectedStatus == OkResponse)
				{
					var actualList = JsonConvert.DeserializeObject<List<HierarchyLeafSoc>>(response.Response); 
																											 
					// Validate that each object contains the required attributes
					foreach (var soc in actualList)
					{
						// Validate COID is not null or empty
						if (string.IsNullOrWhiteSpace(soc.Coid))
							HPGAssert.Fail("COID is missing or empty in SpanOfControl response.");

						// Validate Name is not null or empty
						if (string.IsNullOrWhiteSpace(soc.Name))
							HPGAssert.Fail("Name is missing or empty in SpanOfControl response.");

						// Validate IsPrimary is either true or false (should always be a boolean)
						if (!(soc.IsPrimary == true || soc.IsPrimary == false))
							HPGAssert.Fail("IsPrimary must be a boolean value in SpanOfControl response.");

						// Validate Company is not null or empty
						if (string.IsNullOrWhiteSpace(soc.Company))
							HPGAssert.Fail("Company is missing or empty in SpanOfControl response.");

						// Validate CoidType is one of P, C, S
						if (!(soc.CoidType == "P" || soc.CoidType == "C" || soc.CoidType == "S"))
							HPGAssert.Fail($"CoidType '{soc.CoidType}' is invalid. Must be 'P', 'C', or 'S'.");
					}


					// Optionally, print the formatted response for review
					var formatted = response.Response.Replace("{", "\n        {").Replace(",", ",\n        ");
					ConsoleOut.WriteReport("Response Body:", true);
					ConsoleOut.WriteReport(formatted, true);
					ConsoleOut.WriteReport("\n", true);
				}
			}
		}

		/// <summary>
		/// Test 'GET' request for API endpoint /users/{userName}/Vendor.
		/// </summary>
		public void TestGetUserVendor()
        {
            Steps.AddTestStep(
                "Test sending 'GET' request to /users/<Username>/Vendor API endpoint.",
                "System should respond accordingly.");
            var dbUsers   = _userRepository.GetUserVendorAffiliationDb();
            var scenarios = new List<string> { "active", "deactivated" };


            foreach (var scenario in scenarios)
            {
                var filteredUsers = dbUsers
                    .Where(i => !i.IsDeleted && i.IsDeactivated.Equals(!scenario.Equals("active")))
                    .GroupBy(grp => new { grp.Username, grp.IsDeactivated }).ToDictionary(k => k.Key, j => j.ToList());

                if (filteredUsers.IsNullOrEmpty())
                {
                    HPGWarn.Warn($"Unable to find users for scenario: '{scenario}'!");
                    continue;
                }

                var testUsers = filteredUsers.PickRandomList(5);

                var expectedResponseStatus = scenario.Equals("active") ? OkResponse : NotFoundResponse;

                foreach (var testUser in testUsers)
                {
                    Steps.AddTestStep(
                        $"Sending 'GET' request to /users/{testUser.Key.Username}/Vendor where user is {scenario}",
                        $"System should respond with a {expectedResponseStatus}.");
                    var expectedList = testUser.Value.Select(i => new UserVendorAffiliationResponse()
                        { Id = i.Id, VendorId = i.VendorId }).ToList();

                    var response = GetUserVendor(testUser.Key.Username);

                    switch (testUser.Key.IsDeactivated)
                    {
                        case true:
                            HPGWarn.AreEqual(NotFoundResponse, response.Status, field: ResponseStatusField);
                            break;
                        case false:

                            if (HPGWarn.AreEqual(OkResponse, response.Status, field: ResponseStatusField))
                            {
                                var actualList =
                                    JsonConvert.DeserializeObject<List<UserVendorAffiliationResponse>>(
                                        response.Response);
                                UserVendorAffiliationResponse.ValidateVendorAffiliationList(expectedList, actualList!);
                            }

                            break;
                    }
                }
            }
        }

        /// <summary>
        /// Test 'GET' request for API endpoint /users/{userName}/applications/{appId}/roles for Bad Request Scenarios.
        /// </summary>
        public void TestGetUserRoleBadRequest() => TestBadRequest("roles");

        /// <summary>
        /// Test 'GET' request for API endpoint /users/{userName}/applications/{appId}/soc for Bad Request Scenarios.
        /// </summary>
        public void TestGetUserSocBadRequest() => TestBadRequest("soc");

        /// <summary>
        /// Test 'GET' request for API endpoint /users/{userName}/Vendor for Bad Request Scenarios.
        /// </summary>
        public void TestGetUserVendorBadRequest() => TestBadRequest("Vendor");

        /// <summary>
        /// A method to test Bad request scenarios based on test type.
        /// </summary>
        /// <param name="testType"></param>
        private void TestBadRequest(string testType)
        {
            var testNameType = testType switch
            {
                "roles" => "/users/<userId>/applications/<appId>/roles",
                "soc" => "/users/<userId>/applications/<appId>/soc",
                "Vendor" => "/users/<userId>/applications/<appId>/Vendor",
                "rolesSocVendor" => "/users/<userId>/applications/<appId>",
                _ => throw new ArgumentOutOfRangeException(nameof(testType), testType,
                    $"Unable to recognize test type: '{testType}'!")
            };

            Steps.AddTestStep(
                $"Test sending 'GET' request for {testNameType} API endpoint with bad or null values",
                "Systems should respond with the proper response code.");

            var scenarios = new List<string>()
            {
                "Blank User ID", "Blank Application ID", "Blank User ID and Application ID", "Non-Existent User",
                "Non-Existent Application ID", "Non-Existent User Id and Application ID", "Alpha User Id",
                "Alpha Application ID", "Alpha User ID and Application ID"
			};

            var excludedScenariosForVendors = new List<string>()
            {
                "Blank Application ID", "Blank User ID and Application ID",
                "Non-Existent Application ID", "Non-Existent User Id and Application ID", "Alpha Application ID",
                "Alpha User ID and Application ID"
            };

            var testUser = _userRepository.GetAllUserRoleDb()
                .GroupBy(i => new { UserId = i.Username, AppId = i.ApplicationId })
                .ToDictionary(grp => grp.Key,
                    j => j.ToList().Where(k => !k.IsDeleted)
                        .Select(f => new GeneralIdNameResponse() { Id = f.Id.ToString(), Name = f.Name })).PickRandom();
            var testUserInfo = _userRepository.GetAllUsers()
                .FirstOrDefault(i => i.Username.Equals(testUser.Key.UserId));


            foreach (var scenario in scenarios)
            {
                if (excludedScenariosForVendors.Contains(scenario) && testType.Equals("Vendor")) continue;

                var userId        = testUser.Key.UserId;
                var applicationId = testUser.Key.AppId.ToStringOrEmpty();
                var statusCode    = OkResponse;
                switch (scenario)
                {
                        // TODO: Double check these responses status. come back to it.
                    case "Blank User ID":
                        userId     = string.Empty;
						statusCode = GlobalTestVariables.TestEnvironment.Equals("qa") ? NotFoundResponse : BadRequestResponse;
						//statusCode = BadRequestResponse;
						break;
                    case "Blank Application ID":
                        applicationId = string.Empty;
                        statusCode = GlobalTestVariables.TestEnvironment.Equals("qa")? NotFoundResponse : BadRequestResponse; 
						//statusCode = BadRequestResponse;
						break;
                    case "Blank User ID and Application ID":
                        userId        = string.Empty;
                        applicationId = string.Empty;
						statusCode = GlobalTestVariables.TestEnvironment.Equals("qa") ? NotFoundResponse : BadRequestResponse;
						//statusCode = BadRequestResponse;
						break;
                    case "Non-Existent User":
                        userId     = Guid.NewGuid().ToString();
                        statusCode = NotFoundResponse;
                        break;
                    case "Non-Existent Application ID":
                        applicationId = Guid.NewGuid().ToString();
                        statusCode = testType.Equals("Vendor")
                            ? BadRequestResponse        //InternalServerResponse
							: testUserInfo.IsDeactivated
                                ? NotFoundResponse
                                : OkResponse;
                        break;
                    case "Non-Existent User Id and Application ID":
                        userId        = Guid.NewGuid().ToString();
                        applicationId = Guid.NewGuid().ToString();
                        statusCode    = NotFoundResponse;
                        break;
                    case "Alpha User Id":
                        userId     = "abc";
                        statusCode = NotFoundResponse;
                        break;
                    case "Alpha Application ID":
                        applicationId = "abc";
                        statusCode    = BadRequestResponse;
                        break;
                    case "Alpha User ID and Application ID":
                        userId        = "abc";
                        applicationId = "abc";
                        statusCode    = BadRequestResponse;
                        break;
				}

                Steps.AddTestStep(
                    $"Sending 'GET' request to '{testNameType}' for UserID: '{userId}', user is Deactivated: '{testUserInfo.IsDeactivated}',and ApplicationId:'{applicationId}' for scenario '{scenario}'.",
                    $"System should respond with a Status Code: '{statusCode}'");

                var response = testType switch
                {
                    "roles" => GetUserRoles(userId, applicationId),
                    "soc" => GetUserSoc(userId, applicationId),
                    "Vendor" => GetUserVendor(userId),
                    "rolesSocVendor" => GetUserRoleSocVendor(userId, applicationId),
                    _ => throw new ArgumentOutOfRangeException(nameof(testType), testType,
                        $"Unable to recognize test type: '{testType}'!")
                };

                if (!HPGWarn.AreEqual(statusCode, response.Status, field: ResponseStatusField) ||
                    !statusCode.Equals(OkResponse)) continue;

                if (testType.Equals("rolesSocVendor"))
                {
                    var expected = new UserRoleSocVendorAffiliation(testUserInfo)
                    {
                        RoleModel = new List<GeneralIdNameResponse>(),
                        SOCModel  = new List<SpanOfControl>(),
                        VendorModel = testUserInfo.Type.Equals("Vendor")
                            ? _userRepository.GetUserVendorAffiliationDb(testUserInfo.Id)
                                .Where(i => !i.IsDeleted)
                                .Select(j => new ScVendorModel
                                    { Id = j.Id, VendorId = j.VendorId, VendorName = j.VendorName })
                                .ToList()
                            : new List<ScVendorModel>()
                    };
                    ValidateUserRoleSpocVendorAffiliation(response, expected);
                }
                else
                {
                    HPGWarn.AreEqual("[]", response.Response, field: ResponseBodyField);
                }
            }
        }

        /// <summary>
        /// Test 'GET' request for API endpoint /users/{userName}/applications/{appId}.
        /// </summary>
        public void TestGetRolesSocVendorAffiliation()
        {
            Steps.AddTestStep("Testing 'GET' Request for /users/<userId>/applications/<appId> API endpoint.",
                "Should out the correct response");

            var testUsers = _userRepository.GetAllUsers().Where(i => !i.IsDeactivated);

            var randomTestUsers = new List<UserResponse>();

            randomTestUsers.AddRange(testUsers.Where(i => i.Type.Equals("Employee")).PickRandomList(5));
            //randomTestUsers.AddRange(testUsers.Where(i => i.Type.Equals("Vendor")).PickRandom(5));
            randomTestUsers.AddRange(testUsers.Where(i => (String.IsNullOrEmpty(i.VproStatus) == false)  && i.VproStatus.Equals("VPRO Active") && (String.IsNullOrEmpty(i.VPROUserEmailId) == false)).PickRandomList(5));

        

            foreach (var randomTestUser in randomTestUsers)
            {
                var expected = GetExpectedUserRoleSocVendorAffiliation(randomTestUser);
                Steps.AddTestStep(
                    $"Sending 'GET' request to API endpoint /users/{randomTestUser.Username}/applications/{expected.ApplicationId}",
                    $"System should respond with a {OkResponse}.");
                var response = GetUserRoleSocVendor(randomTestUser.Username, expected.ApplicationId);

                if (!HPGWarn.AreEqual(OkResponse, response.Status, field: ResponseStatusField)) continue;
                ValidateUserRoleSpocVendorAffiliation(response, expected.UserRoleSocVendorAffiliation);
            }
        }

        /// <summary>
        /// Test 'GET' request for API endpoint /users/{userName}/applications/{appId} for Bad Request Scenarios.
        /// </summary>
        public void TestGetRolesSocVendorAffiliationBadRequest() => TestBadRequest("rolesSocVendor");

        /// <summary>
        /// Test sending 'GET' request to 'roles/{roleId}/objectId/{objectId}/hierarchyType/{hierarchy}/applicationId/{appId}' endpoint.
        /// </summary>
        public void TestGetUsersForSpecificRoleAndSpoc(bool withDetails = false)
        {
            var testName = withDetails
                ? "Test sending 'GET' request to 'roles/{roleId}/objectId/{objectId}/hierarchyType/{hierarchy}/applicationId/{appId}/withDetails' endpoint."
                : "Test sending 'GET' request to 'roles/{roleId}/objectId/{objectId}/hierarchyType/{hierarchy}/applicationId/{appId}' endpoint.";

            Steps.AddTestStep(testName, "Should respond appropriately.");

            //get all users
            var userList = _userRepository.GetAllUsers().Where(i => i.VproStatus.Equals("VPRO Active")) .ToList();

            //get current enabled roles
            var userRoleList = _userRepository.GetAllUserRoleDb()
                .Where(i => !i.IsDeleted && !i.Name.Equals("SMART Security Admin"));

            //get current SPOC
            var userSpocList = _userRepository.GetAllUserSocDb().Where(i => !i.IsDeleted);

            foreach (var hierarchy in EnumUtil.GetValues<HomeHierarchyType>())
            {
                if (hierarchy.Equals(HomeHierarchyType.Organization)) continue;

                //get randomly picked role and SPOC
                var randomRole          = userRoleList.PickRandom();
                var randomRoleID        = randomRole.Id;
                var randomApplicationId = randomRole.ApplicationId;

                var facilities = userSpocList
                    .Where(i => i.Hierarchy.Equals((int)hierarchy) && i.ApplicationId.Equals(randomApplicationId))
                    .Select(f => f.OrgObjectID).Distinct().ToList();

                if (facilities.IsNullOrEmpty())
                {
                    ConsoleOut.WriteReport(
                        $"No matching record(s) for the given hierarchy type: '{Enum.GetName(hierarchy)}' ,Application ID: '{randomApplicationId}', and Role: '{randomRole.Name}'.");
                    continue;
                }

                //loop for a few random org object ID
                var randomFacilities = facilities.Count() > 5 ? facilities.PickRandomList(5) : facilities;
                foreach (var randomFacility in randomFacilities)
                {
                    Steps.AddTestStep(
                        $"Getting expected users for ApplicationId: '{randomApplicationId}' RoleId: '{randomRoleID}' Hierarchy: '{Enum.GetName(hierarchy)}', and SPOC: '{randomFacility}'.",
                        "Should be able to get expected users for the specified criteria.");

                    if (withDetails)
                        SendValidateUsersForSpecificRoleAndSpocWithDetails(randomRoleID, randomApplicationId, hierarchy, randomFacility, userList, userRoleList, userSpocList);
                    else
                    {
                        SendValidateUsersForSpecificRoleAndSpoc(randomRoleID, randomApplicationId, hierarchy, randomFacility, userList, userRoleList, userSpocList);
                    }
                }
            }

            //need to add specific validation for user type of vendor!
            if (GlobalTestVariables.TestEnvironment!.Equals("prod")) return;

            Steps.AddTestStep("Sub-Test to get vendor users", "System should respond with vendorUser");
            var test = GetVendorUserWithRoleSpocAndVendorAffiliation(userList, userRoleList, userSpocList).Value;

            if (withDetails)
                SendValidateUsersForSpecificRoleAndSpocWithDetails(test.ApplicationId, test.RoleId, test.hierarchy,
                    test.facility, userList, userRoleList, userSpocList);
            else
            {
                SendValidateUsersForSpecificRoleAndSpoc(test.ApplicationId, test.RoleId, test.hierarchy, test.facility,
                    userList, userRoleList, userSpocList);
            }
        }

        /// <summary>
        /// Sends and validates request for Specific Roles, SPOC, and Vendor Affiliation
        /// </summary>
        /// <param name="roleId"></param>
        /// <param name="applicationId"></param>
        /// <param name="hierarchy"></param>
        /// <param name="facility"></param>
        /// <param name="userList"></param>
        /// <param name="userRoleList"></param>
        /// <param name="userSpocList"></param>
        private void SendValidateUsersForSpecificRoleAndSpoc(Guid roleId, Guid applicationId,
            HomeHierarchyType hierarchy, string facility, List<UserResponse> userList,
            IEnumerable<UserRoleDb> userRoleList, IEnumerable<UserSocDb> userSpocList)
        {
            //get expected user based on randomly picked roles and that has the specific SPOC
            var expectedList = GetExpectedUserForGivenSpocAndRoleList(roleId, applicationId, hierarchy, facility, userList, userRoleList, userSpocList);

            //send request
            Steps.AddTestStep(
                $"Sending 'GET' request to {RolesResource}/<roleId>/objectId/<objectId>/hierarchyType/<hierarchy>/applicationId/<appId>",
                "System should respond accordingly.");
            var response = GetUsersForSpecificRoleAndSpoc(roleId.ToString(), facility, ((int)hierarchy).ToString(), applicationId.ToStringOrEmpty());

            //validate request
            if (!HPGWarn.AreEqual(OkResponse, response.Status, field: ResponseStatusField)) return;
            var actualList = JsonConvert.DeserializeObject<List<UserResponse>>(response.Response);
            ConsoleOut.WriteReport(
                $"Expected Count: '{expectedList.Count}' and Actual Count: '{actualList.Count}'");
            UserResponse.ValidateUserResponseList(expectedList, actualList);
        }

        /// <summary>
        /// Sends and validates request for Specific Roles, SPOC, and Vendor Affiliation with User Detailed information.
        /// </summary>
        /// <param name="roleId"></param>
        /// <param name="applicationId"></param>
        /// <param name="hierarchy"></param>
        /// <param name="facility"></param>
        /// <param name="userList"></param>
        /// <param name="userRoleList"></param>
        /// <param name="userSpocList"></param>
        private void SendValidateUsersForSpecificRoleAndSpocWithDetails(Guid roleId, Guid applicationId,
            HomeHierarchyType hierarchy, string facility, List<UserResponse> userList,
            IEnumerable<UserRoleDb> userRoleList, IEnumerable<UserSocDb> userSpocList)
        {
            //get expected user based on randomly picked roles and that has the specific SPOC
            var sw = new Stopwatch();
            sw.Start();
            var expectedList = GetExpectedUserForGivenSpocAndRoleList(roleId, applicationId, hierarchy, facility,
                userList, userRoleList, userSpocList);
            var expectedUserList =
                GetExpectedUserForGivenSpocAndRoleWithDetailList(expectedList, applicationId, userRoleList,
                    userSpocList);
            sw.Stop();
            Console.WriteLine($"Time took for {expectedUserList.Count} is {sw.Elapsed}");

            //send request
            Steps.AddTestStep(
                $"Sending 'GET' request to {RolesResource}/<roleId>/objectId/<objectId>/hierarchyType/<hierarchy>/applicationId/<appId>/withDetails",
                "System should respond accordingly.");
            var response = GetUsersForSpecificRoleAndSpocWithDetails(roleId.ToString(), facility,
                ((int)hierarchy).ToString(), applicationId.ToStringOrEmpty());

            //validate request
            if (!HPGWarn.AreEqual(OkResponse, response.Status, field: ResponseStatusField)) return;
            var actualList = JsonConvert.DeserializeObject<List<UserRoleSocVendorAffiliation>>(response.Response);
            ConsoleOut.WriteReport(
                $"Expected Count: '{expectedList.Count}' and Actual Count: '{actualList.Count}'");
            UserRoleSocVendorAffiliation.ValidateUserRoleSocVendorAffilitaionList(expectedUserList, actualList);
        }

        /// <summary>
        /// Sends bad requests for Specific Roles, SPOC, and Vendor Affiliation with User information. 
        /// </summary>
        public void TestBadRequestUsersForSpecificRoleAndSpoc() =>
            SendBadRequestUserForSpecificRoleAndSpoc("withoutDetails");

        /// <summary>
        /// Sends bad requests for Specific Roles, SPOC, and Vendor Affiliation with User Detailed information.
        /// </summary>
        public void TestBadRequestUsersForSpecificRoleAndSpocWithDetails() =>
            SendBadRequestUserForSpecificRoleAndSpoc("withDetails");

        private void SendBadRequestUserForSpecificRoleAndSpoc(string testType)
        {
            var testNameType = testType switch
            {
                "withoutDetails" =>
                    "/roles/<roleId>/objectId/<objectId>/hierarchyType/<hierarchy>/applicationId/<appId>",
                "withDetails" =>
                    "roles/{roleId}/objectId/<objectId>/hierarchyType/<hierarchy>/applicationId/<appId>/withDetails",
                _ => throw new ArgumentOutOfRangeException(nameof(testType), testType,
                    $"Unable to recognize test type: '{testType}'!")
            };

            Steps.AddTestStep(
                $"Test sending 'GET' request for {testNameType} API endpoint with bad or null values",
                "Systems should respond with the proper response code.");

            var scenarios = new List<string>()
            {
                "Blank Role ID", "Blank Object ID", "Blank Hierarchy Type", "Blank Application ID",
                "Non-Existent Role ID", "Non-Existent Object ID", "Non-Existent Hierarchy Type",
                "Non-Existent Application ID",
                "Alpha Role ID", "Alpha Object ID", "Alpha Hierarchy Type", "Alpha Application ID"
            };

            var appRole = _applicationRepository.GetApplicationRolesDbs().Where(i => !i.IsDeleted && i.IsEnabled)
                .PickRandom();
            var homeObject = _homeInfoDataDb.Where(i =>
                    i.CompanyId.Equals("1") && i.OrganizationID.Equals("1") && i.COID.ToStringOrEmpty() != string.Empty)
                .PickRandom();

            foreach (var scenario in scenarios)
            {
                var applicationId      = appRole.ApplicationId.ToString();
                var roleId             = appRole.Id.ToString();
                var hierarchyType      = "5";
                var objectId           = homeObject.COID;
                var expectedStatusCode = string.Empty;

                switch (scenario)
                {
                    case "Blank Role ID":
                        roleId             = string.Empty;
                        expectedStatusCode = BadRequestResponse; //was NotFoundResponse;
						break;
                    case "Blank Object ID":
                        objectId           = string.Empty;
                        expectedStatusCode = BadRequestResponse; //was NotFoundResponse;
						break;
                    case "Blank Hierarchy Type":
                        hierarchyType      = string.Empty;
                        expectedStatusCode = BadRequestResponse; //was NotFoundResponse;
						break;
                    case "Blank Application ID":
                        applicationId      = string.Empty;
                        expectedStatusCode = BadRequestResponse;
                        //expectedStatusCode = testType == "withDetails" ? BadRequestResponse: NotFoundResponse;
                        break;
                    case "Non-Existent Role ID":
                        roleId             = "5ba8b90f-e086-46f2-9903-0eaa893fd598";
                        expectedStatusCode = OkResponse;
                        break;
                    case "Non-Existent Object ID":
                        objectId           = "99999";
                        expectedStatusCode = OkResponse;
                        break;
                    case "Non-Existent Hierarchy Type":
                        hierarchyType      = "9";
                        expectedStatusCode = BadRequestResponse;
                        break;
                    case "Non-Existent Application ID":
                        applicationId      = "5ba8b90f-e086-46f2-9903-0eaa893fd598";
                        expectedStatusCode = OkResponse;
                        break;
                    case "Alpha Role ID":
                        roleId             = "ABC";
                        expectedStatusCode = BadRequestResponse;
                        break;
                    case "Alpha Object ID":
                        objectId           = "ABC";
                        expectedStatusCode = OkResponse;
                        break;
                    case "Alpha Hierarchy Type":
                        hierarchyType      = "ABC";
                        expectedStatusCode = BadRequestResponse;
                        break;
                    case "Alpha Application ID":
                        applicationId      = "ABC";
                        expectedStatusCode = BadRequestResponse;
                        break;
                }

                Steps.AddTestStep(
                    $"Sending 'GET' request to '{testNameType}' end point for Scenario: '{scenario}' with roleId: '{roleId}', applicationID: '{applicationId}', Hierarchy: '{hierarchyType}', and objectId: '{objectId}'.",
                    $"System should respond with Status Code: '{expectedStatusCode}'");

                var response = testType.Equals("withoutDetails")
                    ? GetUsersForSpecificRoleAndSpoc(roleId, objectId, hierarchyType, applicationId)
                    : GetUsersForSpecificRoleAndSpocWithDetails(roleId, objectId, hierarchyType, applicationId);

                if (HPGWarn.AreEqual(expectedStatusCode, response.Status, field: ResponseStatusField))
                {
                }
            }
        }

        /// <summary>
        /// Test sending 'POST' request to /roles/usersearch endpoint for with details and with out details scenarios and different hierarchies.
        /// </summary>
        /// <exception cref="ArgumentOutOfRangeException"></exception>
        public void TestPostGetUserSearchOrDetails()
        {
            var (userList, userRoleList, userSpocList) = GetTestDataFromDatabase();

            var scenarios = new List<string>() { "UserSearch with details", "UserSearch without details" };

            //Loop thru the scenarios
            foreach (var scenario in scenarios)
            {
                //loop thru the hierarchy type
                foreach (var hierarchy in EnumUtil.GetValues<HomeHierarchyType>())
                {
                    if (hierarchy.Equals(HomeHierarchyType.Organization)) continue;

                    //get randomly picked role and SPOC
                    var randomRole = userRoleList.PickRandom();

                    var facilities = userSpocList
                        .Where(i => i.Hierarchy.Equals((int)hierarchy) &&
                                    i.ApplicationId.Equals(randomRole.ApplicationId))
                        .Select(f => f.OrgObjectID).Distinct().ToList();

                    if (facilities.IsNullOrEmpty())
                    {
                        ConsoleOut.WriteReport(
                            $"No matching record(s) for the given hierarchy type: '{Enum.GetName(hierarchy)}' ,Application ID: '{randomRole.ApplicationId}', and Role: '{randomRole.Name}'.");
                        continue;
                    }

                    //choose random facility
                    var randomFacility = facilities.PickRandom();

                    //Determine test type
                    string? testName;
                    UserSearchRequest request = new UserSearchRequest
                    {
                        ApplicationId = randomRole.ApplicationId.ToString(),
                        RoleId        = randomRole.Id.ToString(),
                        HierarchyType = (int)hierarchy,
                        ObjectId      = randomFacility
                    };

                    switch (scenario)
                    {
                        case "UserSearch with details":
                            testName =
                                $"Test sending 'POST' request to '/roles/usersearch' with details endpoint for Hierarchy type: '{hierarchy}'.";
                            request.WithDetails = true;
                            break;
                        case "UserSearch without details":
                            testName =
                                $"Test sending 'POST' request to '/roles/usersearch' without details endpoint for Hierarchy type: '{hierarchy}'.";
                            request.WithDetails = false;
                            break;
                        default:
                            throw new ArgumentOutOfRangeException(nameof(scenario));
                    }

                    Steps.AddTestStep(testName, "Should respond appropriately.");
                    ConsoleOut.WriteReport(
                        $"Sending 'POST' request for ApplicationID: '{randomRole.ApplicationId}' RoleID: '{randomRole.Id}' Hierarchy Type: '{hierarchy}' and Object ID: '{randomFacility}'");

                    var expectedUserList = GetFormattedExpectedUserRoleSocVendorAffiliations(randomRole.Id,
                        randomRole.ApplicationId,
                        hierarchy, randomFacility,
                        userList, userRoleList, userSpocList, request.WithDetails);

                    var payload  = JsonConvert.SerializeObject(request);
                    var response = PostGetUserSearch(payload);

                    if (!HPGWarn.AreEqual(OkResponse, response.Status, ResponseStatusField)) continue;

                    var actualList =
                        JsonConvert.DeserializeObject<List<UserRoleSocVendorAffiliation>>(response.Response);

                    ConsoleOut.WriteReport("Validating Expected results matches actual.");
                    UserRoleSocVendorAffiliation.ValidateUserRoleSocVendorAffilitaionList(expectedUserList,
                        actualList!);
                }
            }
        }

        /// <summary>
        /// Test sending 'POST' request to /roles/usersearch endpoint with Bad Values
        /// </summary>
        /// <exception cref="ArgumentOutOfRangeException"></exception>
        public void TestPostGetUserSearchOrDetailsBadRequest()
        {
            var (_, userRoleList, userSpocList) = GetTestDataFromDatabase();
            var randomRole = userRoleList.PickRandom();
            var facility = userSpocList
                .Where(i => i.Hierarchy.Equals((int)HomeHierarchyType.Facility) &&
                            i.ApplicationId.Equals(randomRole.ApplicationId))
                .Select(f => f.OrgObjectID).Distinct().ToList().PickRandom();


            UserSearchRequest originalRequest = new UserSearchRequest
            {
                ApplicationId = randomRole.ApplicationId.ToString(),
                RoleId        = randomRole.Id.ToString(),
                HierarchyType = (int)HomeHierarchyType.Facility,
                ObjectId      = facility,
                WithDetails   = false
            };

            var scenarios = new List<string>()
            {
                "Null Application ID", "Blank Application ID", "Non-Guid Application ID","Null Role ID", "Blank Role ID", "Non-Guid Role ID", "Null Hierarchy Type", "Blank Hierarchy Type", "Alpha Hierarchy Type",
                "Null Object ID", "Blank Object ID", "Invalid Object ID","Null With Details", "Blank With Details"
            };

            foreach (var scenario in scenarios)
            {

                UserSearchRequest request = (UserSearchRequest) originalRequest.Clone();
                string            expectedResponse;
                
                switch (scenario)
                {
                    case "Null Application ID":
                        request.ApplicationId = null;
                        expectedResponse      = BadRequestResponse;
                        break;
                    case "Blank Application ID":
                        request.ApplicationId = "";
                        expectedResponse      = BadRequestResponse;
                        break;
                    case "Non-Guid Application ID":
                        request.ApplicationId = "ABCD";
                        expectedResponse      = BadRequestResponse;
                        break;
                    case "Null Role ID":
                        request.RoleId   = null;
                        expectedResponse = BadRequestResponse;
                        break;
                    case "Blank Role ID":
                        request.RoleId   = "";
                        expectedResponse = BadRequestResponse;
                        break;
                    case "Non-Guid Role ID":
                        request.RoleId = "ABCD";
                        expectedResponse = BadRequestResponse;
                        break;
                    case "Null Hierarchy Type":
                        request.HierarchyType = null;
                        expectedResponse      = BadRequestResponse;
                        break;
                    case "Blank Hierarchy Type":
                        request.HierarchyType = "";
                        expectedResponse = BadRequestResponse;
                        break;
                    case "Alpha Hierarchy Type":
                        request.HierarchyType = "A";
                        expectedResponse = BadRequestResponse;
                        break;
                    case "Null Object ID":
                        request.ObjectId = null;
                        expectedResponse = BadRequestResponse;
                        break;
                    case "Blank Object ID":
                        request.ObjectId = "";
                        expectedResponse = BadRequestResponse;
                        break;
                    case "Invalid Object ID":
                        request.ObjectId = "A";
                        expectedResponse = OkResponse;
                        break;
                    case "Null With Details":
                        request.WithDetails = null;
                        expectedResponse    = OkResponse; 
                        break;
                    case "Blank With Details":
                        request.WithDetails = "";
                        expectedResponse    = BadRequestResponse;
                        break;
                    default:
                        throw new ArgumentOutOfRangeException(nameof(scenario));
                }

                Steps.AddTestStep($"Test Sending 'POST' request to '/roles/usersearch' for Bad Request Scenario {scenario}.",$"System Should respond with a {expectedResponse} response.");

                var payload = JsonConvert.SerializeObject(request, JsonNullSetting);
                ConsoleOut.WriteReport($"Payload: {payload}");

                var response = PostGetUserSearch(payload);

                HPGWarn.AreEqual(expectedResponse, response.Status, ResponseStatusField);

            }
        }

        /// <summary>
        /// Test sending 'POST' request to /users/details endpoint for various scenarios.
        /// </summary>
        /// <param name="userType"></param>
        /// <exception cref="ArgumentOutOfRangeException"></exception>
        public void TestPostGetUserDetails(string userType)
        {
            var (userList, userRoleList, userSpocList) = GetTestDataFromDatabase();
            Steps.AddTestStep("testName", "Should respond appropriately.");

            var testScenarios = new List<string>()
            {
                "Details with roles, SOC, and Vendors", 
                "Details with SOC", 
                "Details with roles",
                "Details with Vendors", 
                "Details with roles and SOC", 
                "Details with roles and Vendors",
                "Details with SOC and Vendors",
				"Details without roles, SOC, and Vendors" 
            };

            //get randomly picked role and SPOC 
            var (randomRole, user, request) = GetTestUser(userType, userRoleList, userList);

            //get expected response
            UserRoleSocVendorAffiliation originalExpected =
                RetrieveExpectedUserRoleSocVendorAffiliation(user, randomRole, userRoleList, userSpocList);

            //Loop thru the test scenarios.
            foreach (var testScenario in testScenarios)
            {
                string?                      testName;
                UserRoleSocVendorAffiliation expectedFormatted = (UserRoleSocVendorAffiliation)originalExpected.Clone();

                switch (testScenario)
                {
                    case "Details with roles, SOC, and Vendors":
                        testName =
                            "Test sending 'POST' request to '/users/details' with roles, SOC, and Vendors endpoint";
                        
                        request.WithDetails = true;
                        request.WithRoles   = true;
                        request.WithSoc     = true;
                        request.WithVendors = true;
                        break;
                    case "Details with SOC": //Actual: '(401) Unauthorized' todo: double check these in POSTMAN
						testName =
                            "Test sending 'POST' request to '/users/details' with SOC and without roles and Vendors endpoint";
                        request.WithDetails           = true;
                        request.WithRoles             = false;
                        request.WithSoc               = true;
                        request.WithVendors           = false;
                        expectedFormatted.RoleModel   = new List<GeneralIdNameResponse>();
                        expectedFormatted.VendorModel = new List<ScVendorModel>();
                        break;
                    case "Details with roles": //Actual: '(401) Unauthorized'
						testName =
                            "Test sending 'POST' request to '/users/details' with roles and without SOC and Vendors endpoint";
                        request.WithDetails           = true;
                        request.WithRoles             = true;
                        request.WithSoc               = false;
                        request.WithVendors           = false;
                        expectedFormatted.SOCModel    = new List<SpanOfControl>();
                        expectedFormatted.VendorModel = new List<ScVendorModel>();
                        break;
                    case "Details with Vendors": //Actual: '(401) Unauthorized'
						testName =
                            "Test sending 'POST' request to '/users/details' with Vendors and without SOC and roles endpoint";
                        request.WithDetails         = true;
                        request.WithRoles           = false;
                        request.WithSoc             = false;
                        request.WithVendors         = true;
                        expectedFormatted.RoleModel = new List<GeneralIdNameResponse>();
                        expectedFormatted.SOCModel  = new List<SpanOfControl>();
                        break;
                    case "Details with roles and SOC":  //Actual: '(401) Unauthorized'
						testName =
                            "Test sending 'POST' request to '/users/details' with roles and SOC and without vendors endpoint";
                        request.WithDetails           = true;
                        request.WithRoles             = true;
                        request.WithSoc               = true;
                        request.WithVendors           = false;
                        expectedFormatted.VendorModel = new List<ScVendorModel>();
                        break;
                    case "Details with roles and Vendors": //Actual: '(401) Unauthorized'
						testName =
                            "Test sending 'POST' request to '/users/details' with roles and Vendors and without SOC endpoint";
                        request.WithDetails        = true;
                        request.WithRoles          = true;
                        request.WithSoc            = false;
                        request.WithVendors        = true;
                        expectedFormatted.SOCModel = new List<SpanOfControl>();
                        break;
                    case "Details with SOC and Vendors": //Actual: '(401) Unauthorized'
						testName =
                            "Test sending 'POST' request to '/users/details' with SOC and Vendors and without roles endpoint";
                        request.WithDetails         = true;
                        request.WithRoles           = false;
                        request.WithSoc             = true;
                        request.WithVendors         = true;
                        expectedFormatted.RoleModel = new List<GeneralIdNameResponse>();
                        break;
                    case "Details without roles, SOC, and Vendors": //Actual: '(401) Unauthorized'
						testName =
                            "Test sending 'POST' request to '/users/details' without roles, SOC, and Vendors endpoint";
                        request.WithDetails           = true;
                        request.WithRoles             = false;
                        request.WithSoc               = false;
                        request.WithVendors           = false;
                        expectedFormatted.RoleModel   = new List<GeneralIdNameResponse>();
                        expectedFormatted.SOCModel    = new List<SpanOfControl>();
                        expectedFormatted.VendorModel = new List<ScVendorModel>();
                        break;
                    default:
                        throw new ArgumentOutOfRangeException(nameof(testScenario));
                }

                Steps.AddTestStep($"{testName} for user type: {userType}. Request - AppId: {request.AppId}, Username: {request.UserName}, Email: {request.Email}", "System should respond appropriately");

                var response = PostGetUserDetails(JsonConvert.SerializeObject(request));
                if (!HPGWarn.AreEqual(OkResponse, response.Status, ResponseStatusField)) continue;

                var actual = JsonConvert.DeserializeObject<UserRoleSocVendorAffiliation>(response.Response);

                ConsoleOut.WriteReport("Validating Expected results matches actual.");
                expectedFormatted.Validate(actual);

                ConsoleOut.WriteReport("Validating Actual results matches expected.");
                actual.Validate(expectedFormatted);
            }
        }

        /// <summary>
        /// Test sending 'POST' request to /users/details endpoint with Bad Values
        /// </summary>
        public void TestPostGetUserDetailsBadRequest()
        {
            var (userList, userRoleList, _) = GetTestDataFromDatabase();
            
            //get randomly picked role and SPOC 
            var (_, _, request) = GetTestUser("employee", userRoleList, userList);
            request.WithRoles = true;
            request.WithSoc = true;
            request.WithVendors = true;
            request.WithDetails = true;

            var scenarios = new List<string> { "null UserName", "blank UserName", "null email", "blank email", "null domain", "blank domain", 
	            "null appId", "blank appId", "Non-Guid appId", "null withRoles", "blank withRoles", "null withSoc", 
	            "blank withSoc", "null withVendors", "blank withVendors", "null email & username", "null email & domain","null email, domain, & username", 
	            "null domain & username", "user not found", "temp access" };

            foreach (var scenario in scenarios)
            {
                UserDetailRequest testRequest = (UserDetailRequest)request.Clone();
                string            expectedResponse;

                switch (scenario)
                {
                    case "null UserName":
                        testRequest.UserName = null;
                        expectedResponse     = OkResponse;
                        break;
                    case "blank UserName":
                        testRequest.UserName = "";
                        expectedResponse     = OkResponse;
                        break;
                    case "null email":
                        testRequest.Email = null;
                        expectedResponse  = OkResponse;
                        break;
                    case "blank email":
                        testRequest.Email = "";
                        expectedResponse  = OkResponse;
                        break;
                    case "null domain":
                        testRequest.Domain = null;
                        expectedResponse   = OkResponse;
                        break;
                    case "blank domain":
                        testRequest.Domain = "";
                        expectedResponse   = OkResponse;
                        break;
                    case "null appId":
                        testRequest.AppId = null;
                        expectedResponse  = OkResponse;
                        break;
                    case "blank appId":
                        testRequest.AppId = "";
                        expectedResponse  = BadRequestResponse;
                        break;
                    case "Non-Guid appId":
                        testRequest.AppId = "ABCD";
                        expectedResponse  = BadRequestResponse;
                        break;
                    case "null withRoles":
                        testRequest.WithRoles = null;
                        expectedResponse     = OkResponse;
                        break;
                    case "blank withRoles":
                        testRequest.WithRoles = "";
                        expectedResponse      = BadRequestResponse;
                        break;
                    case "null withSoc":
                        testRequest.WithSoc = null;
                        expectedResponse    = OkResponse;
                        break;
                    case "blank withSoc":
                        testRequest.WithSoc = "";
                        expectedResponse    = BadRequestResponse;
                        break;
                    case "null withVendors":
                        testRequest.WithVendors = null;
                        expectedResponse     = OkResponse;
                        break;
                    case "blank withVendors":
                        testRequest.WithVendors = "";
                        expectedResponse        = BadRequestResponse;
                        break;
                    case "null email & username":
                        testRequest.UserName = null;
                        testRequest.Email    = null;
                        expectedResponse     = BadRequestResponse;
                        break;
                    case "null email & domain":
                        testRequest.Domain = null;
                        testRequest.Email    = null;
                        expectedResponse     = BadRequestResponse;
                        break;
                    case "null email, domain, & username":
                        testRequest.UserName = null;
                        testRequest.Domain   = null;
                        testRequest.Email    = null;
                        expectedResponse     = BadRequestResponse;
                        break;
                    case "null domain & username":
                        testRequest.Domain = null;
                        testRequest.UserName = null;
                        expectedResponse     = OkResponse;
                        break;
                    case "user not found":
                        testRequest.UserName = "1april.caldwell@davita.ZZZ";
                        testRequest.Email = "1april.caldwell@davita.ZZZ";
                        testRequest.Domain = "nonaffil";
                        testRequest.AppId = "E68AB150-F05F-49BF-8C91-5EC4494FFD4C";
                        testRequest.WithRoles = true;
                        testRequest.WithSoc = true;
                        testRequest.WithVendors = true;
                        testRequest.WithDetails = true;
                        expectedResponse = NotFoundResponse;
                        break;
                    case "temp access":
	                    testRequest.UserName = "96393003-a60c-484c-adea-5c94cf58a334";
	                    testRequest.Email = "testvpro10@abc.com";
	                    testRequest.Domain = "nonaffil";
	                    testRequest.AppId = "E68AB150-F05F-49BF-8C91-5EC4494FFD4C";
	                    testRequest.WithRoles = true;
	                    testRequest.WithSoc = true;
	                    testRequest.WithVendors = true;
	                    testRequest.WithDetails = true;
						expectedResponse = NotAuthorizedResponse;
						break;
                    default:
                        throw new ArgumentOutOfRangeException(nameof(scenario));
                }

                Steps.AddTestStep($"Test Sending 'POST' request to '/users/details' for Bad Request Scenario {scenario}.", $"System Should respond with a {expectedResponse} response.");

                var payload = JsonConvert.SerializeObject(testRequest, JsonNullSetting);
                ConsoleOut.WriteReport($"Payload: {payload}");

                var response = PostGetUserDetails(payload);

                HPGWarn.AreEqual(expectedResponse, response.Status, ResponseStatusField);
            }

        }

		/// <summary>
		/// This test method, `TestPostVproGetUserVPROBadgeInDetailsAsync`, verifies the behavior of the API endpoint `/vpro/GetUserVPROBadgeInDetailsAsync` for different scenarios.
		/// It tests two scenarios:
		/// 1. BadRequest: Sends a POST request with an empty `UserName` and expects a BadRequest response.
		/// 2. GoodRequest: Sends a POST request with a valid `UserName` and expects an OK response: VproActive49.TestUser@mailinator.com
        /// If it fails check to see if the account has been altered or disabled.
		/// The method serializes the request payload, sends the POST request, and asserts that the response status matches the expected response for each scenario.
		/// </summary>
		public void TestPostVproGetUserVPROBadgeInDetailsAsync()
		{
			var scenarios = new List<string> { "BadRequest", "GoodRequest" };

			foreach (var scenario in scenarios)
			{
				var (expectedResponse, request) = scenario switch
				{
					"BadRequest" => (BadRequestResponse, new BadgeInRequest { UserName = "" }),
					//Vpro Specific Test user that exists in all environments do not alter.
					"GoodRequest" => (OkResponse, new BadgeInRequest { UserName = "9a9d71e4-0a1d-49cb-9418-c61ff28a2ee2" }),
					_ => throw new ArgumentOutOfRangeException(nameof(scenario), scenario, null)
				};

				Steps.AddTestStep($"Test Sending 'POST' request to '/vpro/GetUserVPROBadgeInDetailsAsync' for Scenario {scenario}.", $"System Should respond with a {expectedResponse} response.");

				var payload = JsonConvert.SerializeObject(request, JsonNullSetting);
				ConsoleOut.WriteReport($"Payload: {payload}");

				var response = PostGetUserVproBadgeInDetails(payload);

				HPGWarn.AreEqual(expectedResponse, response.Status, ResponseStatusField);
			}

		}

		/// <summary>
		/// Tests the 'GET' /users/detailsByUsername API endpoint for different scenarios.
		/// It sends requests with a blank username, a valid vendor username, and a valid employee username,
		/// then checks that the response status matches the expected result for each scenario.
		/// If the response is OK, it prints the formatted response body.
		/// </summary>
		public void TestGetUsersDetailsByUsername()
        {
            var scenarios = new List<string> { "blank UserName", "valid vendor", "valid employee" };
			
            //Get Random usernames from database
            
			foreach (var scenario in scenarios)
            {

				var (expectedResponse, requestUserName) = scenario switch
				{
					"blank UserName" => (BadRequestResponse,  ""),
					"valid vendor" => (OkResponse, "chuck.Norris@gmail.zzz"),   //VPRO Account
                    "valid employee" => (OkResponse, "HTNASVCTSTAUT02"),        //Service Account
					_ => throw new ArgumentOutOfRangeException(nameof(scenario), scenario, null)
				};

				Steps.AddTestStep($"Test Sending 'GET' request to 'users/detailsByUsername' for Scenario {scenario}: {requestUserName}.", $"System Should respond with a {expectedResponse} response.");
                //var payload = JsonConvert.SerializeObject(requestUserName, JsonNullSetting);
				ConsoleOut.WriteReport($"Payload: {requestUserName}");

				var apiResponse = GetUsersDetailsByUsername(requestUserName);

				HPGWarn.AreEqual(expectedResponse, apiResponse.Status, ResponseStatusField);

                if (apiResponse.Status == OkResponse)
                {
					var reply = apiResponse.Response.Replace("{", "\n        {");
					reply = reply.Replace(",", ",\n        ");
					ConsoleOut.WriteReport("Response Body:", true);
					ConsoleOut.WriteReport(reply, true);
					ConsoleOut.WriteReport("\n", true);
				}
			}
        }

		/// <summary>
		/// Tests the 'POST' /roles/userSearchByRoleAndCoid endpoint with valid and invalid request bodies.
		/// Includes a positive test case (valid roleKey and coid) and two negative test cases (invalid/missing values).
		/// </summary>
		public void TestPostUserSearchByRoleAndCoid()
		{
			// Prepare test data
			var validRole = _applicationRepository.GetApplicationRolesDbs().FirstOrDefault(r => !r.IsDeleted && r.Id != Guid.Empty);
			var validCoid = _homeInfoDataDb.FirstOrDefault(h => !string.IsNullOrEmpty(h.COID))?.COID;

			var testCases = new[]
			{
        // Positive test case: valid roleKey and coid
        new
		{
			Name = "Valid roleKey and coid",
			Request = new { roleKey = validRole?.Id.ToString(), coid = validCoid },
			ExpectedStatus = OkResponse
		},
        // Negative test case: invalid roleKey
        new
		{
			Name = "Invalid roleKey",
			Request = new { roleKey = "invalid-guid", coid = validCoid },
			ExpectedStatus = BadRequestResponse
		},
        // Negative test case: missing coid
        new
		{
			Name = "Missing coid",
			Request = new { roleKey = validRole?.Id.ToString(), coid = (string?)null },
			ExpectedStatus = BadRequestResponse
		}
	};

			foreach (var testCase in testCases)
			{
				Steps.AddTestStep(
					$"POST /roles/userSearchByRoleAndCoid - Payload: {testCase.Name}",
					$"Should respond with {testCase.ExpectedStatus}."
				);

				var payload = JsonConvert.SerializeObject(testCase.Request);
				ConsoleOut.WriteReport($"Payload: {payload}");

				var response = PostSimpleRequest(
					$"{_baseUri}{UserResource}{UserSearchByRoleAndCoid}",
					payload,
					AuthenticationType
				);

				HPGWarn.AreEqual(testCase.ExpectedStatus, response.Status, ResponseStatusField);

				if (response.Status == OkResponse)
				{
					var formattedResponse = response.Response
						.Replace("{", "\n        {")
						.Replace(",", ",\n        ");
					ConsoleOut.WriteReport("Response Body:", true);
					ConsoleOut.WriteReport(formattedResponse, true);
					ConsoleOut.WriteReport("\n", true);
				}
			}
		}

		/// <summary>
		/// Runs a suite of VPRO API client authentication tests by invoking the VproApi test methods:
		/// TestPostVproActiveUser, TestPostVproUserStatusCheck, and TestPostVproGetCredentialingRequest.
		/// </summary>
		public void TestClientAuthVproApis()
		{
			var vproApi = new VproApi();
			vproApi.TestPostVproActiveUser();
			vproApi.TestPostVproUserStatusCheck();
			vproApi.TestPostVproGetCredentialingRequest();

		}

		/// <summary>
		/// Tests the 'GET' /users/{username}/apps/{appId}/socleaflevel API endpoint for different scenarios.
		/// It sends requests with a valid user and appId, an invalid appId, and an invalid user,
		/// then checks that the response status matches the expected result for each test case.
		/// If the response is OK, it prints the formatted response body.
		/// The endpoint pulls from Smart Legacy as well to display Soc Leaf Level information.
		/// </summary>
		public void TestGetSocLeafLevel()
		{
			// Prepare test data
			var testCases = new[]
			{
				new { TestCaseName = "ValidUserAppId", Username = "HTNASVCTSTAUT51", AppId = "E68AB150-F05F-49BF-8C91-5EC4494FFD4C", Expected = OkResponse},
				new { TestCaseName = "InValidAppId", Username = "HTNASVCTSTAUT51", AppId = "E68AB150-F05F-49BF-8C91-5EC4494FFD21", Expected = OkResponse },//BadRequestResponse
                new { TestCaseName = "InValidUser", Username = "HTNASVCTSTAUT99", AppId = "E68AB150-F05F-49BF-8C91-5EC4494FFD4C", Expected = InternalServerResponse },
			};

			foreach (var testCase in testCases)
			{
				Steps.AddTestStep($"GET /users/{testCase.Username}/apps/{testCase.AppId}/socleaflevel - TestCase: {testCase.TestCaseName}", $"Should respond with {testCase.Expected}.");
				var response = GetUsersAppsSocLeafLevel(testCase.Username, testCase.AppId);
				HPGWarn.AreEqual(testCase.Expected, response.Status, ResponseStatusField);
				if (response.Status == OkResponse)
				{
					var formattedResponse = response.Response
						.Replace("{", "\n        {")
						.Replace(",", ",\n        ");

					Steps.AddTestStep($"Smart Legacy Results (formatted)", $"Response Body: {formattedResponse}");
					//ConsoleOut.WriteReport("Response Body:", true);
					//ConsoleOut.WriteReport(formattedResponse, true);
					//ConsoleOut.WriteReport("\n", true);
				}
			}
		}

		/// <summary>
		/// Tests the 'POST' /SelfProvision/VendorAdminNotification endpoint with various scenarios.
		/// Validates request handling for missing required fields (FirstName, LastName, Email, VproUserEmailId, 
		/// VAdminNotifyList, VendorAffiliations), different request types (INV/VBO), and successful notifications.
		/// Verifies that the API responds with appropriate status codes and sends email notifications to 
		/// marlon.cuevas@HealthTrustpg.com for valid requests.
		/// </summary>
		public void TestPostSelfProvisionVendorAdminNotification()
        {

            var scenarios = new List<string> {"ValidRequest", "MissingFirstName", "MissingLastName", "MissingEmail","MissingVproUserEmailId",
        "MissingAdminNotifyList", "MissingVendorAffiliations","RandomRequestType", "VboRequest"};
            foreach (var scenario in scenarios)
            {
				var testPrefix = scenario is "VboRequest" or "RandomRequestType" ? "VBO_" : "INV_";
                string expectedResponse = BadRequestResponse;
				string fname = testPrefix + "AutomationTest";
				string lname = "User_" + DateTime.Now.ToString("MMddHHmmss");

				// Generate a full value request
				VendorAdminNotificationRequest request = new VendorAdminNotificationRequest
                {   //First par is all requestors information.
                    FirstName = fname,
                    LastName = lname,
                    Email = $"{fname}.{lname}@SelfProvisionVendorAdminNotification.com",
                    VproUserEmailId = $"{fname}.{lname}@SelfProvisionVendorAdminNotification.com",
                    VAdminNotifyList = new List<VendorAdminNotificationItem>
                    {
                        new VendorAdminNotificationItem
                        {
                            FirstName = "Marlon",
                            LastName = "Cuevas",
                            Email = "Marlon.Cuevas@HealthTrustpg.com",
                            Facilities = new List<FacilityInfo>
                            {
                                new FacilityInfo { Coid = "34222", OrgName = "Centennial Medical Center" },
                                new FacilityInfo { Coid = "09391", OrgName = "Stonecrest Medical Center" }
                            }
                        }
                    },
                    VendorAffiliations = new List<VendorAffiliation>
                    {
                        new VendorAffiliation { SNV = "900600", VendorName = "CAPITAL X-RAY" },
                        new VendorAffiliation { SNV = "900200", VendorName = "DEPUY SYNTHES (JOINT RECONST)" }
                    },
                    RequestType = scenario == "VboRequest" ? "VBO" : "INV"
                };

				switch (scenario)
                {
                    case "ValidRequest":
						expectedResponse = OkResponse;
						break;
                    case "MissingFirstName":
						//set first name to null to simulate missing first name scenario
                        request.FirstName = null;
						break;
                    case "MissingLastName":
						//set last name to null to simulate missing last name scenario
                        request.LastName = null;
						break;
                    case "MissingEmail":
						//set email to null to simulate missing email scenario
                        request.Email = null;
						break;
                    case "MissingVproUserEmailId":
						//set vpro user email id to null to simulate missing vpro user email id scenario
                        request.VproUserEmailId = null;
						break;
                    case "MissingAdminNotifyList":
						//set admin notify list to null to simulate missing admin notify list scenario
                        request.VAdminNotifyList = null;
						break;
                    case "MissingVendorAffiliations":
                    	//set vendor affiliations to null to simulate missing vendor affiliations scenario
                        request.VendorAffiliations = null;
                        break;
                    case "RandomRequestType":
						//set request type to a random value to simulate random request type scenario will default to VBO
						expectedResponse = OkResponse;
						request.RequestType = "BAD";
						break;
                    case "VboRequest":
						expectedResponse = OkResponse;
                        break;
					default:
                        throw new ArgumentOutOfRangeException(nameof(scenario));
                }
				Steps.AddTestStep($"Test Sending 'POST' request to '/SelfProvision/VendorAdminNotification' for Scenario {scenario}.",
		            $"System Should respond with a {expectedResponse} response AND Send a Notfication email to marlon.cuevas@HealthTrustpg.com");

				var payload = JsonConvert.SerializeObject(request, JsonNullSetting);
				ConsoleOut.WriteReport($"Payload: {payload}");

				var response = PostSelfService(VendorAdminNotificationResource, payload);

				HPGWarn.AreEqual(expectedResponse, response.Status, ResponseStatusField);
				ValidateSelfProvisionVendorAdminNotificationErrorMsg(response.Response, scenario);

			}
        }

		/// <summary>
		/// Tests the 'POST' /SelfProvision/VboRequestResponseNotification endpoint across multiple scenarios.
		/// Validates request handling for missing/invalid fields (Email, Subject, FirstName, LastName, MessageType),
		/// different message types (1=Progress, 2=Reject, 3=Complete), optional fields (MatchedFacilities, 
		/// MatchedVendors, UnmatchedFacilities, UnmatchedVendors, Comments), and request types (INV/VBO).
		/// Verifies appropriate status codes (200 OK, 400 BadRequest, 500 InternalServerError) and error messages
		/// for each test case, ensuring notification emails are sent correctly for valid requests.
		/// </summary>
		public void TestPostSelfProvisionVboRequestResponseNotification()
        {
			//
			Steps.AddTestStep("Test sending 'POST' request to '/SelfProvision/VboRequestResponseNotification' endpoint for various scenarios",
				"System should respond with appropriate status codes and messages");

			var scenarios = new List<string>
	        {
		        "MissingEmail", "InvalidEmail", "MissingSubject", "SubjectAnyValue",
		        "MissingFirstName", "FirstNameAnyValue", "MissingLastName", "LastNameAnyValue",
		        "MissingMessageType", "MsgType1ProgressInv", "MsgType2RejectInv", "MsgType3CompleteInv",
		        "MsgType1ProgressVbo", "MsgType2RejectVbo", "MsgType3CompleteVbo", "MsgTypeAnyOther4",
		        "MissingMatchedFacilities", "MissingMatchedVendors", "MissingUnmatchedFacilities",
		        "MissingUnmatchedVendors", "MissingComments", "MissingRequestType"
	        };

			foreach (var scenario in scenarios)
			{
				Steps.AddTestStep($"Preparing test data for scenario: {scenario}",
					"Should construct appropriate request payload");

				string expectedResponse;
				string fname = "AutomationTest";
				string lname = "User_" + DateTime.Now.ToString("MMMM dd, HHmm") + "hrs";
				string subject = GlobalTestVariables.TestEnvironment == "qasbx"
					? "Processing Request - QASBX TEST MsgType: "
					: "Processing Request - QA TEST MsgType: ";

				// Generate a full value request
				var request = new VboRequestResponseNotificationRequest
				{
					Email = "marlon.cuevas@healthtrustpg.com",
					Subject = subject,
					FirstName = fname,
					LastName = lname,
					MessageType = 3,
					MatchedFacilities = new List<MatchedFacility>
			        {
				        new MatchedFacility
				        {
					        Coid = "11111",
					        OrgName = "SESAME STREET",
					        StatusTypeId = 3,
					        Comments = null
				        },
				        new MatchedFacility
				        {
					        Coid = "22222",
					        OrgName = "NETFLIX",
					        StatusTypeId = 3,
					        Comments = null
				        }
			        },
					MatchedVendors = new List<MatchedVendor>
			        {
				        new MatchedVendor
				        {
					        Id = 123,
					        Name = "Sunset Orthapedic Center",
					        InactivateDate = null,
					        Comments = null
				        },
				        new MatchedVendor
				        {
					        Id = 222,
					        Name = "Silverman Retirement Facilities",
					        InactivateDate = null,
					        Comments = null
				        }
			        },
					UnmatchedFacilities = new List<UnmatchedFacility>
			        {
				        new UnmatchedFacility
				        {
					        Coid = "12345",
					        OrgName = "Retired Facility",
					        StatusTypeId = 4,
					        Comments = null
				        },
				        new UnmatchedFacility
				        {
					        Coid = "12345",
					        OrgName = "Another Facility Name",
					        StatusTypeId = 4,
					        Comments = null
				        },
				        new UnmatchedFacility
				        {
					        Coid = "12345",
					        OrgName = "Nashville Electric Service",
					        StatusTypeId = 4,
					        Comments = null
				        }
			        },
					UnmatchedVendors = new List<UnmatchedVendor>
			        {
				        new UnmatchedVendor
				        {
					        Id = 1,
					        Name = "unmatched vendor 1",
					        InactivateDate = null,
					        Comments = null
				        },
				        new UnmatchedVendor
				        {
					        Id = 1,
					        Name = "unmatched vendor 2",
					        InactivateDate = null,
					        Comments = null
				        }
			        },
					Comments = "This test is coming from a lower environment",
					RequestType = "INV"
				};

				Steps.AddTestStep($"Modifying request for scenario: {scenario}","Should set appropriate values based on test case");

				switch (scenario)
				{
					case "MissingEmail":
						request.Email = null;
						expectedResponse = BadRequestResponse;
						break;
					case "InvalidEmail":
						request.Email = "invalid-email-format";
						expectedResponse = InternalServerResponse;
						break;
					case "MissingSubject":
						request.Subject = null;
						expectedResponse = BadRequestResponse;
						break;
					case "SubjectAnyValue":
						request.Subject = "Any Subject Value Test ";
						expectedResponse = OkResponse;
						break;
					case "MissingFirstName":
						request.FirstName = null;
						expectedResponse = BadRequestResponse;
						break;
					case "FirstNameAnyValue":
						request.FirstName = "TestFirstName";
						expectedResponse = OkResponse;
						break;
					case "MissingLastName":
						request.LastName = null;
						expectedResponse = BadRequestResponse;
						break;
					case "LastNameAnyValue":
						request.LastName = "TestLastName";
						expectedResponse = OkResponse;
						break;
					case "MissingMessageType":
						request.MessageType = null;
						expectedResponse = InternalServerResponse;
						break;
					case "MsgType1ProgressInv":
						request.MessageType = 1;
						request.RequestType = "INV";
						expectedResponse = OkResponse;
						break;
					case "MsgType2RejectInv":
						request.MessageType = 2;
						request.RequestType = "INV";
						expectedResponse = OkResponse;
						break;
					case "MsgType3CompleteInv":
						request.MessageType = 3;
						request.RequestType = "INV";
						expectedResponse = OkResponse;
						break;
					case "MsgType1ProgressVbo":
						request.MessageType = 1;
						request.RequestType = "VBO";
						expectedResponse = OkResponse;
						break;
					case "MsgType2RejectVbo":
						request.MessageType = 2;
						request.RequestType = "VBO";
						expectedResponse = OkResponse;
						break;
					case "MsgType3CompleteVbo":
						request.MessageType = 3;
						request.RequestType = "VBO";
						expectedResponse = OkResponse;
						break;
					case "MsgTypeAnyOther4":
						request.MessageType = 4;
						expectedResponse = InternalServerResponse;
						break;
					case "MissingMatchedFacilities":
						request.MatchedFacilities = null;
						expectedResponse = OkResponse;
						break;
					case "MissingMatchedVendors":
						request.MatchedVendors = null;
						expectedResponse = OkResponse;
						break;
					case "MissingUnmatchedFacilities":
						request.UnmatchedFacilities = null;
						expectedResponse = OkResponse;
						break;
					case "MissingUnmatchedVendors":
						request.UnmatchedVendors = null;
						expectedResponse = OkResponse;
						break;
					case "MissingComments":
						request.Comments = null;
						expectedResponse = OkResponse;
						break;
					case "MissingRequestType":
						request.RequestType = null;
						expectedResponse = OkResponse;
						break;
					default:
						throw new ArgumentOutOfRangeException(nameof(scenario));
				}
				//Update the Subject that includes the message type for better email identification in the inbox
                if (scenario != "MissingSubject" && scenario != "SubjectAnyValue" && scenario != "MissingRequestType")
					request.Subject = subject + (request.MessageType ?? 0) +" " +request.RequestType;

				Steps.AddTestStep($"Sending 'POST' request to '/SelfProvision/VboRequestResponseNotification' for scenario: {scenario}",
					$"System should respond with {expectedResponse} status code");

				var payload = JsonConvert.SerializeObject(request, JsonNullSetting);
				ConsoleOut.WriteReport($"Payload: {payload}");

				var response = PostSelfService(VboRequestResponseNotificationResource, payload);

				Steps.AddTestStep($"Validating response status for scenario: {scenario}",
					$"Should match expected status: {expectedResponse}");

				HPGWarn.AreEqual(expectedResponse, response.Status, ResponseStatusField);
				ValidateVboRequestResponseNotificationMessage(response.Response, response.Status, scenario);
			}
		}

		/// <summary>
		/// Tests the Client Auth: /api/SelfProvision/ingest endpoint for various scenarios, including positive and negative cases.
		/// Validates input validation, error handling, and expected API responses for the ingest self-provisioning feature.
		/// </summary>
		public void TestSelfProvisionIngest()
		{
			Steps.AddTestStep("Test sending 'POST' SelfProvision Ingest requests to " + IngestResource + " API endpoint.", "System should respond accordingly.");

			var scenarios = new List<string>
	        {
                "RequestVbo", "FailEverything",
                "MissingFirstName", "MissingLastName", "MissingEmail",
		        "MissingStatusTypeId",
                "InvalidStatusTypeId", "MissingVproStatus", 
                "MissingVproUserEmailId", "MissingCorrelationId", "MissingFacilities", "MissingVendorAffiliations",
                "MissingComment", "MissingRequestType", "CorrilationIdFailure"
            };

			// Store the correlationId from RequestVbo for reuse in CorrilationIdFailure
			string? requestVboCorrelationId = null;

			foreach (var scenario in scenarios)
			{
				Steps.AddTestStep($"Preparing test data for scenario: {scenario}", "Should construct appropriate request payload");

				// Generate base request with all valid data
				var request = CreateBaseIngestRequest(scenario);

				// Modify request and set expected response based on scenario
				var (expectedResponse, correlationId) = ConfigureIngestScenario(scenario, request, requestVboCorrelationId);

				// Store correlationId for CorrilationIdFailure scenario
				if (scenario == "RequestVbo")
					requestVboCorrelationId = correlationId;


				var formattedRequest = JsonConvert.SerializeObject(request, Formatting.Indented);
				Steps.AddTestStep($"Sending 'POST' request with scenario: {scenario} - Request: {formattedRequest}", $"Expected status: {expectedResponse}");

				var payload = JsonConvert.SerializeObject(request);
				var response = PostSelfService(IngestResource, payload);

				Steps.AddTestStep($"Validating response status for scenario: {scenario}", $"Should match expected status: {expectedResponse}");
				HPGWarn.AreEqual(expectedResponse, response.Status, field: ResponseStatusField);

				Steps.AddTestStep($"{scenario} Response Body", response.Response);

				// Validate specific response details for successful requests
				if (expectedResponse == OkResponse)
					ValidateIngestSuccessResponse(response, scenario);
				else
					ValidateIngestErrorResponse(response, scenario, expectedResponse);
			}

			Steps.AddTestStep("Completed TestSelfProvisionIngest method with all test scenarios.", "All test cases executed successfully.");
		}

		/// <summary>
		/// Test 'GET' request for API endpoint /VendorAdmins with facility and requestType parameters.
		/// </summary>
		public void TestGetVendorAdmins()
		{
			Steps.AddTestStep(
				"Test sending 'GET' request to /VendorAdmins API endpoint with various scenarios.",
				"System should respond accordingly.");

			var scenarios = new List<string>
	            {
		            "Valid VBO Request",
		            "Valid INV Request",
		            "Missing Facility",
		            "Missing RequestType",
		            "Invalid Facility",
		            "Invalid RequestType",
		            "Blank Facility",
		            "Blank RequestType"
	            };

			foreach (var scenario in scenarios)
			{
				string? facility;
				string? requestType;
				string expectedResponseStatus;

				switch (scenario)
				{
					case "Valid VBO Request":
						facility = "34372";
						requestType = "VBO";
						expectedResponseStatus = OkResponse;
						break;
					case "Valid INV Request":
						facility = "34372";
						requestType = "INV";
						expectedResponseStatus = OkResponse;
						break;
					case "Missing Facility":
						facility = null;
						requestType = "VBO";
						expectedResponseStatus = InternalServerResponse;
						break;
					case "Missing RequestType":
						facility = "34372";
						requestType = null;
						expectedResponseStatus = BadRequestResponse;
						break;
					case "Invalid Facility":
						facility = "99999";
						requestType = "VBO";
						expectedResponseStatus = OkResponse;
						break;
					case "Invalid RequestType":
						facility = "34372";
						requestType = "INVALID";
						expectedResponseStatus = OkResponse;
						break;
					case "Blank Facility":
						facility = "";
						requestType = "VBO";
						expectedResponseStatus = InternalServerResponse;
						break;
					case "Blank RequestType":
						facility = "34372";
						requestType = "";
						expectedResponseStatus = BadRequestResponse;
						break;
					default:
						//throw new ArgumentOutOfRangeException(nameof(scenario), scenario, $"Unable to recognize test scenario: '{scenario}'!");
						throw new ArgumentOutOfRangeException(nameof(scenario));
				}

				Steps.AddTestStep(
					$"Sending 'GET' request to /VendorAdmins with Facility: '{facility}' and RequestType: '{requestType}' for scenario: '{scenario}'.",
					$"System should respond with a {expectedResponseStatus}.");

				var response = GetVendorAdmins(facility, requestType);

				if (!HPGWarn.AreEqual(expectedResponseStatus, response.Status, field: ResponseStatusField))
					continue;

				if (response.Status == OkResponse)
				{
					var formattedResponse = response.Response
						.Replace("{", "\n        {")
						.Replace(",", ",\n        ");
					ConsoleOut.WriteReport("Response Body:", true);
					ConsoleOut.WriteReport(formattedResponse, true);
					ConsoleOut.WriteReport("\n", true);

					ValidateVendorAdminsResponse(response.Response, scenario);
				}
			}
		}

		#endregion Test Methods

		#region Validations
		/// <summary>
		/// Validates the VendorAdmins response body structure and content.
		/// </summary>
		/// <param name="responseBody">The JSON response body as string</param>
		/// <param name="scenario">The test scenario name</param>
		private void ValidateVendorAdminsResponse(string responseBody, string scenario)
		{
			Steps.AddTestStep(
				$"Validating VendorAdmins response structure for scenario: '{scenario}'.",
				"Response should contain expected fields and valid data.");

			try
			{
				var vendorAdminsList = JsonConvert.DeserializeObject<List<VendorAdminResponse>>(responseBody);

				if (vendorAdminsList == null)
				{
					HPGWarn.Warn($"Unable to deserialize VendorAdmins response for scenario: '{scenario}'");
					return;
				}

				ConsoleOut.WriteReport($"Total Vendor Admins returned: {vendorAdminsList.Count}");

				if (vendorAdminsList.Count == 0)
				{
					ConsoleOut.WriteReport("Response contains empty array - no vendor admins found for the given criteria.");
					return;
				}

				foreach (var vendorAdmin in vendorAdminsList)
				{
					// Validate required fields are not null or empty
					HPGWarn.False(string.IsNullOrWhiteSpace(vendorAdmin.FirstName),
						field: "FirstName",
						message: "FirstName should not be null or empty");

					HPGWarn.False(string.IsNullOrWhiteSpace(vendorAdmin.LastName),
						field: "LastName",
						message: "LastName should not be null or empty");

					HPGWarn.False(string.IsNullOrWhiteSpace(vendorAdmin.Email),
						field: "Email",
						message: "Email should not be null or empty");

					// Validate email format
					if (!string.IsNullOrWhiteSpace(vendorAdmin.Email))
					{
						var emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
						var isValidEmail = System.Text.RegularExpressions.Regex.IsMatch(vendorAdmin.Email, emailPattern);
						HPGWarn.True(isValidEmail,
							field: "Email Format",
							message: $"Email '{vendorAdmin.Email}' should be in valid format");
					}

					// Validate Facilities list exists and has items
					HPGWarn.False(vendorAdmin.Facilities == null,
	                    field: "Facilities",
	                    message: "Facilities list should not be null");

					if (vendorAdmin.Facilities != null && vendorAdmin.Facilities.Count > 0)
					{
						foreach (var facility in vendorAdmin.Facilities)
						{
							HPGWarn.False(string.IsNullOrWhiteSpace(facility.Coid),
								field: "Facility COID",
								message: "Facility COID should not be null or empty");

							HPGWarn.False(string.IsNullOrWhiteSpace(facility.OrgName),
								field: "Facility OrgName",
								message: "Facility OrgName should not be null or empty");
						}
					}
				}

				ConsoleOut.WriteReport($"Validation completed successfully for {vendorAdminsList.Count} vendor admin(s).");
			}
			catch (JsonException ex)
			{
				HPGAssert.Fail($"Failed to parse VendorAdmins response: {ex.Message}");
			}
			catch (Exception ex)
			{
				HPGAssert.Fail($"Unexpected error during VendorAdmins response validation: {ex.Message}");
			}
		}

		/// <summary>
		/// Validates the success response for 200 OK scenarios.
		/// </summary>
		private void ValidateIngestSuccessResponse(HttpResponse response, string scenario)
		{
			var responseBody = JsonConvert.DeserializeObject<IngestResponse>(response.Response);

			if (responseBody == null)
			{
				HPGWarn.Warn($"Unable to deserialize response body for scenario: {scenario}");
				return;
			}

			HPGWarn.True(responseBody.Id > 0, field: "Id");

			// Scenario-specific validations
			if (scenario == "RequestVbo")
			{
				HPGWarn.AreEqual("VPRO Active", responseBody.VproStatus, field: "VproStatus");
				HPGWarn.AreEqual("VBO", responseBody.RequestType, field: "RequestType");
			}

            if(scenario == "MissingStatusTypeId")
            {
                HPGWarn.AreEqual(null, responseBody.VproStatus, field: "VproStatus");
                HPGWarn.AreEqual("INV", responseBody.RequestType, field: "RequestType");
			}

		}

        /// <summary>
        /// Validates error responses for 400 BadRequest and 500 InternalServerError scenarios.
        /// </summary>
        private void ValidateIngestErrorResponse(HttpResponse response, string scenario, string expectedStatus)
        {
            if (expectedStatus == BadRequestResponse)
            {
                dynamic errorBody = JsonConvert.DeserializeObject<dynamic>(response.Response);

                // Extract the errors object
                var errorsJson = errorBody?.errors?.ToString() ?? "";

                var (fieldName, expectedMessage) = scenario switch
                {
                    "MissingFirstName" => ("FirstName", FirstNameRequiredError),
                    "MissingLastName" => ("LastName", LastNameRequiredError),
                    "MissingEmail" => ("Email", EmailRequiredError),
                    "MissingVproUserEmailId" => ("VPROUserEmailId", VproUserEmailIdRequiredError),
                    "MissingCorrelationId" => ("request", RequestRequiredError),
                    _ => (string.Empty, string.Empty)
                };

                if (!string.IsNullOrEmpty(fieldName))
                {
                    // Parse the actual error message from the array
                    var actualMessage = ParseErrorMessage(response.Response, fieldName);

                    // Validate both that the field exists and the message matches
                    HPGWarn.Contains(errorsJson, fieldName, field: $"Field '{fieldName}' in errors");

                    if (!string.IsNullOrEmpty(actualMessage))
                    {
                        HPGWarn.AreEqual(expectedMessage, actualMessage, field: $"Error message for '{fieldName}'");
                    }
                }
            }
            else if (expectedStatus == InternalServerResponse)
            {
                dynamic errorBody = JsonConvert.DeserializeObject<dynamic>(response.Response);
                var errorMessage = errorBody?.ErrorDetails?.Message?.ToString() ?? "";

                var expectedText = scenario switch
                {
                    "InvalidStatusTypeId" => "FK_SelfProvision_StatusTypeId",
                    "MissingFacilities" => "VendorAffiliations and Facilities cannot be null or empty",
                    "MissingVendorAffiliations" => "VendorAffiliations and Facilities cannot be null or empty",
                    "CorrilationIdFailure" => "UQ_SelfProvision_CorrelationId",
                    _ => string.Empty
                };

                if (!string.IsNullOrEmpty(expectedText))
                    HPGWarn.Contains(errorMessage, expectedText);
            }
        }

		/// <summary>
		/// Validates the user role, span of control, and vendor affiliation data by comparing expected and actual values.
		/// </summary>
		/// <param name="response">The HTTP response containing the JSON data to validate</param>
		/// <param name="expected">The expected UserRoleSocVendorAffiliation object to compare against</param>
		private void ValidateUserRoleSpocVendorAffiliation(HttpResponse response,
            UserRoleSocVendorAffiliation expected)
        {
            var actual = JsonConvert.DeserializeObject<UserRoleSocVendorAffiliation>(response.Response);

            expected.Validate(actual!);
            GeneralIdNameResponse.ValidateGenralList(expected.RoleModel, actual!.RoleModel);
            SpanOfControl.ValidateOrgTreeList(expected.SOCModel, actual.SOCModel);
            ScVendorModel.ValidateScVendorModelList(expected.VendorModel, actual.VendorModel);
        }

		/// <summary>
		///  ValidateSelfProvisionVendorAdminNotificationErrorMsg: This method validates the error message returned by the 
        ///     SelfProvision Vendor Admin Notification API based on different scenarios. 
		/// </summary>
		/// <param name="ApiResponse"></param>
		/// <param name="scenario"></param>
		private static void ValidateSelfProvisionVendorAdminNotificationErrorMsg(string ApiResponse, string scenario)
        {
			string expectedMsg = string.Empty;
			string actualMsg = string.Empty;

			switch (scenario)
			{
				case "ValidRequest":
					Steps.AddTestStep("Validating 'ValidRequest' scenario response", "Should match expected success message");
					expectedMsg = "Notification sent successfully.";
					actualMsg = ApiResponse;
					break;
				case "MissingFirstName":
					Steps.AddTestStep("Validating 'MissingFirstName' scenario error message", "Should indicate FirstName field is required");
					expectedMsg = "The FirstName field is required.";
					actualMsg = ParseErrorMessage(ApiResponse, "FirstName");
					break;
				case "MissingLastName":
					Steps.AddTestStep("Validating 'MissingLastName' scenario error message", "Should indicate LastName field is required");
					expectedMsg = "The LastName field is required.";
					actualMsg = ParseErrorMessage(ApiResponse, "LastName");
					break;
				case "MissingEmail":
					Steps.AddTestStep("Validating 'MissingEmail' scenario error message", "Should indicate Email field is required");
					expectedMsg = "The Email field is required.";
					actualMsg = ParseErrorMessage(ApiResponse, "Email");
					break;
				case "MissingVproUserEmailId":
					Steps.AddTestStep("Validating 'MissingVproUserEmailId' scenario error message", "Should indicate VproUserEmailId field is required");
					expectedMsg = "The VproUserEmailId field is required.";
					actualMsg = ParseErrorMessage(ApiResponse, "VproUserEmailId");
					break;
				case "MissingAdminNotifyList":
					Steps.AddTestStep("Validating 'MissingAdminNotifyList' scenario error message", "Should indicate VAdminNotifyList field is required");
					expectedMsg = "The VAdminNotifyList field is required.";
					actualMsg = ParseErrorMessage(ApiResponse, "VAdminNotifyList");
					break;
				case "MissingVendorAffiliations":
					Steps.AddTestStep("Validating 'MissingVendorAffiliations' scenario error message", "Should indicate VendorAffiliations field is required");
					expectedMsg = "The VendorAffiliations field is required.";
					actualMsg = ParseErrorMessage(ApiResponse, "VendorAffiliations");
					break;
				case "RandomRequestType":
					Steps.AddTestStep("Validating 'RandomRequestType' scenario response", "Should still accept and send notification successfully");
					expectedMsg = "Notification sent successfully.";
					actualMsg = ApiResponse;
					break;
				case "VboRequest":
					Steps.AddTestStep("Validating 'VboRequest' scenario response", "Should match expected success message for VBO request type");
					expectedMsg = "Notification sent successfully.";
					actualMsg = ApiResponse;
					break;
			}

			HPGWarn.AreEqual(expectedMsg, actualMsg, field: $"Scenario: {scenario}");
		}
		
        /// <summary>
		/// This method parses the error message from the API response for a given field name. It attempts to deserialize the JSON response and extract 
        /// the error message associated with the specified field. 
        /// If parsing fails or the expected structure is not found, it returns either an empty string or the original response.
		/// </summary>
		/// <param name="jsonResponse"></param>
		/// <param name="fieldName"></param>
		/// <returns></returns>
		private static string ParseErrorMessage(string jsonResponse, string fieldName)
        {
			if (string.IsNullOrWhiteSpace(jsonResponse))
				return string.Empty;

			try
			{
				var errorResponse = JsonConvert.DeserializeObject<JObject>(jsonResponse);

				if (errorResponse == null)
					return jsonResponse;

				var errors = errorResponse["errors"]?[fieldName];

				if (errors != null && errors.Type == JTokenType.Array && errors.HasValues)
				{
					return errors.First()?.ToString() ?? string.Empty;
				}

				return string.Empty;
			}
			catch (JsonReaderException)
			{
				// If JSON parsing fails, return the original response
				return jsonResponse;
			}
			catch (Exception ex)
			{
				// Log the exception if you have logging available
				ConsoleOut.WriteReport($"Error parsing error message: {ex.Message}");
				return string.Empty;
			}
		}

		/// <summary>
		/// Validates the response message from VboRequestResponseNotification API based on different scenarios.
		/// Checks for appropriate status codes and error messages for various request validation cases.
		/// </summary>
		/// <param name="apiResponse">The API response body as a JSON string</param>
		/// <param name="responseStatus">The HTTP response status code</param>
		/// <param name="scenario">The test scenario being validated</param>
		private static void ValidateVboRequestResponseNotificationMessage(string apiResponse, string responseStatus, string scenario)
		{
			string expectedMsg;
			string actualMsg;

			switch (scenario)
			{
				case "MissingEmail":
					Steps.AddTestStep("Validating 'MissingEmail' scenario error message", "Should indicate Email was null or empty");
					expectedMsg = "Required input Email was null or empty.";
					actualMsg = ParseErrorDetailsMessage(apiResponse);
					break;

				case "InvalidEmail":
					Steps.AddTestStep("Validating 'InvalidEmail' scenario error message", "Should indicate failed to send notification");
					expectedMsg = "Failed to send INV request response notification. Status Code: InternalServerError";
					actualMsg = ParseErrorDetailsMessage(apiResponse);
					break;

				case "MissingSubject":
					Steps.AddTestStep("Validating 'MissingSubject' scenario error message", "Should indicate Subject was null or empty");
					expectedMsg = "Required input Subject was null or empty.";
					actualMsg = ParseErrorDetailsMessage(apiResponse);
					break;

				case "SubjectAnyValue":
					Steps.AddTestStep("Validating 'SubjectAnyValue' scenario response", "Should return success message");
					expectedMsg = "Notification sent successfully.";
					actualMsg = apiResponse;
					break;

				case "MissingFirstName":
					Steps.AddTestStep("Validating 'MissingFirstName' scenario error message", "Should indicate FirstName was null or empty");
					expectedMsg = "Required input FirstName was null or empty.";
					actualMsg = ParseErrorDetailsMessage(apiResponse);
					break;

				case "FirstNameAnyValue":
					Steps.AddTestStep("Validating 'FirstNameAnyValue' scenario response", "Should return success message");
					expectedMsg = "Notification sent successfully.";
					actualMsg = apiResponse;
					break;

				case "MissingLastName":
					Steps.AddTestStep("Validating 'MissingLastName' scenario error message", "Should indicate LastName was null or empty");
					expectedMsg = "Required input LastName was null or empty.";
					actualMsg = ParseErrorDetailsMessage(apiResponse);
					break;

				case "LastNameAnyValue":
					Steps.AddTestStep("Validating 'LastNameAnyValue' scenario response", "Should return success message");
					expectedMsg = "Notification sent successfully.";
					actualMsg = apiResponse;
					break;

				case "MissingMessageType":
					Steps.AddTestStep("Validating 'MissingMessageType' error response", "Should indicate Invalid MessageType");
					expectedMsg = "Invalid MessageType";
					actualMsg = ParseErrorDetailsMessage(apiResponse);
					break;

				case "MsgType1ProgressInv":
					Steps.AddTestStep("Validating 'MsgType1ProgressInv' scenario response", "Should return success message for Progress/INV");
					expectedMsg = "Notification sent successfully.";
					actualMsg = apiResponse;
					break;

				case "MsgType2RejectInv":
					Steps.AddTestStep("Validating 'MsgType2RejectInv' scenario response", "Should return success message for Reject/INV");
					expectedMsg = "Notification sent successfully.";
					actualMsg = apiResponse;
					break;

				case "MsgType3CompleteInv":
					Steps.AddTestStep("Validating 'MsgType3CompleteInv' scenario response", "Should return success message for Complete/INV");
					expectedMsg = "Notification sent successfully.";
					actualMsg = apiResponse;
					break;

				case "MsgType1ProgressVbo":
					Steps.AddTestStep("Validating 'MsgType1ProgressVbo' scenario response", "Should return success message for Progress/VBO");
					expectedMsg = "Notification sent successfully.";
					actualMsg = apiResponse;
					break;

				case "MsgType2RejectVbo":
					Steps.AddTestStep("Validating 'MsgType2RejectVbo' scenario response", "Should return success message for Reject/VBO");
					expectedMsg = "Notification sent successfully.";
					actualMsg = apiResponse;
					break;

				case "MsgType3CompleteVbo":
					Steps.AddTestStep("Validating 'MsgType3CompleteVbo' scenario response", "Should return success message for Complete/VBO");
					expectedMsg = "Notification sent successfully.";
					actualMsg = apiResponse;
					break;

				case "MsgTypeAnyOther4":
					Steps.AddTestStep("Validating 'MsgTypeAnyOther4' error response", "Should indicate MessageType must be 1, 2, or 3");
					expectedMsg = "MessageType must be 1, 2, or 3.";
					actualMsg = ParseErrorDetailsMessage(apiResponse);
					break;

				case "MissingMatchedFacilities":
					Steps.AddTestStep("Validating 'MissingMatchedFacilities' scenario response", "Should return success message (optional field)");
					expectedMsg = "Notification sent successfully.";
					actualMsg = apiResponse;
					break;

				case "MissingMatchedVendors":
					Steps.AddTestStep("Validating 'MissingMatchedVendors' scenario response", "Should return success message (optional field)");
					expectedMsg = "Notification sent successfully.";
					actualMsg = apiResponse;
					break;

				case "MissingUnmatchedFacilities":
					Steps.AddTestStep("Validating 'MissingUnmatchedFacilities' scenario response", "Should return success message (optional field)");
					expectedMsg = "Notification sent successfully.";
					actualMsg = apiResponse;
					break;

				case "MissingUnmatchedVendors":
					Steps.AddTestStep("Validating 'MissingUnmatchedVendors' scenario response", "Should return success message (optional field)");
					expectedMsg = "Notification sent successfully.";
					actualMsg = apiResponse;
					break;

				case "MissingComments":
					Steps.AddTestStep("Validating 'MissingComments' scenario response", "Should return success message (optional field)");
					expectedMsg = "Notification sent successfully.";
					actualMsg = apiResponse;
					break;

				case "MissingRequestType":
					Steps.AddTestStep("Validating 'MissingRequestType' scenario response", "Should return success message (optional field)");
					expectedMsg = "Notification sent successfully.";
					actualMsg = apiResponse;
					break;

				default:
					Steps.AddTestStep($"Validating unhandled scenario: {scenario}", "Should log response for review");
					ConsoleOut.WriteReport($"Unhandled scenario: {scenario}. Response: {apiResponse}");
					return;
			}

			HPGWarn.AreEqual(expectedMsg, actualMsg, field: $"Scenario: {scenario}");
		}
		/// <summary>
		/// Parses the error message from the ErrorDetails.Message field in the API response.
		/// This method is specific to responses with the ErrorDetails wrapper structure.
		/// </summary>
		/// <param name="jsonResponse">The JSON response string containing ErrorDetails</param>
		/// <returns>The error message string from ErrorDetails.Message, or empty string if parsing fails</returns>
		private static string ParseErrorDetailsMessage(string jsonResponse)
		{
			if (string.IsNullOrWhiteSpace(jsonResponse))
				return string.Empty;

			try
			{
				// Deserialize the response to extract ErrorDetails.Message
				var errorResponse = JsonConvert.DeserializeObject<JObject>(jsonResponse);

				if (errorResponse == null)
					return jsonResponse;

				// Navigate to ErrorDetails -> Message
				var message = errorResponse["ErrorDetails"]?["Message"]?.ToString();

				return message ?? string.Empty;
			}
			catch (JsonReaderException ex)
			{
				// If JSON parsing fails, log and return the original response
				ConsoleOut.WriteReport($"Failed to parse ErrorDetails message: {ex.Message}");
				return jsonResponse;
			}
			catch (Exception ex)
			{
				// Log any other exceptions
				ConsoleOut.WriteReport($"Error parsing ErrorDetails message: {ex.Message}");
				return string.Empty;
			}
		}

		#endregion Validations

		#region Helpers
		/// <summary>
		/// Configures the ingest request based on the test scenario and returns the expected response status.
		/// </summary>
		private static (string expectedResponse, string correlationId) ConfigureIngestScenario(string scenario, SelfProvisionIngestRequest request, string? reuseCorrelationId)
		{
			string expectedResponse;
			string correlationId = request.CorrelationId;

			switch (scenario)
			{
				case "RequestVbo":
					request.VproStatus = "VPRO Active";
					request.RequestType = "VBO";
					expectedResponse = OkResponse;
					break;

				case "FailEverything":
					request.StatusTypeId = "4";
					foreach (var facility in request.Facilities)
						facility.StatusTypeId = 4;
					foreach (var vendor in request.VendorAffiliations)
						vendor.StatusTypeId = 4;
					expectedResponse = OkResponse;
					break;

				case "MissingFirstName":
					request.FirstName = null;
					expectedResponse = BadRequestResponse;
					break;

				case "MissingLastName":
					request.LastName = null;
					expectedResponse = BadRequestResponse;
					break;

				case "MissingEmail":
					request.Email = null;
					expectedResponse = BadRequestResponse;
					break;

				case "MissingStatusTypeId":
					request.StatusTypeId = null;
					expectedResponse = InternalServerResponse; //OkResponse;
					break;

				case "InvalidStatusTypeId":
					request.StatusTypeId = "999";
					expectedResponse = InternalServerResponse; //OkResponse;
					break;

				case "MissingVproStatus":
				case "NullVproStatus":
					request.VproStatus = null;
                    request.RequestType = "VBO"; 
					expectedResponse = OkResponse;
					break;

				case "MissingVproUserEmailId":
					request.VproUserEmailId = null;
					expectedResponse = BadRequestResponse;
					break;

				case "MissingCorrelationId":
					request.CorrelationId = null;
					correlationId = "null";
					expectedResponse = BadRequestResponse;
					break;

				case "MissingFacilities":
					request.Facilities = null;
					expectedResponse = InternalServerResponse;
					break;

				case "MissingVendorAffiliations":
					request.VendorAffiliations = null;
					expectedResponse = InternalServerResponse;
					break;

				case "MissingComment":
					request.Comment = null;
					expectedResponse = OkResponse;
					break;

				case "MissingRequestType":
					request.RequestType = null;
                    request.VproStatus = "VPRO Active"; 
					expectedResponse = OkResponse;
					break;

				case "CorrilationIdFailure":
					request.CorrelationId = reuseCorrelationId; // Reuse previous correlationId
					correlationId = request.CorrelationId;
					expectedResponse = InternalServerResponse;
					break;

				default:
					throw new ArgumentOutOfRangeException(nameof(scenario), scenario, $"Unknown scenario: {scenario}");
			}

			return (expectedResponse, correlationId);
		}

		/// <summary>
		/// Creates a base ingest request with all required fields populated with valid data.
		/// </summary>
		private SelfProvisionIngestRequest CreateBaseIngestRequest(string scenario)
		{
			var datePartOfName = DateTime.Now.ToString("yyyyMMMdd_HHmmss");

			return new SelfProvisionIngestRequest
			{
				FirstName = $"AutomationTestRequest_{scenario}",
				LastName = $"QaTest_{datePartOfName}",
				Email = $"AutomationRequestTest.QaTest_{datePartOfName}@abc.com",
				StatusTypeId = "1",
				VproStatus = null,
				VproUserEmailId = "testmarlon1100@gmail.com",
				CorrelationId = Guid.NewGuid().ToString(),
				Facilities = new List<IngestFacilityRequest>
		{
			new IngestFacilityRequest { COID = "34222", OrgName = "HCA - Centennial Medical Center", StatusTypeId = 1, Comments = "AutomationRequestFacility" },
			new IngestFacilityRequest { COID = "09391", OrgName = "HCA - Stonecrest Medical Center", StatusTypeId = 1, Comments = "AutomationRequestFacility" },
			new IngestFacilityRequest { COID = "12345", OrgName = "", StatusTypeId = 4, Comments = "AutomationRequestFacility" }
		},
				VendorAffiliations = new List<IngestVendorRequest>
		{
			new IngestVendorRequest { SNV = "499484", VendorName = "", StatusTypeId = 1, Comments = "AutomationRequestVendor" },
			new IngestVendorRequest { SNV = "499519", VendorName = "", StatusTypeId = 1, Comments = "AutomationRequestVendor" },
			new IngestVendorRequest { SNV = "900600", VendorName = "", StatusTypeId = 1, Comments = "AutomationRequestVendor" },
			new IngestVendorRequest { SNV = "958058", VendorName = "Unknown Vendor", StatusTypeId = 4, Comments = "AutomationRequestVendor" }
		},
				Comment = "Automation Test Executing",
				RequestType = "INV"
			};
		}


		private (string? ApplicationId, UserRoleSocVendorAffiliation UserRoleSocVendorAffiliation)
            GetExpectedUserRoleSocVendorAffiliation(UserResponse user)
        {
            //get current roles for a user

            var userRoles = _userRepository.GetAllUserRoleDb(user.Id.ToString())
                .Where(i => !i.IsDeleted && !i.IsDeactivated);
            List<GeneralIdNameResponse> roles;
            List<SpanOfControl>         spoc;
            string                      applicationId;

            if (userRoles.IsNullOrEmpty())
            {
                applicationId = "9068249a-1cc4-4d8d-bb30-4a0fc9fc98cd";
                roles         = new List<GeneralIdNameResponse>();
            }
            else
            {
                var role = userRoles
                    .GroupBy(grp => grp.ApplicationId)
                    .ToDictionary(g => g.Key, j => j.ToList()).PickRandom();
                applicationId = role.Key.ToString();

                roles = role.Value.Select(i => new GeneralIdNameResponse()
                {
                    Id   = i.Id.ToString(),
                    Name = i.Name.ToStringOrEmpty()
                }).ToList();
            }

            //get current SPOC for user and application
            var soc = _userRepository.GetAllUserSocDb(user.Id)
                .Where(i => !i.IsDeleted && i.ApplicationId.ToString().Equals(applicationId)).ToList();

            //format Spoc
            spoc = HomeService.GetExpectedHierarchyList(soc, _homeInfoDataDb);

            //if user type is Vendor then get vendor affiliation else empty list.
            var vendorAffiliation = _userRepository.GetUserVendorAffiliationDb(user.Id).Where(i => !i.IsDeleted).Select(
                j =>
                    new ScVendorModel { Id = j.Id, VendorId = j.VendorId, VendorName = j.VendorName }).ToList();

            var expectedRoleSpocVendor = new UserRoleSocVendorAffiliation(user)
            {
                RoleModel   = roles,
                SOCModel    = spoc,
                VendorModel = vendorAffiliation
            };

            return (applicationId, expectedRoleSpocVendor);
        }

        private List<UserResponse> GetExpectedUserForGivenSpocAndRoleList(Guid roleId, Guid applicationId,
            HomeHierarchyType homeHierarchyType, string orgObjectId, IEnumerable<UserResponse> userList,
            IEnumerable<UserRoleDb> userRoleList, IEnumerable<UserSocDb> userSpocList)
        {
            //filter user with the role
            var usersWithTheSpecifiedRole = userRoleList.Where(i => i.Id.Equals(roleId) && i.IsDeactivated == false).ToList();

            //Filter users with SPOC, ApplicationId, and with in the filtered user role list. 
            var usersWithTheSpan = DetermineUserHasSpanOfControl(usersWithTheSpecifiedRole,
                userSpocList.Where(i => i.ApplicationId.Equals(applicationId)), homeHierarchyType, orgObjectId);

            return userList.Where(i => usersWithTheSpan.Contains(i.Id)).ToList();
        }

        private HashSet<Guid> DetermineUserHasSpanOfControl(List<UserRoleDb> usersWithTheSpecifiedRole,
            IEnumerable<UserSocDb> userSpocList, HomeHierarchyType homeHierarchyType, string orgObjectId)
        {
            //stripping padded zeros if hierarchy type is not facility level.
            var formattedOrgObjectId = homeHierarchyType.Equals(HomeHierarchyType.Facility)
                ? orgObjectId
                : orgObjectId.ToInt().ToString();

            //get hierarchy for given hierarchy type and org object id
            var homeHierarchyRecord =
                HomeRepository.GetSpecificHomeRecord(homeHierarchyType, formattedOrgObjectId, _homeInfoDataDb);

            var groupedUserSpoc = userSpocList.GroupBy(g => g.UserId).ToDictionary(grp => grp.Key, j => j.ToList());

            //loop thru list of usersWithTheSpecifiedRole
            var results = new HashSet<Guid>();
            foreach (var userWithRole in usersWithTheSpecifiedRole)
            {
                if (!groupedUserSpoc.TryGetValue(userWithRole.UserId, out var user)) continue;

                //exact match to search criteria?
                if (user.Any(i => i.Hierarchy.Equals((int)homeHierarchyType) && i.OrgObjectID.Equals(orgObjectId)))
                    results.Add(user.FirstOrDefault().UserId);
                //does it have higher spoc?
                else if (user.Any(i => i.Hierarchy < (int)homeHierarchyType))
                {
                    //does it match to any of the higher hierarchy?
                    var higherHierarchies = user.Where(i => i.Hierarchy < (int)homeHierarchyType);
                    foreach (var hierarchy in higherHierarchies)
                    {
                        var testHigherHierarchyObjectId = hierarchy.Hierarchy switch
                        {
                            (int)HomeHierarchyType.Organization => homeHierarchyRecord.OrganizationID.ToInt(),
                            (int)HomeHierarchyType.Company => homeHierarchyRecord.CompanyId.ToInt(),
                            (int)HomeHierarchyType.Group => homeHierarchyRecord.GroupId.ToInt(),
                            (int)HomeHierarchyType.Division => homeHierarchyRecord.DivisionID.ToInt(),
                            (int)HomeHierarchyType.Market => homeHierarchyRecord.MarketId.ToInt(),
                            _ => 0
                        };

                        if (!hierarchy.OrgObjectID.ToInt().Equals(testHigherHierarchyObjectId)) continue;

                        results.Add(hierarchy.UserId);
                        break;
                    }
                }
            }

            return results;
        }

        private List<UserRoleSocVendorAffiliation> GetExpectedUserForGivenSpocAndRoleWithDetailList(
            List<UserResponse> users, Guid applicationId, IEnumerable<UserRoleDb> userRoleList,
            IEnumerable<UserSocDb> userSpocList)
        {
            var userRolesDictionary = userRoleList
                .Where(i => i.ApplicationId.Equals(applicationId))
                .GroupBy(g => g.UserId)
                .ToDictionary(g => g.Key, g => g.ToList());

            var userSpocDictionary = userSpocList
                .Where(i => i.ApplicationId.Equals(applicationId))
                .GroupBy(g => g.UserId)
                .ToDictionary(grp => grp.Key, l => l.ToList());

            return users.Select(user => new UserRoleSocVendorAffiliation(user)
            {
                RoleModel = userRolesDictionary[user.Id].Select(i => new GeneralIdNameResponse()
                    { Id = i.Id.ToString(), Name = i.Name }).ToList(),
                SOCModel = HomeService.GetExpectedHierarchyList(userSpocDictionary[user.Id], _homeInfoDataDb),
                VendorModel = _userRepository.GetUserVendorAffiliationDb(user.Id)
                    .Where(i => !i.IsDeleted)
                    .Select(j => new ScVendorModel { Id = j.Id, VendorId = j.VendorId, VendorName = j.VendorName })
                    .ToList()
            }).ToList();
        }

        private (Guid ApplicationId, Guid RoleId, HomeHierarchyType hierarchy, string facility)?
            GetVendorUserWithRoleSpocAndVendorAffiliation(List<UserResponse> userList,
                IEnumerable<UserRoleDb> userRoleList,
                IEnumerable<UserSocDb> userSpocList)
        {
            var userVendorAffiliationList = _userRepository.GetUserVendorAffiliationDb()
                .Where(i => !i.IsDeleted);

            var vendorUser = userList.Where(i => !i.IsDeactivated && i.Type.Equals("Vendor"))
                .ToDictionary(k => k.Id, j => j);

            var vendorUserWithRole = userRoleList
                .Where(i => !i.IsDeleted && vendorUser.ContainsKey(i.UserId))
                .GroupBy(g => g.UserId)
                .ToDictionary(grp => grp.Key, j => j.ToList());

            var vendorUserWithRoleSpoc = userSpocList
                .Where(i => !i.IsDeleted && vendorUserWithRole.ContainsKey(i.UserId))
                .GroupBy(g => g.UserId)
                .ToDictionary(grp => grp.Key, j => j.ToList());

            var testUser = userVendorAffiliationList.Where(i => vendorUserWithRoleSpoc.ContainsKey(i.UserId))
                .PickRandom().UserId;

            vendorUserWithRole.TryGetValue(testUser, out var roles);
            vendorUserWithRoleSpoc.TryGetValue(testUser, out var spoc);

            if (roles!.IsNullOrEmpty() || spoc!.IsNullOrEmpty())
                HPGAssert.Fail($"Unable to find Role and SPOC for User ID: '{testUser}'");
            else
            {
                var role          = roles!.PickRandom();
                var appId         = role.ApplicationId;
                var roleId        = role.Id;
                var hierarchy     = spoc!.Where(i => i.ApplicationId.Equals(appId)).PickRandom();
                var hierarchyType = (HomeHierarchyType)hierarchy.Hierarchy;
                var objectId      = hierarchy.OrgObjectID;


                return (appId, roleId, hierarchyType, objectId);
            }

            return null;
        }

        /// <summary>
        /// Retrieves data from database.
        /// </summary>
        /// <returns></returns>
        private (List<UserResponse> userList, List<UserRoleDb> userRoleList, List<UserSocDb> userSpocList)
            GetTestDataFromDatabase()
        {
            //get all users
            var userList = _userRepository.GetAllUsers().ToList();

            //get current enabled roles
            var userRoleList = _userRepository.GetAllUserRoleDb()
                .Where(i => !i.IsDeleted && !i.Name.Equals("SMART Security Admin")).ToList();

            //get current SPOC
            var userSpocList = _userRepository.GetAllUserSocDb().Where(i => !i.IsDeleted).ToList();
            return (userList, userRoleList, userSpocList);
        }

        /// <summary>
        /// Gets the expected User Role, Soc, and Vendor affiliation for a specified user and application ID
        /// </summary>
        /// <param name="user"></param>
        /// <param name="role"></param>
        /// <param name="userRoleList"></param>
        /// <param name="userSpocList"></param>
        /// <returns></returns>
        private UserRoleSocVendorAffiliation RetrieveExpectedUserRoleSocVendorAffiliation(UserResponse user,
            UserRoleDb role, IEnumerable<UserRoleDb> userRoleList, IEnumerable<UserSocDb> userSpocList)
        {
            var userSoc = userSpocList.Where(i =>
                i.UserId.Equals(user.Id) && i.ApplicationId.Equals(role.ApplicationId) && !i.IsDeleted);

            return new UserRoleSocVendorAffiliation(user)
            {
                RoleModel = userRoleList
                    .Where(i => i.UserId.Equals(user.Id) && i.ApplicationId.Equals(role.ApplicationId) && !i.IsDeleted)
                    .Select(i => new GeneralIdNameResponse()
                        { Id = i.Id.ToString(), Name = i.Name }).ToList(),
                SOCModel = HomeService.GetExpectedHierarchyList(userSoc, _homeInfoDataDb),
                VendorModel = _userRepository.GetUserVendorAffiliationDb(user.Id)
                    .Where(i => !i.IsDeleted)
                    .Select(j => new ScVendorModel { Id = j.Id, VendorId = j.VendorId, VendorName = j.VendorName })
                    .ToList()
            };
        }

        /// <summary>
        /// Returns a random role and user. It also returns a new User Detail request.
        /// todo: can't remember why we need to filter out nonaffil domain users
        /// </summary>
        /// <param name="userType"></param>
        /// <param name="userRoleList"></param>
        /// <param name="userList"></param>
        /// <returns></returns>
        private static (UserRoleDb randomRole, UserResponse user, UserDetailRequest request) GetTestUser(string userType, IEnumerable<UserRoleDb> userRoleList, IReadOnlyCollection<UserResponse> userList)
        {
			var usersFiltered = (userType == "vendor")
				? userList.Where(i => i.Type.ToLower().Equals(userType) && !i.IsDeactivated && i.VproStatus == "VPRO Active" && !i.Domain.Equals("nonaffil", StringComparison.OrdinalIgnoreCase)).ToList()
				: userList.Where(i => i.Type.ToLower().Equals(userType) && !i.IsDeactivated && !i.Domain.Equals("nonaffil", StringComparison.OrdinalIgnoreCase)).ToList();
			var filteredRoles = userRoleList.Where(i => i is { IsDeleted: false, IsDeactivated: false }).ToList();

            var randomRole = (from sUser in usersFiltered
                where filteredRoles.Any(i => i.UserId.Equals(sUser.Id))
                select filteredRoles.First(i => i.UserId.Equals(sUser.Id))).ToList().PickRandom();


            var user = userList.First(i => i.Id.Equals(randomRole.UserId));
            var request = new UserDetailRequest()
            {
                UserName = user.Username,
                Email    = user.Email,
                Domain   = user.Domain,
                AppId    = randomRole.ApplicationId.ToString()
            };
            return (randomRole, user, request);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="roleId"></param>
        /// <param name="roleApplicationId"></param>
        /// <param name="hierarchy"></param>
        /// <param name="facility"></param>
        /// <param name="userList"></param>
        /// <param name="userRoleList"></param>
        /// <param name="userSpocList"></param>
        /// <param name="withDetails"></param>
        /// <returns></returns>
        private List<UserRoleSocVendorAffiliation> GetFormattedExpectedUserRoleSocVendorAffiliations(Guid roleId,
            Guid roleApplicationId, HomeHierarchyType hierarchy, string facility, IEnumerable<UserResponse> userList,
            IReadOnlyCollection<UserRoleDb> userRoleList, IReadOnlyCollection<UserSocDb> userSpocList, bool? withDetails)
        {
            //Get expected users, roles, Soc, and vendor affiliation
            var expectedList = GetExpectedUserForGivenSpocAndRoleList(roleId, roleApplicationId,
                hierarchy, facility,
                userList, userRoleList, userSpocList);

            var expectedUserList =
                GetExpectedUserForGivenSpocAndRoleWithDetailList(expectedList, roleApplicationId,
                    userRoleList,
                    userSpocList);

            if ((bool)withDetails) return expectedUserList.ToList();

            foreach (var user in expectedUserList)
            {
                user.RoleModel   = new List<GeneralIdNameResponse>();
                user.SOCModel    = new List<SpanOfControl>();
                user.VendorModel = new List<ScVendorModel>();
            }

            return expectedUserList.ToList();
        }

        #endregion Helpers
    }
}
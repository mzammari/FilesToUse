﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace SmartSecurityTestAutomation.Services.SmartClientUsers
{
	 
	public class VendorAdminNotificationRequest
	{
		[JsonPropertyName("firstName")]
		public string? FirstName { get; set; }

		[JsonPropertyName("lastName")]
		public string? LastName { get; set; }

		[JsonPropertyName("email")]
		public string? Email { get; set; }

		[JsonPropertyName("vproUserEmailId")]
		public string? VproUserEmailId { get; set; }

		[JsonPropertyName("vAdminNotifyList")]
		public List<VendorAdminNotificationItem>? VAdminNotifyList { get; set; }

		[JsonPropertyName("vendorAffiliations")]
		public List<VendorAffiliation>? VendorAffiliations { get; set; }

		[JsonPropertyName("requestType")]
		public string? RequestType { get; set; }
		//public List<string> AdminNotifyList { get; internal set; }

		public VendorAdminNotificationRequest()
		{
		}
	}

	public class VendorAdminNotificationItem
	{
		[JsonPropertyName("firstName")]
		public string? FirstName { get; set; }

		[JsonPropertyName("lastName")]
		public string? LastName { get; set; }

		[JsonPropertyName("email")]
		public string? Email { get; set; }

		[JsonPropertyName("facilities")]
		public List<FacilityInfo>? Facilities { get; set; }
	}

	public class FacilityInfo
	{
		[JsonPropertyName("coid")]
		public string? Coid { get; set; }

		[JsonPropertyName("orgName")]
		public string? OrgName { get; set; }
	}

	public class VendorAffiliation
	{
		[JsonPropertyName("SNV")]
		public string? SNV { get; set; }

		[JsonPropertyName("vendorName")]
		public string? VendorName { get; set; }
	}
 	 
}

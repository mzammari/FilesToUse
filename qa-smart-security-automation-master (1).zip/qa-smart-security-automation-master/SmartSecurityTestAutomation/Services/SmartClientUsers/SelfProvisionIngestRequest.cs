﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace SmartSecurityTestAutomation.Services.SmartClientUsers;

public class SelfProvisionIngestRequest
{
	[JsonPropertyName("firstName")]
	public string FirstName { get; set; }

	[JsonPropertyName("lastName")]
	public string LastName { get; set; }

	[JsonPropertyName("email")]
	public string Email { get; set; }

	[JsonPropertyName("statusTypeId")]
	public string StatusTypeId { get; set; }

	[JsonPropertyName("vproStatus")]
	public string VproStatus { get; set; }

	[JsonPropertyName("vproUserEmailId")]
	public string VproUserEmailId { get; set; }

	[JsonPropertyName("correlationId")]
	public string CorrelationId { get; set; }

	[JsonPropertyName("facilities")]
	public List<IngestFacilityRequest> Facilities { get; set; }

	[JsonPropertyName("vendorAffiliations")]
	public List<IngestVendorRequest> VendorAffiliations { get; set; }

	[JsonPropertyName("comment")]
	public string Comment { get; set; }

	[JsonPropertyName("requestType")]
	public string RequestType { get; set; }
}

public class IngestFacilityRequest
{
	[JsonPropertyName("COID")]
	public string COID { get; set; }

	[JsonPropertyName("orgName")]
	public string OrgName { get; set; }

	[JsonPropertyName("statusTypeId")]
	public int StatusTypeId { get; set; }

	[JsonPropertyName("comments")]
	public string Comments { get; set; }
}

public class IngestVendorRequest
{
	[JsonPropertyName("SNV")]
	public string SNV { get; set; }

	[JsonPropertyName("vendorName")]
	public string VendorName { get; set; }

	[JsonPropertyName("statusTypeId")]
	public int StatusTypeId { get; set; }

	[JsonPropertyName("comments")]
	public string Comments { get; set; }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace SmartSecurityTestAutomation.Services.SmartClientUsers
{
	public class BadgeInRequest
	{
		[JsonPropertyName("userName")]
		public string? UserName { get; set; }

		[JsonPropertyName("coid")]
		public string? Coid { get; set; }

		[JsonPropertyName("domain")]
		public string? Domain { get; set; }

		[JsonPropertyName("appId")]
		public string? AppId { get; set; }

		[JsonPropertyName("requisitionDateTime")]
		public DateTime? RequisitionDateTime { get; set; }

		public BadgeInRequest()  
		{ 
		}
}


}

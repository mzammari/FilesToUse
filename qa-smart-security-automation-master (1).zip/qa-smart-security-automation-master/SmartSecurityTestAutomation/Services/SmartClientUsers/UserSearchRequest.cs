﻿using System;
using System.Text.Json.Serialization;

namespace SmartSecurityTestAutomation.Services.SmartClientUsers;

public class UserSearchRequest : ICloneable
{
    public object Clone()
    {
        return new UserSearchRequest()
        {
            RoleId = RoleId,
            ObjectId = ObjectId,
            HierarchyType = HierarchyType,
            ApplicationId = ApplicationId,
            WithDetails = WithDetails
        };
    }

    [JsonPropertyName("roleId")]
    public string? RoleId { get; set; }

    [JsonPropertyName("objectId")]
    public string? ObjectId { get; set; }

    [JsonPropertyName("hierarchyType")]
    public dynamic? HierarchyType { get; set; }

    [JsonPropertyName("applicationId")]
    public string? ApplicationId { get; set; }

    [JsonPropertyName("withDetails")]
    public dynamic? WithDetails { get; set; }
}
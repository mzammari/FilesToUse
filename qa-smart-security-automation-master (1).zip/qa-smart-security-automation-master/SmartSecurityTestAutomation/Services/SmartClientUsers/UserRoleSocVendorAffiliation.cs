﻿using System;
using Newtonsoft.Json;
using SmartSecurityTestAutomation.Services.Users;
using SmartSecurityTestAutomation.Services.Vendor;
using System.Collections.Generic;
using System.Linq;
using Utilities.ObjectExtensions;
using Utilities.Validation;

namespace SmartSecurityTestAutomation.Services.SmartClientUsers;

public class UserRoleSocVendorAffiliation : ICloneable
{
    public UserRoleSocVendorAffiliation()
    {
    }

    public UserRoleSocVendorAffiliation(UserResponse user)
    {
        Id            = user.Id;
        UserName      = user.Username;
        Domain        = user.Domain;
        FirstName     = user.FirstName;
        LastName      = user.LastName;
        Email         = user.Email;
        UserType      = user.Type;
        IsDeactivated = user.IsDeactivated;
    }

    public object Clone()
    {
        var clonedUserRoleSocVendorAffiliation = new UserRoleSocVendorAffiliation()
        {
            Id            = Id,
            UserName      = UserName,
            Domain        = Domain,
            FirstName     = FirstName,
            LastName      = LastName,
            Email         = Email,
            UserType      = UserType,
            IsDeactivated = IsDeactivated,
            RoleModel = RoleModel.Select(i => new GeneralIdNameResponse()
            {
                Id = i.Id,
                Name = i.Name
            }).ToList(),
            SOCModel = SOCModel.Select(i => new SpanOfControl()
            {
                HierarchyType = i.HierarchyType,
                ObjectId = i.ObjectId,
                OrgName = i.OrgName
            }).ToList(),
            VendorModel = VendorModel.Select(i => new ScVendorModel()
            {
                Id = i.Id,
                VendorId = i.VendorId,
                VendorName = i.VendorName
            }).ToList()
        };

        return clonedUserRoleSocVendorAffiliation;
    }

    [JsonProperty("id")]
    public Guid Id { get; set; }

    [JsonProperty("userName")]
    public string? UserName { get; set; }

    [JsonProperty("domain")]
    public string Domain { get; set; }

    [JsonProperty("firstName")]
    public string FirstName { get; set; }

    [JsonProperty("lastName")]
    public string LastName { get; set; }

    [JsonProperty("email")]
    public string? Email { get; set; }

    [JsonProperty("userType")]
    public string UserType { get; set; }

    [JsonProperty("isDeactivated")]
    public bool IsDeactivated { get; set; }

    [JsonProperty("roles")]
    public List<GeneralIdNameResponse> RoleModel { get; set; }

    [JsonProperty("spanOfControls")]
    public List<SpanOfControl> SOCModel { get; set; }

    [JsonProperty("vendors")]
    public List<ScVendorModel> VendorModel { get; set; }

    public void Validate(UserRoleSocVendorAffiliation other)
    {
        var overRideMessage =
            $"for UserId: {this.Id}";
        var results = new List<string>()
        {
            ValidationHelpers.AreEqual(this.FirstName.ToStringOrEmpty(), other.FirstName.ToStringOrEmpty(), "FirstName",
                overRideMessage),
            ValidationHelpers.AreEqual(this.LastName.ToStringOrEmpty(), other.LastName.ToStringOrEmpty(), "LastName",
                overRideMessage),
            ValidationHelpers.AreEqual(this.UserName.ToStringOrEmpty(), other.UserName.ToStringOrEmpty(), "UserName",
                overRideMessage),
            ValidationHelpers.AreEqual(this.Email.ToStringOrEmpty(), other.Email.ToStringOrEmpty(), "Email",
                overRideMessage),
            ValidationHelpers.AreEqual(this.UserType.ToStringOrEmpty(), other.UserType.ToStringOrEmpty(), "Type",
                overRideMessage),
            ValidationHelpers.AreEqual(this.Domain.ToStringOrEmpty(), other.Domain.ToStringOrEmpty(), "Domain",
                overRideMessage),
            ValidationHelpers.AreEqual(this.IsDeactivated.ToString(), other.IsDeactivated.ToString(), "IsDeactivated",
                overRideMessage),
        };

        HPGWarn.WarnRange(results.Where(i => i.ToStringOrEmpty() != string.Empty).ToList());
        GeneralIdNameResponse.ValidateGenralList(this.RoleModel, other.RoleModel,true);
        ScVendorModel.ValidateScVendorModelList(this.VendorModel, other.VendorModel,true);
        SpanOfControl.ValidateOrgTreeList(this.SOCModel, other.SOCModel, true);
    }

    public static void ValidateUserRoleSocVendorAffilitaionList(List<UserRoleSocVendorAffiliation> expectedList,
        List<UserRoleSocVendorAffiliation> actualList)
    {
        Steps.AddTestStep("Validating expected list is in actual.", "Expected list should match actual.");
        var actualDictionary = actualList.ToDictionary(i => i.Id, j => j);
        foreach (var expected in expectedList)
        {
            ConsoleOut.WriteReport($"Validating User '{expected.UserName}'.");
            if (!actualDictionary.TryGetValue(expected.Id, out var actual))
                HPGWarn.Warn($"Unable to find expected User Id: '{expected.Id}' in actual!");
            else
            {
                expected.Validate(actual);
                GeneralIdNameResponse.ValidateGenralList(expected.RoleModel, actual.RoleModel, true);
                ScVendorModel.ValidateScVendorModelList(expected.VendorModel, actual.VendorModel, true);
                SpanOfControl.ValidateOrgTreeList(expected.SOCModel, actual.SOCModel, true);
            }
        }

        Steps.AddTestStep("Validating actual list is in expected.", "Actual list should match expected.");
        var expectedDictionary = expectedList.ToDictionary(i => i.Id, j => j);
        foreach (var actual in actualList)
        {
            ConsoleOut.WriteReport($"Validating User '{actual.UserName}'.");
            if (!expectedDictionary.TryGetValue(actual.Id, out var expected))
                HPGWarn.Warn($"Unable to find actual User Id: '{actual.Id}' in expected!");
            else
            {
                actual.Validate(actual);
                GeneralIdNameResponse.ValidateGenralList(actual.RoleModel, expected.RoleModel, true);
                ScVendorModel.ValidateScVendorModelList(actual.VendorModel, expected.VendorModel, true);
                SpanOfControl.ValidateOrgTreeList(actual.SOCModel, expected.SOCModel, true);
            }
        }
    }
}

public class ScVendorModel
{
    [JsonProperty("id")]
    public int Id { get; set; }

    [JsonProperty("vendorId")]
    public int VendorId { get; set; }

    [JsonProperty("vendorName")]
    public string VendorName { get; set; }

    public List<string> Validate(ScVendorModel other)
    {
        var results = new List<string>()
        {
            ValidationHelpers.AreEqual(this.Id.ToStringOrEmpty(), other.Id.ToStringOrEmpty(), "Id"),
            ValidationHelpers.AreEqual(this.VendorId.ToStringOrEmpty(), other.VendorId.ToStringOrEmpty(), "VendorId"),
            ValidationHelpers.AreEqual(this.VendorName.ToStringOrEmpty(), other.VendorName.ToStringOrEmpty(),
                "VendorName"),
        };

        return results.Where(i => i.ToStringOrEmpty() != string.Empty).ToList();
    }

    public static void ValidateScVendorModelList(List<ScVendorModel> expectedList, List<ScVendorModel> actualList,
        bool byPassSecondary = false)
    {
        Steps.AddTestStep("Validating ScVendorModel Model List", "Model should match.");
        Steps.AddTestStep("Validating expected list matches actual list.", "Should both match");
        var actualDictionary = actualList.ToDictionary(i => i.Id, j => j);
        foreach (var expected in expectedList)
        {
            if (!actualDictionary.TryGetValue(expected.Id, out var actual))
                HPGWarn.Warn($"Unable to find ID: '{expected.Id}' in actual list.");
            else
            {
                HPGWarn.WarnRange(expected.Validate(actual));
            }
        }

        if (byPassSecondary) return;

        Steps.AddTestStep("Validating actual list matches expected list.", "Should both match");
        var expectedDictionary = expectedList.ToDictionary(i => i.Id, j => j);
        foreach (var actual in actualList)
        {
            if (!expectedDictionary.TryGetValue(actual.Id, out var expected))
                HPGWarn.Warn($"Unable to find ID: '{actual.Id}' in expected list.");
            else
            {
                HPGWarn.WarnRange(actual.Validate(expected));
            }
        }
    }
}
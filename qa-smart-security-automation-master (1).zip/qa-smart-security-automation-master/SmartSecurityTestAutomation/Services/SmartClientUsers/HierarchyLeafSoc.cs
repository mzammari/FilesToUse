﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace SmartSecurityTestAutomation.Services.SmartClientUsers
{
	public class HierarchyLeafSoc
	{
		// Existing fields...

		[JsonPropertyName("coid")]
		public string Coid { get; set; }

		[JsonPropertyName("name")]
		public string Name { get; set; }

		[JsonPropertyName("countryCodeCulture")]
		public string CountryCodeCulture { get; set; }

		[JsonPropertyName("isPrimary")]
		public bool IsPrimary { get; set; }

		[JsonPropertyName("coidType")]
		public string CoidType { get; set; } // "P" (Parent), "C" (Child), "S" (Stand Alone)

		[JsonPropertyName("company")]
		public string Company { get; set; }
	}
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace SmartSecurityTestAutomation.Services.SmartClientUsers
{
	public class VboRequestResponseNotificationRequest
	{
		[JsonPropertyName("email")]
		public string? Email { get; set; }

		[JsonPropertyName("subject")]
		public string? Subject { get; set; }

		[JsonPropertyName("firstName")]
		public string? FirstName { get; set; }

		[JsonPropertyName("lastName")]
		public string? LastName { get; set; }

		[JsonPropertyName("matchedFacilities")]
		public List<MatchedFacility>? MatchedFacilities { get; set; }

		[JsonPropertyName("matchedVendors")]
		public List<MatchedVendor>? MatchedVendors { get; set; }

		[JsonPropertyName("unmatchedFacilities")]
		public List<UnmatchedFacility>? UnmatchedFacilities { get; set; }

		[JsonPropertyName("unmatchedVendors")]
		public List<UnmatchedVendor>? UnmatchedVendors { get; set; }

		[JsonPropertyName("comments")]
		public string? Comments { get; set; }

		[JsonPropertyName("messageType")]
		public int? MessageType { get; set; }

		[JsonPropertyName("requestType")]
		public string? RequestType { get; set; }

		public VboRequestResponseNotificationRequest()
		{
		}
	}

	public class MatchedFacility
	{
		[JsonPropertyName("coid")]
		public string? Coid { get; set; }

		[JsonPropertyName("orgName")]
		public string? OrgName { get; set; }

		[JsonPropertyName("statusTypeId")]
		public int? StatusTypeId { get; set; }

		[JsonPropertyName("comments")]
		public string? Comments { get; set; }
	}

	public class MatchedVendor
	{
		[JsonPropertyName("id")]
		public int? Id { get; set; }

		[JsonPropertyName("name")]
		public string? Name { get; set; }

		[JsonPropertyName("inactivateDate")]
		public DateTime? InactivateDate { get; set; }

		[JsonPropertyName("comments")]
		public string? Comments { get; set; }
	}

	public class UnmatchedFacility
	{
		[JsonPropertyName("coid")]
		public string? Coid { get; set; }

		[JsonPropertyName("orgName")]
		public string? OrgName { get; set; }

		[JsonPropertyName("statusTypeId")]
		public int? StatusTypeId { get; set; }

		[JsonPropertyName("comments")]
		public string? Comments { get; set; }
	}

	public class UnmatchedVendor
	{
		[JsonPropertyName("id")]
		public int? Id { get; set; }

		[JsonPropertyName("name")]
		public string? Name { get; set; }

		[JsonPropertyName("inactivateDate")]
		public DateTime? InactivateDate { get; set; }

		[JsonPropertyName("comments")]
		public string? Comments { get; set; }
	}
}

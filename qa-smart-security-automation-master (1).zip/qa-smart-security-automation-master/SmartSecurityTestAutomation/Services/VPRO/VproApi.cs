﻿using SmartSecurityTestAutomation.Tests;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestPlatform.CommunicationUtilities.ObjectModel;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Utilities.HttpUtility;
using Utilities.ObjectExtensions;
using SmartSecurityTestAutomation.Services.Users; 
using Utilities.SetupTestUsers;
using Azure.Identity;

namespace SmartSecurityTestAutomation.Services.VPRO;

public class VproApi : MasterApi
{
	#region Private Variables

	//https//qasbx-api-smartauthorization.healthtrustpg.com/VPRO/VerifyVPROStatus	
	private static readonly string BaseUri = GlobalTestVariables.Configuration["SmartSecurity:BaseUri"]!;
	private const string VproUserStatus = "/VPRO/VerifyVPROStatus";
	private const string VproCheckOnOff = "/VPRO/checkVPRO";
	private const string VproCandidate = "/VPRO/getVPROCandidate";
	private const string VproCredentialing = "/VPRO/getVPROCredentialingRequests";
	private const string ByVproUserEmailId = "/users/GetByVPROUserEmailId";
	private const string VproFacilityVisits = "/VPRO/getVPROFacilityVisits";
	private const string VproGetVproBadgeInEndTime = "/VPRO/getVPROBadgeInEndTime";
	private const string Claims = "/users/claims";
	private const string UserResource = "/Users";
	private const string ClaimResource = "/claims";
	private readonly VproRepository vproRepository = new(GlobalTestVariables.Configuration["SmartSecurity:DatabaseServer"]!,
			GlobalTestVariables.Configuration["SmartSecurity:DatabaseName"]!);

	#endregion Private Variables

	#region API Call
	/// <summary>
	/// GET Api Call - GetCheckVPRO - Checks if the Environment has VPRO Feature enabled On or Off
	/// </summary> 
	/// <returns></returns>
	private static HttpResponse GetVPRORequest(string? endpoint)
	{
		var response = GetSimpleRequest($"{BaseUri}{endpoint}");
		return response;
	}
	/// <summary>
	/// Post Api Call
	/// </summary>
	/// <param name="payload"></param>
	/// <returns></returns>
	private static HttpResponse PostVproUserRequest(string? endpoint, string? payload)
	{
		var response = PostSimpleRequest($"{BaseUri}{endpoint}", payload);
		return response;
	}

	#endregion API Call

	#region Test Methods

	/// <summary>
	///		This api test is going away eventually - Checks VPRO is enabled in Environment(qasbx,qa)
	/// </summary>
	public bool TestGetVproIsEnabledCheck()
	{
		Steps.AddTestStep("Test sending 'GET' request to " + VproCheckOnOff + " API endpoint to see if VPRO functionality is ENABLED.", "System should respond accordingly.");
		Steps.AddTestStep($"Sending 'GET' request to " + VproCheckOnOff + " API endpoint - no payload.",
			$"Systems should respond with a status code: '{OkResponse}'.");
		var response = GetVPRORequest(VproCheckOnOff);
		var vproEnabled = false;

		switch (GlobalTestVariables.TestEnvironment)
		{
			case "qasbx":
				Steps.AddTestStep($"Expecting True for qasbx Environment", $"Setting expected value");
				vproEnabled = true;
				break;
			case "qa":
				Steps.AddTestStep($"Expecting True for qa Environment", $"Setting expected value");
				vproEnabled = true;
				break;
			default:
				break;
		}

		if (HPGWarn.AreEqual(OkResponse, response.Status, field: ResponseStatusField))
		{
			HPGWarn.AreEqual(vproEnabled.ToString(), response.Response, field: ResponseBodyField);
		}

		return response.Response.ToBool();

	}

	/// <summary>
	///		Test a single Acitve VPRO user POST/VPRO/VerifyVPROStatus endpoint. 
	/// </summary>
	public void TestPostVproActiveUser()
	{
		Steps.AddTestStep("Test sending 'POST' SINGLE request to " + VproUserStatus + " API endpoint for a IsActive user.", "System should respond accordingly.");

		//todo: Pull test users from Db
		var vproRequest = new VproUser("VproActive49.TestUser@mailinator.com");
		var payload = JsonConvert.SerializeObject(vproRequest);
		Steps.AddTestStep($"Sending 'POST' request to " + VproUserStatus + " API endpoint with the following payload: " + payload + ".",
			$"Systems should respond with a status code: '{OkResponse}'.");
		//execute the post call
		var response = PostVproUserRequest(VproUserStatus, payload);

		//Validate the results
		if (HPGWarn.AreEqual(OkResponse, response.Status, field: ResponseStatusField))
		{
			var strResponse = JObject.Parse(response.Response).ToString();
			var vproStatus = strResponse.Substring(20, 11);
			var vproCode = strResponse.Substring(55, 2);
			var vproDesc = strResponse.Substring(90, 6);
			var x = strResponse.Substring(108, 6);
			//HPGWarn.AreEqual("VPRO Active", temp["vproStatus"].ToString(), field: ResponseBodyField);
			HPGWarn.AreEqual("VPRO Active", vproStatus, field: ResponseBodyField);
			HPGWarn.AreEqual("49", vproCode, field: ResponseBodyField);
			HPGWarn.AreEqual("Active", x, field: ResponseBodyField);

		}
		else
		{
			HPGWarn.AreEqual(OkResponse, response.Status, field: ResponseStatusField);
		}

	}

	/// <summary>
	///		Test POST/VPRO/VerifyVPROStatus endpoint: Testing for: Active, In Active, Not Found accounts
	///		Test Data are hardcoded for VPRO endpoint which is out of our control. We just have a wrapper around their API
	///		Limitations: We don't have the ability to access VPRO db nor the ability to create test users on their system
	/// </summary>
	public void TestPostVproUserStatusCheck()
	{
		Steps.AddTestStep("Test sending 'POST' Multiple request to " + VproUserStatus + " API endpoint for POS & NEG test.", "System should respond accordingly.");

		Dictionary<string, string> vproTestScenarios = new Dictionary<string, string>();
		vproTestScenarios.Add("44", "VproTermed44.TestUser@mailinator.com");    //VPRO Inactive
		vproTestScenarios.Add("49", "VproActive49.TestUser@mailinator.com");    //VPRO Active
																				// VPRO reported to have cleaned their Db up from vpro accts with status = 50
																				// Delete lines by EOY: vproTestScenarios.Add("50", "10jleone@innovative-health.zzz");			//VPRO Not Found
		vproTestScenarios.Add("51", "VproSuspended51.TestUser@mailinator.com"); //VPRO Inactive
		vproTestScenarios.Add("Not Found", "CHUCK.NORRIS@GMAIL.ZZZ");           //VPRO Not Found
		vproTestScenarios.Add("Bad Request", "");

		foreach (var vproUserRequest in vproTestScenarios)
		{

			var vproRequest = new VproUser(vproUserRequest.Value);
			var payload = JsonConvert.SerializeObject(vproRequest);
			var apiResponse = (vproUserRequest.Key == "Bad Request") ? BadRequestResponse : OkResponse;
			Steps.AddTestStep($"Sending 'POST' request to " + VproUserStatus + " API endpoint with the following payload: {" + payload + "}.",
				$"Systems should respond with a status code: '{apiResponse}'.");
			//execute the post call
			var response = PostVproUserRequest(VproUserStatus, payload);
			//execute the get call
			var apiVproCandidatePayload = VproCandidate + "?email=" + vproUserRequest.Value;
			var apiCandidatesResponse = GetVPRORequest(apiVproCandidatePayload);

			string expectedStatusResponse = OkResponse;
			string expectedVproStatus = string.Empty;

			switch (vproUserRequest.Key)
			{
				case "0":
					expectedVproStatus = "VPRO Not Found";
					break;
				case "44":
					expectedVproStatus = "VPRO Inactive";
					break;
				case "49":
					expectedVproStatus = "VPRO Active";
					break;
				case "50":
					expectedVproStatus = "VPRO Inactive";
					break;
				case "51":
					expectedVproStatus = "VPRO Inactive";
					break;
				case "Not Found":
					expectedVproStatus = "VPRO Not Found";
					break;
				case "Bad Request":
					expectedStatusResponse = BadRequestResponse;
					expectedVproStatus = "No search criteria provided.";
					break;
				default:
					throw new Exception("Some other Error happened for Scenario " + vproUserRequest.Key);
					break;
			}

			if (HPGWarn.AreEqual(expectedStatusResponse, response.Status, field: ResponseStatusField))
			{
				var expectedCandidateStatusId = vproUserRequest.Key;
				if (vproUserRequest.Key.Equals("Bad Request"))
				{
					HPGWarn.AreEqual(expectedVproStatus, response.Response, field: ResponseBodyField);
				}
				else
				{
					int len = 2;
					if (vproUserRequest.Key == "Not Found")
					{
						len = 4;
						expectedCandidateStatusId = "null";
					}

					var temp = JObject.Parse(response.Response);
					HPGWarn.AreEqual(expectedVproStatus, temp["vproStatus"].ToString(), field: ResponseBodyField);
					int startPos = apiCandidatesResponse.Response.IndexOf("statusID") + 10;
					var statusId = apiCandidatesResponse.Response.Substring(startPos, len);
					var UserStatusIdReturned = statusId.Replace(',', ' ').TrimEnd();
					HPGWarn.AreEqual(expectedCandidateStatusId, UserStatusIdReturned, field: "statusID:");

				}


			}
		}
	}

	/// <summary>
	///		Test Gets VPRO Credentialing Request with coid, and status authorization.
	///			GET/VPRO/getVPROCandidate?email= validEmail endpoint & Logs results with payload and response.body
	/// </summary>
	public void TestGetVproCandidate()
	{
		Steps.AddTestStep("Test sending 'GET' request to " + VproCandidate + "API endpoint to get candidate information.", "System should respond accordingly.");

		Dictionary<string, string> vproEmailTestScenarios = new Dictionary<string, string>
		{
			{ "Active", "VproActive49.TestUser@mailinator.com" },
			{ "InActive", "VproSuspended51.TestUser@mailinator.com" },
			{ "NotFound", "VproTermed44.TestUser@mailinator.com" },
			{ "MissingEmail", "" },
			{ "BadEmail", "123abc()#" },
			{ "Active1", "Abigail.james@stryker.zzz" },
			{ "Active2", "adeahl@globusmedical.zzz" },
			{ "Active3", "Allen.Wernon@smith-nephew.zzz" }
		};

		foreach (var vproEmailRequest in vproEmailTestScenarios)
		{
			var vproRequest = string.Empty;
			var expectedStatusResponse = string.Empty;
			switch (vproEmailRequest.Key)
			{
				case "Active":
					expectedStatusResponse = OkResponse;
					vproRequest = VproCandidate + "?email=" + vproEmailRequest.Value;
					break;
				case "Active1":
					expectedStatusResponse = OkResponse;
					vproRequest = VproCandidate + "?email=" + vproEmailRequest.Value;
					break;
				case "Active2":
					expectedStatusResponse = OkResponse;
					vproRequest = VproCandidate + "?email=" + vproEmailRequest.Value;
					break;
				case "Active3":
					expectedStatusResponse = OkResponse;
					vproRequest = VproCandidate + "?email=" + vproEmailRequest.Value;
					break;
				case "InActive":
					expectedStatusResponse = OkResponse;
					vproRequest = VproCandidate + "?email=" + vproEmailRequest.Value;
					break;
				case "NotFound":
					expectedStatusResponse = OkResponse;
					vproRequest = VproCandidate + "?email=" + vproEmailRequest.Value;
					break;
				case "MissingEmail":
					expectedStatusResponse = BadRequestResponse;
					vproRequest = VproCandidate + "?email=" + vproEmailRequest.Value;
					break;
				case "BadEmail":
					//expectedStatusResponse = BadRequestResponse;
					expectedStatusResponse = OkResponse;
					vproRequest = VproCandidate + "?email=" + vproEmailRequest.Value;
					break;
			}

			//execute the get call
			var apiResponse = GetVPRORequest(vproRequest);
			Steps.AddTestStep($"Sending 'GET' request to " + VproCandidate + " API endpoint. Scenario: " + vproEmailRequest.Key + " with the following request: {" + vproEmailRequest.Value + "}.",
				$"Systems should respond with a status code: '{expectedStatusResponse}'.");

			if (HPGWarn.AreEqual(expectedStatusResponse, apiResponse.Status, field: ResponseStatusField))
			{
				if (vproEmailRequest.Key.Equals("Bad Request"))
				{   //Todo: VPRO takes everything regardless of input. There should be 2 bad request but 1 now as of 13Feb24
					HPGWarn.AreEqual(expectedStatusResponse, apiResponse.Status, field: ResponseStatusField);

				}
				else
				{
					HPGWarn.AreEqual(expectedStatusResponse, apiResponse.Status, field: ResponseStatusField);
				}
				var reply = apiResponse.Response.Replace(",", ",\n        ");
				ConsoleOut.WriteReport("Response Body:", true);
				ConsoleOut.WriteReport(reply, true);
				ConsoleOut.WriteReport("\n", true);
			}
		}
	}

	/// <summary>
	///		Test POST/VPRO/getVPROCandidate?email= validEmail endpoint & Logs results with payload and response.body
	/// </summary>
	public void TestPostVproGetCredentialingRequest()
	{
		Steps.AddTestStep("Test sending 'POST' Multiple request to " + VproCredentialing + " API endpoint for POS & NEG test.", "System should respond accordingly.");

		Dictionary<string, string> vproTestScenarios = new Dictionary<string, string>
		{
			{ "Active", "VproActive49.TestUser@mailinator.com" },		//"Allen.Wernon@smith-nephew.zzz" 
			{ "InActive", "VproSuspended51.TestUser@mailinator.com" },	//"craigkarpe+34@gmail.zzz"
			{ "Not Found",  "VproTermed44.TestUser@mailinator.com"},	//"chuck.norris@stryker.zzz"
			{ "BadRequest_MissingEmail", "" },
			/* Ui doing validation so these are not bad requests anymore
			{ "BadRequest_NumericMix", "1234$&*()" },
			{ "BadRequest_NumbersEmail", "123456789" },
			{ "BadRequest_AlphabeticEmail", "abcdefghijklmnop@abc.com" },
			{ "BadRequest_NonAlphaNumericEmail", "!@#$%^&*()" }, Keep until end of 2025 then remove */
		};
		foreach (var vproUserRequest in vproTestScenarios)
		{
			var expectedStatusResponse = OkResponse;
			var vproRequest = new VproUser(vproUserRequest.Value);
			var payload = JsonConvert.SerializeObject(vproRequest);
			Steps.AddTestStep($"Sending 'POST' request to " + VproCredentialing + " API endpoint with the following {" + vproUserRequest.Key + "} user payload: {" + payload + "}.",
				$"Systems should respond with a status code: '{expectedStatusResponse}'.");
			//execute the post call
			var apiResponse = PostVproUserRequest(VproCredentialing, payload);
			switch (vproUserRequest.Key)
			{
				case "Active":
					expectedStatusResponse = OkResponse;
					break;
				case "InActive":
					expectedStatusResponse = OkResponse;
					break;
				case "Not Found":
					expectedStatusResponse = OkResponse;
					break;
				case "BadRequest_MissingEmail":
					expectedStatusResponse = BadRequestResponse;
					break;
				/* Ui doing validation so these are not bad requests anymore
				case "BadRequest_NumericMix":
					//expectedStatusResponse = BadRequestResponse; 
					break;

				case "BadRequest_NumbersEmail":
					//expectedStatusResponse = BadRequestResponse;
					break;
				case "BadRequest_AlphabeticEmail":
					//expectedStatusResponse = BadRequestResponse;
					break;
				case "BadRequest_NonAlphaNumericEmail":
					//expectedStatusResponse = BadRequestResponse;
					break;
					*/
				default:
					throw new Exception("Some other Error happened for Scenario " + vproUserRequest.Key);
					//break; << apparently unreachable code: suggestion was to comment it out. Remove at EOY2025
			}
			/* TODO: Improvments on this test
				1. Capture the coid values being returned from the api into a coid <list>
				2. Build a query with the coid<list> (need to figure out what file that would go in)
				3. Connect to Db
				4. Execute query, Get results for the VPRO User
				5. Display as part of the results to validate */

			if (HPGWarn.AreEqual(expectedStatusResponse, apiResponse.Status, field: ResponseStatusField))
			{
				if (vproUserRequest.Key.Equals("Bad Request"))
				{
					HPGWarn.AreEqual(expectedStatusResponse, apiResponse.Status, field: ResponseStatusField);
				}
				else
				{
					HPGWarn.AreEqual(expectedStatusResponse, apiResponse.Status, field: ResponseStatusField);
					if (vproUserRequest.Key.Contains("BadRequest_"))
					{
						ConsoleOut.WriteReport("        VPRO API returns 200 OK Status for Negative test - NO RESULTS IN BODY:", true);
					}
					var reply = apiResponse.Response.Replace("{", "\n        {");
					reply = reply.Replace(",", ",\n        ");
					ConsoleOut.WriteReport("Response Body:", true);
					ConsoleOut.WriteReport(reply, true);
					ConsoleOut.WriteReport("\n", true);
				}
			}
		}
	}

	/// <summary>
	/// Test sending 'POST' request to the VproCredentialing API endpoint for VproUserInsideOutsideUserSoc.
	/// This method tests the VPRO credentialing request for users inside and outside the user span of control (SoC).
	/// It modifies the security roles and span of control for a specified user and validates the response.
	/// </summary>
	public void TestPostVproGetCredentialingRequestInsideOutsideUserSoc()
	{
		Steps.AddTestStep("Test sending 'POST' request to " + VproCredentialing + " API endpoint for VproUserInsideOutsideUserSoc.", "System should respond accordingly.");
		// Define test scenarios
		Dictionary<string, string> vproTestScenarios = new Dictionary<string, string>
					{
						{ "InsideUserSoc", "VproActive49.TestUser@mailinator.com" }
						// asOf: july - vpro data has changed We no longer have vpro data for this scenario. Need to research VPRO ACCTS to find one
						//{ "OutsideUserSoc", "clayton.swinney@abbott.com" }  
					};

		//Get SecAdmin & Modify HTNASVCTSTAUT01. Under SA Role remove HealthTrust & Verify at least 1 SoC from test accts are assinged. 
		var securityTestUser = vproRepository.GetSecurityAdminUserKey();
		if (ModSecAdminUsersRoleSoC("VproInsideOutsideUserSocTest", securityTestUser, true))
		{
			// Execute test scenarios
			foreach (var vproUserRequest in vproTestScenarios)
			{
				var vproRequest = new VproUser(vproUserRequest.Value);
				var payload = JsonConvert.SerializeObject(vproRequest);
				var expectedStatusResponse = OkResponse;

				Steps.AddTestStep($"Sending 'POST' request to  '{VproCredentialing}' API endpoint with the following payload: '{payload}'. Tester: {securityTestUser},{vproUserRequest} Test.",
					$"Systems should respond with a status code: '{expectedStatusResponse}'.");

				// Execute the post call
				var apiResponse = PostVproUserRequest(VproCredentialing, payload);
				// Validate the response
				if (HPGWarn.AreEqual(expectedStatusResponse, apiResponse.Status, field: ResponseStatusField))
				{
					var json = JObject.Parse(apiResponse.Response);

					var insideUserSoCArray = json["vproFacilityInsideUserSoC"] as JArray;
					var outsideUserSoCArray = json["vproFacilityOutsideUserSoC"] as JArray;

					// Collect COIDs from inside array
					var insideCoids = insideUserSoCArray?
						.Select(j => j["coid"]?.ToString())
						.Where(coid => !string.IsNullOrEmpty(coid))
						.ToList() ?? new List<string>();

					// Collect COIDs from outside array
					var outsideCoids = outsideUserSoCArray?
						.Select(j => j["coid"]?.ToString())
						.Where(coid => !string.IsNullOrEmpty(coid))
						.ToList() ?? new List<string>();

					// Report COIDs found
					if (insideCoids.Any())
						ConsoleOut.WriteReport($"InsideUserSoC COIDs: {string.Join(", ", insideCoids)}", true);
					else
						ConsoleOut.WriteReport("No COIDs found in InsideUserSoC array.", true);

					if (outsideCoids.Any())
						ConsoleOut.WriteReport($"OutsideUserSoC COIDs: {string.Join(", ", outsideCoids)}", true);
					else
						ConsoleOut.WriteReport("No COIDs found in OutsideUserSoC array.", true);

					Steps.AddTestStep("Checking: vproFacilityInsideUserSoC & vproFacilityOutsideUserSoC Part for COIDs.", "True");

					// Validation: Expect at least 1 COID in either array
					if (!insideCoids.Any() && !outsideCoids.Any())
					{
						HPGAssert.Fail("Validation failed: No 'coid' found in either array. Expecting at least 1 coid. Add Healthtrust Soc to HTNASVCTSTAUT51");
					}

					var reply = json.ToString(Formatting.Indented);
					ConsoleOut.WriteReport("Response Body:", true);
					ConsoleOut.WriteReport(reply, true);
					ConsoleOut.WriteReport("\n", true);
				}

			}
			Steps.AddTestStep("Resetting Test user: " + securityTestUser, "ModSecAdminUsersRoleSoC - system should responde accordingly");
			ModSecAdminUsersRoleSoC("VproInsideOutsideUserSocTest", securityTestUser, false);
		}
		else
		{
			Steps.AddTestStep("Unable to modify ServiceAcct: HTNASVCTSTAUT01 by setting testers account to on " +
			"facility inside/outside user soc for SoC", "System should respond accordingly.");
		}
	}

	/// <summary>
	///		Test POST/VPRO/getVPROCandidate?email= validEmail endpoint & Logs results with payload and response.body
	/// </summary>
	public void TestGetByVproUserEmailIdRequest()
	{
		Steps.AddTestStep("Test sending 'GET' request to " + ByVproUserEmailId + " API endpoint duplicate email check.", "System should respond accordingly.");
		List<string> TestCases = new List<string>()
		{
			"AddUniqueEmail",		//Unique VproEmailUserId: 204 response body is empty
			"AddDuplicateEmail",	//Duplicate VproEmailUserId: 200 OK with response body.length>0
			"EmptySetEmail",
			"EditUniqueEmail",
			"EditDuplicateEmail",
			"BadRequest",
			"EmptySet",
		};

		VproUserDb vproUserNew = new VproUserDb { UserKey = "7000D594-607B-4A0D-8AEA-041743EC5A22", VproEmailUserId = "Space.Ghost@hbb.com" };
		VproUserDb vproUserExisting = new VproUserDb { VproEmailUserId = "VproActive49.TestUser@mailinator.com" };
		vproUserExisting.UserKey = (GlobalTestVariables.TestEnvironment == "qasbx")
			? "d90044f8-5750-4b35-8be9-d68b5863cede"    //User key for qasbx
			: "b62ccaae-8acb-453a-867f-4f0fe2dc6a45";   //User Key fro qa

		foreach (var testCase in TestCases)
		{
			var vproRequest = string.Empty;
			var expectedStatusResponse = string.Empty;
			switch (testCase)
			{
				case "AddUniqueEmail":
					expectedStatusResponse = NoContent;
					vproRequest = ByVproUserEmailId + "?vproUserEmailId=" + vproUserNew.VproEmailUserId;
					break;
				case "AddDuplicateEmail":
					expectedStatusResponse = OkResponse;
					vproRequest = ByVproUserEmailId + "?vproUserEmailId=" + vproUserExisting.VproEmailUserId;
					break;
				case "EmptySetEmail":
					expectedStatusResponse = BadRequestResponse;
					vproRequest = ByVproUserEmailId + "?vproUserEmailId=" + string.Empty;
					break;

				case "EditUniqueEmail":
					expectedStatusResponse = NoContent;
					vproRequest = ByVproUserEmailId + "?userid=" + vproUserNew.UserKey + "&vproUserEmailId=" + vproUserNew.VproEmailUserId;
					break;
				case "EditDuplicateEmail":
					expectedStatusResponse = OkResponse;
					vproRequest = ByVproUserEmailId + "?userid=" + vproUserExisting.UserKey + "&vproUserEmailId=" + vproUserExisting.VproEmailUserId;
					break;
				case "BadRequest":
					expectedStatusResponse = BadRequestResponse;
					vproRequest = ByVproUserEmailId + "?userid=BadRequest&vproUserEmailId=BadRequest";
					break;
				case "EmptySet":
					expectedStatusResponse = BadRequestResponse;
					vproRequest = ByVproUserEmailId + "?userid=" + string.Empty + "&vproUserEmailId=" + string.Empty;
					break;
			}

			Steps.AddTestStep($"Sending 'GET' request to " + ByVproUserEmailId + " API endpoint. Scenario: {" + testCase + " Request: " + vproRequest + "}.", $"Systems should respond with a status code: '{expectedStatusResponse}'.");
			var apiResponse = GetVPRORequest(vproRequest);
			HPGWarn.AreEqual(expectedStatusResponse, apiResponse.Status, field: ResponseStatusField);
			if (apiResponse.Response.Length > 0)
			{
				var reply = apiResponse.Response.Replace(",", ",\n        ");
				ConsoleOut.WriteReport("Response Body:", true);
				ConsoleOut.WriteReport(reply, true);
				ConsoleOut.WriteReport("\n", true);
			}
		}
	}

	/// <summary>
	///		Test POST/VPRO/getVPROFacilityVisits 
	/// </summary>
	public void TestPostVproGetVproFacilityVisits()
	{
		Steps.AddTestStep(
			"Test sending 'POST' Multiple request to " + VproFacilityVisits + " API endpoint for POS & NEG test.",
			"System should respond accordingly.");
		Dictionary<string, string> vproTestScenarios = new Dictionary<string, string>
		{
			{ "ExistingEmail", OkResponse },
			{ "NullRequest", BadRequestResponse },
			{ "NotExistingEmail", OkResponse },
			{ "BadEmailExtension", OkResponse },
			{ "BadEmailFormat1", BadRequestResponse },
			{ "BadEmailFormat2", BadRequestResponse },
			{ "BadStartDate", OkResponse },
			{ "BadEndDate", OkResponse },
			{ "MissingEmail", BadRequestResponse },
			{ "MissingStartDate", BadRequestResponse },
			{ "MissingEndDate", BadRequestResponse }
			// Only hits late night: { "VproSystemUnresponsive", InternalServerResponse}
		};
		foreach (var vproTestCase in vproTestScenarios)
		{
			var vproRequest = new VproUser();
			var expectedStatusResponse = vproTestCase.Value;
			switch (vproTestCase.Key)
			{
				case "ExistingEmail":
					vproRequest.Email = "clayton.swinney@abbott.com";
					vproRequest.StartDate = "2024-01-01T01:00";
					vproRequest.EndDate = "2024-09-31T23:59";
					break;
				case "NullRequest":
					vproRequest.Email = null;
					vproRequest.StartDate = null;
					vproRequest.EndDate = null;
					break;
				case "NotExistingEmail":
					vproRequest.Email = "Fred.Flinstone@gmail.com";
					vproRequest.StartDate = "2024-01-01T01:00";
					vproRequest.EndDate = "2024-09-31T23:59";
					break;
				case "BadEmailExtension":
					vproRequest.Email = "clayton.swinney@abbott.zip";
					vproRequest.StartDate = "2024-01-01T01:00";
					vproRequest.EndDate = "2024-09-31T23:59";
					break;
				case "BadEmailFormat1":
					vproRequest.Email = "clayton.swinney abbott.zip";
					vproRequest.StartDate = "2024-01-01T01:00";
					vproRequest.EndDate = "2024-09-31T23:59";
					break;
				case "BadEmailFormat2":
					vproRequest.Email = "clayton.swinney$abbott.com";
					vproRequest.StartDate = "2024-01-01T01:00";
					vproRequest.EndDate = "2024-09-31T23:59";
					break;
				case "BadStartDate":
					vproRequest.Email = "clayton.swinney@abbott.com";
					vproRequest.StartDate = "0000-01-01";
					vproRequest.EndDate = "2024-09-31T23:59";
					break;
				case "BadEndDate":
					vproRequest.Email = "clayton.swinney@abbott.com";
					vproRequest.StartDate = "2024-01-01T01:00";
					vproRequest.EndDate = "2024-07-99";
					break;
				case "MissingEmail":
					vproRequest.Email = "";
					vproRequest.StartDate = "2024-01-01T01:00";
					vproRequest.EndDate = "2024-09-31T23:59";
					break;
				case "MissingStartDate":
					vproRequest.Email = "clayton.swinney@abbott.com";
					vproRequest.StartDate = "";
					vproRequest.EndDate = "2024-09-31T23:59";
					break;
				case "MissingEndDate":
					vproRequest.Email = "clayton.swinney@abbott.com";
					vproRequest.StartDate = "2024-01-01T01:00";
					vproRequest.EndDate = "";
					break;
				case "VproSystemUnresponsive":  //need to try and hit this during the day.
					vproRequest.Email = "clayton.swinney@abbott.com";
					vproRequest.StartDate = "zzzz-zz-zz";
					vproRequest.EndDate = "zzzz-zz-zz";
					break;
				default:
					throw new Exception("Some other Error happened for Scenario " + vproTestCase.Key);
					break;
			}

			var payload = JsonConvert.SerializeObject(vproRequest);
			Steps.AddTestStep(
				"API Post Request:" + VproFacilityVisits + " - TestScenario: " + vproTestCase.Key + ", Email: " + vproRequest.Email + ", StartDate: " +
				vproRequest.StartDate + ", EndDate: " + vproRequest.EndDate + ". ",
				"Expected Status Response: " + expectedStatusResponse);
			var apiResponse = PostVproUserRequest(VproFacilityVisits, payload);
			if (HPGWarn.AreEqual(expectedStatusResponse, apiResponse.Status, field: ResponseStatusField))
			{
				var reply = apiResponse.Response.Replace("{", "\n        {");
				reply = reply.Replace(",", ",\n        ");
				ConsoleOut.WriteReport("Response Body:", true);
				ConsoleOut.WriteReport(reply, true);
				ConsoleOut.WriteReport("\n", true);
			}
		}
	}
	/// <summary>
	///		Test Get/VPRO/getVPROBadgeInEndTime
	/// </summary>
	public void TestGetVproBadgeInEndTime()
	{
		Steps.AddTestStep("Test sending 'Get' Multiple request to " + VproGetVproBadgeInEndTime + " API endpoint for POS & NEG test.",
			"System should respond accordingly.");
		const string ValidEndOfDay = "2024-07-01T23:59:59";
		const string ValidTillNextDay = "2024-07-02T05:59:59";
		Dictionary<string, string> vproTestScenarios = new Dictionary<string, string>
		{
			{ "2024-07-01T00:00:60", BadRequestResponse },	//Error
			{ "2024-07-01T00:00:00", OkResponse },			//2024-07-01T23:59:59
			{ "2024-07-01T00:00:59", OkResponse },          //2024-07-01T23:59:59
			{ "2024-07-01T00:01:00", OkResponse },          //2024-07-01T23:59:59
			{ "2024-07-01T00:10:00", OkResponse },          //2024-07-01T23:59:59
			{ "2024-07-01T17:00:00", OkResponse },          //2024-07-01T23:59:59
			{ "2024-07-01T17:59:59", OkResponse },          //2024-07-01T23:59:59
			{ "2024-07-01T18:00:00", OkResponse },			//2024-07-02T05:59:59
			{ "2024-07-01T23:59:59", OkResponse },			//2024-07-02T05:59:59
			{ "2024-07-01T23:59:60", BadRequestResponse }	//Error
		};
		foreach (var TestCase in vproTestScenarios)
		{
			var expectedResponse = TestCase.Value;
			var vproRequest = VproGetVproBadgeInEndTime + "?badgeInDate=" + TestCase.Key;
			var apiResponse = GetVPRORequest(vproRequest);
			Steps.AddTestStep("API Get Request:" + VproGetVproBadgeInEndTime + " - TestScenario: " + TestCase.Key + ". ", "Expected Status Response: " + expectedResponse);
			if (HPGWarn.AreEqual(expectedResponse, apiResponse.Status, field: ResponseStatusField))
			{
				if (apiResponse.Status.Contains(BadRequestResponse))
				{
					var errorMsg = apiResponse.Response.Substring(135, 63).Replace("[", "").Replace("\"", "").Replace("]}", "");
					var expectedError = "badgeInDate:The value '" + TestCase.Key + "' is not valid.";
					HPGWarn.AreEqual(expectedError, errorMsg, field: "Errors");
				}
				else
				{
					if ((TestCase.Key.Substring(11, 2).Contains("00")) || (TestCase.Key.Substring(11, 2).Contains("17")))
					{
						HPGWarn.AreEqual(ValidEndOfDay, apiResponse.Response.Replace("\"", ""), field: "Same Day Expire TimeStamp:" + apiResponse.Response);
					}
					else
					{
						HPGWarn.AreEqual(ValidTillNextDay, apiResponse.Response.Replace("\"", ""), field: "Next Day Expire TimeStamp:" + apiResponse.Response);
					}
				}
			}
		}

	}

	#endregion Test Methods

	#region Helpers

	///<summary>
	/// Cleans up VPRO user data by setting users to inactive or updating their roles and affiliations.
	/// This method should be run when there is a need to correct or clean up VPRO user data in the system.
	/// </summary>
	public void TestVproDataIssueCorrections()
	{
		Steps.AddTestStep("Test data clean up: TestVproDataIssueCorrections()", "System should respond accordingly.");
		var userApi = new UserApi();
		var actionToTake = "setUsersToInactive"; //used to set bad user data to Inactive
												 //var actionToTake = "setAffiliationRoleSoc"; //used to set vendor affiliation, role, soc
		const string sProcurement = "9068249A-1CC4-4D8D-BB30-4A0FC9FC98CD";
		List<string> sProcurementVboRole = new List<string>() { "0B6EDD25-4C04-4D31-B28C-20D3B141DAC5" };
		AddUserRoleSoc userRoleSoc = new AddUserRoleSoc();
		var vproUsers = vproRepository.GetVproUserData(actionToTake); //setTestDataAffiliationSoc
		foreach (var vproUser in vproUsers)
		{
			userRoleSoc.UserId = vproUser.UserKey.ToString();
			userRoleSoc.ApplicationId = sProcurement;
			userRoleSoc.IsDeactivated = vproUser.IsDeactivated;
			userRoleSoc.RoleIds = sProcurementVboRole.ToList();
			userRoleSoc.Roles = new List<RoleDetail>
			{
				new() { Id = "0B6EDD25-4C04-4D31-B28C-20D3B141DAC5",
						Name = "Procurement - Vendor Bill Only",
						IsDeleted = false,
						UserType = "Vendor" }
			};
			userRoleSoc.VendorAffiliation = new List<Vendor.VendorModel>
			{
				new() { Id = 900600,
						Name = "CAPITAL X-RAY" }
			};
			userRoleSoc.SpanOfControl = new List<Users.SpanOfControl>
			{
				new()
				{   HierarchyType = "5",
					ObjectId = "09391",
					OrgName = "Stonecrest Medical Center",
					IsDeleted = false,
					CreatedOn = DateTime.Now,
					IsVproFacility = false,
					VproFacilityName = string.Empty,
					VproFacilityCoid = string.Empty
				}
			};
			if (actionToTake == "setAffiliationRoleSoc")
			{
				userRoleSoc.VproStatus = "VPRO Not Found";
				userRoleSoc.ByPassVPROEndDate = new DateTimeOffset(2025, 12, 31, 0, 0, 0, TimeSpan.Zero);
				userRoleSoc.VPROUserEmailId = vproUser.Email;
			}
			else
			{
				userRoleSoc.IsDeactivated = true;
				userRoleSoc.VproStatus = null;
				userRoleSoc.ByPassVPROEndDate = null;
				userRoleSoc.VPROUserEmailId = "BadDataAutomationCleanUp";
			}

			var desc = $"Sending clean up request: {actionToTake} for User: {userRoleSoc.UserId}.";
			var Payload = JsonConvert.SerializeObject(userRoleSoc, JsonNullSetting);
			var response = PostSimpleRequest($"{BaseUri}{UserResource}{ClaimResource}", Payload);
			Steps.AddTestStep(desc, $"Expecting: {OkResponse} ; Actual: {response.Status}.");
			HPGWarn.AreEqual(OkResponse, response.Status, field: ResponseStatusField);
		}

	}

	/// <summary>
	/// Modifies the security roles and span of control for a specified user.
	/// </summary>
	/// <param name="actionToTake">The action to take, such as setting roles or resetting them.</param>
	/// <param name="userId">The ID of the user to modify.</param>
	/// <param name="reset">Indicates whether to reset the roles and span of control.</param>
	/// <returns>The status of the response from the API call.</returns>
	public bool ModSecAdminUsersRoleSoC(string actionToTake, string userId, bool reset)
	{
		// Create a new instance of UserApi
		var userApi = new UserApi();

		// Define application and role IDs
		var smartSecApp = "E68AB150-F05F-49BF-8C91-5EC4494FFD4C";
		var secAdmin = "5BA8B90F-E086-46F2-9903-0EAA893FD674";

		// Create a list of roles
		List<string> smartSecurityRoles = new List<string>() { secAdmin };

		// Create a new instance of AddUserRoleSoc and set its properties
		AddUserRoleSoc userRoleSoc = new AddUserRoleSoc();
		userRoleSoc.UserId = userId;
		userRoleSoc.ApplicationId = smartSecApp;
		userRoleSoc.IsDeactivated = false;
		userRoleSoc.RoleIds = smartSecurityRoles.ToList();
		userRoleSoc.Roles = new List<RoleDetail>
		{
			new() { Id = "5BA8B90F-E086-46F2-9903-0EAA893FD674",
					Name = "Security - Administrator",
					IsDeleted = false,
					UserType = "Employee" }
		};

		// Set the span of control for the user
		userRoleSoc.SpanOfControl = new List<Users.SpanOfControl>
		{
			new()
			{   HierarchyType = "0",
				ObjectId = "00001",
				OrgName = "HealthTrust",
				IsDeleted = reset,
				IsVproFacility = null,
				VproFacilityName = string.Empty,
				VproFacilityCoid = string.Empty
			},
			new()
			{   HierarchyType = "5",
				ObjectId = "09391",
				OrgName = "Stonecrest Medical Center",
				IsDeleted = false,
				CreatedOn = DateTime.Now,
				IsVproFacility = false,
				VproFacilityName = string.Empty,
				VproFacilityCoid = string.Empty
			},
			new()
			{   HierarchyType = "5",
				ObjectId = "27625",
				OrgName = "Angel Medical Center",
				IsDeleted = false,
				CreatedOn = DateTime.Now,
				IsVproFacility = false,
				VproFacilityName = string.Empty,
				VproFacilityCoid = string.Empty
			},
			new()
			{   HierarchyType = "5",
				ObjectId = "35940",
				OrgName = "HCA Florida Woodmont Hosptial",
				IsDeleted = false,
				CreatedOn = DateTime.Now,
				IsVproFacility = false,
				VproFacilityName = string.Empty,
				VproFacilityCoid = string.Empty
			}
		};

		// Create a description for the action
		var desc = $"Mod Testers Soc to Facility only: {actionToTake} for User: {userRoleSoc.UserId}.";

		// Serialize the userRoleSoc object to JSON
		var Payload = JsonConvert.SerializeObject(userRoleSoc, JsonNullSetting);

		// Send a POST request to the API
		var response = PostSimpleRequest($"{BaseUri}{UserResource}{ClaimResource}", Payload);

		// Add a test step with the description and expected response
		Steps.AddTestStep(desc, $"Expecting: {OkResponse} ; Actual: {response.Status}.");

		// Validate the response status
		if (HPGWarn.AreEqual(OkResponse, response.Status, field: ResponseStatusField))
			return true;
		else
			return false;
	}
	#endregion Helpers
}

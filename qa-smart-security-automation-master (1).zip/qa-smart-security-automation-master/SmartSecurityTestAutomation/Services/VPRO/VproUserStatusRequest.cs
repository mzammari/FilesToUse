﻿using System;
using System.Text.Json.Serialization;
using SmartSecurityTestAutomation;
using Utilities.Generators;
using Utilities.ObjectExtensions;

namespace SmartSecurityTestAutomation.Services.VPRO;

public class VproUser
{
	[JsonPropertyName("email")]
	public string Email { get; set; }
	[JsonPropertyName("startDate")]
	public string StartDate { get; set; }
	[JsonPropertyName("endDate")]
	public string EndDate { get; set; }


	public VproUser()
	{
	}

	public VproUser(string email)
	{
		Email = email;
	}

}


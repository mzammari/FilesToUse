﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartSecurityTestAutomation.Services.VPRO;

//todo: Need to double check if i need this class. Might be able to use the one in User folder and add new VPRO Fields
//todo: Check and see how many changes it will take to merge and have our code use that class

public class VproUserDb
{
	public string Username { get; set; }
	public string Domain { get; set; }
	public string FirstName { get; set; }
	public string LastName { get; set; }
	public string Email { get; set; }
	public int UserType { get; set; }
	public bool IsDeactivated { get; set; }
	public bool IsDeleted { get; set; }
	public Guid UserId { get; set; }
	public string VproStatus { get; set; }
	public string ByPassVPROEndDate { get; set; }
	public string VproEmailUserId { get; set; }
	public string SupplierPotalUpdatedDate { get; set;}
	public string UserKey { get; set; }
}




﻿using SmartSecurityTestAutomation.Services.Users;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Utilities.DatabaseUtility;
using Utilities.ObjectExtensions;
using Utilities.SetupTestUsers;

namespace SmartSecurityTestAutomation.Services.VPRO;

public class VproRepository
{
	private readonly string _server;
	private readonly string _dbName;

	public VproRepository(string server, string dbName)
	{
		_server = server;
		_dbName = dbName;
	}
	
	/// <summary>
	/// Connects to Db and gets the VBO - Vpro Users that exists within Security Db
	/// </summary>
	/// <param name="vproUserEmail"></param>
	/// <param name="timeToWait"></param>
	/// <returns></returns>
	/// <exception cref="Exception"></exception>
	public IEnumerable<UserResponse> GetVproUser(string vproUserEmail = null, int timeToWait = 0)
	{
		if (timeToWait > 0)
			Thread.Sleep(1000 * timeToWait);
		try
		{
			var dbs = new DbSql(_server, _dbName);
			var query = vproUserEmail == null ? SelectVproUsers : $"{SelectSingleVproUser} WHERE U.VPROUserEmailId = '{vproUserEmail}' AND U.IsDeactivated = 0 ";
			return dbs.GetRecordsIntoObject<UserResponse>(query);
		}
		catch (Exception e)
		{
			Console.WriteLine(e);
			throw new Exception($"Unable to retrieve SMART Security Single VPRO User data!\r\nError Message: {e}");
		}
	}
	
	/// <summary>
	///		GetAllVproUsersDb - Gets ALL Vpro specific Vendors
	/// </summary>
	/// <param name="timeToWait"></param>
	/// <returns></returns>
	/// <exception cref="Exception"></exception>
	public (IEnumerable<UserResponse> vproRecords, List<UserResponse> testUser) GetAllVproUsers(int timeToWait = 0)
	{
		if (timeToWait > 0)
			Thread.Sleep(1000 * timeToWait);
		try
		{
			var dbs = new DbSql(_server, _dbName);
			var vproRecords = dbs.GetRecordsIntoObject<UserResponse>(SelectVproUsers);
			//var testUser = new List<UserResponse>();
			var testUser = vproRecords.Where(i => i.LastName.Contains("DoNotAlter")).ToList();
			return (vproRecords, testUser) ;
		}
		catch (Exception e)
		{
			Console.WriteLine(e);
			throw new Exception($"Unable to retrieve SMART Security ALL VPRO Users data!\r\nError Message: {e}");
		}
	}
	
	/// <summary>
	/// Retrieves VPRO user data based on the specified query type.
	/// </summary>
	/// <param name="queryType">The type of query to execute. Valid values are 'update' or 'inactive'.</param>
	/// <param name="timeToWait">The time to wait before executing the query, in seconds.</param>
	/// <returns>An enumerable collection of UserResponse objects.</returns>
	/// <exception cref="Exception">Thrown when unable to retrieve VPRO user data.</exception>
	public IEnumerable<UserResponse> GetVproUserData(string queryType, int timeToWait = 0)
	{
		if (timeToWait > 0)
			Thread.Sleep(1000 * timeToWait);
		try
		{
			var dbs = new DbSql(_server, _dbName);
			string query;
			var query2 = queryType.ToLower();
			switch (queryType.ToLower())
			{
				case "setaffiliationrolesoc":
					query = SelectVproTestDataCorrections;
					break;
				case "setuserstoinactive":
					query = SelectBadDataSetVproAcctsInactive;
					break;
				default:
					throw new ArgumentException("Invalid query type. Use 'update' or 'inactive'.");
			}

			return dbs.GetRecordsIntoObject<UserResponse>(query);
		}
		catch (Exception e)
		{
			Console.WriteLine(e);
			throw new Exception($"Unable to retrieve SMART Security VPRO User data!\r\nError Message: {e}");
		}
	}

	/// <summary
	//  Retrieves the Security Admin UserKey from the database.
	/// </summary>
	/// <returns>The UserKey as a string if found; otherwise, throws an exception.</returns>
	/// <exception cref="Exception">Thrown when the Security Admin UserKey cannot be retrieved or is not found in the database.</exception>
	public string GetSecurityAdminUserKey()
	{
		try
		{
			// Initialize the database connection
			var dbs = new DbSql(_server, _dbName);

			// Execute the query to get the Security Admin UserKey
			var result = dbs.GetRecordsIntoObject<UserResponse>(SelectSecurityAdmin).FirstOrDefault();

			// Return the UserKey as a string if found, otherwise throw an exception
			return result?.UserKey?.ToString() ?? throw new Exception("Security Admin UserKey not found in the database.");
		}
		catch (Exception e)
		{
			Console.WriteLine(e);
			throw new Exception($"Unable to retrieve Security Admin UserKey!\r\nError Message: {e.Message}");
		}
	}

	/// <summary>
	/// Query that gets Existing VPRO Single user 
	/// </summary>
	private const string SelectSingleVproUser = @"SELECT  U.FirstName, U.LastName, U.Username, U.Email, U.UserTypeId, U.Domain,
        U.IsDeactivated, U.VPROStatus, U.BypassVPROEndDate, U.VPROUserEmailId, U.UserKey 
		FROM [USER] U ";

	/// <summary>
	/// Query that gets ALL Existing VPRO users with different status
	/// </summary>
	private const string SelectVproUsers = @"SELECT U.FirstName, U.LastName, U.Username, U.Email, U.UserTypeId, U.Domain,
        U.IsDeactivated, U.VPROStatus, U.BypassVPROEndDate, U.VPROUserEmailId, U.UserKey
		FROM [USER] U 
		WHERE U.UserTypeId = 2
		AND U.VPROStatus IS NOT NULL
        AND LEN(U.VPROStatus) > 0
        AND U.LastName = 'DoNotAlter'
		AND U.IsDeactivated = 0 
        ORDER BY U.VPROStatus ";

	/// <summary>
	///  Query the database for all vendors missing vproEmailId & vproStatus
	/// </summary>
	private const string SelectBadDataSetVproAcctsInactive =
		@"SELECT U.Username, U.FirstName, U.LastName, U.Email, U.VPROStatus, U.BypassVPROEndDate, U.VPROUserEmailId, U.UserKey
		FROM [USER] U 		
		WHERE U.UserTypeId  = 2 
		AND U.IsDeactivated = 0
		AND U.VPROUserEmailId IS NULL 
        AND U.USERNAME NOT IN ( 'gpousered77200455de4',
                                'gpouser5ca885b358584',
                                'gpouserad37ba252cc54',
                                'SMART.vendor1@demo-supplier.com',
                                'gpouserbdd3687536fd4',
                                '6a7cb746-c87c-4f17-b5cc-39248b1ca802',
                                'gpouserb8f3d59a02154',
                                'gpouser4c74b682d02d4',
                                'gpousere03fecec71474',
                                'gpouser9e87ac079fb44',
                                'allen.wernon@smith-nephew.zzz',
                                'adeahl@globusmedical.zzz',
                                'Abigail.james@stryker.zzz',
                                '9a9d71e4-0a1d-49cb-9418-c61ff28a2ee2',
                                'c78923b0-abd1-4bfd-b1ae-208d2eae6ec2',
                                'april.caldwell@davita.ZZZ',
                                'amrobb0103@gmail.zzz',
                                'fperezct@gmail.zzz',
                                'Rebecca.McDaniel@centaurihs.zzz',
                                'malikaht@gmail.zzz',
                                'chuck.Norris@gmail.zzz',
                                '10jleone@innovative-health.zzz',
                                'craigkarpe+34@gmail.zzz',
                                '9390014c-02c1-4faf-92d5-ab66190e9fc1')
		AND U.USERNAME NOT IN ( SELECT U2.Username
		                        FROM [USER] U2 
		                        WHERE U2.Username     != U2.Email  
		                        AND U2.UserTypeId     = 2 
		                        AND U2.IsDeactivated  = 0
		                        AND U2.VPROUserEmailId IS NULL) --42 
		ORDER BY U.Email --142";

	/// <summary>
	/// Query the database for all vendors missing vproEmailId & vproStatus but have previously connected to supplier portal. Email != Username
	/// </summary>
	private const string SelectVproTestDataCorrections =
		@"SELECT U.Username, U.FirstName, U.LastName, U.Email, U.VPROStatus, U.BypassVPROEndDate, U.VPROUserEmailId, U.UserKey
		FROM [USER] U 
		WHERE U.UserTypeId  = 2 
		AND U.IsDeactivated = 0
		AND U.VPROUserEmailId IS NULL --42
        AND U.USERNAME NOT IN ( 'gpousered77200455de4',
                                'gpouser5ca885b358584',
                                'gpouserad37ba252cc54',
                                'SMART.vendor1@demo-supplier.com',
                                'gpouserbdd3687536fd4',
                                '6a7cb746-c87c-4f17-b5cc-39248b1ca802',
                                'gpouserb8f3d59a02154',
                                'gpouser4c74b682d02d4',
                                'gpousere03fecec71474',
                                'gpouser9e87ac079fb44',
                                'allen.wernon@smith-nephew.zzz',
                                'adeahl@globusmedical.zzz',
                                'Abigail.james@stryker.zzz',
                                '9a9d71e4-0a1d-49cb-9418-c61ff28a2ee2',
                                'c78923b0-abd1-4bfd-b1ae-208d2eae6ec2',
                                'april.caldwell@davita.ZZZ',
                                'amrobb0103@gmail.zzz',
                                'fperezct@gmail.zzz',
                                'Rebecca.McDaniel@centaurihs.zzz',
                                'malikaht@gmail.zzz',
                                'chuck.Norris@gmail.zzz',
                                '10jleone@innovative-health.zzz',
                                'craigkarpe+34@gmail.zzz',
                                '9390014c-02c1-4faf-92d5-ab66190e9fc1')
		AND U.Username != U.Email
		ORDER BY U.Email";

	/// <summary>
	/// Get Test Security Admin User
	/// </summary>
	private const string SelectSecurityAdmin = @"SELECT  U.UserKey FROM [USER] U WHERE U.Username = 'HTNASVCTSTAUT51'";

}


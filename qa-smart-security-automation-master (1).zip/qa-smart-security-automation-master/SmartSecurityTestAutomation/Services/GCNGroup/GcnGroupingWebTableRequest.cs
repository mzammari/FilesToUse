﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
namespace SmartSecurityTestAutomation.Services.GCNGroup;

public class GcnGroupingWebTableRequest
{

	[JsonProperty("take")]
	public int Take { get; set; }
	[JsonProperty("skip")]
	public int Skip { get; set; }
	[JsonProperty("searchFilter")]
	public string? SearchFilter { get; set; }
	[JsonProperty("attributeFilter")]
	public AttributeFilter? AttributeFilter { get; set; }
	[JsonProperty("columnSorts")]
	public string? ColumnSorts { get; set; }
	[JsonProperty("sortOrder")]
	public string? SortOrder { get; set; }

	// Generates a JSON payload string for the given scenario
	public string GenerateWebTableDataRequest(string scenario, GcnGroupRepository groupDb)
	{
		var basePayload = new Dictionary<string, object?>
		{
			{ "take", 10 },
			{ "skip", 0 },
			{ "columnSort", "createdOn" },
			{ "sortOrder", "asc" }
		};

		switch (scenario)
		{
			case "TakeIsMissing":
				basePayload.Remove("take");
				break;
			case "TakeIsZero":
				basePayload["take"] = 0;
				break;
			case "TakeIsNotZero":
				basePayload["take"] = 5;
				break;
			case "SkipIsZero":
				basePayload["skip"] = 0;
				break;
			case "SkipIsNotZero":
				basePayload["skip"] = 3;
				break;
			case "TakeSkipAreEqual":
				basePayload["take"] = 5;
				basePayload["skip"] = 5;
				break;
			case "SearchFilterInvalid":
				basePayload["searchFilter"] = "!!!invalid###";
				break;
			case "SearchFilterValid":
				basePayload["searchFilter"] = "Test";
				break;
			case "AttributeFilterRegion":
				basePayload["regionId"] = 1;
				break;
			case "AttributeFilterDivision":
				basePayload["divisionId"] = 1;
				break;
			case "AttributeFilterLob":
				basePayload["lobId"] = 1;
				break;
			case "AttributeFilterSubLob":
				basePayload["subLobId"] = 1;
				break;
			case "AttributeFilterApDataCapture":
				basePayload["apDataCaptureId"] = 1;
				break;
			case "ColumnSortBad":
				basePayload["columnSort"] = "badColumn";
				break;
			case "ColumnSortCreatedOn":
				basePayload["columnSort"] = "createdOn";
				break;
			case "SortOrderBad":
				basePayload["sortOrder"] = "badOrder";
				break;
			case "SortOrderDesc":
				basePayload["sortOrder"] = "desc";
				break;
			case "SortOrderAsc":
				basePayload["sortOrder"] = "asc";
				break;
		}

		return Newtonsoft.Json.JsonConvert.SerializeObject(basePayload);
	}
}

public class AttributeFilter
{
	[JsonProperty("regionId")]
	public int RegionId { get; set; }
	[JsonProperty("divisionId")]
	public int DivisionId { get; set; }
	[JsonProperty("lobId")]
	public int LobId { get; set; }
	[JsonProperty("subLobId")]
	public int SubLobId { get; set; }
	[JsonProperty("apDataCaptureId")]
	public int ApDataCaptureId { get; set; }
}
 





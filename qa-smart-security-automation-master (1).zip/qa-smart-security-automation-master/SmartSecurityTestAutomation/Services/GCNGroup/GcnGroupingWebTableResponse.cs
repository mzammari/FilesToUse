﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartSecurityTestAutomation.Services.GCNGroup;

public class GcnGroupingWebTableResponse
{
	public int TotalRecords { get; set; }
	public List<GcnGroupCOIDs> CoidData { get; set; }
}


public class GcnGroupCOIDs 
{
	public int GroupId { get; set; }
	public string GroupName { get; set; }
	public string Coid { get; set; }
	public string? ApDataCapture { get; set; }
	public string? Division { get; set; }
	public string? Lob { get; set; }
	public string? SubLob { get; set; }
	public string? Region { get; set; }
	public string CoidName { get; set; }
	public string HomeHierarchyDivisionName { get; set; }
	public DateTimeOffset CreatedOn { get; set; }
	public string CreatedBy { get; set; }
	public DateTimeOffset? UpdatedOn { get; set; }
	public string? UpdatedBy { get; set; }
} 

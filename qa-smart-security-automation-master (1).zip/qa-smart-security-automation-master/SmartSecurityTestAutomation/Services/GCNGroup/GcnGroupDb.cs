// GcnGroupDb.cs
// Represents the database entity for a GCN Group in the SmartSecurityTestAutomation system.
// Author: [Your Name]
// Created: [Date]
using System;

public class GcnGroupDb
{
    public int Id { get; set; }
    public string? Name { get; set; }
    public string? OrgName { get; set; }
    public string? Coid { get; set; } 
    public bool IsDeleted { get; set; } 
}

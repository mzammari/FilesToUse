﻿using Newtonsoft.Json;
using System;
//using SmartSecurityTestAutomation.Services.GCNGroup;
using System.Collections.Generic;
//using System.Reflection.Metadata;


namespace SmartSecurityTestAutomation.Services.GCNGroup;

public class GcnGroupCoidUpsertRequest
{
	[JsonProperty("gcN_GroupId")]
	public int GcN_GroupId { get; set; }

	[JsonProperty("coid")]
	public string Coid { get; set; }

	[JsonProperty("regionId")]
	public int RegionId { get; set; }

	[JsonProperty("divisionId")]
	public int DivisionId { get; set; }

	[JsonProperty("lobId")]
	public int LobId { get; set; }

	[JsonProperty("subLobId")]
	public int SubLobId { get; set; }

	[JsonProperty("apDataCaptureId")]
	public int ApDataCaptureId { get; set; }


	#region Helpers
	// Example static factory methods
	public GcnGroupCoidUpsertRequest GenerateGcnUpsertRequest(string testCase, Dictionary<string, int> maxIdValuesDb)
	{ 
		Steps.AddTestStep($"GenerateGcnUpsertRequest. TC: {testCase}", $"System should respond accordingly.");

		GcnGroupCoidUpsertRequest request = new GcnGroupCoidUpsertRequest();

		if (testCase.Contains("Request"))
		{
			request = AddUpdateRequest(testCase, maxIdValuesDb);
		}

		if (testCase.Contains("Missing"))
		{
			request = MissingInputFieldRequest(testCase, maxIdValuesDb);

		}

		if (testCase.Contains("MaxRecordPlus"))
		{
			request = NotExistsOutOfRangeRequest(testCase, maxIdValuesDb);
		}
		return request;

	}
	public GcnGroupCoidUpsertRequest AddUpdateRequest( string postType, Dictionary<string, int> maxIdValuesDb)
	{ 
		Steps.AddTestStep($"BUILD - AddUpdateRequest. TC: {postType}", $"System should respond accordingly.");
		var random = new Random();
		// Retrieve max ID values from the database
		int maxGroupId = GetMaxValue(maxIdValuesDb, "MaxId_Group", 1);
		int maxCoid = GetMaxValue(maxIdValuesDb, "MaxId_Group_COID", 99999);
		int maxRegionId = GetMaxValue(maxIdValuesDb, "MaxId_Region", 1);
		int maxDivisionId = GetMaxValue(maxIdValuesDb, "MaxId_Division", 1);
		int maxLobId = GetMaxValue(maxIdValuesDb, "MaxId_LOB", 1);
		int maxSubLobId = GetMaxValue(maxIdValuesDb, "MaxId_SubLOB", 1);
		int maxApDataCaptureId = GetMaxValue(maxIdValuesDb, "MaxId_APDataCapture", 1);

		// Generate random IDs within valid ranges & Coids
		var group = random.Next(1, maxGroupId + 1); // Random value between 1 and maxGroupId (inclusive)
		var region = random.Next(1, maxRegionId + 1); // Random value between 1 and maxRegionId (inclusive)
		var division = random.Next(1, maxDivisionId + 1); // Random value between 1 and maxDivisionId (inclusive)
		var lob = random.Next(1, maxLobId + 1); // Random value between 1 and maxLobId (inclusive)
		var subLob = random.Next(1, maxSubLobId + 1); // Random value between 1 and maxSubLobId (inclusive)
		var apDataCapture = random.Next(1, maxApDataCaptureId + 1); // Random value between 1 and maxApDataCaptureId (inclusive)
		
		//Increment COID if it's an "AddRequest"; otherwise, "UpdateRequest" use previous coid 
		var coid = postType == "AddRequest" ? maxCoid + 1 : maxCoid; // Random value between 1 and maxCoid (inclusive)

		return new GcnGroupCoidUpsertRequest
		{
			GcN_GroupId = group,
			Coid = coid.ToString(), // Use local variable, not property
			RegionId = region,
			DivisionId = division,
			LobId = lob,
			SubLobId = subLob,
			ApDataCaptureId = apDataCapture
		};
	}
	private static int GetMaxValue(Dictionary<string, int> dict, string key, int defaultValue)
	=> dict != null && dict.TryGetValue(key, out var value) ? value : defaultValue;

	public GcnGroupCoidUpsertRequest MissingInputFieldRequest(string postType, Dictionary<string, int> maxIdValuesDb)
	{
		Steps.AddTestStep($"BUILD - MissingInputFieldRequest. TC: {postType}", $"System should respond accordingly.");
		var random = new Random();

		int maxGroupId = GetMaxValue(maxIdValuesDb, "MaxId_Group", 1);
		int maxCoid = GetMaxValue(maxIdValuesDb, "MaxId_Group_COID", 99999);
		int maxRegionId = GetMaxValue(maxIdValuesDb, "MaxId_Region", 1);
		int maxDivisionId = GetMaxValue(maxIdValuesDb, "MaxId_Division", 1);
		int maxLobId = GetMaxValue(maxIdValuesDb, "MaxId_LOB", 1);
		int maxSubLobId = GetMaxValue(maxIdValuesDb, "MaxId_SubLOB", 1);
		int maxApDataCaptureId = GetMaxValue(maxIdValuesDb, "MaxId_APDataCapture", 1);

		var group = random.Next(1, maxGroupId + 1);
		var coid = maxCoid + 1;
		var region = random.Next(1, maxRegionId + 1);
		var division = random.Next(1, maxDivisionId + 1);
		var lob = random.Next(1, maxLobId + 1);
		var subLob = random.Next(1, maxSubLobId + 1);
		var apDataCapture = random.Next(1, maxApDataCaptureId + 1);

		return postType switch
		{
			"MissingGroupId" => new GcnGroupCoidUpsertRequest
			{
				// GroupId missing (set to 0)
				GcN_GroupId = 0,
				Coid = coid.ToString(),
				RegionId = region,
				DivisionId = division,
				LobId = lob,
				SubLobId = subLob,
				ApDataCaptureId = apDataCapture
			},
			"MissingCoid" => new GcnGroupCoidUpsertRequest
			{
				GcN_GroupId = group,
				Coid = null, // Coid missing
				RegionId = region,
				DivisionId = division,
				LobId = lob,
				SubLobId = subLob,
				ApDataCaptureId = apDataCapture
			},
			"MissingRegion" => new GcnGroupCoidUpsertRequest
			{
				GcN_GroupId = group,
				Coid = coid.ToString(),
				RegionId = 0, // RegionId missing
				DivisionId = division,
				LobId = lob,
				SubLobId = subLob,
				ApDataCaptureId = apDataCapture
			},
			"MissingDivision" => new GcnGroupCoidUpsertRequest
			{
				GcN_GroupId = group,
				Coid = coid.ToString(),
				RegionId = region,
				DivisionId = 0, // DivisionId missing
				LobId = lob,
				SubLobId = subLob,
				ApDataCaptureId = apDataCapture
			},
			"MissingLob" => new GcnGroupCoidUpsertRequest
			{
				GcN_GroupId = group,
				Coid = coid.ToString(),
				RegionId = region,
				DivisionId = division,
				LobId = 0, // LobId missing
				SubLobId = subLob,
				ApDataCaptureId = apDataCapture
			},
			"MissingSubLob" => new GcnGroupCoidUpsertRequest
			{
				GcN_GroupId = group,
				Coid = coid.ToString(),
				RegionId = region,
				DivisionId = division,
				LobId = lob,
				SubLobId = 0, // SubLobId missing
				ApDataCaptureId = apDataCapture
			},
			_ => throw new ArgumentException($"Unknown Missing Field test case: {postType}")
		};
	}

	public GcnGroupCoidUpsertRequest NotExistsOutOfRangeRequest(string testCase, Dictionary<string, int> maxIdValuesDb)
	{
		Steps.AddTestStep($"BUILD - NotExistsOutOfRangeRequest. TC: {testCase}", $"System should respond accordingly.");
		var random = new Random();
		int maxGroupId = GetMaxValue(maxIdValuesDb, "MaxId_Group", 1);
		int maxCoid = GetMaxValue(maxIdValuesDb, "MaxId_Group_COID", 99999);
		int maxRegionId = GetMaxValue(maxIdValuesDb, "MaxId_Region", 1);
		int maxDivisionId = GetMaxValue(maxIdValuesDb, "MaxId_Division", 1);
		int maxLobId = GetMaxValue(maxIdValuesDb, "MaxId_LOB", 1);
		int maxSubLobId = GetMaxValue(maxIdValuesDb, "MaxId_SubLOB", 1);
		int maxApDataCaptureId = GetMaxValue(maxIdValuesDb, "MaxId_APDataCapture", 1);
		var group = random.Next(1, maxGroupId + 1);
		var region = random.Next(1, maxRegionId + 1);
		var division = random.Next(1, maxDivisionId + 1);
		var lob = random.Next(1, maxLobId + 1);
		var subLob = random.Next(1, maxSubLobId + 1);
		var apDataCapture = random.Next(1, maxApDataCaptureId + 1);

		GcnGroupCoidUpsertRequest MaxRequest = new GcnGroupCoidUpsertRequest()
		{
			GcN_GroupId = (testCase == "MaxRecordPlus1GroupId") ? maxGroupId + 1 : group,
			Coid = maxCoid.ToString(),
			RegionId = (testCase == "MaxRecordPlus1Region") ? maxRegionId + 1 : region,
			DivisionId = (testCase == "MaxRecordPlus1Division") ? maxDivisionId + 1 : division,
			LobId = (testCase == "MaxRecordPlus1Lob") ? maxLobId + 1 : lob,
			SubLobId = (testCase == "MaxRecordPlus1SubLob") ? maxSubLobId + 1 : subLob,
			ApDataCaptureId = maxApDataCaptureId
		};
		return MaxRequest;
	}
	// Add more helper methods for other test cases as needed
	#endregion Helpers



}




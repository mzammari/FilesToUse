﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartSecurityTestAutomation.Services.GCNGroup
{
	public class GcnGroupStatusResponse
	{
		[JsonProperty("groupId")]
		public int GroupId { get; set; }

		[JsonProperty("groupName")]
		public string? GroupName { get; set; }

		[JsonProperty("coids")]
		public CoidInfo[]? Coids { get; set; }
	}

	public class CoidInfo
	{
		[JsonProperty("coid")]
		public string? Coid { get; set; }

		[JsonProperty("coidName")]
		public string? CoidName { get; set; }
	}
}

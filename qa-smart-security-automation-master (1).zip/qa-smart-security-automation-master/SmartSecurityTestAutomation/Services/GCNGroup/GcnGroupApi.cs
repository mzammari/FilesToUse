﻿using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using SmartSecurityTestAutomation.Tests;
using Utilities.HttpUtility;
using Utilities.ObjectExtensions;

namespace SmartSecurityTestAutomation.Services.GCNGroup;

public class GcnGroupApi : MasterApi
{
	private static readonly string BaseUri = GlobalTestVariables.Configuration["SmartSecurity:BaseUri"]!;
	private const string AuthenticationType = "oAuth";
	private const string AllGroupsResource = "/gcn/all-groups-list";
	private const string GroupUserByUsername = "/gcn/group-users-by-username";
	private const string GetAllGcnAttributesResource = "/gcn/getAllGcnAttributes";
	private const string GcnGroupCoidUpsertResource = "/gcn/group-coid-upsert";
	private const string GcnPostGroupingWebTableDataResource = "/gcn/gcn-grouping-web-table-data";
	private const string GcnDeleteGroupCoidResource = "/gcn/group-coid-delete";
	private const string GcnAddAttributeName = "/gcn/add-gcn-attribute-name";
	private readonly string _baseClientUri;

	private readonly string _baseUri;
    private readonly GcnGroupRepository _groupDb;

    public GcnGroupApi()
    {
        _baseUri = GlobalTestVariables.Configuration!["SmartSecurity:BaseUri"]!;
		_baseClientUri = (GlobalTestVariables.Configuration["EnvironmentDomain"] == "HCA")
			? GlobalTestVariables.Configuration["SmartSecurityClient:BaseApiGeeXUri"]
			: GlobalTestVariables.Configuration["SmartSecurityClient:BaseUri"];
        _groupDb = new GcnGroupRepository(
            GlobalTestVariables.Configuration["SmartSecurity:DatabaseServer"]!,
            GlobalTestVariables.Configuration["SmartSecurity:DatabaseName"]!);
    }

	#region API Calls
	/// <summary>
	/// GetGcnRequest - Simple get request
	/// </summary>
	/// <param name="endpoint"></param>
	/// <returns></returns>
	private static HttpResponse GetGcnRequest(string? endpoint)
	{ 
		var response = GetSimpleRequest($"{BaseUri}{endpoint}");
		return response;
	}

	/// <summary>
	/// Sends a GET request to the /gcn/all-groups-list endpoint to retrieve all GCN groups.
	/// Returns the HTTP response containing the list of groups as provided by the API.
	/// </summary>
	private HttpResponse GetAllGroups() =>
		GetSimpleRequest($"{_baseUri}{AllGroupsResource}");
	
	//private HttpResponse GetGroupUsersByUsername(string userName) =>
	//GetSimpleRequest($"{_baseUri}{GroupUserByUsername}?username={Uri.EscapeDataString(userName)}");

	/// <summary>
	/// Post Api Call
	/// </summary>
	/// <param name="payload"></param>
	/// <returns></returns>
	private HttpResponse PostGcnRequest(string? endpoint, string? payload)
	{
		var response = PostSimpleRequest($"{_baseUri}{endpoint}", payload);
		return response;
	}

	/// <summary>
	/// Deletes a GCN group COID association by sending a POST request to the /gcn/delete-gcn-group-coid endpoint.
	/// </summary>
	/// <param name="groupId"></param>
	/// <param name="coid"></param>
	/// <returns></returns>
	private HttpResponse DeleteGcnRequest(string? groupId, string? coid)
	{  
		var request = $"{_baseUri}{GcnDeleteGroupCoidResource}?groupId={groupId}&coid={coid}";
		var response = DeleteSimpleRequest(request);
		return response;
	}

	#endregion API Calls

	#region API Tests methods

	/// <summary>
	/// Test 'GET' request for /gcn/all-groups-list endpoint.
	/// </summary>
	public void TestGetAllGroups()
    {
        Steps.AddTestStep("Test 'GET' request for /gcn/all-groups-list endpoint.", "System should respond accordingly.");

        var expectedGroups = _groupDb.GetAllGroupsDb()
			.Where(g => !g.IsDeleted).OrderBy(g => g.Coid).ToList();
		var response = GetGcnRequest(AllGroupsResource); 
		if (HPGWarn.AreEqual(OkResponse, response.Status, field: ResponseStatusField))
		{ 
			// Deserialize the response to a list of GcnGroupStatusResponse, then filter out items where Name (coidName) is null
			var actualGroups = JsonConvert.DeserializeObject<List<GcnGroupStatusResponse>>(response.Response)?.ToList();
			PrintActualGroupsAndResponseBody(actualGroups, response.Response);
		}

		//Todo: 19Sept - Return db table results for expected as api response format. Then compare lists. Modify ValidateGcnGroupDbList for it.
		//ValidateGcnGroupDbList(expectedGroups, flattenedActualGroups!);
	}

	/// <summary>
	/// Test negative and edge cases for /gcn/all-groups-list endpoint.
	/// </summary>
	public void TestGetAllGroupsNegativeAndEdgeCases()
    {
        // Unauthorized request
        Steps.AddTestStep("Test unauthorized request for /gcn/all-groups-list.", "Should respond with 401 Unauthorized.");
        var actualResponse = GetSimpleRequest($"{_baseUri}{AllGroupsResource}", tokenType: "InvalidToken");
		HPGWarn.AreEqual(NotAuthorizedResponse, actualResponse.Status, field: "Response Status Code");

		// Bad request (simulate by sending to wrong endpoint)
		Steps.AddTestStep("Test bad request for /gcn/all-groups-list.", "Should respond with 404 NotFound.");
        var badResponse = GetSimpleRequest($"{_baseUri}/gcn/all-groups-list/invalid");
        HPGWarn.AreEqual(NotFoundResponse, badResponse.Status, field: "Response Status Code");
    }
		
	/// <summary>
	/// Tests the /gcn/group-users-by-username endpoint for both valid and invalid scenarios.
	/// Valid: username = "HTNASVCTSTAUT50" (should return 200 OK)
	/// Invalid: username = null (should return 400 BadRequest)
	/// Reports results for each scenario.
	/// </summary>
	public void TestGroupUserByUsername()
	{
		var testScenarios = new[]
		{
			new { Username = "HTNASVCTSTAUT50", ExpectedStatus = OkResponse, Description = "Valid username" },
			new { Username = (string?)null, ExpectedStatus = BadRequestResponse, Description = "Null username (invalid)" }
		};

		foreach (var scenario in testScenarios)
		{
			string requestUri = scenario.Username != null
				? $"{_baseUri}{GroupUserByUsername}?username={Uri.EscapeDataString(scenario.Username)}"
				: $"{_baseUri}{GroupUserByUsername}?username="; // Passing empty for null

			var response = GetSimpleRequest(requestUri);

			bool statusMatches = HPGWarn.AreEqual(scenario.ExpectedStatus, response.Status, field: ResponseStatusField);

			var resultsSummary = new StringBuilder();
			resultsSummary.AppendLine($"Scenario: {scenario.Description}");
			resultsSummary.AppendLine($"Request URI: {requestUri}");
			resultsSummary.AppendLine($"Expected Status: {scenario.ExpectedStatus}");
			resultsSummary.AppendLine($"Actual Status: {response.Status}");

			if (scenario.ExpectedStatus == OkResponse && statusMatches)
			{
				// Parse and validate the response body for the valid scenario
				try
				{
					var jArray = JArray.Parse(response.Response);
					foreach (var obj in jArray.Children<JObject>())
					{
						int id = obj.Value<int?>("id") ?? 0;
						int userId = obj.Value<int?>("userId") ?? 0;
						int groupId = obj.Value<int?>("gcN_GroupId") ?? 0;
						string createdOn = obj.Value<string>("createdOn") ?? string.Empty;
						string createdBy = obj.Value<string>("createdBy") ?? string.Empty;

						// HPGWarn for null or zero values
						HPGWarn.True(id != 0, field: "id", message: "id is null or zero.");
						HPGWarn.True(userId != 0, field: "userId", message: "userId is null or zero.");
						HPGWarn.True(groupId != 0, field: "gcN_GroupId", message: "gcN_GroupId is null or zero.");
						HPGWarn.True(!string.IsNullOrEmpty(createdOn), field: "createdOn", message: "createdOn is null or empty.");
						HPGWarn.True(!string.IsNullOrEmpty(createdBy), field: "createdBy", message: "createdBy is null or empty.");

						resultsSummary.AppendLine($"id: {id}, userId: {userId}, gcN_GroupId: {groupId}, createdOn: {createdOn}, createdBy: {createdBy}");
					}
				}
				catch (Exception ex)
				{
					HPGWarn.True(false, field: "Response Body", message: $"Failed to parse response: {ex.Message}");
					resultsSummary.AppendLine("Failed to parse response body.");
				}
			}
			else
			{
				// For invalid scenario, just check status
				HPGWarn.AreEqual(scenario.ExpectedStatus, response.Status, field: ResponseStatusField);
			}

			resultsSummary.AppendLine(statusMatches ? "Test Passed." : "Test Failed.");

			Steps.AddTestStep(
				$"Test 'GET' request for /gcn/group-users-by-username with {scenario.Description}.",
				resultsSummary.ToString()
			);
		}
	}

	/// <summary>
	/// Sends a GET request to the /gcn/getAllGCNAttributes endpoint using client authentication.
	/// Validates that the response status is either 200 OK or 400 BadRequest.
	/// If successful, prints the formatted response body for review.
	/// Used to verify the retrieval of all GCN attributes via the client-authenticated API.
	/// </summary>
	public void TestGetAllGcnAttributesFmGcn()
	{
		Steps.AddTestStep("Test sending 'GET' request to /gcn/getAllGCNAttributes endpoint.", "System should respond with 200 OK or 400 BadRequest.");

		var response = GetSimpleRequest($"{_baseUri}{GetAllGcnAttributesResource}");

		if (response.Status == OkResponse)
		{
			//Deserialize response to list of GcnAttributeResponse objects if needed for further validation
			var actualAttributes = JsonConvert.DeserializeObject<GetAllGcnAttributesResponse>(response.Response);
			GetAllGcnAttributesResponse expectedAttributes = _groupDb.GetGcnAttributesDb();
			ConsoleOut.WriteReport("Response Body:", true);
			ValidateGcnAttributes(expectedAttributes, actualAttributes);
		}
		else
		{
			HPGWarn.AreEqual(BadRequestResponse, response.Status, ResponseStatusField);
		}
	}
	
	/// <summary>
	/// Tests the GCN Group COID upsert API endpoint with various scenarios, including add, update, missing fields, and invalid IDs.
	/// For each test case, sends a POST request with a generated payload and validates the response status and message.
	/// Also verifies that the database reflects the expected changes for successful upserts.
	/// </summary>
	public void TestPostGcnGroupCoidUpsert()
	{
		Steps.AddTestStep($"Test sending 'POST' request to {GcnGroupCoidUpsertResource} API endpoint", "System should respond accordingly.");
		// Prepare test cases: key is scenario, value is expected response status
		var TestCases = new Dictionary<string, string>
		{
		{ "AddRequest", OkResponse },
		{ "UpdateRequest", OkResponse },
		{ "MissingGroupId", InternalServerResponse },// "(500) InternalServerError"
		{ "MissingCoid", BadRequestResponse },
		{ "MissingRegion", InternalServerResponse },
		{ "MissingDivision", InternalServerResponse },
		{ "MissingLob", InternalServerResponse },
		{ "MissingSubLob", InternalServerResponse },
		{ "MaxRecordPlus1GroupId", InternalServerResponse },
		{ "MaxRecordPlus1Region", InternalServerResponse },
		{ "MaxRecordPlus1Division", InternalServerResponse },
		{ "MaxRecordPlus1Lob", InternalServerResponse },
		{ "MaxRecordPlus1SubLob", InternalServerResponse }
		};

		// Create a new upsert request object and get the current max IDs for all GCN attributes
		GcnGroupCoidUpsertRequest gcnGroupCoidUpsert = new GcnGroupCoidUpsertRequest();
		var maxIds = _groupDb.GetGcnMaxAttributeIdsDb();
		Steps.AddTestStep($"TC SETUP - Max Gcn attribute Ids acquired.", $"System should respond accordingly. maxIds:{maxIds.Count.ToString()}");
		// Iterate through each test case and execute the upsert
		foreach (var testCase in TestCases)
		{
			var expectedMsg = String.Empty;
			// Generate the payload for the current test case
			var payload = JsonConvert.SerializeObject(gcnGroupCoidUpsert.GenerateGcnUpsertRequest(testCase.Key, maxIds));

			Steps.AddTestStep($"Test Case: {testCase.Key}", $"Payload: {payload}");
			// Send the POST request to the API
			var response = PostGcnRequest(GcnGroupCoidUpsertResource, payload);

			Steps.AddTestStep($"Test Case: {testCase.Key}", $"Expected Status: {testCase.Value}, Actual Status: {response.Status}");

			// Handle successful add or update scenarios
			if (testCase.Key == "AddRequest" || testCase.Key == "UpdateRequest")
			{
				var upsertResponse = JsonConvert.DeserializeObject<GcnGroupCoidUpsertResponse>(response.Response);
				// Validate that the response status is as expected
				expectedMsg = "GCN Group COID upserted successfully";
				Steps.AddTestStep($"Comparing Response.Status:", HPGWarn.AreEqual(testCase.Value, response.Status, ResponseStatusField).ToString());
				// Validate that the response message is as expected
				Steps.AddTestStep($"Comparing Response.Status:", HPGWarn.AreEqual(expectedMsg, upsertResponse?.Message, "Post Response Message").ToString());
				// Validate that the database reflects the upserted values
				ValidateAttributeUpsert(payload, testCase.Key);
			}

			// Handle negative scenarios: missing or invalid fields
			if (testCase.Key.Contains("Missing") || testCase.Key.Contains("MaxRecordPlus1"))
			{
				var actualError = response.Response;
				// Special handling for missing COID, which returns a validation error array
				if (testCase.Key.Equals("MissingCoid"))
				{
					var responseJson = JObject.Parse(response.Response);
					var coidMessages = responseJson["errors"]?["COID"]?.ToObject<string[]>();
					if (coidMessages != null)
					{
						foreach (var msg in coidMessages)
						{
							actualError = msg; // Output: "COID is required"
						}
					}
				}

				expectedMsg = GetUpsertErrorMsgs(testCase.Key);
				Steps.AddTestStep($"Comparing Response.Status:", HPGWarn.AreEqual(testCase.Value, response.Status, ResponseStatusField).ToString());
				// Validate that the error message matches the expected error for the scenario
				Steps.AddTestStep($"Comparing Response.Response:", HPGWarn.AreEqual(expectedMsg, actualError, "Post Response Message").ToString());
			}
		}
	}

	/// <summary>
	/// Test 'POST' request for /gcn/gcn-grouping-web-table-data endpoint.
	/// Take, skip, column Sort and sortOrder are currently required parameters. 
	/// TAKE parameter responds to how many rows you want back of the total result set
	/// SKIP - skip would be how many you want to skip in the total result set before you take however many records you want to take
	/// sortOrder =  "asc" or "desc" 
	/// "columnSort":  currently only "createdOn"
	/// All Attribute filters are option
	/// the response object returns a totalCount of the total data set & and a list of gcnGroupCOIDs
	/// </summary>
	public void TestPostGcnGroupingWebTableData()
	{
		Steps.AddTestStep($"Test sending 'POST' request to {GcnPostGroupingWebTableDataResource} API endpoint", "System should respond accordingly.");

		var TestCases = new Dictionary<string, string>
		{
			{ "TakeIsMissing", BadRequestResponse },
			{ "TakeIsZero", InternalServerResponse },
			{ "TakeIsNotZero", OkResponse },
			{ "SkipIsZero", OkResponse }, 
			{ "SkipIsNotZero", OkResponse }, 
			{ "TakeSkipAreEqual", OkResponse},
			{ "SearchFilterInvalid", OkResponse},
			{ "SearchFilterValid", OkResponse},
			{ "AttributeFilterRegion", OkResponse},
			{ "AttributeFilterDivision", OkResponse},
			{ "AttributeFilterLob", OkResponse},
			{ "AttributeFilterSubLob", OkResponse},
			{ "AttributeFilterApDataCapture", OkResponse},
			{ "ColumnSortBad", InternalServerResponse },
			{ "ColumnSortCreatedOn", OkResponse },
			{ "SortOrderBad", InternalServerResponse },
			{ "SortOrderDesc", OkResponse},
			{ "SortOrderAsc", OkResponse}
		};

		// Assume GcnGroupingWebTableRequest has a method GenerateRequest(scenario, db) for payload generation
		var requestBuilder = new GcnGroupingWebTableRequest();
		foreach (var testCase in TestCases)
		{
			string scenario = testCase.Key;
			string expectedStatus = testCase.Value;

			// Generate payload for the scenario
			string payload = requestBuilder.GenerateWebTableDataRequest(scenario, _groupDb);

			Steps.AddTestStep($"Test Case: {scenario}", $"Payload: {payload}");

			var response = PostGcnRequest(GcnPostGroupingWebTableDataResource, payload);

			Steps.AddTestStep($"Test Case: {scenario}", $"Expected Status: {expectedStatus}, Actual Status: {response.Status}");

			bool statusMatches = HPGWarn.AreEqual(expectedStatus, response.Status, field: ResponseStatusField);

			if (expectedStatus == OkResponse && statusMatches)
			{
				// Validate response body structure
				try
				{
					var respObj = JObject.Parse(response.Response);
					var totalCount = respObj["totalCount"]?.Value<int>() ?? -1;
					var dataList = respObj["gcnGroupCOIDs"] as JArray;

					HPGWarn.True(totalCount >= 0, field: "totalCount", message: "totalCount missing or negative.");
					HPGWarn.True(dataList != null, field: "gcnGroupCOIDs", message: "gcnGroupCOIDs missing.");

					Steps.AddTestStep($"Test Case: {scenario} - Response Body", $"totalCount: {totalCount}, gcnGroupCOIDs count: {dataList?.Count ?? 0}");
				}
				catch (Exception ex)
				{
					HPGWarn.True(false, field: "Response Body", message: $"Failed to parse response: {ex.Message}");
					Steps.AddTestStep($"Test Case: {scenario} - Response Body", "Failed to parse response body.");
				}
			}
			else if (expectedStatus != OkResponse)
			{
				// For negative/edge cases, check for error message or structure
				HPGWarn.AreEqual(expectedStatus, response.Status, field: ResponseStatusField);
				Steps.AddTestStep($"Test Case: {scenario} - Error Response", $"Response: {response.Response}");
			}
		}
	}

	/// <summary>
	/// Tests the deletion of GCN Group COID associations via the /gcn/group-coid-delete endpoint.
	/// </summary>
	public void TestDeleteGcnGroupCoid()
	{
		Steps.AddTestStep($"Test sending 'DELETE' request to {GcnDeleteGroupCoidResource} API endpoint", "System should respond accordingly.");
		
		var TestCases = new Dictionary<string, string>
		{
			{ "ValidGroupCoid", OkResponse },
			{ "InvalidGroupCoid", NotFoundResponse },
			{ "MissingGroupId", BadRequestResponse },
			{ "MissingCoid", BadRequestResponse },
			{ "DeleteAgain", NotFoundResponse }
		};

		//Declare random variable to get a random validRecord
		var random = new Random();
		
		//Get a valid groupId and coid from DB. these records are always isDeleted = 0
		var validRecord = _groupDb.GetGroupIdCoid();

		// Get a random KeyValuePair from the dictionary
		var validPair = validRecord.ElementAt(random.Next(validRecord.Count));
		int validGroupId = validPair.Key;
		string validCoid = validPair.Value;
		string isDeletedExpected = "true";

		// For invalid, use IDs that are not present in DB
		int invalidGroupId = 9999999;
		int invalidCoid = 8888888; 

		foreach (var testCase in TestCases)
		{
			string scenario = testCase.Key;
			string expectedStatus = testCase.Value;

			string? groupId = null;
			string? coid = null;

			switch (scenario)
			{
				//Note: do not change the order of ValidGroupCoid and DeleteAgain test cases.
				//DeleteAgain depends on ValidGroupCoid to delete first.
				case "ValidGroupCoid":
					groupId = validGroupId.ToString();
					coid = validCoid.ToString(); 
					break;
				case "InvalidGroupCoid":
					groupId = invalidGroupId.ToString();
					coid = invalidCoid.ToString();
					break;
				case "MissingGroupId":
					groupId = null;
					coid = validCoid.ToString();
					break;
				case "MissingCoid":
					groupId = validGroupId.ToString();
					coid = null;
					break;
				case "DeleteAgain":
					// First, ensure the record is deleted (if not already)
					groupId = validGroupId.ToString();
					coid = validCoid.ToString();
					break;
			}

			Steps.AddTestStep($"Test Case: {scenario}", $"GroupId: {groupId ?? "null"}, Coid: {coid ?? "null"}");

			var response = DeleteGcnRequest(groupId, coid);

			Steps.AddTestStep($"Test Case: {scenario}", $"Expected Status: {expectedStatus}, Actual Status: {response.Status}");


			bool statusMatches = HPGWarn.AreEqual(expectedStatus, response.Status, field: ResponseStatusField);

			// For negative cases, optionally check error message structure
			if (scenario == "MissingGroupId" || scenario == "MissingCoid")
			{
				// Expecting validation error in response
				Steps.AddTestStep($"Test Case: {scenario} - Error Response", $"Response: {response.Response}");
				HPGWarn.True(response.Response.Contains("required") || response.Response.Contains("errors"), field: "Response Body", message: "Expected validation error.");
			}
			else if (scenario == "InvalidGroupCoid" || scenario == "DeleteAgain")
			{
				// NotFound expected, check for not found message
				Steps.AddTestStep($"Test Case: {scenario} - Error Response", $"Response: {response.Response}");
			}
			else if (scenario == "ValidGroupCoid" && statusMatches)
			{
				// Optionally, check for success message
				Steps.AddTestStep($"Test Case: {scenario} - Success Response", $"Response: {response.Response}");

				//Parse out the message from response.Response body
				var actualResponseJson = JObject.Parse(response.Response);
				var actualMessage = actualResponseJson["message"]?.ToString();

				HPGWarn.AreEqual("GCN Group COID deleted successfully", actual: actualMessage, field: "Response Body", message: "GCN Group COID deleted successfully");
				// Validate that the record is marked as deleted in the database (soft delete)
				var isDeletedActual = _groupDb.GetisDeletedValuePostDeletion(groupId.ToInt(), coid).ToString();
				HPGWarn.AreEqual(isDeletedExpected, isDeletedActual, field: "isDeleted", message: "(SOFT DELETE) - Record was marked as deleted in DB. ");
				Steps.AddTestStep($"ValidGroupCoid - DB Validation", $"isDeleted Expected: {isDeletedExpected}, Actual: {isDeletedActual}");
			}

			Steps.AddTestStep($"Test Case: {scenario}", statusMatches ? "Test Passed." : "Test Failed.");
		}
	}

	/// <summary>
	///  Test the Add GCN Attribute Name via the /gcn/add-gcn-attribute-name endpoint
	/// </summary>
	public void TestAddGcnAttributeName()
	{
		Steps.AddTestStep($"Test sending 'POST' request to {GcnAddAttributeName} API endpoint", "System should respond accordingly.");

		var TestCases = new Dictionary<string, string>
					{
						{ "CreateRegion", OkResponse }, //gcnAttributeType = region
						{ "CreateDivision", OkResponse },//gcnAttributeType = division
						{ "CreateLob", OkResponse },//gcnAttributeType = lob
						{ "CreateSubLob", OkResponse },		//gcnAttributeType = sub lob
						{ "CreateApDataCapture", OkResponse },//gcnAttributeType = ap data capture
						{ "DupRegionName", OkResponse},
						{ "DupDivisionName", OkResponse },
						{ "DupLobName", OkResponse },
						{ "DupSubLobName", OkResponse },
						{ "DupApDataCaptureName", OkResponse },
						{ "MissingName", BadRequestResponse},
						{ "MissingGcnAttributeType", BadRequestResponse},
						{"BadGcnAttributeType", BadRequestResponse }
					};

		// Helper to get attribute type string for each test case
		string GetAttributeType(string scenario)
		{
			return scenario switch
			{
				"CreateRegion" or "DupRegionName" => "region",
				"CreateDivision" or "DupDivisionName" => "division",
				"CreateLob" or "DupLobName" => "lob",
				"CreateSubLob" or "DupSubLobName" => "sub lob",
				"CreateApDataCapture" or "DupApDataCaptureName" => "ap data capture",
				_ => ""
			};
		}

		// Replace the GenerateName helper logic with timestamp including hour, minute, second for uniqueness
		// DateTime format used: MMddyy-HHmmss (MonthDayYear-HourMinuteSecond) appended at the end of the name for uniqueness.
		string GenerateName(string scenario, string attributeType)
		{
			if (scenario.StartsWith("Dup"))
				return $"ApiTestAddName-{attributeType.Replace(" ", "")}-{DateTime.Now:MMddyy-HHmmss}";
			if (scenario.StartsWith("Create"))
				return $"ApiTestAddName-{attributeType.Replace(" ", "")}-{DateTime.Now:MMddyy-HHmmss}";
			return "";
		}

		// Store duplicate names for duplicate test cases
		var duplicateNames = new Dictionary<string, string>();

		foreach (var testCase in TestCases)
		{
			string scenario = testCase.Key;
			string expectedStatus = testCase.Value;
			string attributeType = GetAttributeType(scenario);
			string name = GenerateName(scenario, attributeType);

			// For duplicate test cases, use the same name as the previous create
			if (scenario.StartsWith("Dup"))
			{
				string createScenario = "Create" + attributeType.Replace(" ", "").First().ToString().ToUpper() + attributeType.Replace(" ", "").Substring(1);
				if (duplicateNames.ContainsKey(attributeType))
					name = duplicateNames[attributeType];
				else
					name = GenerateName(scenario, attributeType);
			}

			// For create scenarios, store the name for later duplicate use
			if (scenario.StartsWith("Create"))
			{
				duplicateNames[attributeType] = name;
			}

			// Build payload
			var payloadObj = new JObject();
			if (scenario != "MissingName")
				payloadObj["name"] = name;
			if (scenario != "MissingGcnAttributeType")
				payloadObj["gcnAttributeType"] = attributeType;
			if (scenario == "BadGcnAttributeType")
				payloadObj["gcnAttributeType"] = "badType";

			string payload = payloadObj.ToString(Formatting.None);

			Steps.AddTestStep($"Test Case: {scenario}", $"Payload: {payload}");

			var response = PostGcnRequest(GcnAddAttributeName, payload);

			Steps.AddTestStep($"Test Case: {scenario}", $"Expected Status: {expectedStatus}, Actual Status: {response.Status}");

			bool statusMatches = HPGWarn.AreEqual(expectedStatus, response.Status, field: ResponseStatusField);

			string actualResponse = "";
			try
			{
				var respJson = JObject.Parse(response.Response);
				actualResponse = respJson["message"]?.ToString() ?? response.Response;
			}
			catch
			{
				actualResponse = response.Response;
			}

			if (expectedStatus == OkResponse && statusMatches)
			{
				if (scenario.StartsWith("Create"))
				{
					HPGWarn.AreEqual("Attribute name added successfully.", actualResponse, field: "Response Body", message: "Attribute name added successfully.");
					Steps.AddTestStep($"Test Case: {scenario} - Success Response", $"Response: {actualResponse}");
					ValidateAttributeCreate( name, attributeType);//todo: flush out this method
				}
				else if (scenario.StartsWith("Dup"))
				{
					HPGWarn.AreEqual("Attribute name already exists.", actualResponse, field: "Response Body", message: "Attribute name already exists.");
					Steps.AddTestStep($"Test Case: {scenario} - Duplicate Response", $"Response: {actualResponse}");
				}
			}
			else if (expectedStatus == BadRequestResponse)
			{
				Steps.AddTestStep($"Test Case: {scenario} - BadRequest Response", $"Response: {actualResponse}");
				HPGWarn.True(actualResponse.Contains("required") || actualResponse.Contains("errors"), field: "Response Body", message: "Expected validation error.");
			}
			else if (expectedStatus == NotFoundResponse)
			{
				Steps.AddTestStep($"Test Case: {scenario} - NotFound Response", $"Response: {actualResponse}");
			}

			Steps.AddTestStep($"Test Case: {scenario}", statusMatches ? "Test Passed." : "Test Failed.");
		}
	}
	

	/// <summary>
	/// Exploring tuples in C#
	/// </summary>
	public void TestWithTuple()
	{
		var validRecord = _groupDb.GetGroupIdForDeletion2();

		//Loop through each tuple in the list and print out the values
		foreach (var record in validRecord)
		{
			Console.WriteLine($"GroupId: {record.grpId}, Coid: {record.coid}, isDeleted: {record.isDeleted.ToString()}");
		}

	}



	#endregion API Tests methods

	#region Helpers

	/// <summary>
	/// Compares two lists of GcnGroupDb objects (expected and actual) for equality.
	/// Throws an exception if the counts differ or if any item's Id, Name, or Coid do not match at the same index.
	/// Used to validate that the API response matches the expected database results.
	/// </summary>
	private static void ValidateGcnGroupDbList(List<GcnGroupDb> expectedList, List<GcnGroupDb> actualList)
	{
		// Compare count
		// Get a total count of Coid elements within the actualList array
		//int actualCount = actualList.Where(g => g.Coids != null)
		//							   .Sum(g => g.Coids!.Length);

		if (expectedList.Count != actualList.Count)
			throw new Exception($"Expected count {expectedList.Count}, but got {actualList.Count}.");

		// Compare each item by Id, GroupName, FacilityName, Coid
		for (int i = 0; i < expectedList.Count; i++)
		{
			var expected = expectedList[i];
			var actual = actualList[i];

			if (expected.Id != actual.Id)
				throw new Exception($"Mismatch at index {i}: Expected Id {expected.Id}, Actual Id {actual.Id}.");

			if (!string.Equals(expected.Name, actual.Name, StringComparison.Ordinal))
				throw new Exception($"Mismatch at index {i}: Expected GroupName '{expected.Name}', Actual GroupName '{actual.Name}'.");

			if (!string.Equals(expected.Coid, actual.Coid, StringComparison.Ordinal))
				throw new Exception($"Mismatch at index {i}: Expected FacilityName '{expected.OrgName}', Actual FacilityName '{actual.Coid}'.");
		}
	}
	
	/// <summary>
	/// Prints all values from the raw JSON response body and the parsed actualGroups list.
	/// Adds HPGWarns if groupId, groupName, or coid are null.
	/// </summary>
	/// <param name="actualGroups">List of parsed GcnGroupStatusResponse objects.</param>
	/// <param name="responseBody">Raw JSON response body.</param>
	public static void PrintActualGroupsAndResponseBody(List<GcnGroupStatusResponse>? actualGroups, string responseBody)
	{
		// Print each value from the response body, one per line
		Console.WriteLine("Raw Response Body Values:");
		foreach (var value in ParseJsonValues(responseBody))
		{
			Console.WriteLine(value);
		}

		// Print parsed actualGroups
		Console.WriteLine("\nParsed Actual Groups:");
		if (actualGroups == null || actualGroups.Count == 0)
		{
			Console.WriteLine("No groups found.");
			return;
		}

		foreach (var group in actualGroups)
		{
			// Step comment for each GroupId being evaluated
			Steps.AddTestStep($"Evaluating GroupId: {group.GroupId}", $"Checking group '{group.GroupName}' and its COIDs.");

			// HPGWarn for null groupId
			if (group.GroupId == 0)
			{
				HPGWarn.True(false, field: "groupId", message: "groupId is null or zero.");
			}
			Console.WriteLine($"GroupId: {group.GroupId}");

			// HPGWarn for null groupName
			if (string.IsNullOrEmpty(group.GroupName))
			{
				HPGWarn.True(false, field: "groupName", message: "groupName is null or empty.");
			}
			Console.WriteLine($"GroupName: {group.GroupName}");

			if (group.Coids != null)
			{
				foreach (var coid in group.Coids)
				{
					// HPGWarn for null coid
					if (string.IsNullOrEmpty(coid.Coid))
					{
						HPGWarn.True(false, field: "coid", message: "coid is null or empty.");
					}
					Console.WriteLine($"Coid: {coid.Coid}");
					Console.WriteLine($"CoidName: {(string.IsNullOrEmpty(coid.CoidName) ? "The API returns NULL for this value because it exists in GCN_Group_COID tbl but does not in vw_refHomeHierarchy" : coid.CoidName)}");
				}
			}
			Console.WriteLine(); // Line feed after each group
		}
	}

	/// <summary>
	/// Parses all values from a JSON array of objects, including nested arrays.
	/// Each property value is returned as a formatted string "PropertyName: Value".
	/// For array properties, each element's properties are also parsed and returned.
	/// </summary>
	/// <param name="json">A JSON string representing an array of objects.</param>
	/// <returns>An enumerable of strings, each representing a property and its value.</returns>
	private static IEnumerable<string> ParseJsonValues(string json)
	{
		var jArray = JArray.Parse(json);
		foreach (var obj in jArray.Children<JObject>())
		{
			foreach (var prop in obj.Properties())
			{
				// If the property value is an array, iterate through its items and their properties
				if (prop.Value.Type == JTokenType.Array)
				{
					foreach (var arrItem in prop.Value)
					{
						foreach (var arrProp in arrItem.Children<JProperty>())
						{
							yield return $"{arrProp.Name}: {arrProp.Value}";
						}
					}
				}
				else
				{
					// For non-array properties, return the property name and value
					yield return $"{prop.Name}: {prop.Value}";
				}
			}
		}
	}

	/// <summary>
	/// Validates the GCN attributes between expected and actual responses by comparing counts and values for groups, regions, divisions, LOBs, subLOBs, and AP data captures.
	/// Reports mismatches using HPGWarn and Steps.
	/// </summary>
	private static void ValidateGcnAttributes(GetAllGcnAttributesResponse expectedAttributes, GetAllGcnAttributesResponse? actualAttributes)
	{ 
		// Validate counts 
		Steps.AddTestStep("Validating GCN Attributes counts between expected and actual data.", "Counts should match for all GCN attribute types.");
		HPGWarn.AreEqual(expectedAttributes.Groups.Count.ToString(), actualAttributes.Groups.Count.ToString(), "GCN Groups count mismatch.");
		HPGWarn.AreEqual(expectedAttributes.Regions.Count.ToString(), actualAttributes.Regions.Count.ToString(), "GCN Regions count mismatch.");
		HPGWarn.AreEqual(expectedAttributes.Divisions.Count.ToString(), actualAttributes.Divisions.Count.ToString(), "GCN Divisions count mismatch.");
		HPGWarn.AreEqual(expectedAttributes.LoBs.Count.ToString(), actualAttributes.LoBs.Count.ToString(), "GCN LoBs count mismatch.");
		HPGWarn.AreEqual(expectedAttributes.SubLOBs.Count.ToString(), actualAttributes.SubLOBs.Count.ToString(), "GCN SubLOBs count mismatch.");
		HPGWarn.AreEqual(expectedAttributes.ApDataCaptures.Count.ToString(), actualAttributes.ApDataCaptures.Count.ToString(), "GCN ApDataCaptures count mismatch.");
	 
		// Further detailed validation can be added here as needed
		Steps.AddTestStep("Validating GCN Attributes between expected and actual data.", "GCN attribute types should all match.");

		ValidateAttribute(expectedAttributes.Groups.ToArray(), actualAttributes.Groups.ToArray(), "GCN Groups");
		ValidateAttribute(expectedAttributes.Regions.ToArray(), actualAttributes.Regions.ToArray(), "GCN Regions");
		ValidateAttribute(expectedAttributes.Divisions.ToArray(), actualAttributes.Divisions.ToArray(), "GCN Divisions");
		ValidateAttribute(expectedAttributes.LoBs.ToArray(), actualAttributes.LoBs.ToArray(), "GCN LoBs");
		ValidateAttribute(expectedAttributes.SubLOBs.ToArray(), actualAttributes.SubLOBs.ToArray(), "GCN SubLOBs");
		ValidateAttribute(expectedAttributes.ApDataCaptures.ToArray(), actualAttributes.ApDataCaptures.ToArray(), "GCN ApDataCaptures");
		
	}
	
	/// <summary>
	/// Validates that the expected and actual attribute arrays (such as groups, regions, divisions, etc.)
	/// match by comparing their IDs and names. Reports mismatches, missing, or extra items via HPGWarn and Steps.
	/// Used for detailed comparison of GCN attribute types between database and API response.
	/// </summary>
	private static void ValidateAttribute<T>(T[] expected, T[] actual, string attributeName)
	{
		var msg = new StringBuilder();
		var expectedDict = new Dictionary<int, string>();
		var actualDict = new Dictionary<int, string>();

		switch (attributeName)
		{
			case "GCN Groups":
				//Declare 2 dictionaries and load expected andactual into each dictionary for comparison 
				expectedDict = expected.Cast<GcnGroup>().ToDictionary(i => i.GroupId, i => i.GroupName);
				actualDict = actual.Cast<GcnGroup>().ToDictionary(g => g.GroupId, g => g.GroupName);
				break;
			case "GCN Regions":
				expectedDict = expected.Cast<GcnRegion>().ToDictionary(i => i.RegionId, i => i.RegionName);
				actualDict = actual.Cast<GcnRegion>().ToDictionary(g => g.RegionId, g => g.RegionName);
				break;
			case "GCN Divisions":
				expectedDict = expected.Cast<GcnDivision>().ToDictionary(i => i.DivisionId, i => i.DivisionName);
				actualDict = actual.Cast<GcnDivision>().ToDictionary(g => g.DivisionId, g => g.DivisionName);
				break;
			case "GCN LoBs":
				expectedDict = expected.Cast<GcnLob>().ToDictionary(i => i.LobId, i => i.LobName);
				actualDict = actual.Cast<GcnLob>().ToDictionary(g => g.LobId, g => g.LobName);
				break;
			case "GCN SubLOBs":
				expectedDict = expected.Cast<GcnSubLob>().ToDictionary(i => i.SubLobId, i => i.SubLobName);
				actualDict = actual.Cast<GcnSubLob>().ToDictionary(g => g.SubLobId, g => g.SubLobName);
				break;
			case "GCN ApDataCaptures":
				expectedDict = expected.Cast<GcnApDataCapture>().ToDictionary(i => i.ApDataCaptureId, i => i.CaptureName);
				actualDict = actual.Cast<GcnApDataCapture>().ToDictionary(g => g.ApDataCaptureId, g => g.CaptureName);
				break;
			default:
				Console.WriteLine("Unknown attribute type.");
				break;
		}

		Steps.AddTestStep($"Validating {attributeName} Attributes", $"{attributeName} Attribute - should all match.");

		foreach (var expectedRecord in expectedDict)
		{
			int expectedId = expectedRecord.Key;
			string expectedName = expectedRecord.Value ?? string.Empty;

			if (actualDict.TryGetValue(expectedId, out var actualName))
			{
				actualName = actualName ?? string.Empty;
				if (!string.Equals(expectedName, actualName, StringComparison.Ordinal))
				{
					Steps.AddTestStep($"{attributeName}: Name MISMATCH for Id {expectedId}.", $"Expected: '{expectedName}', Actual: '{actualName}'");
					HPGWarn.True(false, field: $"{attributeName}[{expectedId}]", message: $"Name MISMATCH. Expected: '{expectedName}', Actual: '{actualName}'");
				}
				else
				{
					Steps.AddTestStep($"{attributeName}: Match for Id {expectedId}.", $"Name: '{expectedName}'");
					HPGWarn.AreEqual(expectedName, actualName, field: $"{attributeName} :{actualName}. SUCCESSFUL Name match!!");
				}
			}
			else
			{
				Steps.AddTestStep($"{attributeName}: MISSING Id {expectedId} in actual.", $"Expected Name: '{expectedName}'");
				HPGWarn.True(false, field: $"{attributeName}:[{expectedId}]", message: $"Id {expectedId} NOT FOUND in actual data.");
			}
		}
		// Check for extra items in actualDict
		foreach (var actualRecord in actualDict)
		{
			if (!expectedDict.ContainsKey(actualRecord.Key))
			{
				string actualName = actualRecord.Value ?? string.Empty;
				HPGWarn.True(false, field: $"{attributeName}[{actualRecord.Key}]", message: $"Extra Id {actualRecord.Key} in actual. Name: '{actualName}'");
				Steps.AddTestStep($"{attributeName}: Extra Id {actualRecord.Key} in actual.", $"Name: '{actualName}'");
			}
		}
	}

	private void ValidateAttributeUpsert(string payload, string testCase)
	{
		Steps.AddTestStep($"ValidateAttributeUpsert: {testCase}", $"Payload: {payload}");
		var jObject = JObject.Parse(payload);
		int groupId = jObject.Value<int>("gcN_GroupId");
		int coid = jObject.Value<int>("coid");
		string region = jObject.Value<string>("regionId") ?? string.Empty;
		string division = jObject.Value<string>("divisionId") ?? string.Empty;
		string lob = jObject.Value<string>("lobId") ?? string.Empty;
		string subLob = jObject.Value<string>("subLobId") ?? string.Empty;
		string apDataCapture = jObject.Value<string>("apDataCaptureId") ?? string.Empty;

		var dbRecord = _groupDb.GetGcnGroupCoidByGroupIdAndCoidDb(groupId, coid, region, division,lob, subLob, apDataCapture);
		var dbGrpId = dbRecord.TryGetValue("GCN_GroupId", out int grpIdValue).ToString();
		var dbCoid = dbRecord.TryGetValue("COID", out int coidValue).ToString();
		var dbRegion = dbRecord.TryGetValue("RegionId", out int regionValue).ToString();
		var dbDivision = dbRecord.TryGetValue("DivisionId", out int divisionValue).ToString();
		var dbLob = dbRecord.TryGetValue("LobId", out int lobValue).ToString();
		var dbSubLob = dbRecord.TryGetValue("SubLobId", out int subLobValue).ToString();
		var dbApDataCapture = dbRecord.TryGetValue("APDataCaptureId", out int apDataCaptureValue).ToString();

		Steps.AddTestStep($"Comparing GroupId: {testCase}", HPGWarn.AreEqual(groupId.ToString(), grpIdValue.ToString(), $"GroupId mismatch after {testCase}.").ToString());
		Steps.AddTestStep($"Comparing COID: {testCase}", HPGWarn.AreEqual(coid.ToString(), coidValue.ToString(), $"Coid mismatch after {testCase}.").ToString());
		Steps.AddTestStep($"Comparing RegionId: {testCase}", HPGWarn.AreEqual(region, regionValue.ToString(), $"Region mismatch after {testCase}.").ToString());
		Steps.AddTestStep($"Comparing DivisionId: {testCase}", HPGWarn.AreEqual(division, divisionValue.ToString(), $"Division mismatch after {testCase}.").ToString());
		Steps.AddTestStep($"Comparing LobId: {testCase}", HPGWarn.AreEqual(lob, lobValue.ToString(), $"Lob mismatch after {testCase}.").ToString());
		Steps.AddTestStep($"Comparing SubLobId: {testCase}", HPGWarn.AreEqual(subLob, subLobValue.ToString(), $"SubLob mismatch after {testCase}.").ToString());
		Steps.AddTestStep($"Comparing ApDataCaptureId: {testCase}", HPGWarn.AreEqual(apDataCapture, apDataCaptureValue.ToString(), $"ApDataCapture mismatch after {testCase}.").ToString());
	}
	
	private static string GetUpsertErrorMsgs(string testCase)
	{
		var dvEnvironment = GlobalTestVariables.TestEnvironment;
		var dbName = dvEnvironment == "qasbx" ? "SmartSecurityQA" : "SmartSecurity";


		var errorMsg = String.Empty;
		switch (testCase)
		{
			case "MissingGroupId":
			case "MaxRecordPlus1GroupId":
				errorMsg = $"Exception in UpsertGCNGroupCOID: The MERGE statement conflicted with the FOREIGN KEY constraint \"FK_GCN_Group_COID\". The conflict occurred in database \"{dbName}\", table \"dbo.GCN_Group\", column 'Id'.\r\nThe statement has been terminated.";
				break;
			case "MissingCoid":
			case "MaxRecordPlus1Coid":
				errorMsg = "COID is required";
				break;
			case "MissingRegion":
			case "MaxRecordPlus1Region":
				errorMsg = $"Exception in UpsertGCNGroupCOID: The MERGE statement conflicted with the FOREIGN KEY constraint \"FK_GCN_Group_COID_Region\". The conflict occurred in database \"{dbName}\", table \"dbo.GCN_Region\", column 'Id'.\r\nThe statement has been terminated.";
				break;
			case "MissingDivision":
			case "MaxRecordPlus1Division":
				errorMsg = $"Exception in UpsertGCNGroupCOID: The MERGE statement conflicted with the FOREIGN KEY constraint \"FK_GCN_Group_COID_Division\". The conflict occurred in database \"{dbName}\", table \"dbo.GCN_Division\", column 'Id'.\r\nThe statement has been terminated.";
				break;
			case "MissingLob":
			case "MaxRecordPlus1Lob":
				errorMsg = $"Exception in UpsertGCNGroupCOID: The MERGE statement conflicted with the FOREIGN KEY constraint \"FK_GCN_Group_COID_LOB\". The conflict occurred in database \"{dbName}\", table \"dbo.GCN_LOB\", column 'Id'.\r\nThe statement has been terminated.";
				break;
			case "MissingSubLob":
			case "MaxRecordPlus1SubLob":
				errorMsg = $"Exception in UpsertGCNGroupCOID: The MERGE statement conflicted with the FOREIGN KEY constraint \"FK_GCN_Group_COID_SubLOB\". The conflict occurred in database \"{dbName}\", table \"dbo.GCN_SubLOB\", column 'Id'.\r\nThe statement has been terminated.";
				break;
			default:
				errorMsg = "Unknown test case for missing field.";
				break;
		}
		return errorMsg;



	}

	private static void ValidateTestErrorResponse( string expectedMsg, string actualMsg)
	{
		var responseJson = JObject.Parse(actualMsg);
		var errorsPart = responseJson["errors"];
		if (errorsPart != null)
		{
			foreach (var error in errorsPart.Children<JProperty>())
			{
				var field = error.Name;
				var messages = error.Value.ToObject<string[]>();
				foreach (var msg in messages)
				{
					// Use field and msg as needed, e.g. log or assert
					Console.WriteLine($"Field: {field}, Expected:{expectedMsg}, Actual:{msg}");
				}
			}
		}
	}

	private static void ValidateAttributeCreate(string name, string attributeType)
	{
		Steps.AddTestStep("ValidateAttributeCreate", "Validating that the attribute was created in the database.");
		// This is a placeholder for actual DB validation logic
		// In a real implementation, you would query the database to ensure the attribute exists
		Steps.AddTestStep("ValidateAttributeCreate", "Attribute creation validated in the database (placeholder).");
	}

	#endregion Helpers
}
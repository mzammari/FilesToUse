using Microsoft.Data.SqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Utilities.DatabaseUtility;
using Utilities.ObjectExtensions;

namespace SmartSecurityTestAutomation.Services.GCNGroup;

public class GcnGroupRepository
{
	private readonly string _server;
	private readonly string _dbName;

	#region Methods that Get a DB Record Set

	///<summary>
	/// Initializes a new instance of the GcnGroupRepository class with the specified SQL Server and database name.
	/// This constructor sets up the repository to interact with the GCN group-related tables in the given database.
	/// </summary>
	public GcnGroupRepository(string server, string dbName)
	{
		_server = server;
		_dbName = dbName;
	}

	/// <summary>
	/// Retrieves all GCN group records from the database using the specified query.
	/// If the dbRequest parameter is "zeroResults", a query returning zero results is used.
	/// Throws an exception if retrieval fails.
	/// </summary>
	public IEnumerable<GcnGroupDb> GetAllGroupsDb(string dbRequest = SelectAllGroups)
	{
		if (dbRequest == "zeroResults")
			dbRequest = SelectZeroResultsSet;
		try
		{
			var dbs = new DbSql(_server, _dbName);
			var queryResults = dbs.GetRecordsIntoObject<GcnGroupDb>(dbRequest);
			return queryResults;
		}
		catch (Exception e)
		{
			Console.WriteLine(e);
			throw new Exception($"Unable to retrieve GCN Group data!\r\nError Message: {e}");
		}
	}


	///<summary>
	/// Retrieves all GCN attribute records from the database, including groups, regions, divisions, LOBs, subLOBs, and AP data captures.
	/// Returns a GetAllGcnAttributesResponse containing lists of each attribute type.
	/// Throws an exception if retrieval fails.
	/// </summary>
	public GetAllGcnAttributesResponse GetGcnAttributesDb()
	{
		try
		{
			var dbs = new DbSql(_server, _dbName);

			var groups = dbs.GetRecordsIntoObject<GcnGroup>(SelectGcnGroup).ToList();
			var regions = dbs.GetRecordsIntoObject<GcnRegion>(SelectGcnRegion).ToList();
			var divisions = dbs.GetRecordsIntoObject<GcnDivision>(SelectGcnDivision).ToList();
			var loBs = dbs.GetRecordsIntoObject<GcnLob>(SelectGcnLob).ToList();
			var subLOBs = dbs.GetRecordsIntoObject<GcnSubLob>(SelectGcnSubLob).ToList();
			var apDataCaptures = dbs.GetRecordsIntoObject<GcnApDataCapture>(SelectGcnApDataCapture).ToList();

			var getAllGcnAttributesResponse = new GetAllGcnAttributesResponse()
			{
				Groups = groups,
				Regions = regions,
				Divisions = divisions,
				LoBs = loBs,
				SubLOBs = subLOBs,
				ApDataCaptures = apDataCaptures
			};

			return getAllGcnAttributesResponse;
		}
		catch (Exception e)
		{
			Console.WriteLine(e);
			throw new Exception($"Unable to retrieve GCN Attribute data!\r\nError Message: {e}");
		}
	}

	/// <summary>
	/// Retrieves the maximum IDs for each GCN attribute type 
	/// (Group, Group_COID, Region, Division, LOB, SubLOB, APDataCapture) from the database.
	/// Executes a single query that selects the maximum ID for each attribute table 
	/// and returns the results as a dictionary.
	/// Throws an exception if retrieval fails.
	/// </summary>
	public Dictionary<string, int> GetGcnMaxAttributeIdsDb()
	{
		try
		{
			// Initialize database access object with server and database name
			var dbs = new DbSql(_server, _dbName);

			// Prepare dictionary to hold the results
			var queryResults = new Dictionary<string, int>();

			// Execute the query to get a DataTable containing the max IDs for each attribute
			var dt = dbs.GetRecordsIntoDataTable(SelectMaxGcnAttributeIds);

			// If the query returned at least one row, extract each column's value into the dictionary
			if (dt.Rows.Count > 0)
			{
				foreach (System.Data.DataColumn col in dt.Columns)
				{
					// Add the column name and its value from the first row to the results dictionary
					queryResults[col.ColumnName] = dt.Rows[0][col].ToInt();
				}
			}

			// Return the dictionary containing max IDs for each attribute
			return queryResults;
		}
		catch (Exception e)
		{
			// Log the exception and throw a new exception with additional context
			Console.WriteLine(e);
			throw new Exception($"Unable to retrieve GCN Max Attribute Ids data!\r\nError Message: {e}");
		}
	}

	public Dictionary<string, int> GetGcnGroupCoidByGroupIdAndCoidDb(int GCN_GroupId, int COID, string RegionId, string DivisionId, string LobId, string SubLobId, string APDataCaptureId)
	{
		try
		{
			// Initialize database access object with server and database name
			var dbs = new DbSql(_server, _dbName);

			var dbQuery = string.Format(SelectGcnRecordUpserted, GCN_GroupId, COID, RegionId, DivisionId, LobId, SubLobId, APDataCaptureId);
			// Prepare dictionary to hold the results
			var queryResults = new Dictionary<string, int>();
			// Execute the query to get a DataTable containing the max IDs for each attribute
			var dt = dbs.GetRecordsIntoDataTable(dbQuery);

			// If the query returned at least one row, extract each column's value into the dictionary
			if (dt.Rows.Count > 0)
			{
				foreach (System.Data.DataColumn col in dt.Columns)
				{
					// Add the column name and its value from the first row to the results dictionary
					queryResults[col.ColumnName] = dt.Rows[0][col].ToInt();
				}
			}

			// Return the dictionary containing max IDs for each attribute
			return queryResults;
		}
		catch (Exception e)
		{
			// Log the exception and throw a new exception with additional context
			Console.WriteLine(e);
			throw new Exception($"Unable to retrieve Upserted Record from Db!\r\nError Message: {e}");
		}
	}

	public List<(int grpId, string coid, bool isDeleted)> GetGroupIdForDeletion2()
	{
		try 
		{

			//Initialize database access object with server and database name
			var dbs = new DbSql(_server, _dbName);

			//Prepare variables to hold the results
			int grpId = 0;
			string coid = string.Empty;
			bool isDeleted = false;

			//Prepare the list variable for the tuple
			List<(int grpId, string coid, bool isDeleted)> resultList = new List<(int grpId, string coid, bool isDeleted)>();

			//Execute the query to get a DataTable containing the GCN GroupId and COID for deletion
			var dt = dbs.GetRecordsIntoDataTable(SelectGcnRecordForSoftDelete);

			// If the query returned at least one row, extract the GCN_GroupId, COID, and IsDeleted values
			if (dt.Rows.Count > 0)
			{
				for (int i = 0; i < dt.Rows.Count; i++)
				{
					grpId = dt.Rows[i]["GCN_GroupId"].ToInt();
					coid = dt.Rows[i]["COID"].ToString() ?? string.Empty;
					isDeleted = dt.Rows[i]["IsDeleted"].ToBool();
					resultList.Add((grpId, coid, isDeleted));
				}
			}

			//Return the GCN_GroupId, COID, and IsDeleted values as a tuple
			return resultList;


			//Return the GCN_GroupId, COID, and IsDeleted values as a tuple
			return new List<(int grpId, string coid, bool isDeleted)> { (grpId, coid, isDeleted) };
		}
		catch (Exception e) 
		{ 
			Console.WriteLine(e); 
			throw new Exception($"Unable to retrieve GCN GroupId for Deletion!\r\nError Message: {e}");
		}
	}

	public Dictionary<int, string> GetGroupIdCoid()
	{
		try
		{
			// Initialize database access object with server and database name
			var dbs = new DbSql(_server, _dbName);

			// Prepare dictionary to hold the results
			var queryResults = new Dictionary<int, string>();

			// Execute the query to get a DataTable containing the max IDs for each attribute
			var dt = dbs.GetRecordsIntoDataTable(SelectGcnGroupIdCoid);

			// If the query returned at least one row, extract each column's value into the dictionary
			if (dt.Rows.Count > 0)
			{
				foreach (System.Data.DataRow row in dt.Rows)
				{
					int groupId = row["GCN_GroupId"].ToInt();
					string coid = row["COID"].ToString() ?? string.Empty;
					queryResults[groupId] = coid;
				}

			}

			// Return the dictionary containing max IDs for each attribute
			return queryResults;
		}
		catch (Exception e)
		{
			// Log the exception and throw a new exception with additional context
			Console.WriteLine(e);
			throw new Exception($"Unable to retrieve GCN Existing GroupId & Coid Id data!\r\nError Message: {e}");
		}
	}

	public bool GetisDeletedValuePostDeletion(int? groupId, string coid)
	{
		try
		{ 
			// Initialize database access object with server and database name
			var dbs = new DbSql(_server, _dbName);

			// Format the query with the provided groupId and coid
			var dbQuery = string.Format(SelectDeletedFlagForGroupIdCoid, groupId, coid);

			// Execute the query to get a DataTable containing the IsDeleted flag
			var dt = dbs.GetRecordsIntoDataTable(dbQuery);

			// Check if the query returned at least one row and extract the IsDeleted value
			if (dt.Rows.Count > 0 && dt.Columns.Contains("IsDeleted"))
			{
				return dt.Rows[0]["IsDeleted"].ToBool();
			}

			// If no rows found, return false (or throw if that's preferred)
			return false;
		}
		catch (Exception e)
		{
			// Log the exception and throw a new exception with additional context
			Console.WriteLine(e);
			throw new Exception($"Unable to retrieve Existing GCN (GroupId & Coid) Id isDeleted Flag Value!\r\nError Message: {e}");
		}
	}

	/*
	//Note: this method wont run in qa or on jenkins because of permission issues.
	//Leaving it here for now. Was a good learning expereince and refresher on ADO.NET
		public void DisableAllGroups(bool disable = false)
		{	
			var disableValue = disable ? 1 : 0;
			var builder = new SqlConnectionStringBuilder
			{
				DataSource = _server,
				InitialCatalog = _dbName,
				CommandTimeout = 60,
				IntegratedSecurity = true,
				TrustServerCertificate = true
			};

			var _connectionString = builder.ConnectionString;
			var sql = $"UPDATE GCN_Group_COID SET IsDeleted = {disableValue} WHERE IsDeleted != {disableValue}";

			using var connection = new SqlConnection(_connectionString);
			connection.Open();
			//SqlDataAdapter adapter = new SqlDataAdapter(sql, connection);
			using var command = new SqlCommand(sql, connection);
			var rowsAffected = command.ExecuteNonQuery();
		}
	//Note: GET NULLS HERE FOR NAME FIELD BECAUSE THEY DO NOT EXISTS IN HomeHierarchy but maybe defined in GCN_COID Tbl
	//Getting names from HomeHierarchy is throwing counts off.  Need to pay around with query
	
	private const string SelectAllGroups = @"SELECT G.Id, G.Name, H.OrgName, GC.COID, GC.IsDeleted
	FROM GCN_Group                G
	INNER JOIN GCN_Group_COID     GC 
	  ON  G.Id                  = GC.GCN_GroupId
	LEFT JOIN vw_refHomeHierarchy H 
	  ON  GC.COID               = H.OrgObjectID
	WHERE G.IsDeleted   = 0
	  AND GC.IsDeleted  = 0
	ORDER BY G.Id";

	 */
	#endregion Methods that Get a DB Record Set

	#region Start of SQL Queries
	private const string SelectAllGroups = @"SELECT GC.Id, (SELECT GG.Name FROM GCN_Group GG WHERE GG.ID = GC.GCN_GroupId) Name, GC.COID, GC.IsDeleted
FROM  GCN_Group_COID     GC         
WHERE GC.IsDeleted   = 0   
ORDER BY GC.Id";

	//Todo: Can't remember why i declared this query: SelectZeroResultsSet. Hold on to it for now see if i remember later but not in use as of 17Nov25 
	private const string SelectZeroResultsSet = @"SELECT GC.Id, (SELECT GG.Name FROM GCN_Group GG WHERE GG.ID = GC.GCN_GroupId) Name, GC.COID, GC.IsDeleted
FROM  GCN_Group_COID GC WHERE GC.CreatedOn = '1900-01-01 00:00:00' ";


	private const string SelectGcnGroup = @"SELECT Id as GroupId, Name as GroupName FROM GCN_Group";
	private const string SelectGcnRegion = @"SELECT Id as RegionId, Name as RegionName FROM GCN_Region";
	private const string SelectGcnDivision = @"SELECT Id as DivisionId, Name as DivisionName FROM GCN_Division";
	private const string SelectGcnLob = @"SELECT Id as LobId, Name as LobName FROM GCN_LOB";
	private const string SelectGcnSubLob = @"SELECT Id as SubLobId, Name as SubLobName FROM GCN_SubLOB";
	private const string SelectGcnApDataCapture = @"SELECT Id as ApDataCaptureId, Name as CaptureName FROM GCN_APDataCapture";
	private const string SelectMaxGcnAttributeIds = @"SELECT (SELECT MAX(G.Id) FROM GCN_Group G) AS MaxId_Group,
        (SELECT MAX(TRY_CAST(C.COID AS INT)) FROM GCN_Group_COID C WHERE TRY_CAST(C.COID AS INT) IS NOT NULL) AS MaxId_Group_COID,
        (SELECT MAX(R.Id) FROM GCN_Region R)        AS MaxId_Region,
        (SELECT MAX(D.Id) FROM GCN_Division D)      AS MaxId_Division,
        (SELECT MAX(L.Id) FROM GCN_LOB L)           AS MaxId_LOB,
        (SELECT MAX(S.Id) FROM GCN_SubLOB S)        AS MaxId_SubLOB,
        (SELECT MAX(A.Id) FROM GCN_APDataCapture A) AS MaxId_ApDataCap";
	private const string SelectGcnRecordUpserted = @"SELECT C.GCN_GroupId, C.COID, C.RegionId, C.DivisionId, C.LobId, C.SubLobId, C.APDataCaptureId 
		FROM GCN_Group_COID C 
		WHERE C.GCN_GroupId = {0} 
		AND C.COID = {1}
		AND C.RegionId = {2}
		AND C.DivisionId = {3}
		AND C.LobId = {4}
		AND C.SubLobId = {5}
		AND C.APDataCaptureId = {6}";
	private const string SelectGcnRecordForSoftDelete = @"SELECT C.GCN_GroupId, C.COID, C.IsDeleted FROM GCN_Group_COID C WHERE C.COID > 90001 AND C.IsDeleted = 0 ORDER BY C.GCN_GroupId, C.COID ";
	private const string SelectGcnGroupIdCoid = @"SELECT C.GCN_GroupId, C.COID FROM GCN_Group_COID C WHERE C.COID > 90001 AND C.IsDeleted = 0 ORDER BY C.GCN_GroupId, C.COID ";
	private const string SelectDeletedFlagForGroupIdCoid = @"SELECT C.IsDeleted FROM GCN_Group_COID C WHERE C.GCN_GroupId = {0} AND C.COID = {1} ";
	#endregion Start of SQL Queries
}
﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartSecurityTestAutomation.Services.GCNGroup
{
	public class GetAllGcnAttributesResponse
	{
		[JsonProperty("groups")]
		public List<GcnGroup> Groups { get; set; }

		[JsonProperty("regions")]
		public List<GcnRegion> Regions { get; set; }

		[JsonProperty("divisions")]
		public List<GcnDivision> Divisions { get; set; }

		[JsonProperty("loBs")]
		public List<GcnLob> LoBs { get; set; }

		[JsonProperty("subLOBs")]
		public List<GcnSubLob> SubLOBs { get; set; }

		[JsonProperty("apDataCaptures")]
		public List<GcnApDataCapture> ApDataCaptures { get; set; }
	}

	public class GcnGroup
	{
		[JsonProperty("groupId")]
		public int GroupId { get; set; }

		[JsonProperty("groupName")]
		public string GroupName { get; set; }
	}

	public class GcnRegion
	{
		[JsonProperty("regionId")]
		public int RegionId { get; set; }

		[JsonProperty("regionName")]
		public string RegionName { get; set; }
	}

	public class GcnDivision
	{
		[JsonProperty("divisionId")]
		public int DivisionId { get; set; }

		[JsonProperty("divisionName")]
		public string DivisionName { get; set; }
	}

	public class GcnLob
	{
		[JsonProperty("lobId")]
		public int LobId { get; set; }

		[JsonProperty("lobName")]
		public string LobName { get; set; }
	}

	public class GcnSubLob
	{
		[JsonProperty("subLobId")]
		public int SubLobId { get; set; }

		[JsonProperty("subLobName")]
		public string SubLobName { get; set; }
	}

	public class GcnApDataCapture
	{
		[JsonProperty("apDataCaptureId")]
		public int ApDataCaptureId { get; set; }

		[JsonProperty("captureName")]
		public string CaptureName { get; set; }
	}

}

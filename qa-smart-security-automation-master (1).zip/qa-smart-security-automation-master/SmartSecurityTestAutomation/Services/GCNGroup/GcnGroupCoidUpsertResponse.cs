﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartSecurityTestAutomation.Services.GCNGroup;

public class GcnGroupCoidUpsertResponse
{
	[JsonProperty("message")]
	public string Message { get; set; }
	// Add other properties as needed
}

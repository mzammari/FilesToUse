﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using OpenQA.Selenium.Chrome;
using SmartSecurityTestAutomation.Models;
using SmartSecurityTestAutomation.Page.Objects.Ping;
using SmartSecurityTestAutomation.Tests;
using Utilities.HttpUtility;
using Utilities.ObjectExtensions;

using WebUiAutomation;

namespace SmartSecurityTestAutomation.Services;

public class MasterApi
{
    protected const string OkResponse             = "(200) OK";
    protected const string NoContent              = "(204) NoContent";
    protected const string BadRequestResponse     = "(400) BadRequest";
    protected const string NotFoundResponse       = "(404) NotFound";
    protected const string NotAuthorizedResponse  = "(401) Unauthorized";
    protected const string InternalServerResponse = "(500) InternalServerError";
	private static readonly string PingAuthUri = GlobalTestVariables.Configuration["SmartSecurity:PingUri"];
	protected const string  ResponseStatusField = "Response Status Code";
    protected const string  ResponseBodyField   = "Response Body";
    
    private static  string? _appToken;
    private static  string? _oauthToken;

	protected static readonly JsonSerializerSettings JsonNullSetting = new()
        { NullValueHandling = NullValueHandling.Ignore };

    /// <summary>
    /// Gets Token from Smart Security
    /// </summary>
    /// <returns></returns>
    /// <exception cref="Exception"></exception>
    protected static string GetAuthToken(NetworkCredential? credential = null, bool resetAuthToken = false)
    {
        if (_appToken!.ToStringOrEmpty() != string.Empty && !resetAuthToken) return _appToken!;
        var authUrl           = $"{GlobalTestVariables.Configuration!["SmartSecurity:BaseUri"]}/token";
        var networkCredential = credential ?? GlobalTestVariables.Credential;
        var wrc               = new WebRequestCall();
        var res               = wrc.GetApiToken(authUrl, networkCredential);

        if (res.Status.Equals(OkResponse))
        {
            _appToken = res.Response.Contains("access_token") 
                ? JObject.Parse(res.Response).GetValue("access_token").ToStringOrEmpty()
                : res.Response;
            return _appToken;
        }

        throw new Exception(
            $"Unable to get Security Token from the following URL: '{authUrl}' for the following user: '{credential.UserName}'!\r\n{res.Status} - {res.Response}");
    }

    public static string GetPingToken(SecurityUser? user = null, bool resetAuthToken = false)
    {
        if (_appToken!.ToStringOrEmpty() != string.Empty && !resetAuthToken) return _appToken!;

        var browser = new Browser(GlobalTestVariables.SeleniumHub);
        var options = new ChromeOptions();
        options.AddArgument("--headless=new");
        browser.OpenNewBrowser("chrome", GlobalTestVariables.SeleniumGridToggle.Equals("ON"),options);
        browser.Navigate(PingAuthUri);

        var securityUser = user ?? GlobalTestVariables.DefaultUser;
        //todo: will go away once windows Cred is removed from SMART Dashboard
        if (GlobalTestVariables.TestEnvironment.Equals("qasbx"))
            securityUser = GlobalTestVariables.UsersB!.First(i=> i.UserName.Equals(securityUser!.UserName));

		Thread.Sleep(1000); //wait for page to load, was experiencing timing issue
		var pingPage= new AuthorizationPage(browser);
        _appToken = pingPage.GetPingToken(securityUser.UserName, securityUser.Creds);

        browser.Close();

        return _appToken;
    }

    /// <summary>
    /// Gets token from HT via oAuth2
    /// </summary>
    /// <returns></returns>
    /// <exception cref="Exception"></exception>
    private static string GetOAuthToken()
    {
        if (_oauthToken!.ToStringOrEmpty() != string.Empty) return _oauthToken!;

        var wrc     = new WebRequestCall();
        var baseUrl = GlobalTestVariables.Configuration!["SmartSecurityClient:SecurityOAuthUri"];
        var res = wrc.GetApiToken(baseUrl!, GlobalTestVariables.Configuration["SmartSecurityClient:ClientId"]!,
            GlobalTestVariables.Configuration["SmartSecurityClient:ClientSecret"]!, "smart_security", GlobalTestVariables.Credential);

        if (!res.Status.Equals("(200) OK"))
            throw new Exception(
                $"Unable to get Security Token from the following: '{baseUrl}'!");
        
        _oauthToken = JObject.Parse(res.Response).GetValue("access_token").ToStringOrEmpty();
        
        return _oauthToken;
    }


    /// <summary>
    /// Sends a simple GET request to the specified url
    /// </summary>
    /// <param name="request"></param>
    /// <param name="tokenType"></param>
    /// <returns></returns>
    protected static HttpResponse GetSimpleRequest(string request, string tokenType = "SmartAuthorization")
    {
        var token   = tokenType.Equals("SmartAuthorization") ? GetPingToken() : GetOAuthToken();
        var headers = new Dictionary<string, string> { { "Authorization", $"Bearer {token}" } };
        var wrc     = new WebRequestCall();
        var result  = wrc.SendApiRequest(request, RestMethod.Get, headers);
        ConsoleOut.WriteReport($"Response Time: {result.ResponseTime:fff} ms");
        
        return result;
    }

    /// <summary>
    /// Sends a simple POST request to the specified url along with its payload
    /// </summary>
    /// <param name="request"></param>
    /// <param name="payload"></param>
    /// <param name="tokenType"></param>
    /// <returns></returns>
    protected static HttpResponse PostSimpleRequest(string request, string? payload, string tokenType = "SmartAuthorization")
    {
        var token   = tokenType.Equals("SmartAuthorization") ? GetPingToken() : GetOAuthToken();
        var headers = new Dictionary<string, string> { { "Authorization", $"Bearer {token}" } };
        var wrc     = new WebRequestCall();
        var result  = wrc.SendApiRequest(request, RestMethod.Post, headers, payload);
        ConsoleOut.WriteReport($"Response Time: {result.ResponseTime:fff} ms");

        return result;
    }

	/// <summary>
	/// Sends a POST request for SelfService endpoints that require x-api-key header.
	/// </summary>
	/// <param name="request"></param>
	/// <param name="payload"></param>
	/// <param name="tokenType"></param>
	/// <returns></returns>
	protected static HttpResponse PostSelfServiceRequest(string request, string? payload, string tokenType = "SmartAuthorization")
	{
		var token = tokenType.Equals("SmartAuthorization") ? GetPingToken() : GetOAuthToken();
        var apiKey = Environment.GetEnvironmentVariable("SelfProvisionXApiKey");

		var headers = new Dictionary<string, string>
	{
		{ "Authorization", $"Bearer {token}" },
		{ "x-api-key", apiKey }
	};

		var wrc = new WebRequestCall();
		var result = wrc.SendApiRequest(request, RestMethod.Post, headers, payload);
		ConsoleOut.WriteReport($"Response Time: {result.ResponseTime:fff} ms");

		return result;
	}

	/// <summary>
	/// Sends a simple DELETE request to the specified url along with its payload (if supported).
	/// </summary>
	/// <param name="request"></param>
	/// <param name="payload"></param>
	/// <param name="tokenType"></param>
	/// <returns></returns>
	protected static HttpResponse DeleteSimpleRequest(string request, string tokenType = "SmartAuthorization")
	{
		var token = tokenType.Equals("SmartAuthorization") ? GetPingToken() : GetOAuthToken();
		var headers = new Dictionary<string, string> { { "Authorization", $"Bearer {token}" } };
		var wrc = new WebRequestCall();
		var result = wrc.SendApiRequest(request, RestMethod.Delete, headers);
		ConsoleOut.WriteReport($"Response Time: {result.ResponseTime:fff} ms");
		return result;
	}

	/// <summary>
	/// Sends a simple DELETE request to the specified url along with its payload (if supported).
	/// </summary>
	/// <param name="request"></param>
	/// <param name="payload"></param>
	/// <param name="tokenType"></param>
	/// <returns></returns>
	protected static HttpResponse DeleteSimpleRequest2(string request, string? payload = null, string tokenType = "SmartAuthorization")
    {
        using var client = new HttpClient();
        client.DefaultRequestHeaders.Add("Authorization", $"Bearer {GetAuthToken()}");
        var httpRequest = new HttpRequestMessage(HttpMethod.Delete, request);

        if (!string.IsNullOrEmpty(payload))
        {
            httpRequest.Content = new StringContent(payload, Encoding.UTF8, "application/json");
        }

        var response = client.Send(httpRequest);
        var responseBody = response.Content.ReadAsStringAsync().Result;
        var status = $"({(int)response.StatusCode}) {response.StatusCode}";
        return new HttpResponse(status, responseBody);
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using SmartSecurityTestAutomation.Data.Views;
using SmartSecurityTestAutomation.Enums;
using SmartSecurityTestAutomation.Services.Orgs;
using Utilities.DatabaseUtility;
using Utilities.ObjectExtensions;

namespace SmartSecurityTestAutomation.Services.Home;

public class HomeRepository
{
    private readonly string _server;
    private readonly string _dbName;


    public HomeRepository(string server, string dbName)
    {
        _server = server;
        _dbName = dbName;
    }

    public IEnumerable<HomeDataDb> GetHomeData()
    {
        try
        {
            var dbs = new DbSql(_server, _dbName);

            return dbs.GetRecordsIntoObject<HomeDataDb>(SqlSelectHome);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw new Exception($"SQL Error!\r\n{e}");
        }
    }

    private const string SqlSelectHome = @"Select gp.GPOIDName as [Name]	  
	  ,org.[OrganizationDesc] as [Organization]
      ,org.OrganizationID            
	  ,trim(co.CompanyName) as [CompanyName]
      ,co.CompanyID	  
      ,co.Active as CompanyActive
	  ,trim(grp.GroupName) as [GroupName]
      ,grp.GroupID
      ,grp.Active as GroupActive
	  ,trim(div.DivisionName) as [DivisionName]	  
      ,div.DivisionID
      ,div.Active as DivisionActive
	  ,trim(mrk.MarketName) as [MarketName]
      ,mrk.MarketID
      ,mrk.Active as MarketActive
      ,gp.COID	  	        
	  ,case when gp.active is null then 1 else gp.active end as [IsActive]
from [tblOrganization] org
left join [tblCompanies] co
		on org.OrganizationID = co.OrganizationID
left join [tblGroups] grp
		on co.CompanyID = grp.CompanyID
left join [tblDivisions] div
		on grp.GroupID = div.GroupID
left join [tblMarkets] mrk
		on div.DivisionID = mrk.DivisionID
left join [tblCOIDs] coid
		on mrk.MarketID = coid.MarketID
        and div.DivisionID = coid.DivisionID
        and grp.GroupID = coid.GroupID
        and co.CompanyID = coid.CompanyID
left join [tblGPOIDs] gp
        on coid.ParentGPOID = gp.GPOID";
    
    public IEnumerable<Hierarchy> GetOrgTreeByLevel(HomeHierarchyType hierarchyType, string parentId)
    {
        var query = string.Empty;
        switch (hierarchyType)
        {
            case HomeHierarchyType.Company:
                query = string.Format(SqlSelectCompany, parentId);
                break;
            case HomeHierarchyType.Group:
                query = string.Format(SqlSelectGroup, parentId);
                break;
            case HomeHierarchyType.Division:
                query = string.Format(SqlSelectDivision, parentId);
                break;
            case HomeHierarchyType.Market:
                query = string.Format(SqlSelectMarket, parentId);
                break;
            default:
                throw new ArgumentOutOfRangeException(nameof(hierarchyType), hierarchyType, null);
        }

        try
        {
            var dbs = new DbSql(_server, _dbName);

            return dbs.GetRecordsIntoObject<Hierarchy>(query);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw new Exception($"Unable to retrieve HOME data!\r\nError Message: {e}");
        }
    }

    private const string SqlSelectCompany = @"SELECT '1' as ParentHierarchy
      ,c.CompanyID as [ParentId]
      ,TRIM(c.CompanyName) as [ParentName]
      ,'2' as [ChildHierarchy]
      ,g.GroupID as [ChildId]
      ,TRIM(g.GroupName) as [ChildName]
  FROM [HOME].[dbo].[tblGroups] g
  join [HOME].[dbo].[tblCompanies] c on c.CompanyID = g.CompanyID and g.Active = 1
  where c.CompanyID = {0}";

    private const string SqlSelectGroup = @"Select '2' as ParentHierarchy
        ,g.GroupID as [ParentId]
        ,TRIM(g.GroupName) as [ParentName]
        ,'3' as [ChildHierarchy]
        ,d.DivisionID as [ChildId]
        ,TRIM(d.DivisionName) as [ChildName]
  from [HOME].[dbo].[tblDivisions] d
  join [HOME].[dbo].[tblGroups] g on g.GroupID = d.GroupID and d.Active = 1
  where d.GroupID = {0}";

    private const string SqlSelectDivision = @"Select '3' as ParentHierarchy
        ,d.DivisionID as [ParentId]
        ,TRIM(d.DivisionName) as [ParentName]
        ,'4' as [ChildHierarchy]
        ,m.MarketID as [ChildId]
        ,TRIM(m.MarketName) as [ChildName]
  from [HOME].[dbo].[tblMarkets] m
  join [HOME].[dbo].[tblDivisions] d on d.DivisionID = m.DivisionID and m.Active = 1
  where m.DivisionID = {0}";

    private const string SqlSelectMarket = @"select '4' as ParentHierarchy
        ,m.MarketID as [ParentId]
        ,TRIM(m.MarketName) as [ParentName]
        ,'5' as [ChildHierarchy]
        ,c.COID  as [ChildId]
        ,TRIM(g.GPOIDName) as [ChildName]
  from [HOME].[dbo].[tblCOIDs] c 
  join  [HOME].[dbo].[tblMarkets] m on m.MarketID = c.MarketID 
  join [HOME].[dbo].[tblGPOIDs] g on c.ParentGPOID = g.GPOID and g.Active = 1
  where c.MarketID = {0}";

    public static HomeDataDb GetSpecificHomeRecord(HomeHierarchyType hierarchyType, string orgObjId, IEnumerable<HomeDataDb> homeList)
    {
        return (hierarchyType switch
        {
            HomeHierarchyType.Company => homeList.FirstOrDefault(i => i.CompanyId.ToStringOrEmpty().Equals(orgObjId)),
            HomeHierarchyType.Group => homeList.FirstOrDefault(i => i.GroupId.ToStringOrEmpty().Equals(orgObjId)),
            HomeHierarchyType.Division => homeList.FirstOrDefault(i => i.DivisionID.ToStringOrEmpty().Equals(orgObjId)),
            HomeHierarchyType.Market => homeList.FirstOrDefault(i => i.MarketId.ToStringOrEmpty().Equals(orgObjId)),
            _ => homeList.FirstOrDefault(i => i.COID.ToStringOrEmpty().Equals(orgObjId))
        })!;
    }

    public static string GetSpecificHomeName(HomeHierarchyType hierarchyType, string orgObjId,
        IEnumerable<HomeDataDb> homeList)
    {
        return (hierarchyType switch
        {
            HomeHierarchyType.Company => homeList.FirstOrDefault(i => i.CompanyId.ToStringOrEmpty().Equals(orgObjId)).CompanyName,
            HomeHierarchyType.Group => homeList.FirstOrDefault(i => i.GroupId.ToStringOrEmpty().Equals(orgObjId)).GroupName,
            HomeHierarchyType.Division => homeList.FirstOrDefault(i => i.DivisionID.ToStringOrEmpty().Equals(orgObjId)).DivisionName,
            HomeHierarchyType.Market => homeList.FirstOrDefault(i => i.MarketId.ToStringOrEmpty().Equals(orgObjId)).MarketName,
            _ => homeList.FirstOrDefault(i => i.COID.ToStringOrEmpty().Equals(orgObjId)).Name
        })!;
    }

    /// <summary>
    /// Returns a collection of RefHomeModel from HOME Database.
    /// </summary>
    /// <returns></returns>
    /// <exception cref="Exception"></exception>
    public IEnumerable<RefHomeModel> GetRefHomeModels()
    {
        try
        {
            var dbs = new DbSql(_server, _dbName);

            return dbs.GetRecordsIntoObject<RefHomeModel>(SelectHomeRefView);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw new Exception($"SQL Error!\r\n{e}");
        }
    }

    private const string SelectHomeRefView = @"SELECT DISTINCT t.* 
      FROM (Select TRIM(gp.GPOIDName) as [GPOIDName]	  
	  ,org.[OrganizationDesc] as [OrganizationName]
      ,org.OrganizationID            
	  ,trim(co.CompanyName) as [CompanyName]
      ,co.CompanyID	  
      ,co.Active as CompanyActive
	  ,trim(grp.GroupName) as [GroupName]
      ,grp.GroupID
      ,grp.Active as GroupActive
	  ,trim(div.DivisionName) as [DivisionName]	  
      ,div.DivisionID
      ,div.Active as DivisionActive
	  ,trim(mrk.MarketName) as [MarketName]
      ,mrk.MarketID
      ,mrk.Active as MarketActive
      ,gp.COID	  	        
	  ,case when gp.active = 1 and mrk.Active = 1 then 1 else 0 end as FacilityActive
from [tblOrganization] org
left join [tblCompanies] co
		on org.OrganizationID = co.OrganizationID
left join [tblGroups] grp
		on co.CompanyID = grp.CompanyID
left join [tblDivisions] div
		on grp.GroupID = div.GroupID
left join [tblMarkets] mrk
		on div.DivisionID = mrk.DivisionID
left join [tblCOIDs] coid
		on mrk.MarketID = coid.MarketID
        and div.DivisionID = coid.DivisionID
        and grp.GroupID = coid.GroupID
        and co.CompanyID = coid.CompanyID
left join [tblGPOIDs] gp
        on coid.ParentGPOID = gp.GPOID
      ) a
      CROSS APPLY (
        VALUES
          (0, 'Oraganization', RIGHT('0000' + cast(OrganizationID AS VARCHAR(7)), 5), OrganizationName,1),
          (1, 'Company', RIGHT('0000' + cast(CompanyId AS VARCHAR(7)), 5), CompanyName,CompanyActive),
          (2, 'Group', RIGHT('0000' + cast(GroupID AS VARCHAR(7)), 5), GroupName, GroupActive),
          (3, 'Division', RIGHT('0000' + cast(DivisionID AS VARCHAR(7)), 5), DivisionName,DivisionActive),
          (4, 'Market', RIGHT('0000' + cast(MarketID AS VARCHAR(7)), 5), MarketName,MarketActive),
          (5, 'Facility', COID, GPOIDName,FacilityActive)
      ) t(HierarchyType, HierarchyLevel, OrgObjectID, OrgName, Active)
 where OrgObjectID is not null";
}
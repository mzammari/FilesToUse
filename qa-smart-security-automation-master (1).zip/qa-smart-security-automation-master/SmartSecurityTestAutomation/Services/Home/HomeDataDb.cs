﻿namespace SmartSecurityTestAutomation.Services.Home;

public class HomeDataDb
{
    public string Name           { get; set; }
    public string Organization   { get; set; }
    public string OrganizationID { get; set; }
    public string CompanyName    { get; set; }
    public string CompanyId      { get; set; }
    public bool   CompanyActive  { get; set; }
    public string GroupName      { get; set; }
    public string GroupId        { get; set; }
    public bool   GroupActive    { get; set; }
    public string DivisionName   { get; set; }
    public string DivisionID     { get; set; }
    public bool   DivisionActive { get; set; }
    public string MarketName     { get; set; }
    public string MarketId       { get; set; }
    public bool   MarketActive   { get; set; }
    public string COID           { get; set; }
    public bool   IsActive       { get; set; }
}
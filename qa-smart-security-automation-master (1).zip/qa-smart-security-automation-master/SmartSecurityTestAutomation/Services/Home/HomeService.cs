﻿using System.Collections.Generic;
using System.Linq;
using AutomationCoreLite.Reporting;
using Microsoft.Extensions.Configuration;
using SmartSecurityTestAutomation.Services.Users;
using SmartSecurityTestAutomation.Tests;
using Utilities.HttpUtility;
using Utilities.ObjectExtensions;

namespace SmartSecurityTestAutomation.Services.Home;

public class HomeService : MasterApi
{
    private const string GetNameResource = "/organization/getname";

    private static HttpResponse getHomeName(Dictionary<string, string?> param) => GetSimpleRequest(
        RequestBuilder.BuildRequestWithParameters(
            $"{GlobalTestVariables.Configuration["Home:BaseUri"]}{GetNameResource}",
            param));


    public string GetHomeName(string hierarchyLevel, string? objectId)
    {
        var parameters = new Dictionary<string, string?>()
        {
            { "hierarchyType", hierarchyLevel },
            { "objectID", objectId }
        };

        var response = getHomeName(parameters);

        if (response.Status.Equals("(200) OK"))
            return response.Response;

        HPGAssert.Fail(
            $"Unable to get response from HOME API for hierarchy level: {hierarchyLevel} and object ID: {objectId}");

        return string.Empty;
    }

    public static List<SpanOfControl> GetExpectedHierarchyList(IEnumerable<UserSocDb> rawSocList,
        IEnumerable<HomeDataDb> homeRefData, bool oldWay = false)
    {
        var results = rawSocList.Select(i => new SpanOfControl()
        {
            OrgName       = null!,
            HierarchyType = i.Hierarchy.ToString(),
            ObjectId      = i.OrgObjectID
        });

        var hierarchies = results.ToList();
        foreach (var result in hierarchies)
        {
            if (result.ObjectId.ToStringOrEmpty() == string.Empty)
            {
                HPGWarn.Warn($"ObjectId is Null/Empty!");
            }
            else
            {
                var temp        = result.ObjectId.PadLeft(5, '0');
                var homeDataDbs = homeRefData.ToList();
                result.OrgName = result.HierarchyType switch
                {
                    "0" => homeDataDbs.Where(i => !i.OrganizationID.IsNull())
                        .First(o => o.OrganizationID.Equals(result.ObjectId.ToInt().ToStringOrEmpty())).Organization,
                    "1" => homeDataDbs.Where(c => !c.CompanyName.IsNull())
                        .First(i => i.CompanyId.Equals(result.ObjectId.ToInt().ToStringOrEmpty()))
                        .CompanyName,
                    "2" => homeDataDbs.Where(g => !g.GroupId.IsNull()).First(i =>
                            i.GroupId.Equals(result.ObjectId.ToInt().ToStringOrEmpty()))
                        .GroupName,
                    "3" => homeDataDbs.Where(d => !d.DivisionID.IsNull())
                        .First(i => i.DivisionID.Equals(result.ObjectId.ToInt().ToStringOrEmpty()))
                        .DivisionName,
                    "4" => homeDataDbs.Where(m => !m.MarketId.IsNull()).First(i =>
                            i.MarketId.Equals(result.ObjectId.ToInt().ToStringOrEmpty()))
                        .MarketName,
                    //todo: will be removed  removed
                    _ => oldWay
                        ? GetOrgNameWithPrefix(homeDataDbs, result)
                        : GetOrgNameWithoutPrefix(homeDataDbs, result)
                };

                result.ObjectId = temp;
            }
        }

        return hierarchies;
    }

    private static string GetOrgNameWithoutPrefix(IReadOnlyCollection<HomeDataDb> homeDataDbs, SpanOfControl result)
    {
        return homeDataDbs.Where(co => co.COID.ToStringOrEmpty() != string.Empty)
            .Any(i => i.COID.Equals(
                result.ObjectId!.Length < 5 ? $"0{result.ObjectId}" : result.ObjectId))
            ? $"{homeDataDbs.Where(co => co.COID.ToStringOrEmpty() != string.Empty).First(i => i.COID.Equals(result.ObjectId.Length < 5 ? $"0{result.ObjectId}" : result.ObjectId)).Name}"
            : null!;
    }

    private static string GetOrgNameWithPrefix(IReadOnlyCollection<HomeDataDb> homeDataDbs, SpanOfControl result)
    {
        return homeDataDbs.Where(co => co.COID.ToStringOrEmpty() != string.Empty)
            .Any(i => i.COID.Equals(
                result.ObjectId!.Length < 5 ? $"0{result.ObjectId}" : result.ObjectId))
            ? $"{homeDataDbs.Where(co => co.COID.ToStringOrEmpty() != string.Empty).First(i => i.COID.Equals(result.ObjectId!.Length < 5 ? $"0{result.ObjectId}" : result.ObjectId)).CompanyName} - {homeDataDbs.Where(co => co.COID.ToStringOrEmpty() != string.Empty).First(i => i.COID.Equals(result.ObjectId!.Length < 5 ? $"0{result.ObjectId}" : result.ObjectId)).Name}"
            : null!;
    }
}
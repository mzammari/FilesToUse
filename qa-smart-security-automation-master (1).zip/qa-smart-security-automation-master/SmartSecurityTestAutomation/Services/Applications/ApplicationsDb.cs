﻿using System;

namespace SmartSecurityTestAutomation.Services.Applications;

public class ApplicationsDb
{
    public Guid   Id          { get; set; }
    public string Name        { get; set; }
    public string Description { get; set; }
    public Guid   ApiKey      { get; set; }
    public bool   IsEnabled   { get; set; }
    public bool   IsDeleted   { get; set; }
}
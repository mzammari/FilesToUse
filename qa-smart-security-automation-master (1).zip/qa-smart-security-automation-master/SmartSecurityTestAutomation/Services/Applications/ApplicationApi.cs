﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using SmartSecurityTestAutomation.Enums;
using SmartSecurityTestAutomation.Tests;
using Utilities.HttpUtility;
using Utilities.ObjectExtensions;

namespace SmartSecurityTestAutomation.Services.Applications;

public class ApplicationApi : MasterApi
{
    private const    string                ApplicationResource = "/applications";
    private const    string                RolesResource       = "/roles";
    private readonly string                _baseUri;
    private readonly ApplicationRepository _applicationDb;

    public ApplicationApi()
    {
        _baseUri = GlobalTestVariables.Configuration!["SmartSecurity:BaseUri"]!;
        _applicationDb = new ApplicationRepository(GlobalTestVariables.Configuration["SmartSecurity:DatabaseServer"]!,
            GlobalTestVariables.Configuration["SmartSecurity:DatabaseName"]!);
    }


    #region API Call

    /// <summary>
    /// An API call to get application information
    /// </summary>
    /// <returns></returns>
    private HttpResponse GetApplications() =>
        GetSimpleRequest($"{_baseUri}{ApplicationResource}");

    /// <summary>
    /// An API call to get roles based on a specific application
    /// </summary>
    /// <param name="appId"></param>
    /// <returns></returns>
    private HttpResponse GetApplicationRoles(string appId) =>
        GetSimpleRequest($"{_baseUri}{ApplicationResource}/{appId}{RolesResource}");

    #endregion API Call

    #region Test Methods

    /// <summary>
    /// Test 'GET' request for /applications endpoint.
    /// Manual Estimated Execution Time: 0:05:00
    /// </summary>
    public void TestGetApplications()
    {
        Steps.AddTestStep("Test 'GET' request for /applications endpoint.", "System should respond accordingly.");


        //todo: need to modify to use different security users
        var testApplicationData = _applicationDb.GetApplicationsDb().Where(i => !i.IsDeleted && i.IsEnabled);

        var expectedList = testApplicationData
            .Select(i => new GeneralIdNameResponse() { Id = i.Id.ToString(), Name = i.Name })
            .ToList();

        var response = GetApplications();
        if (!HPGWarn.AreEqual(OkResponse, response.Status, field: "Response Status Code")) return;
        var actualList = JsonConvert.DeserializeObject<List<GeneralIdNameResponse>>(response.Response);
        GeneralIdNameResponse.ValidateGenralList(expectedList, actualList!);
    }

	/// <summary>
	/// Test 'GET' request for /applications/&lt;Application ID&gt;/roles endpoint.
	/// Manual Estimated Execution Time: 0:05:00
	/// If you find this one fails. Double check Service Accts HTNASVCTSTAUT53, HTNASVCTSTAUT54 for additional Security Admin roles inadvertantly assigned
	/// </summary>
	public void TestGetRolesByApplicationId()
    {
        Steps.AddTestStep("Test 'GET' request for /applications/<Application ID>/roles endpoint.",
            "Systems should respond accordingly.");
        
        foreach (var enumUser in EnumUtil.GetValues<SecurityUserType>())
        {
            var sUser = enumUser.GetEnumDescription();
            
            Steps.AddTestStep($"Starting scenario for Security User: '{sUser}'.","Should respond back with the correct roles.");

            //get specified security user and set the network credentials to that user
            var testUser             = GlobalTestVariables.Users.First(i => i.RoleName.Contains(sUser));
            GetPingToken(testUser, true);

            //get the applicable configured roles for the specified user
            var configuredRoles = _applicationDb.GetApplicationRolesForSpecificSecurityType(sUser)
                .Where(i => !i.IsDeleted).ToList();
			//Check if sUser is assigned Client Admin role. If so then the user can not see Procurement VBO Role or any other Security role.
			var allRoles = Enumerable.Empty<ApplicationRolesDb>();
			if (sUser == "Security - Client Administrator")
            {
                // Remove the role with Name "Procurement - Vendor Bill Only" from the list for procVB
                allRoles = _applicationDb.GetApplicationRolesDbs().Where(i => !i.IsDeleted && !i.ApplicationName.Equals("SMART - Security", StringComparison.OrdinalIgnoreCase)
                && !(i.ApplicationName.Equals("SMART - Procurement", StringComparison.OrdinalIgnoreCase) && i.Name.Equals("Procurement - Vendor Bill Only", StringComparison.OrdinalIgnoreCase)));
            }
            else
            { //get all roles
                allRoles = _applicationDb.GetApplicationRolesDbs().Where(i => !i.IsDeleted); 
            }
			var applicationRoles = configuredRoles.IsNullOrEmpty() ? allRoles : configuredRoles;

            //Group the roles by application id
            var applicationRoleDictionary = applicationRoles.GroupBy(g => g.ApplicationId).ToDictionary(grp => grp.Key,
                j => j.Select(k => new GeneralIdNameResponse { Id = k.Id.ToString(), Name = k.Name }).ToList());
			//loop thru the application id
			foreach (var exp in applicationRoleDictionary)
            {
                Steps.AddTestStep($"Sending 'GET' request for AppId: '{exp.Key}' for Security User Type: '{sUser}'.",
                    "System should respond with a (200) OK and a list of role(s).");
				//get the roles for the application id
				var response = GetApplicationRoles(exp.Key.ToString());
                if (!HPGWarn.AreEqual("(200) OK", response.Status, field: "Response Status Code")) continue;
                var actualList = JsonConvert.DeserializeObject<List<GeneralIdNameResponse>>(response.Response);
                GeneralIdNameResponse.ValidateGenralList(exp.Value, actualList!);
            }
        }

        GetPingToken(resetAuthToken: true);
    }

    /// <summary>
    /// Test 'GET' request for /applications/<Application ID>/roles endpoint with bad or null values.
    /// Manual Estimated Execution Time: 0:05:00
    /// </summary>
    public void TestGetRolesByApplicationIdBadRequest()
    {
        GetPingToken(resetAuthToken: true);

        Steps.AddTestStep(
            "Test 'GET' request for /applications/<Application ID>/roles endpoint with bad or null values.",
            "Systems should respond accordingly.");

        var scenarios = new List<string>() { "Blank Value", "Non-Guid", "Non-Existent Application Guid" };

        foreach (var scenario in scenarios)
        {
            var testValue          = string.Empty;
            var expectedStatusCode = string.Empty;
            switch (scenario)
            {
                case "Blank Value":
                    testValue          = "";
                    expectedStatusCode = NotFoundResponse;
                    break;
                case "Non-Guid":
                    testValue          = "abc123";
                    expectedStatusCode = BadRequestResponse;
                    break;
                case "Non-Existent Application Guid":
                    testValue          = Guid.NewGuid().ToString();
                    expectedStatusCode = OkResponse;
                    break;
            }

            Steps.AddTestStep(
                $"Sending 'GET' request for /applications/<Application ID>/roles endpoint with value'{testValue}' for scenario: '{scenario}'.",
                $"Systems should respond with a {expectedStatusCode}.");

            var response = GetApplicationRoles(testValue);
            if (!HPGWarn.AreEqual(expectedStatusCode, response.Status, field: ResponseStatusField)) continue;

            switch (scenario)
            {
                case "Non-Guid":
                {
                    var errorResponse = JsonConvert.DeserializeObject<BadRequestReponse>(response.Response);
                    HPGWarn.AreEqual($"The value '{testValue}' is not valid.",
                        errorResponse!.Errors.AppId.FirstOrDefault(),
                        field: "Error Response");
                    break;
                }
                case "Non-Existent Application Guid":
                {
                    var results = JsonConvert.DeserializeObject<List<GeneralIdNameResponse>>(response.Response);
                    HPGWarn.True(results!.IsNullOrEmpty(), field: "Empty Array");
                    break;
                }
            }
        }
    }

	#endregion Test Methods

	#region Validation Methods

	#endregion Validation Methods

	#region Helper Methods

	#endregion Helper Methods
}
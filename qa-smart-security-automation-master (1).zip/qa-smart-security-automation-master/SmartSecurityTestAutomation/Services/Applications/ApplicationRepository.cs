﻿using System;
using System.Collections.Generic;
using SmartSecurityTestAutomation.Services.Users;
using Utilities.DatabaseUtility;

namespace SmartSecurityTestAutomation.Services.Applications;

public class ApplicationRepository
{
    private readonly string _server;
    private readonly string _dbName;


    public ApplicationRepository(string server, string dbName)
    {
        _server = server;
        _dbName = dbName;
    }

    public IEnumerable<ApplicationsDb> GetApplicationsDb()
    {
        try
        {
            var dbs   = new DbSql(_server, _dbName);
            return dbs.GetRecordsIntoObject<ApplicationsDb>(SelectApplications);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw new Exception($"Unable to retrieve SMART Security data!\r\nError Message: {e}");
        }
    }

    private const string SelectApplications = @"SELECT ApiKey as [Id]
      ,[Name]
      ,[Description]
      ,[ApiKey]
      ,[IsEnabled]     
      ,[IsDeleted]     
  FROM [dbo].[Application]";

    public IEnumerable<ApplicationRolesDb> GetApplicationRolesDbs()
    {
		IEnumerable <ApplicationRolesDb> applicationRolesDbs = new List<ApplicationRolesDb >();

		try
        {
            var dbs   = new DbSql(_server, _dbName);
			applicationRolesDbs = dbs.GetRecordsIntoObject<ApplicationRolesDb>(SelectApplicationsRole);
            return applicationRolesDbs;

		}
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw new Exception($"Unable to retrieve SMART Security data!\r\nError Message: {e}");
        }
    }

    private const string SelectApplicationsRole = @"SELECT r.RoleKey as [Id]
      ,r.[Name]
      ,r.[Description]
      ,a.ApiKey as [ApplicationId] 
      ,a.Name AS [ApplicationName]
      ,a.[ApiKey] as [ApplicationKey]
      ,r.[RoleKey]
      ,r.[IsDeleted]
      ,a.IsEnabled        
  FROM [dbo].[Role] r
  join [dbo].[Application] a on r.ApplicationId = a.Id";

    public IEnumerable<ApplicationRolesDb> GetApplicationRolesByUserTypeDbs(bool isEmployee = true)
    {
        try
        {
            var dbs   = new DbSql(_server, _dbName);
            var query = isEmployee ? SelectApplicationsRoleEmployee : SelectApplicationsRoleVendor;
            return dbs.GetRecordsIntoObject<ApplicationRolesDb>(query);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw new Exception($"Unable to retrieve SMART Security data!\r\nError Message: {e}");
        }
    }


    private const string SelectApplicationsRoleEmployee = @"SELECT r.RoleKey as [Id]
      ,r.[Name]
      ,r.[Description]
      ,a.ApiKey as [ApplicationId] 
      ,a.Name AS [ApplicationName]
      ,r.[IsDeleted]
      ,a.IsEnabled        
  FROM [dbo].[Application] a
  INNER join [dbo].[Role] r ON a.Id=r.ApplicationId
  LEFT JOIN [dbo].[UserType_Role] ur ON r.Id=ur.RoleId
  WHERE a.IsEnabled=1 AND ur.Id IS NULL";


    private const string SelectApplicationsRoleVendor = @"SELECT distinct r.RoleKey as [Id]
      ,r.[Name]
      ,r.[Description]
      ,a.ApiKey as [ApplicationId] 
      ,a.Name AS [ApplicationName]
      ,r.[IsDeleted]
      ,a.IsEnabled  
   FROM [dbo].[Application] a
    INNER JOIN [dbo].[Role] r ON a.Id=r.ApplicationId
		INNER JOIN [dbo].[UserType_Application] ua ON a.Id=ua.ApplicationId
		INNER JOIN [dbo].[UserType_Role] ur ON r.Id=ur.RoleId
		WHERE a.IsEnabled=1";

    public IEnumerable<ApplicationRolesDb> GetApplicationRolesForSpecificSecurityType(string type)
    {
        try
        {
            var dbs   = new DbSql(_server, _dbName);
            var query = string.Format(SelectApplicationRolesForSecurityUser, type);
            return dbs.GetRecordsIntoObject<ApplicationRolesDb>(query);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw new Exception($"Unable to retrieve SMART Security data!\r\nError Message: {e}");
        }
    }

    private const string SelectApplicationRolesForSecurityUser = @"select r2.RoleKey as [Id]
        ,r2.Name
        ,r2.[Description]
        ,a.ApiKey as [ApplicationId]
        ,r2.IsDeleted
        ,a.IsEnabled
  from [dbo].[Role] r1
  join [dbo].[AdminRoleGovernance] arg on r1.Id = arg.AdminRoleId
  join [dbo].[Role] r2 on arg.GovernedRoleId = r2.Id
  join [dbo].[Application] a on r2.ApplicationId = a.Id
  
  where r1.Name = '{0}'";
}
﻿using System;
using System.Collections.Specialized;

namespace SmartSecurityTestAutomation.Services.Applications;

public class ApplicationRolesDb
{

    public Guid   Id              { get; set; } //RoleKey
    public string Name            { get; set; } //roleName
    public string Description     { get; set; } //roleDesc
    public Guid   ApplicationId   { get; set; } //ApiKey
    public string ApplicationName { get; set; } //AppDesc
    public bool   IsDeleted       { get; set; } //role.IsDeleted
    public bool   IsEnabled       { get; set; } //Application.IsEnabled
}
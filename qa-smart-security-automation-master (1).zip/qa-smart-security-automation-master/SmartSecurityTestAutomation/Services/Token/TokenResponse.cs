﻿using Newtonsoft.Json;

namespace SmartSecurityTestAutomation.Services.Token;

public class TokenResponse
{
    [JsonProperty("accesstoken")]
    public string? AccessToken { get; set; }

    [JsonProperty("refreshtoken")]
    public string? RefreshToken { get; set; }
}
﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using SmartSecurityTestAutomation.Tests;
using Utilities.HttpUtility;
using Utilities.ObjectExtensions;

namespace SmartSecurityTestAutomation.Services.Token;

public class TokenApi : MasterApi
{
    private const  string  TokenResource        = "/token";
    private const  string  TokenUserResource    = "/token/user";
    private const  string  TokenRefreshResource = "/token/refresh";
    private static string? _baseUrl;

    public TokenApi()
    {
        _baseUrl = GlobalTestVariables.Configuration!["SmartSecurity:BaseUri"]!;
    }
    #region API Call

    private static HttpResponse GetTokenUser(Dictionary<string, string?> parameters = null!)
    {
        var request =
            RequestBuilder.BuildRequestWithParameters(
                $"{_baseUrl}{TokenUserResource}",
                parameters);

        var wrc    = new WebRequestCall();
        var result = wrc.SendApiRequest(request, RestMethod.Get);
        ConsoleOut.WriteReport($"Response Time: {result.ResponseTime:fff} ms");

        return result;
    }

    private static HttpResponse GetNewAuthToken()
    {
        var authUrl           = $"{_baseUrl}{TokenResource}";
        var networkCredential = GlobalTestVariables.Credential;
        var wrc               = new WebRequestCall();
        return wrc.GetApiToken(authUrl, networkCredential);
    }

    private static HttpResponse GetRefreshToken(string? payload)
    {
        var wrc     = new WebRequestCall();
        var request = $"{_baseUrl}{TokenRefreshResource}";
        var result  = wrc.SendApiRequest(request, RestMethod.Post,payload:payload);
        ConsoleOut.WriteReport($"Response Time: {result.ResponseTime:fff} ms");
        return result;
    }

    #endregion API Call

    #region Test Methods

    /// <summary>
    /// Test sending 'GET' request to /token/user API endpoint.
    /// Manual Estimated Execution Time: 0:01:00
    /// </summary>
    public void TestGetTokenUser()
    {
        Steps.AddTestStep("Test sending 'GET' request to /token/user API endpoint.",
            "System should respond accordingly.");

        var token = GetPingToken(resetAuthToken:true);
        Steps.AddTestStep(
            $"Sending 'GET' request for the following token: '{token}' for user: {GlobalTestVariables.UserName} .",
            $"System should respond with a (200) OK and with {GlobalTestVariables.UserName} in the response body.");

        var param = new Dictionary<string, string?>
        {
            { "token", token }
        };

        var response = GetTokenUser(param);
        if (HPGWarn.AreEqual("(200) OK", response.Status, field: "Response Status Code"))
        {
            HPGWarn.AreEqual(GlobalTestVariables.UserName, response.Response, field: "Response Body");
        }
    }

    /// <summary>
    /// Test sending 'GET' request to /token/user API endpoint with bad or null values.
    /// Manual Estimated Execution Time: 0:05:00
    /// </summary>
    public void TestGetTokenUserBadRequest()
    {
        Steps.AddTestStep("Test sending 'GET' request to /token/user API endpoint with bad or null values.",
            "System should respond with a (400) BadRequest.");
        var scenarios = new List<string>() { "Null Token", "Blank Token", "Invalid Token" };
        foreach (var scenario in scenarios)
        {
            var param              = new Dictionary<string, string?>();
            string        expectedStatusCode = string.Empty;
            switch (scenario)
            {
                case "Null Token":
                    expectedStatusCode = BadRequestResponse;
                    break;
                case "Blank Token":
                    param.Add("token", string.Empty);
                    expectedStatusCode = BadRequestResponse;
                    break;
                case "Invalid Token":
                    param.Add("token",
                        "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6IkhDQVxcSE5JNzk2NCIsIm5iZiI6MTY1ODk0NDk3OCwiZXhwIjoxNjU5NTQ5Nzc4LCJpYXQiOjE2NTg5NDQ5Nzh9.b2uaEA45EfAz4fuJdi0dTA1pOX1eOuUl6S1jMz4pAT7");
                    expectedStatusCode = NoContent;
                    break;
            }

            Steps.AddTestStep($"Sending 'GET' request to /token/user for the following scenario: {scenario}.",
                $"System should respond with the following status code: {expectedStatusCode}.");
            var response = GetTokenUser(param);
            HPGWarn.AreEqual(expectedStatusCode, response.Status, field: "Response Status Code");
            if (response.Status.Equals(InternalServerResponse))
            {
                HPGWarn.Contains(response.Response, "Unable to process the request.");
            }
        }
    }

    /// <summary>
    /// Test sending 'GET' request to /token/refresh API endpoint.
    /// </summary>
    public void TestGetRefreshToken()
    {
        Steps.AddTestStep("Test sending 'POST' request to /token/refresh API endpoint.",
            "System should respond accordingly.");

        Steps.AddTestStep("Sending 'GET' request to /token API endpoint to get current token.",
            "System should respond accordingly.");
        var responseCurrentToken = GetNewAuthToken();
        if (!HPGWarn.AreEqual(OkResponse, responseCurrentToken.Status, field: ResponseStatusField))
        {
            HPGWarn.Warn("Unable to continue test due to inability to get a Token!");
            return;
        }

        var currentToken = new TokenResponse
        {
            AccessToken = JObject.Parse(responseCurrentToken.Response).GetValue("access_token").ToStringOrEmpty(),
            RefreshToken = JObject.Parse(responseCurrentToken.Response).GetValue("refresh_token").ToStringOrEmpty()
        };

        Steps.AddTestStep("Sending 'GET' request to /token/refresh API endpoint to get new refresh token.",
            "System should respond accordingly.");
        var payload              = JsonConvert.SerializeObject(currentToken);
        var responseRefreshToken = GetRefreshToken(payload);

        if (!HPGWarn.AreEqual(OkResponse, responseRefreshToken.Status, field: ResponseStatusField)) return;
        
        var refreshToken = new TokenResponse
        {
            AccessToken  = JObject.Parse(responseRefreshToken.Response).GetValue("access_token").ToStringOrEmpty(),
            RefreshToken = JObject.Parse(responseRefreshToken.Response).GetValue("refresh_token").ToStringOrEmpty()
        };

        HPGWarn.True(refreshToken.AccessToken.ToStringOrEmpty() != string.Empty,field:"Access Token");
        HPGWarn.True(refreshToken.RefreshToken.ToStringOrEmpty() != string.Empty, field: "Refresh Token");
    }

    public void TestGetRefreshTokenBadRequest()
    {
        Steps.AddTestStep("Test sending 'POST' request to /token/refresh API endpoint with bad or null values..",
            "System should respond accordingly.");

        var scenarios = new List<string>() { "Null Access Token", "Blank Access Token", "Invalid Access Token", "Null Refresh Token", "Blank Refresh Token", "Invalid Refresh Token" };

        Steps.AddTestStep("Sending 'GET' request to /token API endpoint to get current token.",
            "System should respond accordingly.");
        var responseCurrentToken = GetNewAuthToken();
        if (!HPGWarn.AreEqual(OkResponse, responseCurrentToken.Status, field: ResponseStatusField))
        {
            HPGWarn.Warn("Unable to continue test due to inability to get a Token!");
            return;
        }

        var resetToken = new TokenResponse
        {
            AccessToken  = JObject.Parse(responseCurrentToken.Response).GetValue("access_token").ToStringOrEmpty(),
            RefreshToken = JObject.Parse(responseCurrentToken.Response).GetValue("refresh_token").ToStringOrEmpty()
        };

        foreach (var scenario in scenarios)
        {
            var testToken = resetToken;
            string expectedResponse;
            switch (scenario)
            {
                case "Null Access Token":
                    testToken.AccessToken = null;
                    expectedResponse      = BadRequestResponse;
                    break;
                case "Blank Access Token":
                    testToken.AccessToken = "";
                    expectedResponse      = BadRequestResponse;
                    break;
                case "Invalid Access Token":
                    testToken.AccessToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6IkhDQVxcSE5JNzk2NCIsIm5iZiI6MTY2OTczNTY4MCwiZXhwIjoxNjY5NzM2MjgwLCJpYXQiOjE2Njk3MzU2ODB9.A9uBxiFAbe0-CU";
                    expectedResponse = BadRequestResponse;
                    break;
                case "Null Refresh Token":
                    testToken.RefreshToken = null;
                    expectedResponse       = BadRequestResponse;
                    break;
                case "Blank Refresh Token":
                    testToken.RefreshToken = "";
                    expectedResponse       = BadRequestResponse;
                    break;
                case "Invalid Refresh Token":
                    testToken.RefreshToken = "52Kw5neW+rs4zqETH0rx0R3JX1ZF/6L3HQOBETG";
                    expectedResponse       = BadRequestResponse;
                    break;
                default: throw new Exception($"Unable to recognize scenario: '{scenario}'!");
            }

            var payload  = scenario.Contains("Null") 
                ? JsonConvert.SerializeObject(testToken, JsonNullSetting) : JsonConvert.SerializeObject(testToken);
            
            Steps.AddTestStep($"Sending 'POST' request to /token/refresh API endpoint for Scenario '{scenario}' with Payload: '{payload}'.",$"System should respond with a {expectedResponse}.");
            
            var response = GetRefreshToken(payload);

            if (HPGWarn.AreEqual(expectedResponse, response.Status, field: ResponseStatusField))
            {
                if (scenario.Equals("Invalid Access Token"))
                {
                    responseCurrentToken = GetNewAuthToken();
                    if (!HPGWarn.AreEqual(OkResponse, responseCurrentToken.Status, field: ResponseStatusField))
                    {
                        HPGWarn.Warn("Unable to continue test due to inability to get a Token!");
                        return;
                    }

                    resetToken = new TokenResponse
                    {
                        AccessToken  = JObject.Parse(responseCurrentToken.Response).GetValue("access_token").ToStringOrEmpty(),
                        RefreshToken = JObject.Parse(responseCurrentToken.Response).GetValue("refresh_token").ToStringOrEmpty()
                    };
                }
                else
                {
                    HPGWarn.AreEqual("Invalid client request", response.Response, field: ResponseBodyField);
                }
            }
        }
    }

    #endregion Test Methods
}
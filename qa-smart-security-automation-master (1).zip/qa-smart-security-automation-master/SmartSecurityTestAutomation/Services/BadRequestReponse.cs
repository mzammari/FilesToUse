﻿using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace SmartSecurityTestAutomation.Services;

public class BadRequestReponse
{
    [JsonPropertyName("type")]
    public string Type { get; set; }

    [JsonPropertyName("title")]
    public string Title { get; set; }

    [JsonPropertyName("status")]
    public int Status { get; set; }

    [JsonPropertyName("traceId")]
    public string TraceId { get; set; }

    [JsonPropertyName("errors")]
    public Errors Errors { get; set; }
}

public class Errors
{
    [JsonPropertyName("isVendor")]
    public List<string> IsVendor { get; set; }

    [JsonPropertyName("userId")]
    public List<string> UserId { get; set; }

    [JsonPropertyName("ApplicationId")]
    public List<string> ApplicationId { get; set; }

    [JsonPropertyName("appId")]
    public List<string> AppId { get; set; }

    [JsonPropertyName("HierarchyType")]
    public List<string> HierarchyType { get; set; }
    
    [JsonPropertyName("ParentId")]
    public List<string> ParentId { get; set; }

}
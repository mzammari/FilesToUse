﻿using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using Utilities.ObjectExtensions;
using Utilities.Validation;

namespace SmartSecurityTestAutomation.Services;

public class GeneralIdNameResponse
{
    [JsonPropertyName("id")]
    public string Id { get; set; }

    [JsonPropertyName("name")]
    public string? Name { get; set; }

    public static void ValidateGenralList(List<GeneralIdNameResponse> expectedList, List<GeneralIdNameResponse> actualList, bool byPassSecondary = false)
    {
		// Sort both lists by Id in ascending order
		expectedList = expectedList.OrderBy(x => x.Id).ToList();
		actualList = actualList.OrderBy(x => x.Id).ToList();

		Steps.AddTestStep("Validating GeneralIdNameResponse Model List", "Model should match.");
        Steps.AddTestStep("Validating expected list matches actual list.", "Should both match");
		
        var actualDictionary = actualList.ToDictionary(i => i.Id, j => j);
        foreach (var expected in expectedList)
        {
            var testActual = actualDictionary;
            var testExpected = expected;

            if (!actualDictionary.TryGetValue(expected.Id, out var actual))
                HPGWarn.Warn($"Unable to find ID: '{expected.Id}' in actual! Double check correct Security Role assignment");
            else
            {
                HPGWarn.AreEqual(expected.Name, actual.Name, field: "Name");
            }
        }

        if(byPassSecondary) return;

        Steps.AddTestStep("Validating actual list matches expected list.", "Should both match");
        var expectedDictionary = expectedList.ToDictionary(i => i.Id, j => j);
        foreach (var actual in actualList)
        {	
			if (!expectedDictionary.TryGetValue(actual.Id, out var expected))
                HPGWarn.Warn($"Unable to find ID: '{actual.Id}' in expected! {actual.Name}");
            else
            {
                HPGWarn.AreEqual(actual.Name, expected.Name, field: "Name");
            }
        }
    }
}
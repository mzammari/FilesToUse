﻿using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using Utilities.ObjectExtensions;
using Utilities.Validation;

namespace SmartSecurityTestAutomation.Services.Orgs;

public class UserOrgTree
{
    [JsonProperty("id")]
    public string Id { get; set; }

    [JsonProperty("label")]
    public string Label { get; set; }

    [JsonProperty("typeId")]
    public string TypeId { get; set; }

    [JsonProperty("dn")]
    public string Dn { get; set; }

    [JsonProperty("children")]
    public object Children { get; set; }

    public List<string> Validate(UserOrgTree other)
    {
        var results = new List<string>()
        {
            ValidationHelpers.AreEqual(this.Id.ToStringOrEmpty(), other.Id.ToStringOrEmpty(),
                "Id"),
            ValidationHelpers.AreEqual(this.Label.ToStringOrEmpty(), other.Label.ToStringOrEmpty(),
                "Label"),
            ValidationHelpers.AreEqual(this.TypeId.ToStringOrEmpty(), other.TypeId.ToStringOrEmpty(),
                "TypeId"),
            ValidationHelpers.AreEqual(this.Dn.ToStringOrEmpty(), other.Dn.ToStringOrEmpty(),
                "Dn"),
        };

        return results.Where(i => i != string.Empty).ToList();
    }
}
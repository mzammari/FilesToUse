﻿using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using Utilities.ObjectExtensions;
using Utilities.Validation;

namespace SmartSecurityTestAutomation.Services.Orgs;

public class UserOrgTreeRoot
{
    [JsonProperty("organizationID")]
    public string? OrganizationID { get; set; }

    [JsonProperty("organizationTypeId")]
    public string? OrganizationTypeId { get; set; }

    [JsonProperty("organizationName")]
    public string? OrganizationName { get; set; }

    [JsonProperty("companyID")]
    public int CompanyID { get; set; }

    [JsonProperty("companyName")]
    public string? CompanyName { get; set; }

    [JsonProperty("isChild")]
    public bool IsChild { get; set; }

    public List<string> Validate(UserOrgTreeRoot other)
    {
        var results = new List<string>()
        {
            ValidationHelpers.AreEqual(this.OrganizationID.ToStringOrEmpty(), other.OrganizationID.ToStringOrEmpty(),
                "OrganizationID"),
            ValidationHelpers.AreEqual(this.OrganizationTypeId.ToStringOrEmpty(),
                other.OrganizationTypeId.ToStringOrEmpty(),
                "OrganizationTypeId"),
            ValidationHelpers.AreEqual(this.OrganizationName.ToStringOrEmpty(),
                other.OrganizationName.ToStringOrEmpty(),
                "OrganizationName"),
            ValidationHelpers.AreEqual(this.CompanyID.ToStringOrEmpty(), other.CompanyID.ToStringOrEmpty(),
                "CompanyID"),
            ValidationHelpers.AreEqual(this.CompanyName.ToStringOrEmpty(), other.CompanyName.ToStringOrEmpty(),
                "CompanyName"),
            ValidationHelpers.AreEqual(this.IsChild.ToStringOrEmpty(), other.IsChild.ToStringOrEmpty(),
                "IsChild"),
        };

        return results.Where(i => i != string.Empty).ToList();
    }
}
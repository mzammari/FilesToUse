﻿using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using Utilities.ObjectExtensions;
using Utilities.Validation;


namespace SmartSecurityTestAutomation.Services.Orgs;

public class Hierarchy
{
    [JsonPropertyName("parentHierarchy")]
    public int ParentHierarchy { get; set; }

    [JsonPropertyName("parentId")]
    public int ParentId { get; set; }

    [JsonPropertyName("parentName")]
    public string ParentName { get; set; }

    [JsonPropertyName("childHierarchy")]
    public int ChildHierarchy { get; set; }

    private string _childId = null!;

    [JsonPropertyName("childId")]
    public string ChildId
    {
        get => _childId;
        set => _childId = value.Trim();
    }

    [JsonPropertyName("childName")]
    public string ChildName { get; set; }

    public List<string> Validate(Hierarchy other)
    {
        var overrideMessage = $" for ChildId: {_childId.Trim()}";
        var results = new List<string>()
        {
            ValidationHelpers.AreEqual(this.ParentHierarchy.ToStringOrEmpty(), other.ParentHierarchy.ToStringOrEmpty(),
                "ParentHierarchy",overrideMessage),
            ValidationHelpers.AreEqual(this.ParentId.ToStringOrEmpty(), other.ParentId.ToStringOrEmpty(), "ParentId",overrideMessage),
            ValidationHelpers.AreEqual(this.ParentName.ToStringOrEmpty(), other.ParentName.ToStringOrEmpty(),
                "ParentName",overrideMessage),
            ValidationHelpers.AreEqual(this.ChildHierarchy.ToStringOrEmpty(), other.ChildHierarchy.ToStringOrEmpty(),
                "ChildHierarchy",overrideMessage),
            ValidationHelpers.AreEqual(this.ChildId.ToStringOrEmpty(), other.ChildId.ToStringOrEmpty(), "ChildId",overrideMessage),
            ValidationHelpers.AreEqual(this.ChildName.ToStringOrEmpty(), other.ChildName.ToStringOrEmpty(),
                "ChildName",overrideMessage),
        };

        return results.Where(i => i != string.Empty).ToList();
    }
}

public class OrgTreeHierarchy
{
    [JsonPropertyName("hierarchy")]
    public List<Hierarchy> Hierarchy { get; set; }
}
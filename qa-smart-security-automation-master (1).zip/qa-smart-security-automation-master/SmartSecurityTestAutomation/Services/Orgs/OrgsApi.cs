﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using AutomationCoreLite.Reporting;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using SeleniumExtras.WaitHelpers;
using SmartSecurityTestAutomation.Enums;
using SmartSecurityTestAutomation.Models;
using SmartSecurityTestAutomation.Services.Applications;
using SmartSecurityTestAutomation.Services.Home;
using SmartSecurityTestAutomation.Services.Users;
using SmartSecurityTestAutomation.Tests;
using Utilities.HttpUtility;
using Utilities.ObjectExtensions;

namespace SmartSecurityTestAutomation.Services.Orgs;

public class OrgsApi : MasterApi
{
    private const  string  OrgsResource      = "/orgs";
    private const  string  HierarchyResource = "/hierarchy";
    private const  string  FullOrgTreeRoot   = "/full-org-tree-root";
    private const  string  FullTree          = "/full-tree";
    
    private readonly UserRepository _userRepository =
        new(GlobalTestVariables.Configuration!["SmartSecurity:DatabaseServer"]!,
            GlobalTestVariables.Configuration["SmartSecurity:DatabaseName"]!);

    private readonly ApplicationRepository _applicationRepository =
        new(GlobalTestVariables.Configuration["SmartSecurity:DatabaseServer"]!,
            GlobalTestVariables.Configuration["SmartSecurity:DatabaseName"]!);

    private static readonly string            _baseUri = GlobalTestVariables.Configuration["SmartSecurity:BaseUri"]!;
    private readonly        NetworkCredential _testUserCredential;
    private readonly SecurityUser _testUser;
    private readonly        List<HomeDataDb>  _homeDataDb;

    public OrgsApi()
    {
        var homeDb = new HomeRepository(GlobalTestVariables.Configuration!["Home:DatabaseServer"]!,
            GlobalTestVariables.Configuration["Home:DataBaseName"]!);
        _homeDataDb = homeDb.GetHomeData().ToList();
        _testUser = GlobalTestVariables.Users!.FirstOrDefault(x => x.Access.Equals("Limited"));
        _testUserCredential = new NetworkCredential(_testUser!.UserName,
            _testUser.Creds);
    }

    #region API Call

    private static HttpResponse GetOrgs() => GetSimpleRequest($"{_baseUri}{OrgsResource}");

    private static HttpResponse GetFullOrgTreeRoot() =>
        GetSimpleRequest($"{_baseUri}{OrgsResource}{FullOrgTreeRoot}");

    private static HttpResponse GetFullTree() =>
        GetSimpleRequest($"{_baseUri}{OrgsResource}{FullTree}");

    private static HttpResponse GetOrgNameByObjectIdAndHierarchyType(string hierarchyType, string id) =>
        GetSimpleRequest(
            $"{GlobalTestVariables.Configuration!["SmartSecurity:BaseUri"]}{OrgsResource}/{hierarchyType}/{id}");

    private static HttpResponse GetOrgTree(Dictionary<string, string?> parameters = null!) => GetSimpleRequest(
        RequestBuilder.BuildRequestWithParameters(
            $"{GlobalTestVariables.Configuration!["SmartSecurity:BaseUri"]}{OrgsResource}{HierarchyResource}",
            parameters));

    #endregion API Call

    #region Test Methods

    /// <summary>
    /// Test sending 'GET' request for /orgs endpoint.
    /// Manual Estimated Execution Time: 0:01:00
    /// </summary>
    public void TestGetOrgs()
    {
        Steps.AddTestStep("Test sending 'GET' request for /orgs endpoint.", "System should respond with a (200) OK");
        var response = GetOrgs();
        if (!HPGWarn.AreEqual("(200) OK", response.Status, field: "Response Status Code")) return;
        
        var result = JsonConvert.DeserializeObject<List<GeneralIdNameResponse>>(response.Response)!
            .FirstOrDefault();

        HPGWarn.AreEqual("1", result!.Id, field: "Id");
        HPGWarn.AreEqual("HealthTrust", result.Name, field: "Name");
    }

    /// <summary>
    ///Test sending 'GET' request for /orgs/&lt;Hierarchy Type&gt;/&lt;ID&gt; endpoint.
    /// Manual Estimated Execution Time: 0:05:00
    /// </summary>
    public void TestGetOrgName()
    {
        Steps.AddTestStep("Test sending 'GET' request for /orgs/<Hierarchy Type>/<ID> endpoint.",
            "System should respond accordingly.");
        var testHomeData = _homeDataDb.Where(i => i.IsActive).PickRandomList(3);

        //company
        TestGetOrgNameByLevel(HomeHierarchyType.Company, testHomeData);

        //Group
        TestGetOrgNameByLevel(HomeHierarchyType.Group, testHomeData);

        //Division
        TestGetOrgNameByLevel(HomeHierarchyType.Division, testHomeData);

        //Market
        TestGetOrgNameByLevel(HomeHierarchyType.Market, testHomeData);

        //Facility
        TestGetOrgNameByLevel(HomeHierarchyType.Facility, testHomeData);
    }

    /// <summary>
    /// a method to send 'GET' request to an API endpoint based on hierarchy type.
    /// </summary>
    /// <param name="hierarchyType"></param>
    /// <param name="testHomeData"></param>
    /// <exception cref="ArgumentOutOfRangeException"></exception>
    private void TestGetOrgNameByLevel(HomeHierarchyType hierarchyType, List<HomeDataDb> testHomeData)
    {
        foreach (var testMember in testHomeData)
        {
            string testId;
            string testName;
            string type;
            string expectedResponse = OkResponse;
            switch (hierarchyType)
            {
                case HomeHierarchyType.Company:
                    type     = "1";
                    testId   = testMember.CompanyId.ToString();
                    testName = testMember.CompanyName;
                    break;
                case HomeHierarchyType.Group:
                    type     = "2";
                    testId   = testMember.GroupId.ToString();
                    testName = testMember.GroupName;
                    break;
                case HomeHierarchyType.Division:
                    type     = "3";
                    testId   = testMember.DivisionID.ToString();
                    testName = testMember.DivisionName;
                    break;
                case HomeHierarchyType.Market:
                    type     = "4";
                    testId   = testMember.MarketId.ToString();
                    testName = testMember.MarketName;
                    break;
                case HomeHierarchyType.Facility:
                    type     = "5";
                    testId   = testMember.COID;
                    testName = $"{testMember.CompanyName} - {testMember.Name}";
                    break;
                default:
                    throw new ArgumentOutOfRangeException(nameof(hierarchyType), hierarchyType,
                        "Unknown Hierarchy Type!");
            }

            if (testId.ToStringOrEmpty().Equals(string.Empty))
                expectedResponse = NotFoundResponse;
            Steps.AddTestStep(
                $"Sending 'GET' request to /orgs/{type}/{testId} for {hierarchyType} level scenario.",
                $"System should respond with a {expectedResponse} and '{testName}' in the response Body");
            var response =
                GetOrgNameByObjectIdAndHierarchyType(type, testId);

            if (HPGWarn.AreEqual(expectedResponse, response.Status, field: "Response Status Code") && expectedResponse.Equals(OkResponse))
            {
                HPGWarn.AreEqual(testName.Trim(), response.Response.Trim(), field: "Response Body");
            }
        }
    }

    /// <summary>
    /// Test sending 'GET' request for /orgs/&lt;Hierarchy Type&gt;/&lt;ID&gt; with bad or null values.
    /// Manual Estimated Execution Time: 0:05:00
    /// </summary>
    public void TestGetOrgNameBadRequest()
    {
        Steps.AddTestStep("Test sending 'GET' request for /orgs/<Hierarchy Type>/<ID> with bad or null values.",
            "Systems should respond accordingly.");

        var scenarios = new List<string>()
        {
            "Null Hierarchy Type", "Null Id", "Null Hierarchy Type and Id", "Alpha Hierarchy Type", "Alpha Id",
            "Alpha Hierarchy Type and Id", "Non-existing Hierarchy Type", "Non-existing ID",
            "Non-existing Hierarchy Type and Id"
        };

        foreach (var scenario in scenarios)
        {
            var hierarchyType = string.Empty;
            var id            = string.Empty;
            var statusCode    = string.Empty;
            var errorMessage  = string.Empty;

            switch (scenario)
            {
                case "Null Hierarchy Type":
                    hierarchyType = string.Empty;
                    id            = "1";
                    statusCode    = "(404) NotFound";
                    break;
                case "Null Id":
                    hierarchyType = "1";
                    id            = string.Empty;
                    statusCode    = "(404) NotFound";
                    break;
                case "Null Hierarchy Type and Id":
                    hierarchyType = string.Empty;
                    id            = string.Empty;
                    statusCode    = "(404) NotFound";
                    break;
                case "Alpha Hierarchy Type":
                    hierarchyType = "abc";
                    id            = "1";
                    statusCode    = "(400) BadRequest";
                    errorMessage  = $"The value '{hierarchyType}' is not valid.";
                    break;
                case "Alpha Id":
                    hierarchyType = "1";
                    id            = "abc";
                    statusCode    = "(200) OK";
                    break;
                case "Alpha Hierarchy Type and Id":
                    hierarchyType = "abc";
                    id            = "abc";
                    statusCode    = "(400) BadRequest";
                    errorMessage  = $"The value '{hierarchyType}' is not valid.";
                    break;
                case "Non-existing Hierarchy Type":
                    hierarchyType = "10";
                    id            = "1";
                    statusCode    = "(200) OK";
                    break;
                case "Non-existing ID":
                    hierarchyType = "1";
                    id            = "99999";
                    statusCode    = "(200) OK";
                    break;
                case "Non-existing Hierarchy Type and Id":
                    hierarchyType = "10";
                    id            = "99999";
                    statusCode    = "(200) OK";
                    break;
            }

            Steps.AddTestStep($"Sending 'GET' request to /orgs/{hierarchyType}/{id} for '{scenario}' scenario.",
                $"System should respond '{statusCode}'.");
            var response = GetOrgNameByObjectIdAndHierarchyType(hierarchyType, id);
            if (!HPGWarn.AreEqual(statusCode, response.Status, field: "Response Status Code")) continue;
            
            if (!errorMessage.Equals(string.Empty))
            {
                HPGWarn.Contains(response.Response, errorMessage, field: "Response Error");
            }

            if (!response.Status.Equals("(200) OK")) continue;
            var results = JsonConvert.DeserializeObject<List<GeneralIdNameResponse>>(response.Response);
            HPGWarn.True(results!.IsNullOrEmpty(), field: "Empty response array.");
        }
    }

    /// <summary>
    ///Test sending 'GET' request to /orgs/hierarchy endpoint.
    /// Manual Estimated Execution Time: 0:10:00
    /// </summary>
    public void TestGetOrgTree()
    {
        Steps.AddTestStep("Test sending 'GET' request to /orgs/hierarchy endpoint.",
            "System should respond accordingly.");
        var testHomeData = _homeDataDb.Where(i => i.IsActive && i.OrganizationID.Equals("1"));

        TestGetOrgTreeByLevel(HomeHierarchyType.Company, testHomeData);
        TestGetOrgTreeByLevel(HomeHierarchyType.Group, testHomeData);
        TestGetOrgTreeByLevel(HomeHierarchyType.Division, testHomeData);
        TestGetOrgTreeByLevel(HomeHierarchyType.Market, testHomeData);
        TestGetOrgTreeByLevel(HomeHierarchyType.Facility, testHomeData);
    }

    /// <summary>
    /// Sends a 'GET' request and validates the list of children based on hierarchy type and parent id
    /// </summary>
    /// <param name="homeHierarchyType"></param>
    /// <param name="testHomeData"></param>
    /// <exception cref="ArgumentOutOfRangeException"></exception>
    private void TestGetOrgTreeByLevel(HomeHierarchyType homeHierarchyType, IEnumerable<HomeDataDb> testHomeData)
    {
        //Picks a random record.
        var testSample = testHomeData.PickRandom();
        var homeDb = new HomeRepository(GlobalTestVariables.Configuration!["Home:DatabaseServer"]!,
            GlobalTestVariables.Configuration["Home:DataBaseName"]!);
        List<Hierarchy>? expectedList = null;
        string?         hierarchyType;
        string          parentId;

        //Gets the expected data base on the sample record and hierarchy type.
        switch (homeHierarchyType)
        {
            case HomeHierarchyType.Company:
                expectedList  = homeDb.GetOrgTreeByLevel(homeHierarchyType, testSample.CompanyId).ToList();
                hierarchyType = "1";
                parentId      = testSample.CompanyId;
                break;
            case HomeHierarchyType.Group:
                expectedList  = homeDb.GetOrgTreeByLevel(homeHierarchyType, testSample.GroupId).ToList();
                hierarchyType = "2";
                parentId      = testSample.GroupId;
                break;
            case HomeHierarchyType.Division:
                expectedList  = homeDb.GetOrgTreeByLevel(homeHierarchyType, testSample.DivisionID).ToList();
                hierarchyType = "3";
                parentId      = testSample.DivisionID;
                break;
            case HomeHierarchyType.Market:
                expectedList  = homeDb.GetOrgTreeByLevel(homeHierarchyType, testSample.MarketId).ToList();
                hierarchyType = "4";
                parentId      = testSample.MarketId;
                break;
            case HomeHierarchyType.Facility:
                hierarchyType = "5";
                parentId      = testSample.MarketId;
                break;
            default:
                throw new ArgumentOutOfRangeException(nameof(homeHierarchyType), homeHierarchyType,
                    $"Unknown Hierarchy Type");
        }


        Steps.AddTestStep(
            $"Sending 'GET' request at the {homeHierarchyType} level with the following query parameters: HierarchyType: '{hierarchyType}' ParentId: '{parentId}'.",
            "System should respond with a (200) OK.");

        var query = new Dictionary<string, string?>()
        {
            { "ParentId", parentId },
            { "HierarchyType", hierarchyType },
            { "OrgId", "1" }
        };

        //sends the request
        var response = GetOrgTree(query);

        if (!HPGWarn.AreEqual("(200) OK", response.Status)) return;

        if (homeHierarchyType.Equals(HomeHierarchyType.Facility))
        {
            var actualList = JsonConvert.DeserializeObject<OrgTreeHierarchy>(response.Response);
            HPGWarn.True(actualList!.Hierarchy.IsNullOrEmpty(), field: "Empty array list.");
        }
        else
        {
            var actualList = JsonConvert.DeserializeObject<OrgTreeHierarchy>(response.Response);
            ValidateOrgTreeList(expectedList!, actualList!.Hierarchy);
        }
    }

    /// <summary>
    /// Test sending 'GET' request to /orgs/Hierarchy endpoint with Bad or null values.
    /// Manual Estimated Execution Time: 0:05:00
    /// </summary>
    public void TestGetOrgTreeBadRequest()
    {
        //Note: OrgId will be refactored out due to it not being used in HOME API correctly. User story TBD.
        Steps.AddTestStep("Test sending 'GET' request to /orgs/Hierarchy endpoint with Bad or null values.",
            "System should respond with a 400 Bad Request or an empty array.");
        
        //null hierarchy Type
        string  parentId      = "1";
        string? hierarchyType = string.Empty;
        GetOrgTreeBadRequestByScenario(hierarchyType, parentId, "null hierarchy Type", BadRequestResponse);

        //null parent id
        parentId      = string.Empty;
        hierarchyType = "1";
        GetOrgTreeBadRequestByScenario(hierarchyType, parentId, "null parent id", BadRequestResponse);

        //null parent id and hierarchy Type
        parentId      = string.Empty;
        hierarchyType = string.Empty;
        GetOrgTreeBadRequestByScenario(hierarchyType, parentId, "null parent id and hierarchy Type",
            BadRequestResponse);

        //alpha hierarchy Type
        parentId      = "1";
        hierarchyType = "abc";
        GetOrgTreeBadRequestByScenario(hierarchyType, parentId, "alpha hierarchy Type", BadRequestResponse);

        //alpha parent id
        parentId      = "abc";
        hierarchyType = "1";
        GetOrgTreeBadRequestByScenario(hierarchyType, parentId, "alpha parent id", BadRequestResponse);

        //alpha parent id and hierarchy Type
        parentId      = "abc";
        hierarchyType = "abc";
        GetOrgTreeBadRequestByScenario(hierarchyType, parentId, "alpha parent id and hierarchy Type",
            BadRequestResponse);

        //non-existent hierarchy Type
        parentId      = "1";
        hierarchyType = "8";
        GetOrgTreeBadRequestByScenario(hierarchyType, parentId, "non-existent hierarchy Type", BadRequestResponse);

        //non-existent parent id
        parentId      = "99999";
        hierarchyType = "1";
        GetOrgTreeBadRequestByScenario(hierarchyType, parentId, "non-existent parent id", OkResponse);

        //non-existent parent id and hierarchy Type
        parentId      = "99999";
        hierarchyType = "8";
        GetOrgTreeBadRequestByScenario(hierarchyType, parentId, "non-existent parent id and hierarchy Type",
            BadRequestResponse);
    }

    /// <summary>
    /// Sends 'GET' request with bad values based on the scenario and validates the response. 
    /// </summary>
    /// <param name="hierarchyType"></param>
    /// <param name="parentId"></param>
    /// <param name="scenario"></param>
    /// <param name="errorResponse"></param>
    private void GetOrgTreeBadRequestByScenario(string? hierarchyType, string parentId, string scenario,
        string errorResponse)
    {
        var hierarchyList = new List<string>
        {
            "null hierarchy Type", "null parent id and hierarchy Type", "alpha hierarchy Type",
            "alpha parent id and hierarchy Type", "non-existent hierarchy Type",
            "non-existent parent id and hierarchy Type"
        };
        var parentIdList = new List<string>
        {
            "null parent id", "null parent id and hierarchy Type", "alpha parent id",
            "alpha parent id and hierarchy Type"
        };

        const string genericError      = "The value '{0}' is invalid.";
        const string abcErrorHierarchy = "The value '{0}' is not valid for HierarchyType.";
        const string abcErrorParent    = "The value '{0}' is not valid for ParentId.";

        Steps.AddTestStep(
            $"Sending 'GET' request to /orgs/Hierarchy endpoint with the following parameters: HierarchyType: '{hierarchyType}' Parent ID: '{parentId}' for scenario: '{scenario}'.",
            $"System should respond with a {errorResponse}.");

        var query = new Dictionary<string, string?>
        {
            { "ParentId", parentId },
            { "HierarchyType", hierarchyType },
            { "OrgId", "1" }
        };

        var response = GetOrgTree(query);

        if (HPGWarn.AreEqual(errorResponse, response.Status))
        {
            if (errorResponse.Equals("(400) BadRequest"))
            {
                var errorResult = JsonConvert.DeserializeObject<BadRequestReponse>(response.Response);
                if (hierarchyList.Contains(scenario))
                {
                    var expectedError = scenario.Contains("alpha")
                        ? string.Format(abcErrorHierarchy, hierarchyType)
                        : string.Format(genericError, hierarchyType);
                    HPGWarn.AreEqual(expectedError,
                        errorResult.Errors.HierarchyType.First().ToStringOrEmpty(), field: "Hierarchy Error Response");
                }

                if (parentIdList.Contains(scenario))
                {
                    var expectedError = scenario.Contains("alpha")
                        ? string.Format(abcErrorParent, parentId)
                        : string.Format(genericError, parentId);
                    HPGWarn.AreEqual(expectedError,
                        errorResult.Errors.ParentId.First().ToStringOrEmpty(), field: "Hierarchy Error Response");
                }
            }
            else
            {
                var result = JsonConvert.DeserializeObject<OrgTreeHierarchy>(response.Response);
                HPGWarn.True(result.Hierarchy.IsNullOrEmpty(), field: "Empty array list.");
            }
        }
    }

    public void TestGetFullOrgTreeRoot()
    {
        var securityUser = GlobalTestVariables.Configuration!["SecurityUser:UserName"];
        Steps.AddTestStep($"Test sending 'GET' request to '{OrgsResource}{FullOrgTreeRoot}'.",
            $"System should respond with a {OkResponse}.");
        //reset auth token to test user
        if (!GlobalTestVariables.TestEnvironment!.Equals("prod"))
        {
            //GetAuthToken(_testUserCredential, true);
            GetPingToken(_testUser, true);
        }
            

        var application = _applicationRepository.GetApplicationsDb()
            .FirstOrDefault(i => i.Name.Equals("SMART - Security", StringComparison.CurrentCultureIgnoreCase));

        //get test user security span of control
        var user = _userRepository.GetAllUserSocDb().Where(i =>
            i.Username.Equals(securityUser, StringComparison.CurrentCultureIgnoreCase)
            && i.ApplicationId.ToStringOrEmpty().Equals(application!.ApiKey.ToStringOrEmpty())
            && !i.IsDeleted);

        //format span of control into full org tree class object
        var expectedUserOrgList = FormatUserOrgTreeRoot(user);

        Steps.AddTestStep(
            $"Sending 'GET' request to '{OrgsResource}{FullOrgTreeRoot}' with {securityUser} credentials.",
            $"System should respond with a {OkResponse}.");

        //send request
        var response = GetFullOrgTreeRoot();

        //validate response
        if (!HPGWarn.AreEqual(OkResponse, response.Status, field: ResponseStatusField)) return;
        var actualUserOrgList = JsonConvert.DeserializeObject<List<UserOrgTreeRoot>>(response.Response);
        ValidateFullOrgTreeRootList(expectedUserOrgList, actualUserOrgList);

        //reset auth token
        GetPingToken(resetAuthToken: true);
    }

    public void TestGetFullTree()
    {
        var securityUser = GlobalTestVariables.Users!.FirstOrDefault(i => i.Access.Equals("Limited"));
        Steps.AddTestStep(
            $"Test sending 'GET' request to {OrgsResource}{FullTree} api end point with test user {securityUser!.UserName} credentials.",
            $"System should respond with a {OkResponse}");
        //reset auth token to test user
        if (!GlobalTestVariables.TestEnvironment!.Equals("prod"))
            GetPingToken(_testUser, true);

        var application = _applicationRepository.GetApplicationsDb()
            .FirstOrDefault(i => i.Name.Equals("SMART - Security", StringComparison.CurrentCultureIgnoreCase));

        //get test user security span of control
        var user = _userRepository.GetAllUserSocDb().Where(i =>
            i.Username.Equals(securityUser.UserName, StringComparison.CurrentCultureIgnoreCase)
            && i.ApplicationId.ToStringOrEmpty().Equals(application.ApiKey.ToStringOrEmpty())
            && !i.IsDeleted);

        //format span of control into full tree class object
        var expectedUserOrgList = FormatUserOrgTree(user).ToList();

        //send request
        Steps.AddTestStep("Sending 'GET' Request.", $"System should respond with a {OkResponse}");
        var response = GetFullTree();

        //validate response
        if (!HPGWarn.AreEqual(OkResponse, response.Status, field: ResponseStatusField)) return;
        var actualUserOrgList = JsonConvert.DeserializeObject<List<UserOrgTree>>(response.Response);
        ValidateUserOrgTree(expectedUserOrgList, actualUserOrgList);
    }

    #endregion Test Methods

    #region Validations

    private void ValidateOrgTreeList(List<Hierarchy>? expectedList, List<Hierarchy> actualList)
    {
        Steps.AddTestStep("Validating expected list matches actual list.", "Should both match");
        var actualDictionary = actualList.ToDictionary(i => i.ChildId, j => j);
        foreach (var expected in expectedList!)
        {
            if (!actualDictionary.TryGetValue(expected.ChildId, out var actual))
                HPGWarn.Warn(
                    $"Unable to find ChildId: '{expected.ChildId}' and Child Name: '{expected.ChildName}' in actual list!");
            else
            {
                HPGWarn.WarnRange(expected.Validate(actual));
            }
        }

        Steps.AddTestStep("Validating actual list matches expected list.", "Should both match");
        var expectedDictionary = expectedList.ToDictionary(i => i.ChildId, j => j);
        foreach (var actual in actualList)
        {
            if (!expectedDictionary.TryGetValue(actual.ChildId, out var expected))
                HPGWarn.Warn(
                    $"Unable to find ChildId: '{actual.ChildId}' and Child Name: '{actual.ChildName}' in expected list!");
            else
            {
                HPGWarn.WarnRange(actual.Validate(expected));
            }
        }
    }

    private void ValidateFullOrgTreeRootList(IEnumerable<UserOrgTreeRoot> expectedUserOrgList,
        List<UserOrgTreeRoot>? actualUserOrgList)
    {
        Steps.AddTestStep("Validating expected list is in actual list.", "Expected should match actual");
        var actualDictionary = actualUserOrgList!.ToDictionary(root => root.OrganizationID!);
        foreach (var expected in expectedUserOrgList)
        {
            if (!actualDictionary.TryGetValue(expected.OrganizationID!, out var actual))
                HPGWarn.Warn(
                    $"Unable to find Org ID: '{expected.OrganizationID}' Hierarchy Type: '{expected.OrganizationTypeId}' in Actual!");
            else
            {
                HPGWarn.WarnRange(expected.Validate(actual));
            }
        }

        Steps.AddTestStep("Validating actual list is in expected list.", "Actual should match expected");
        var expectedDictionary = actualUserOrgList!.ToDictionary(root => root.OrganizationID!);
        foreach (var actual in actualUserOrgList!)
        {
            if (!expectedDictionary.TryGetValue(actual.OrganizationID!, out var expected))
                HPGWarn.Warn(
                    $"Unable to find Org ID: '{actual.OrganizationID}' Hierarchy Type: '{actual.OrganizationTypeId}' in Expected!");
            else
            {
                HPGWarn.WarnRange(actual.Validate(expected));
            }
        }
    }

    private void ValidateUserOrgTree(List<UserOrgTree> expectedUserOrgList, List<UserOrgTree>? actualUserOrgList)
    {
        Steps.AddTestStep("Validating expected list is in actual.", "Expected list is in Actual");
        var actualDictionary = actualUserOrgList!.ToDictionary(i => i.Dn, j => j);
        foreach (var expected in actualUserOrgList!)
        {
            if (!actualDictionary.TryGetValue(expected.Dn, out var actual))
                HPGWarn.Warn($"Expecting DN: '{expected.Dn}' but was not in actual!");
            else
            {
                HPGWarn.WarnRange(expected.Validate(actual));
            }
        }

        Steps.AddTestStep("Validating actual list is in expected.", "Actual list is in expected");
        var expectedDictionary = expectedUserOrgList.ToDictionary(i => i.Dn, j => j);
        foreach (var actual in actualUserOrgList)
        {
            if (!expectedDictionary.TryGetValue(actual.Dn, out var expected))
                HPGWarn.Warn($"Actual DN: '{actual.Dn}' but was not in expected!");
            else
            {
                HPGWarn.WarnRange(actual.Validate(expected));
            }
        }
    }

    #endregion Validations

    #region Helpers

    private static IEnumerable<UserOrgTreeRoot> FormatUserOrgTreeRoot(IEnumerable<UserSocDb> userSocs)
    {
        var homeApi = new HomeService();

        return (from soc in userSocs
            let name = homeApi.GetHomeName(soc.Hierarchy.ToString(), soc.OrgObjectID).Replace("\"", "")
            select new UserOrgTreeRoot()
            {
                OrganizationID     = soc.OrgObjectID,
                OrganizationTypeId = soc.Hierarchy.ToString(),
                CompanyName        = name,
                CompanyID          = 0,
                IsChild            = false,
                OrganizationName   = null
            }).ToList();
    }

    private IEnumerable<UserOrgTree> FormatUserOrgTree(IEnumerable<UserSocDb> userSocs)
    {
        var result = new List<UserOrgTree>();
        foreach (var soc in userSocs)
        {
            var orgObjectId = soc.Hierarchy.ToInt() != 5 ? soc.OrgObjectID.ToInt().ToString() : soc.OrgObjectID;
            var filteredHomeList = soc.Hierarchy switch
            {
                0 => _homeDataDb.Where(i => i.IsActive && i.OrganizationID.Equals(orgObjectId)).ToList(),
                1 => _homeDataDb.Where(i => i.IsActive && i.CompanyId.ToStringOrEmpty().Equals(orgObjectId)).ToList(),
                2 => _homeDataDb.Where(i => i.IsActive && i.GroupId.ToStringOrEmpty().Equals(orgObjectId)).ToList(),
                3 => _homeDataDb.Where(i => i.IsActive && i.DivisionID.ToStringOrEmpty().Equals(orgObjectId)).ToList(),
                4 => _homeDataDb.Where(i => i.IsActive && i.MarketId.ToStringOrEmpty().Equals(orgObjectId)).ToList(),
                _ => _homeDataDb.Where(i => i.IsActive && i.COID.ToStringOrEmpty().Equals(orgObjectId)).ToList()
            };

            var       startingHierarchy = soc.Hierarchy.ToInt() == 5 ? 5 : soc.Hierarchy.ToInt();
            const int maxHierarchy      = 6;
            for (var i = startingHierarchy; i < maxHierarchy; i++)
            {
                var formattedHierarchy = i switch
                {
                    1 => filteredHomeList.Select(d => new { d.OrganizationID, d.CompanyId, Label = d.CompanyName })
                        .Distinct().Select(i => new UserOrgTree
                        {
                            Id     = i.CompanyId, Label = i.Label,
                            TypeId = "1",
                            Dn     = $"{i.OrganizationID}/{i.CompanyId}"
                        }),
                    2 => filteredHomeList
                        .Select(d => new { d.OrganizationID, d.CompanyId, d.GroupId, Label = d.GroupName }).Distinct()
                        .Select(i => new UserOrgTree
                        {
                            Id = i.GroupId, Label = i.Label, TypeId = "2",
                            Dn = $"{i.OrganizationID}/{i.CompanyId}/{i.GroupId}"
                        }),
                    3 => filteredHomeList
                        .Select(d => new
                            { d.OrganizationID, d.CompanyId, d.GroupId, d.DivisionID, Label = d.DivisionName })
                        .Distinct().Select(i => new UserOrgTree
                        {
                            Id = i.DivisionID, Label = i.Label, TypeId = "3",
                            Dn = $"{i.OrganizationID}/{i.CompanyId}/{i.GroupId}/{i.DivisionID}"
                        }),
                    4 => filteredHomeList
                        .Select(d => new
                        {
                            d.OrganizationID, d.CompanyId, d.GroupId, d.DivisionID, d.MarketId, Label = d.MarketName
                        }).Distinct().Select(i => new UserOrgTree
                        {
                            Id = i.MarketId, Label = i.Label, TypeId = "4",
                            Dn = $"{i.OrganizationID}/{i.CompanyId}/{i.GroupId}/{i.DivisionID}/{i.MarketId}"
                        }),
                    5 => filteredHomeList
                        .Select(d => new
                        {
                            d.OrganizationID, d.CompanyId, d.GroupId, d.DivisionID, d.MarketId, d.COID, Label = d.Name
                        }).Distinct().Select(i => new UserOrgTree
                        {
                            Id = i.COID, Label = i.Label, TypeId = "5",
                            Dn = $"{i.OrganizationID}/{i.CompanyId}/{i.GroupId}/{i.DivisionID}/{i.MarketId}/{i.COID}"
                        }),
                    _ => throw new ArgumentOutOfRangeException(nameof(userSocs), "Went to high!")
                };
                result.AddRange(formattedHierarchy);
            }
        }

        return result;
    }

    #endregion Helpers
}
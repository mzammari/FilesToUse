﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace SmartSecurityTestAutomation.Services.SelfProvision;

public class SelfProvisionRequestDetailsResponse
{
	[JsonPropertyName("selfProvision")]
	public SelfProvisionRequestDetails SelfProvision { get; set; }

	[JsonPropertyName("selfProvisionDetails")]
	public List<SelfProvisionDetail> SelfProvisionDetails { get; set; }
}

public class SelfProvisionRequestDetails
{
	[JsonPropertyName("id")]
	public int Id { get; set; }

	[JsonPropertyName("firstName")]
	public string FirstName { get; set; }

	[JsonPropertyName("lastName")]
	public string LastName { get; set; }

	[JsonPropertyName("email")]
	public string Email { get; set; }

	[JsonPropertyName("statusTypeId")]
	public string StatusTypeId { get; set; }

	[JsonPropertyName("vproStatus")]
	public string VproStatus { get; set; }

	[JsonPropertyName("vproUserEmailId")]
	public string VproUserEmailId { get; set; }

	[JsonPropertyName("correlationId")]
	public Guid CorrelationId { get; set; }

	[JsonPropertyName("createdOn")]
	public DateTimeOffset CreatedOn { get; set; }

	[JsonPropertyName("createdBy")]
	public string CreatedBy { get; set; }

	[JsonPropertyName("updatedOn")]
	public DateTimeOffset UpdatedOn { get; set; }

	[JsonPropertyName("updatedBy")]
	public string UpdatedBy { get; set; }

	[JsonPropertyName("totalCount")]
	public int TotalCount { get; set; }
}

public class SelfProvisionDetail
{
	[JsonPropertyName("id")]
	public int Id { get; set; }

	[JsonPropertyName("selfProvisionId")]
	public int SelfProvisionId { get; set; }

	[JsonPropertyName("statusTypeId")]
	public int StatusTypeId { get; set; }

	[JsonPropertyName("description")]
	public string Description { get; set; }

	[JsonPropertyName("recommendation")]
	public string Recommendation { get; set; }

	[JsonPropertyName("statusType")]
	public string StatusType { get; set; }

	[JsonPropertyName("actionDate")]
	public DateTimeOffset ActionDate { get; set; }

	[JsonPropertyName("approve")]
	public bool Approve { get; set; }

	[JsonPropertyName("deny")]
	public bool Deny { get; set; }
}

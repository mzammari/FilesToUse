﻿using SmartSecurityTestAutomation.Services.Users;
using SmartSecurityTestAutomation.Services.SelfProvision;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Utilities.DatabaseUtility;
using Utilities.ObjectExtensions;

namespace SmartSecurityTestAutomation.Services.SelfProvision;

public class SelfProvisionRepository
{
	private readonly string _server;
	private readonly string _dbName;

	public SelfProvisionRepository(string server, string dbName)
	{
		_server = server;
		_dbName = dbName;
	}

	/// <summary
	//  Retrieves the Security Admin UserKey from the database.
	/// </summary>
	/// <returns>The UserKey as a string if found; otherwise, throws an exception.</returns>
	/// <exception cref="Exception">Thrown when the Security Admin UserKey cannot be retrieved or is not found in the database.</exception>
	public string GetSecurityAdminUserKey()
	{
		try
		{
			// Initialize the database connection
			var dbs = new DbSql(_server, _dbName);

			// Execute the query to get the Security Admin UserKey
			var result = dbs.GetRecordsIntoObject<string>(SelectSecurityAdmin).FirstOrDefault();

			// Return the UserKey as a string if found, otherwise throw an exception
			if (string.IsNullOrEmpty(result))
				throw new Exception("Security Admin UserKey not found in the database.");

			return result;
		}
		catch (Exception e)
		{
			Console.WriteLine(e);
			throw new Exception($"Unable to retrieve Security Admin (HTNASVCTSTAUT51) UserKey!\r\nError Message: {e.Message}");
		}
	}

	public SelfProvisionRequest GetRandomSelfProvisionRequestRecord()
	{
		try
		{
			var dbs = new DbSql(_server, _dbName);
			var result = dbs.GetRecordsIntoObject<SelfProvisionRequest>(SelectSelfProvisionRequest).FirstOrDefault();
			return result ?? throw new Exception("No Self Provision Request records found in the database.");
		}
		catch (Exception e)
		{
			Console.WriteLine(e);
			throw new Exception($"Unable to retrieve a random Self Provision Request record!\r\nError Message: {e.Message}");
		}
	}

	public ServiceAccountDbDetails GetServiceAcctUserKeySmartAppKeyRoleKeyDetails()
	{
		try
		{
			// Initialize the database connection
			var dbs = new DbSql(_server, _dbName);
			var result = dbs.GetRecordsIntoObject<ServiceAccountDbDetails>(SelectServiceAcctUserKeySmartAppKeyRoleKey).FirstOrDefault();
			return result ?? throw new Exception("Service Account details not found in the database.");
		}
		catch (Exception e)
		{
			Console.WriteLine(e);
			throw new Exception($"Unable to retrieve Service Account (HTNASVCTSTAUT51) UserKey, Smart App Key, and Role Key!\r\nError Message: {e.Message}");
		}
	}

	public SelfProvisionRequestDetails GetSelfProvisionRequestDetailsById(int selfProvisionId)
	{

		try
		{
			var dbs = new DbSql(_server, _dbName);
			var query = $"{SelectSelfProvisionRecord}{selfProvisionId}";
			var result = dbs.GetRecordsIntoObject<SelfProvisionRequestDetails>(query).FirstOrDefault();
			return result ?? throw new Exception("No Self Provision Request records found in the database.");
		}
		catch (Exception e)
		{
			Console.WriteLine(e);
			throw new Exception($"Unable to retrieve a random Self Provision Request record!\r\nError Message: {e.Message}");
		}

	}

	public List<SelfProvisionDetail> GetSelfProvisionFacilityVendorDetails(int selfProvisionId)
	{
		try
		{
			var dbs = new DbSql(_server, _dbName);
			var query = string.Format(SelectSelfProvisionFacilityVendorRecords, selfProvisionId);
			var result = dbs.GetRecordsIntoObject<SelfProvisionDetail>(query).ToList();
			return result;
		}
		catch (Exception e)
		{
			Console.WriteLine(e);
			throw new Exception($"Unable to retrieve Self Provision Facility/Vendor details!\r\nError Message: {e.Message}");
		}
	}




	/// <summary>
	/// Get Test Security Admin User
	/// </summary>
	private const string SelectSecurityAdmin = @"SELECT  U.UserKey FROM [USER] U WHERE U.Username = 'HTNASVCTSTAUT51'";

	/// <summary>
	/// Get Service Account details for Smart App, Role and User Key 
	/// </summary>
	private const string SelectServiceAcctUserKeySmartAppKeyRoleKey = @"SELECT U.Username, U.UserKey, A.ApiKey, R.RoleKey, UR.IsDeleted
FROM [User]     U
JOIN User_Role  UR
  ON U.Id =     UR.UserId
JOIN Role       R
  ON UR.RoleId  = R.ID
JOIN Application A
  ON R.ApplicationId = A.Id
WHERE U.Username  = 'HTNASVCTSTAUT51'
  AND A.Name      = 'SMART - Security'
  AND R.Name      = 'Security - VBO Support (Read Only)'";

	private const string SelectSelfProvisionRequest = @"SELECT TOP 1 SP.Id as SelfProvisionId, SP.FirstName, SP.LastName, SP.Email, SP.StatusTypeId, SP.VPROStatus, SP.VPROUserEmailId
	FROM SelfProvision SP WHERE SP.StatusTypeId = 1 ORDER BY NEWID()";

	private const string SelectSelfProvisionRecord = @"SELECT  SP.Id, SP.FirstName,  SP.LastName,      SP.Email,     SP.StatusTypeId, SP.VPROStatus,
    SP.VPROUserEmailId,   SP.CorrelationId, SP.CreatedOn, SP.CreatedBy FROM SelfProvision SP WHERE SP.Id = ";

	//todo: need to check with ref.HomeHierarchy and filter out COID that are not under the users org SoC
	private const string SelectSelfProvisionFacilityVendorRecords = @"
	SELECT SPF.Id, SPF.SelfProvisionId, SPF.StatusTypeId, 'Facility' AS Description, SPF.OrgObjectID+' - '+SPF.OrgName AS Recommendation, 
	  SPF.StatusTypeId, SPF.CreatedOn AS ActionDate, 
	  CASE 
		  WHEN SPF.StatusTypeId = 3 THEN 'true'
		  WHEN SPF.StatusTypeId = 1 THEN 'false'
		  ELSE 'false'
	  END AS 'Approve', 
	  CASE 
		  WHEN SPF.StatusTypeId = 3 THEN 'false'
		  WHEN SPF.StatusTypeId = 1 THEN 'false'
		  ELSE 'true'
	  END AS 'Deny'
	FROM SelfProvisionFacility SPF
	JOIN SelfProvision SP ON SPF.SelfProvisionId = SP.Id
	WHERE SP.Id = {0}
	UNION ALL
	SELECT SPV.Id, SPV.SelfProvisionId, SPV.StatusTypeId, 'Vendor Affiliation' AS Description, CAST(SPV.VendorId AS VARCHAR(7))+' - '+SPV.VendorName AS Recommendation, 
	  SPV.StatusTypeId, SPV.CreatedOn AS ActionDate, 
	  CASE 
		  WHEN SPV.StatusTypeId = 3 THEN 'true'
		  WHEN SPV.StatusTypeId = 1 THEN 'false'
		  ELSE 'false'
	  END AS 'Approve', 
	  CASE 
		  WHEN SPV.StatusTypeId = 3 THEN 'false'
		  WHEN SPV.StatusTypeId = 1 THEN 'false'
		  ELSE 'true'
	  END AS 'Deny'
	FROM SelfProvisionVendor SPV
	JOIN SelfProvision SP ON SPV.SelfProvisionId = SP.Id
	WHERE SP.Id = {0}
	ORDER BY 4";
}

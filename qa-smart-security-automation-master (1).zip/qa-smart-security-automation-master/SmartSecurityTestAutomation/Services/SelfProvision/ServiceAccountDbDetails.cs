using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartSecurityTestAutomation.Services.SelfProvision;
public class ServiceAccountDbDetails
{
    public string Username { get; set; }
    public Guid UserKey { get; set; }
    public Guid ApiKey { get; set; }
    public Guid RoleKey { get; set; }
    public bool IsDeleted { get; set; }
}

public class  SelfProvisionRequest
{
	public string SelfProvisionId { get; set; }
	public string FirstName { get; set; }
	public string LastName { get; set; }
	public string Email { get; set; }
	public string StatusTypeId { get; set; }
	public string VPROStatus { get; set; }
	public string VPROUserEmailId { get; set; }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace SmartSecurityTestAutomation.Services.SelfProvision;

public class SelfProvisionRequestScope
{
	[JsonPropertyName("statusTypeIds")]
	public List<string>? StatusTypeIds { get; set; }

	[JsonPropertyName("take")]
	public int? Take { get; set; }

	[JsonPropertyName("skip")]
	public int? Skip { get; set; }

	[JsonPropertyName("searchFilter")]
	public string? SearchFilter { get; set; }

	[JsonPropertyName("columnSort")]
	public string? ColumnSort { get; set; }

	[JsonPropertyName("sortOrder")]
	public string? SortOrder { get; set; }
}

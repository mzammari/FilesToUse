﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace SmartSecurityTestAutomation.Services.SelfProvision;

public class IngestResponse
{
	[JsonPropertyName("id")]
	public int Id { get; set; }

	[JsonPropertyName("createdOn")]
	public DateTimeOffset CreatedOn { get; set; }

	[JsonPropertyName("createdBy")]
	public string CreatedBy { get; set; }

	[JsonPropertyName("firstName")]
	public string FirstName { get; set; }

	[JsonPropertyName("lastName")]
	public string LastName { get; set; }

	[JsonPropertyName("email")]
	public string Email { get; set; }

	[JsonPropertyName("statusTypeId")]
	public int StatusTypeId { get; set; }

	[JsonPropertyName("vproStatus")]
	public string VproStatus { get; set; }

	[JsonPropertyName("vproUserEmailId")]
	public string VproUserEmailId { get; set; }

	[JsonPropertyName("correlationId")]
	public Guid CorrelationId { get; set; }

	[JsonPropertyName("facilities")]
	public List<IngestFacility> Facilities { get; set; }

	[JsonPropertyName("vendorAffiliations")]
	public List<IngestVendorAffiliation> VendorAffiliations { get; set; }

	[JsonPropertyName("comments")]
	public string Comments { get; set; }

	[JsonPropertyName("requestType")]
	public string RequestType { get; set; }
}

public class IngestFacility
{
	[JsonPropertyName("coid")]
	public string Coid { get; set; }

	[JsonPropertyName("orgName")]
	public string OrgName { get; set; }

	[JsonPropertyName("statusTypeId")]
	public int StatusTypeId { get; set; }

	[JsonPropertyName("comments")]
	public string Comments { get; set; }
}

public class IngestVendorAffiliation
{
	[JsonPropertyName("vendorName")]
	public string VendorName { get; set; }

	[JsonPropertyName("snv")]
	public string Snv { get; set; }

	[JsonPropertyName("statusTypeId")]
	public int StatusTypeId { get; set; }

	[JsonPropertyName("comments")]
	public string Comments { get; set; }
}

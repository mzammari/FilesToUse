﻿using SmartSecurityTestAutomation.Services.SmartClientUsers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartSecurityTestAutomation.Services.SelfProvision;

/// <summary>
/// Root response model for VendorAdmins API endpoint
/// </summary>
public class VendorAdminsRootResponse
{
	[JsonProperty("vendorAdmins")]
	public List<VendorAdminResponse> VendorAdmins { get; set; }
}

/// <summary>
/// Response model for individual VendorAdmin data
/// </summary>
public class VendorAdminResponse
{
	[JsonProperty("firstName")]
	public string FirstName { get; set; }

	[JsonProperty("lastName")]
	public string LastName { get; set; }

	[JsonProperty("email")]
	public string Email { get; set; }

	[JsonProperty("facilities")]
	public List<VendorAdminFacilityInfo> Facilities { get; set; }
}

/// <summary>
/// Response model for facility information within VendorAdmin response
/// </summary>
public class VendorAdminFacilityInfo
{
	[JsonProperty("coid")]
	public string Coid { get; set; }

	[JsonProperty("orgName")]
	public string OrgName { get; set; }

	[JsonProperty("statusTypeId")]
	public int StatusTypeId { get; set; }

	[JsonProperty("comments")]
	public string Comments { get; set; }
}

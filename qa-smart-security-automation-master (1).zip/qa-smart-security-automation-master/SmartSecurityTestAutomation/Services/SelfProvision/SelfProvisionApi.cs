﻿using Newtonsoft.Json;
using SmartSecurityTestAutomation.Services.Users;
using SmartSecurityTestAutomation.Tests;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilities.HttpUtility;
using Utilities.ObjectExtensions;

namespace SmartSecurityTestAutomation.Services.SelfProvision;


public class SelfProvisionApi : MasterApi
{

	#region Private Variables
	private static readonly string BaseUri = GlobalTestVariables.Configuration["SmartSecurity:BaseUri"]!;
	private static readonly string UserClaimsResource = "/users/claims"; 
	private const string SelfProvisionResource = "/api/SelfProvision";
	private const string PersonalScope = "/personal-scope";
	private const string RequestDetails = "/self-provision-request-details";
	private const string ApprovalRequestAction = "/approval-request-action";
	private readonly SelfProvisionRepository selfServiceRepository = new(GlobalTestVariables.Configuration["SmartSecurity:DatabaseServer"]!,
			GlobalTestVariables.Configuration["SmartSecurity:DatabaseName"]!);
	#endregion Private Variables

	#region API Call
	private static HttpResponse GetSelfServiceRequest(string? endpoint)
	{
		var response = GetSimpleRequest($"{BaseUri}{SelfProvisionResource}{endpoint}");
		return response;
	}

	private static HttpResponse PostSelfServiceRequest(string? endpoint, string? body)
	{
		var response = PostSimpleRequest($"{BaseUri}{SelfProvisionResource}{endpoint}", body);
		return response;
	}
	/// <summary>
	/// Tests the /api/SelfProvision/personal-scope endpoint for various scenarios, including positive and negative cases.
	/// Validates role-based access, input validation, and expected API responses for the personal scope self-provisioning feature.
	/// </summary>
	public void TestSelfProvisionPersonalScope()
	{
		//Declare a dictionary with roles: Security - VBO Request Approver, Security - VBO Support (Read Only)
		var supportRoles = new Dictionary<string, string>
	{
	{ "Security - VBO Request Approver", "D3C2E2C3-1F4C-4D1A-8C5D-0B8E3C6F7A9B" },
	{ "Security - VBO Support (Read Only)", "7F4E2A1B-3C4D-5E6F-7081-92A3B4C5D6E7" }
	};

		foreach (var role in supportRoles)
		{
			Steps.AddTestStep($"Validating Support Role: {role.Value} in the system. Endpoint: personal-scope",
			$"Role: '{role.Key}' should exist in the system.");

			//remove sec admin role & assign read only role to service account 
			Steps.AddTestStep("Reconfiguring Service Account Roles for Self Provisioning Personal Scope Tests", "Removing 'Security - Administrator' role and assigning 'Security - VBO Support (Read Only)' role to the service account.");
			var provisionRequest = GetRandomProvisionRequest();
			AssignSupportRole2ServiceAcct(role.Key, role.Value);

			// Positive scenario: valid request.  
			var positiveRequest = new SelfProvisionRequestScope()
			{
				StatusTypeIds = new List<string> { "1" },
				Take = 10,
				Skip = 0,
				SearchFilter = provisionRequest.FirstName,
				ColumnSort = "firstName",
				SortOrder = "asc"
			};
			var posPayload = JsonConvert.SerializeObject(positiveRequest);
			var posResponse = PostSelfServiceRequest(PersonalScope, posPayload);
			HPGWarn.AreEqual(OkResponse, posResponse.Status, field: ResponseStatusField);
			var formattedPosPayload = JsonConvert.SerializeObject(JsonConvert.DeserializeObject(posPayload), Formatting.Indented);
			Steps.AddTestStep($"Sending 'POST' Positive request to {PersonalScope} API endpoint with the following scenario: Positive - payload: {formattedPosPayload}.",
							$"Systems should respond with a status code: '{posResponse.Status}'.");

			dynamic posBody = JsonConvert.DeserializeObject<dynamic>(posResponse.Response);
			Steps.AddTestStep("Positive Response Body", posResponse.Response);

			HPGWarn.True(posBody.isSecurityVendorAdministrator != null, field: "isSecurityVendorAdministrator");
			HPGWarn.True(posBody.isSecurityVBOSupportReadOnly != null, field: "isSecurityVBOSupportReadOnly");
			if (posBody.selfProvision != null && posBody.selfProvision.Count > 0)
			{
				HPGWarn.True(true, field: "selfProvision[]");
			}



			// Negative scenario: statusTypeIds not in allowed range
			var badStatusTypeRequest = new SelfProvisionRequestScope()
			{
				StatusTypeIds = new List<string> { "8" },
				Take = 10,
				Skip = 0,
				SearchFilter = "Charlie",
				ColumnSort = "firstName",
				SortOrder = "asc"
			};
			var badStatusPayload = JsonConvert.SerializeObject(badStatusTypeRequest);
			var badStatusResponse = PostSelfServiceRequest(PersonalScope, badStatusPayload);
			Steps.AddTestStep($"Sending 'POST' request to {PersonalScope} API endpoint with the following scenario: Bad statusTypeId - payload: {badStatusPayload}.",
			$"Systems should respond with a status code: '{badStatusResponse.Status}'.");

			HPGWarn.AreEqual(BadRequestResponse, badStatusResponse.Status, field: ResponseStatusField);
			Steps.AddTestStep("Bad StatusTypeId Response", badStatusResponse.Response);
			HPGWarn.Contains(badStatusResponse.Response, "StatusTypeId must be between 1 and 4.");

			// Negative scenario: take < 1
			var badTakeRequest = new SelfProvisionRequestScope()
			{
				StatusTypeIds = new List<string> { "1" },
				Take = 0,
				Skip = 0,
				SearchFilter = "Charlie",
				ColumnSort = "firstName",
				SortOrder = "asc"
			};
			var badTakePayload = JsonConvert.SerializeObject(badTakeRequest);
			var badTakeResponse = PostSelfServiceRequest(PersonalScope, badTakePayload);
			Steps.AddTestStep($"Sending 'POST' request to {PersonalScope} API endpoint with the following scenario: Bad Take - payload: {badTakePayload}.",
			$"Systems should respond with a status code: '{badTakeResponse.Status}'.");

			HPGWarn.AreEqual(InternalServerResponse, badTakeResponse.Status, field: ResponseStatusField);
			Steps.AddTestStep("Bad Take Response", badTakeResponse.Response);
			HPGWarn.Contains(badTakeResponse.Response, "The number of rows provided for a FETCH clause must be greater then zero.");

			// Negative scenario: searchFilter not found
			var notFoundRequest = new SelfProvisionRequestScope()
			{
				StatusTypeIds = new List<string> { "1" },
				Take = 10,
				Skip = 0,
				SearchFilter = "Ivan Rakitić",
				ColumnSort = "firstName",
				SortOrder = "asc"
			};
			var notFoundPayload = JsonConvert.SerializeObject(notFoundRequest);
			var notFoundResponse = PostSelfServiceRequest(PersonalScope, notFoundPayload);
			Steps.AddTestStep($"Sending 'POST' request to {PersonalScope} API endpoint with the following scenario: Not Found Request - payload: {notFoundPayload}.",
			$"Systems should respond with a status code: '{notFoundResponse.Status}'.");

			HPGWarn.AreEqual(OkResponse, notFoundResponse.Status, field: ResponseStatusField);
			dynamic notFoundBody = JsonConvert.DeserializeObject<dynamic>(notFoundResponse.Response);
			Steps.AddTestStep("Not Found Response", notFoundResponse.Response);
			HPGWarn.True(notFoundBody.selfProvision == null || notFoundBody.selfProvision.Count == 0, field: "selfProvision[] empty");

			// Negative scenario: bad columnSort
			var badColumnSortRequest = new SelfProvisionRequestScope()
			{
				StatusTypeIds = new List<string> { "1" },
				Take = 10,
				Skip = 0,
				SearchFilter = "Charlie",
				ColumnSort = "BadColumnName",
				SortOrder = "asc"
			};
			var badColumnSortPayload = JsonConvert.SerializeObject(badColumnSortRequest);
			var badColumnSortResponse = PostSelfServiceRequest(PersonalScope, badColumnSortPayload);
			Steps.AddTestStep($"Sending 'POST' request to {PersonalScope} API endpoint with the following scenario: Bad ColumnSort - payload: {badColumnSortPayload}.",
			$"Systems should respond with a status code: '{badColumnSortResponse.Status}'.");

			HPGWarn.AreEqual(InternalServerResponse, badColumnSortResponse.Status, field: ResponseStatusField);
			Steps.AddTestStep("Bad ColumnSort Response", badColumnSortResponse.Response);
			dynamic badColumnSortBody = JsonConvert.DeserializeObject<dynamic>(badColumnSortResponse.Response);
			HPGWarn.Contains(badColumnSortBody?.ErrorDetails?.Message?.ToString(), "Invalid ColumnSort value: BadColumnName");

			// Negative scenario: bad sortOrder
			var badSortOrderRequest = new SelfProvisionRequestScope()
			{
				StatusTypeIds = new List<string> { "1" },
				Take = 10,
				Skip = 0,
				SearchFilter = "Charlie",
				ColumnSort = "firstName",
				SortOrder = "bad"
			};
			var badSortOrderPayload = JsonConvert.SerializeObject(badSortOrderRequest);
			var badSortOrderResponse = PostSelfServiceRequest(PersonalScope, badSortOrderPayload);
			Steps.AddTestStep($"Sending 'POST' request to {PersonalScope} API endpoint with the following scenario: Bad SortOrder - payload: {badSortOrderPayload}.",
			$"Systems should respond with a status code: '{badSortOrderResponse.Status}'.");

			HPGWarn.AreEqual(InternalServerResponse, badSortOrderResponse.Status, field: ResponseStatusField);
			Steps.AddTestStep("Bad SortOrder Response", badSortOrderResponse.Response);
			dynamic badSortOrderBody = JsonConvert.DeserializeObject<dynamic>(badSortOrderResponse.Response);
			HPGWarn.Contains(badSortOrderBody?.ErrorDetails?.Message?.ToString(), "Invalid SortOrder value: bad");
		}

		//Revert changes: assign sec admin role & remove read only role from service account
		Steps.AddTestStep("Reverting Service Account Roles after Self Provisioning Personal Scope Tests",
		"Restoring 'Security - Administrator' role and removing 'Security - VBO Support (Read Only)' role from the service account.");
		AssignSupportRole2ServiceAcct();
	}
	/// <summary>
	/// Tests the /api/SelfProvision/self-provision-request-details endpoint for both valid and invalid SelfProvisionId values.
	/// Verifies correct API responses and validates returned data against the database for different support roles.
	/// </summary>
	public void TestSelfProvisionRequestDetails()
	{
		Steps.AddTestStep("Test sending 'GET' SelfProvision request to " + RequestDetails + "API endpoint.", "System should respond accordingly.");

		//Declare a dictionary with roles: Security - VBO Request Approver, Security - VBO Support (Read Only)
		var supportRoles = new Dictionary<string, string>
		{
		{ "Security - VBO Request Approver", "D3C2E2C3-1F4C-4D1A-8C5D-0B8E3C6F7A9B" },
		{ "Security - VBO Support (Read Only)", "7F4E2A1B-3C4D-5E6F-7081-92A3B4C5D6E7" }
		};

		foreach (var role in supportRoles)
		{
			int invalidProvisionId = 999999999;
			Steps.AddTestStep($"Validating Support Role: {role.Value} in the system. Endpoint: personal-scope",
			$"Role: '{role.Key}' should exist in the system.");

			//remove sec admin role & assign read only role to service account 
			Steps.AddTestStep("Reconfiguring Service Account Roles for Self Provisioning Personal Scope Tests",
			"Removing 'Security - Administrator' role and assigning 'Security - VBO Support (Read Only)' role to the service account.");
			var provisionRequest = GetRandomProvisionRequest();
			AssignSupportRole2ServiceAcct(role.Key, role.Value);
			//create a list with invalid provision id & valid provision id and loop through it on the request.
			//Validate OkResponse for valid provision id and NotFound for invalid provision id
			var provisionIdsToTest = new List<int> { invalidProvisionId, provisionRequest.SelfProvisionId.ToInt() };
			foreach (var provisionId in provisionIdsToTest)
			{
				Steps.AddTestStep($"Sending 'GET' request to {RequestDetails} API endpoint with SelfProvisionId: {provisionId}.",
				$"Systems should respond accordingly.");
				var apiResponse = GetSelfServiceRequest($"{RequestDetails}?selfProvisionId={provisionId}");

				if (provisionId == invalidProvisionId)
				{
					HPGWarn.AreEqual(NotFoundResponse, apiResponse.Status, field: ResponseStatusField);
				}
				else
				{
					HPGWarn.AreEqual(OkResponse, apiResponse.Status, field: ResponseStatusField);
					Steps.AddTestStep("Valid ProvisionId Response Body", apiResponse.Response);
					var responseBody = JsonConvert.DeserializeObject<SelfProvisionRequestDetailsResponse>(apiResponse.Response);

					//Get ApprovalRequest from Db
					var expectedSelfProvision = selfServiceRepository.GetSelfProvisionRequestDetailsById(responseBody.SelfProvision.Id);
					var expectedFacilityVendorDetails = selfServiceRepository.GetSelfProvisionFacilityVendorDetails(responseBody.SelfProvision.Id);

					//verify responseBody.SelfProvision fields are not null
					ValidateSelfProvisionRequest(expectedSelfProvision, responseBody.SelfProvision);

					//ValidateSelfProvisionDetails(responsBody.SelfProvisionDetails)
					ValidateSelfProvisionDetailList(expectedFacilityVendorDetails, responseBody.SelfProvisionDetails);
				}
			}
			//Revert changes: assign sec admin role & remove read only role from service account
			Steps.AddTestStep("Reverting Service Account Roles after Self Provisioning Personal Scope Tests",
			"Restoring 'Security - Administrator' role and removing 'Security - VBO Support (Read Only)' role from the service account.");
			AssignSupportRole2ServiceAcct();

		}
	}
	//public void TestSelfProvisionApprovalRequestAction()
	//{
	
	//}

	#endregion TestMethods


	#region Helper Methods

	/// <summary>
	/// Executes the /users/claims API endpoint for a given user and role assignment.
	/// </summary> 
	/// <returns>HttpResponse from the claims API call.</returns>
	public HttpResponse AssignSupportRole2ServiceAcct(string roleDesc = "Security - Administrator", string roleKey = null)
	{
		var serviceAcctDetails = selfServiceRepository.GetServiceAcctUserKeySmartAppKeyRoleKeyDetails();
		var userName = serviceAcctDetails.Username;
		var userKey = serviceAcctDetails.UserKey.ToString();
		var secAppKey = serviceAcctDetails.ApiKey.ToString();
		
		var secAdminRole = "Security - Administrator";
		var secAdminRoleKey = "5BA8B90F-E086-46F2-9903-0EAA893FD674";
		
		var secReadOnlyRole = "Security - VBO Support (Read Only)";
		var secReadOnlyRoleKey = "B29D46C6-79B2-4BE5-992B-9B724DDB2A5B";
		
		var secRequestApprover = "Security - VBO Request Approver";
		var secRequestApproverKey = "75440062-1976-4B51-990A-8684C518447E";
		
		bool assignSecAdmin = true;
		bool assignRequestApprover = true;
		bool assignReadOnly = true;

		switch (roleDesc)
		{
			case "Security - VBO Support (Read Only)": 
				assignReadOnly = false;
				break;
			case "Security - VBO Request Approver":
				assignRequestApprover = false;
				break;
			default:
				assignSecAdmin = false;
				break;
		}

		var roleToAssign = roleDesc == null ? secAdminRole : roleDesc;
		string actionMessage;
		if (roleDesc != secAdminRole)
		{ 
			actionMessage = $"Removing 'Security - Administrator' role and assigning '{roleToAssign}' role to the service account: {userName}.";
		}
		else
		{
			actionMessage = $"Restoring 'Security - Administrator' role and removing '{roleToAssign}' role from the service account: {userName}.";
		}
		Steps.AddTestStep("Preparing to call /users/claims API endpoint to update service account roles.", actionMessage);

		var request = new AddUserRoleSoc
		{
			UserId = userKey,
			ApplicationId = secAppKey,
			IsDeactivated = false,
			RoleIds = new List<string?> { secAdminRoleKey, secReadOnlyRoleKey, secRequestApproverKey },
			Roles = new List<RoleDetail>
			{
			new RoleDetail
				{
				Id = secAdminRoleKey,
				Name = secAdminRole,
				IsDeleted = assignSecAdmin,
				UserType = "Employee"
				}
				,
			new RoleDetail
				{
				Id = secReadOnlyRoleKey,
				Name = secReadOnlyRole,
				IsDeleted = assignReadOnly,
				UserType = "Employee"
				}
				,
			new RoleDetail
				{
				Id = secRequestApproverKey,
				Name = secRequestApprover,
				IsDeleted = assignRequestApprover,
				UserType = "Employee"
				}
			},
			//include span of control here
			SpanOfControl = new List<SpanOfControl>
			{
			new SpanOfControl
				{
				HierarchyType = "0",
				ObjectId = "00001",
				OrgName = "HealthTrust",
				IsDeleted = false,
				IsVproFacility = null,
				VproFacilityName = null,
				VproFacilityCoid = null
				}
			},
			VproStatus = null,
			ByPassVPROEndDate = null,
			VPROUserEmailId = null,
			IsSmartSecurity = true,
			UserGcnGroups = new List<UserGcnGroup>()
			{
				new UserGcnGroup
				{
					GroupId = 0,
					GroupName = null,
					IsSelected = false
				}
			},

		};

		var payload = JsonConvert.SerializeObject(request, JsonNullSetting);
		//Declare a var formattedPayload to hold formatted json string for logging
		var formattedPayload = JsonConvert.SerializeObject(JsonConvert.DeserializeObject(payload), Formatting.Indented);
				Steps.AddTestStep($"Sending 'POST' request to {UserClaimsResource} API endpoint with the following payload: {formattedPayload}.",
				$"Systems should respond with a status code: '{OkResponse}'.");
		var response = PostSimpleRequest($"{BaseUri}{UserClaimsResource}", payload);
 
		Steps.AddTestStep("Service Account Role Update Response. Expected: True", response.Response);
		return response;
		//


	}
	
	///<summary>
	/// Retrieves a random self-provision request record from the database using the SelfProvisionRepository.
	/// This is typically used to obtain a sample or test record for use in self-provisioning API tests.
	/// </summary>
	public SelfProvisionRequest GetRandomProvisionRequest()
	{
		var randomRecord = selfServiceRepository.GetRandomSelfProvisionRequestRecord();
		return randomRecord;
	}

	/// <summary>
	/// Validates that all properties of the expected and actual SelfProvisionRequestDetails objects match.
	/// Adds test steps and asserts equality for each relevant field.
	/// </summary>
	public static void ValidateSelfProvisionRequest(SelfProvisionRequestDetails expected, SelfProvisionRequestDetails actual)
	{
		Steps.AddTestStep("Validating SelfProvisionRequestDetails Model", "Model should match.");
		Steps.AddTestStep("Validating expected object matches actual object.", "Should both match");

		HPGWarn.AreEqual(expected.Id.ToString(), actual.Id.ToString(), field: "Id");
		HPGWarn.AreEqual(expected.FirstName, actual.FirstName, field: "FirstName");
		HPGWarn.AreEqual(expected.LastName, actual.LastName, field: "LastName");
		HPGWarn.AreEqual(expected.Email, actual.Email, field: "Email");
		HPGWarn.AreEqual(expected.StatusTypeId, actual.StatusTypeId, field: "StatusTypeId");
		HPGWarn.AreEqual(expected.VproStatus, actual.VproStatus, field: "VproStatus");
		HPGWarn.AreEqual(expected.VproUserEmailId, actual.VproUserEmailId, field: "VproUserEmailId");
		HPGWarn.AreEqual(expected.CorrelationId.ToString(), actual.CorrelationId.ToString(), field: "CorrelationId");
		HPGWarn.AreEqual(expected.CreatedOn.ToString(), actual.CreatedOn.ToString(), field: "CreatedOn");
		HPGWarn.AreEqual(expected.CreatedBy.ToString(), actual.CreatedBy.ToString(), field: "CreatedBy");
	}

	/// <summary>
	/// Validates that each SelfProvisionDetail in the expected list matches a corresponding entry in the actual list and vice versa.
	/// Compares all relevant fields and logs warnings for any mismatches or missing entries.
	/// </summary>
	public static void ValidateSelfProvisionDetailList(List<SelfProvisionDetail> expectedList, List<SelfProvisionDetail> actualList, bool byPassSecondary = false)
	{
		Steps.AddTestStep("Validating SelfProvisionDetail Model List", "Model should match.");

		var actualListDict = actualList.ToDictionary(g => new { g.Id, g.SelfProvisionId, g.Recommendation });

		foreach (var expected in expectedList)
		{
			Steps.AddTestStep($"Validating SelfProvisionDetail with ID: {expected.Id} and SelfProvisionId: {expected.SelfProvisionId}", "Should match expected values.");
			if (actualListDict.TryGetValue(new { expected.Id, expected.SelfProvisionId, expected.Recommendation }, out var actual))
			{
				HPGWarn.AreEqual(expected.Description, actual.Description, field: "Description");
				HPGWarn.AreEqual(expected.Recommendation, actual.Recommendation, field: "Recommendation");
				HPGWarn.AreEqual(expected.StatusTypeId.ToString(), actual.StatusTypeId.ToString(), field: "StatusTypeId");
				HPGWarn.AreEqual(expected.Approve.ToString(), actual.Approve.ToString(), field: "Approve");
				HPGWarn.AreEqual(expected.Deny.ToString(), actual.Deny.ToString(), field: "Deny");
			}
			else
			{   //If this hits, check if the coid belongs to HeathTrust org tree in db
				HPGWarn.Warn($"No matching actual found for expected ID: '{expected.Id}', SelfProvisionId: '{expected.SelfProvisionId}'");
			}
		}

		//now check that actualList matches expectedList
		var expectedListDict = expectedList.ToDictionary(g => new { g.Id, g.SelfProvisionId, g.Recommendation });

		foreach (var actual in actualList)
		{
			Steps.AddTestStep($"Validating SelfProvisionDetail with ID: {actual.Id} and SelfProvisionId: {actual.SelfProvisionId}", "Should match expected values.");
			if (actualListDict.TryGetValue(new { actual.Id, actual.SelfProvisionId, actual.Recommendation }, out var expected))
			{
				HPGWarn.AreEqual(actual.Description, expected.Description, field: "Description");
				HPGWarn.AreEqual(actual.Recommendation, expected.Recommendation, field: "Recommendation");
				HPGWarn.AreEqual(actual.StatusTypeId.ToString(), expected.StatusTypeId.ToString(), field: "StatusTypeId");
				HPGWarn.AreEqual(actual.Approve.ToString(), expected.Approve.ToString(), field: "Approve");
				HPGWarn.AreEqual(actual.Deny.ToString(), expected.Deny.ToString(), field: "Deny");
			}
			else
			{
				HPGWarn.Warn($"No matching actual found for expected ID: '{actual.Id}', SelfProvisionId: '{actual.SelfProvisionId}'");
			}
		}
	}

	#endregion Helper Methods











}


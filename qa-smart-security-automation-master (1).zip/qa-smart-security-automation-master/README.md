# SMART Security Automation
This repository will test SMART Security Application from the front end UI and back end API.

## Dependencies
- Automation Core Lite (Hosted on HCA Nexus) 
- .NET 6+
- Selenium 4
- xUnit
- xUnit Runner Console
- xUnit Runner Utility
- xUnit Runner Visiual Studio
- xUnit Context

## Setup
A test.runesettings file is **required** and is **not included** in the repo. It will need to have the following environment variables be set in the file:
- Environment - Environment under test
- MailinatorAppKey - Application Key for mailinator API

Below is an example of the test.runsettings file:
```
<?xml version="1.0" encoding="utf-8" ?>
<RunSettings>
  <RunConfiguration>
    <EnvironmentVariables>
      <!-- List of environment variables we want to set-->
      <MailinatorAppKey>string</MailinatorAppKey>
      <Environment>qa</Environment>
    </EnvironmentVariables>
  </RunConfiguration>
</RunSettings>
```

To associate the test.runsettings file to the tests do the following in VS. Goto "Test" in the menu bar -> hover over "Configure Run Settings" -> select "Select Solution Wide runsettings File" -> select the test.runsettings file you created.

Ensure the test Security Users are created and setup in PASS for the specified environments. Use the securityUsers.\<env>.json in the SecurityUsers folder and SecurityUser object to identify the test security user used by the automation.

## SMART Security Additional Information
For additional information, please take a look at the Jupyter Notebook under the SMART Security Notebook. Information on Juypter Notebook: https://code.visualstudio.com/docs/datascience/jupyter-notebooks 
